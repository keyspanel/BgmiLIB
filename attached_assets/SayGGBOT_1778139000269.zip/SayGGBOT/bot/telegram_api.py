import io
import os
import logging
import qrcode
from bot.config import LOG_DIR

logger = logging.getLogger(__name__)


def generate_upi_qr(upi_string: str) -> io.BytesIO | None:
    try:
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=8,
            border=2,
        )
        qr.add_data(upi_string)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf
    except Exception as e:
        logger.error(f"QR generation failed: {e}")
        return None


def append_purchase_log(role: str, line: str):
    os.makedirs(LOG_DIR, exist_ok=True)
    filename = "ResellersPaid.txt" if role == "reseller" else "PaidUsers.txt"
    filepath = os.path.join(LOG_DIR, filename)
    try:
        with open(filepath, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        logger.error(f"Failed to write log: {e}")
