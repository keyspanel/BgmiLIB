import json
import logging
import urllib.error
import urllib.request
import urllib.parse
from datetime import datetime, timezone

from bot import database as db

logger = logging.getLogger(__name__)


def _apply_token(url: str, token: str = None) -> str:
    if not token:
        return url
    try:
        parsed = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs['token'] = [token]
        new_query = urllib.parse.urlencode(qs, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))
    except Exception:
        if '?' in url:
            import re
            cleaned = re.sub(r'([?&])token=[^&]*', '', url)
            sep = '&' if '?' in cleaned else '?'
            return cleaned + sep + f"token={urllib.parse.quote(token)}"
        return url + f"?token={urllib.parse.quote(token)}"


def build_api_url(base_url: str, game_value: str = None, duration_value: str = None,
                  device_value: str = None, currency_value: str = None,
                  token: str = None) -> str:
    if '?' in base_url:
        base, query = base_url.split('?', 1)
        if game_value:
            query = _replace_param(query, 'game', game_value)
        if duration_value:
            query = _replace_param(query, 'duration', duration_value)
        if device_value:
            query = _replace_param(query, 'max_devices', device_value)
        if currency_value:
            query = _replace_param(query, 'currency', currency_value)
        url = base + '?' + query
    else:
        params = []
        if game_value:
            params.append(f"game={urllib.parse.quote(game_value)}")
        if duration_value:
            params.append(f"duration={urllib.parse.quote(duration_value)}")
        if device_value:
            params.append(f"max_devices={urllib.parse.quote(device_value)}")
        if currency_value:
            params.append(f"currency={urllib.parse.quote(currency_value)}")
        if params:
            url = base_url + '?' + '&'.join(params)
        else:
            url = base_url
    return _apply_token(url, token)


def _replace_param(query: str, key: str, value: str) -> str:
    import re
    pattern = re.compile(rf'{re.escape(key)}=[^&]*')
    if pattern.search(query):
        return pattern.sub(f'{key}={urllib.parse.quote(value)}', query)
    else:
        return query + f'&{key}={urllib.parse.quote(value)}'


async def resolve_source(cat_id: int, dur_id: int) -> dict:
    rule = await db.fetch_one(
        """
        SELECT sr.*, ap.name AS provider_name, ap.base_url AS provider_base_url, ap.token AS provider_token, ap.is_active AS provider_is_active
        FROM source_rules sr
        LEFT JOIN api_providers ap ON ap.id = sr.api_provider_id
        WHERE sr.category_id = $1 AND sr.duration_id = $2
        LIMIT 1
        """,
        cat_id, dur_id
    )

    if not rule:
        return {"found": False, "reason": "no_source_rule"}

    rule = dict(rule)

    if not rule.get("is_active"):
        return {"found": False, "reason": "source_rule_inactive"}

    return {
        "found": True,
        "rule_id": rule["id"],
        "source_type": rule["source_type"],
        "api_provider_id": rule.get("api_provider_id"),
        "provider_name": rule.get("provider_name"),
        "provider_base_url": rule.get("provider_base_url"),
        "provider_token": rule.get("provider_token"),
        "provider_is_active": rule.get("provider_is_active"),
        "api_game_value": rule.get("api_game_value"),
        "api_duration_value": rule.get("api_duration_value"),
        "api_device_value": rule.get("api_device_value"),
        "api_currency_value": rule.get("api_currency_value"),
    }


_API_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (compatible; KeyStoreBot/1.0)',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
}


def _fetch_api_key_sync(final_url: str) -> dict:
    try:
        req = urllib.request.Request(final_url, method='GET', headers=_API_HEADERS)
        with urllib.request.urlopen(req, timeout=15) as resp:
            status_code = resp.getcode()
            raw_body = resp.read().decode()
    except urllib.error.HTTPError as e:
        body_snippet = ''
        try:
            body_snippet = e.read().decode()[:2000]
        except Exception:
            pass
        return {
            "error": f"api_request_failed: HTTP {e.code} {e.reason}",
            "raw_response": body_snippet,
            "http_status": e.code,
        }
    except Exception as e:
        return {"error": f"api_request_failed: {type(e).__name__}: {e}", "raw_response": None}

    return {"error": None, "raw_body": raw_body, "http_status": status_code}


def _parse_duration_hours(value: str) -> int | None:
    if not value:
        return None
    v = str(value).strip().lower()
    try:
        return int(v)
    except ValueError:
        pass
    import re
    m = re.match(r'^(\d+)\s*d$', v)
    if m:
        return int(m.group(1)) * 24
    m = re.match(r'^(\d+)\s*h$', v)
    if m:
        return int(m.group(1))
    return None


def _validate_api_key_object(key_obj: dict | None, source_info: dict) -> dict:
    if key_obj is None:
        return {"ok": True}

    returned_game = key_obj.get("game")
    expected_game = source_info.get("api_game_value")
    if expected_game and returned_game is not None:
        if str(returned_game).strip().lower() != str(expected_game).strip().lower():
            return {
                "ok": False,
                "reason": f"API fulfillment failed: returned game mismatch. Expected {expected_game}, got {returned_game}.",
            }

    returned_duration = key_obj.get("duration")
    expected_duration_raw = source_info.get("api_duration_value")
    if expected_duration_raw and returned_duration is not None:
        expected_hours = _parse_duration_hours(expected_duration_raw)
        try:
            returned_hours = int(returned_duration)
        except (TypeError, ValueError):
            returned_hours = None
        if expected_hours is not None and returned_hours is not None:
            if expected_hours != returned_hours:
                return {
                    "ok": False,
                    "reason": f"API fulfillment failed: returned duration mismatch. Expected {expected_hours}, got {returned_hours}.",
                }

    returned_devices = key_obj.get("max_devices")
    expected_devices_raw = source_info.get("api_device_value")
    if expected_devices_raw and returned_devices is not None:
        try:
            expected_devices = int(expected_devices_raw)
            returned_devices_int = int(returned_devices)
            if expected_devices != returned_devices_int:
                return {
                    "ok": False,
                    "reason": f"API fulfillment failed: returned max_devices mismatch. Expected {expected_devices}, got {returned_devices_int}.",
                }
        except (TypeError, ValueError):
            pass

    returned_status = key_obj.get("status")
    if returned_status is not None:
        try:
            s = int(returned_status)
            if s != 1:
                return {
                    "ok": False,
                    "reason": f"API fulfillment failed: returned key status {s} indicates unusable key.",
                }
        except (TypeError, ValueError):
            s_str = str(returned_status).lower()
            if s_str in ("inactive", "expired", "banned", "disabled"):
                return {
                    "ok": False,
                    "reason": f"API fulfillment failed: returned key status '{returned_status}' indicates unusable key.",
                }

    return {"ok": True}


async def fetch_api_key(source_info: dict, cat_id: int, dur_id: int, cat_name: str, dur_name: str) -> dict:
    import asyncio

    base_url = source_info.get("provider_base_url") or ""
    if not base_url:
        return {"success": False, "reason": "provider_base_url_missing"}

    if not source_info.get("provider_is_active"):
        return {"success": False, "reason": "provider_inactive"}

    game_val = source_info.get("api_game_value")
    dur_val = source_info.get("api_duration_value")
    device_val = source_info.get("api_device_value")
    currency_val = source_info.get("api_currency_value")
    token_val = source_info.get("provider_token")

    final_url = build_api_url(
        base_url,
        game_val,
        dur_val,
        device_val,
        currency_val,
        token=token_val,
    )

    logger.info(
        "fetch_api_key: cat=%s dur=%s provider=%s game=%s duration_map=%s devices=%s token_present=%s url=%s",
        cat_id, dur_id, source_info.get("provider_name"), game_val, dur_val, device_val,
        bool(token_val), final_url
    )

    loop = asyncio.get_event_loop()
    http_result = await loop.run_in_executor(None, _fetch_api_key_sync, final_url)

    if http_result.get("error"):
        logger.error(
            "fetch_api_key FAILED: cat=%s dur=%s provider=%s rule_id=%s http_status=%s err=%s url=%s response=%s",
            cat_id, dur_id, source_info.get("provider_name"), source_info.get("rule_id"),
            http_result.get("http_status"), http_result["error"], final_url,
            (http_result.get("raw_response") or "")[:500]
        )
        return {
            "success": False,
            "reason": http_result["error"],
            "request_url": final_url,
            "raw_response": http_result.get("raw_response"),
            "http_status": http_result.get("http_status"),
        }

    raw_body = http_result["raw_body"]

    try:
        parsed = json.loads(raw_body)
    except json.JSONDecodeError:
        logger.error("fetch_api_key: invalid JSON cat=%s dur=%s body=%s", cat_id, dur_id, raw_body[:500])
        return {
            "success": False,
            "reason": "invalid_json_response",
            "request_url": final_url,
            "raw_response": raw_body[:5000],
        }

    success_val = parsed.get("success")
    status_val = str(parsed.get("status", "")).lower()
    ok_val = parsed.get("ok")
    is_success = (
        success_val is True or
        success_val == 1 or
        str(success_val).lower() == "true" or
        status_val in ("success", "ok", "true", "1") or
        ok_val is True or
        ok_val == 1 or
        str(ok_val).lower() == "true"
    )

    if not is_success:
        logger.warning("fetch_api_key: api returned failure cat=%s dur=%s parsed=%s", cat_id, dur_id, str(parsed)[:500])
        return {
            "success": False,
            "reason": "api_returned_failure",
            "request_url": final_url,
            "raw_response": raw_body[:5000],
        }

    keys_list = None
    if isinstance(parsed.get("data"), dict):
        keys_list = parsed.get("keys") or parsed["data"].get("keys")
    else:
        keys_list = parsed.get("keys")
    single_key = parsed.get("key")

    key_obj = None
    key_value = None

    if keys_list and isinstance(keys_list, list) and len(keys_list) > 0:
        first_item = keys_list[0]
        if isinstance(first_item, dict):
            key_obj = first_item
            key_value = str(first_item.get("user_key", "")).strip()
        else:
            key_value = str(first_item).strip()
    elif single_key:
        if isinstance(single_key, dict):
            key_obj = single_key
            key_value = str(single_key.get("user_key", "")).strip()
        else:
            key_value = str(single_key).strip()

    if not key_value:
        logger.warning("fetch_api_key: no user_key in response cat=%s dur=%s parsed=%s", cat_id, dur_id, str(parsed)[:500])
        return {
            "success": False,
            "reason": "user_key missing or empty in API response",
            "request_url": final_url,
            "raw_response": raw_body[:5000],
        }

    validation = _validate_api_key_object(key_obj, source_info)
    if not validation["ok"]:
        logger.warning("fetch_api_key: validation failed cat=%s dur=%s reason=%s", cat_id, dur_id, validation["reason"])
        return {
            "success": False,
            "reason": validation["reason"],
            "request_url": final_url,
            "raw_response": raw_body[:5000],
        }

    logger.info("fetch_api_key: got key for cat=%s dur=%s key_len=%d", cat_id, dur_id, len(key_value))
    return {
        "success": True,
        "key_value": key_value,
        "request_url": final_url,
        "raw_response": raw_body[:5000],
    }


async def fulfill_paid_order(order_id: int) -> dict:
    import json as _json

    order = await db.fetch_one(
        """
        SELECT o.*, u.telegram_id, u.username, u.first_name,
               c.name AS live_category_name, d.name AS live_duration_name,
               d.category_id AS dur_cat_id
        FROM orders o
        JOIN users u ON u.id = o.user_id
        LEFT JOIN product_keys pk ON o.key_id = pk.id
        LEFT JOIN categories c ON COALESCE(pk.category_id, NULL) = c.id
        LEFT JOIN durations d ON COALESCE(pk.duration_id, NULL) = d.id
        WHERE o.id = $1
        LIMIT 1
        """,
        order_id
    )
    if not order:
        return {"success": False, "reason": "order_not_found"}

    order = dict(order)

    if order.get("fulfillment_status") == "fulfilled":
        return {"success": True, "already_fulfilled": True, "key_value": order.get("purchased_key_value", "")}

    snapshot_raw = order.get("source_rule_snapshot")
    if not snapshot_raw:
        source_info_live = await resolve_source_from_order(order)
        if not source_info_live:
            await _mark_fulfillment_failed(order_id, "no_source_rule_and_no_snapshot")
            return {"success": False, "reason": "no_source_rule_and_no_snapshot"}
        snapshot = source_info_live
    else:
        try:
            snapshot = _json.loads(snapshot_raw)
        except Exception:
            await _mark_fulfillment_failed(order_id, "invalid_source_snapshot")
            return {"success": False, "reason": "invalid_source_snapshot"}

    source_type = snapshot.get("source_type", "manual")
    cat_name = str(order.get("purchased_category_name") or order.get("live_category_name") or "Unknown")
    dur_name = str(order.get("purchased_duration_name") or order.get("live_duration_name") or "Unknown")
    provider_name = snapshot.get("provider_name") or ""

    cat_id = snapshot.get("category_id")
    dur_id = snapshot.get("duration_id")
    if not cat_id or not dur_id:
        cat_id, dur_id = await _resolve_cat_dur_from_order(order)
    if not cat_id or not dur_id:
        await _mark_fulfillment_failed(order_id, "cannot_determine_category_duration")
        return {"success": False, "reason": "cannot_determine_category_duration"}

    await db.execute(
        "UPDATE orders SET fulfillment_attempted_at = NOW() WHERE id = $1",
        order_id
    )

    if source_type == "manual":
        return await _fulfill_manual(order_id, cat_id, dur_id, cat_name, dur_name, snapshot)

    if source_type == "api":
        return await _fulfill_api_only(order_id, cat_id, dur_id, cat_name, dur_name, snapshot)

    if source_type == "api_and_manual":
        return await _fulfill_api_and_manual(order_id, cat_id, dur_id, cat_name, dur_name, snapshot)

    await _mark_fulfillment_failed(order_id, f"unknown_source_type: {source_type}")
    return {"success": False, "reason": f"unknown_source_type: {source_type}"}


async def _resolve_cat_dur_from_order(order: dict) -> tuple:
    cat_name = order.get("purchased_category_name") or ""
    dur_name = order.get("purchased_duration_name") or ""

    if cat_name and dur_name:
        row = await db.fetch_one(
            """
            SELECT d.id AS dur_id, d.category_id AS cat_id
            FROM durations d
            JOIN categories c ON c.id = d.category_id
            WHERE c.name = $1 AND d.name = $2
            LIMIT 1
            """,
            cat_name, dur_name
        )
        if row:
            return (row["cat_id"], row["dur_id"])

    if order.get("key_id"):
        row = await db.fetch_one(
            "SELECT category_id, duration_id FROM product_keys WHERE id = $1",
            order["key_id"]
        )
        if row:
            return (row["category_id"], row["duration_id"])

    return (None, None)


async def resolve_source_from_order(order: dict) -> dict | None:
    cat_id, dur_id = await _resolve_cat_dur_from_order(order)
    if not cat_id or not dur_id:
        return None
    info = await resolve_source(cat_id, dur_id)
    if not info.get("found"):
        return None
    return {
        "source_type": info["source_type"],
        "rule_id": info.get("rule_id"),
        "category_id": cat_id,
        "duration_id": dur_id,
        "api_provider_id": info.get("api_provider_id"),
        "provider_name": info.get("provider_name"),
        "provider_base_url": info.get("provider_base_url"),
        "provider_token": info.get("provider_token"),
        "provider_is_active": info.get("provider_is_active"),
        "api_game_value": info.get("api_game_value"),
        "api_duration_value": info.get("api_duration_value"),
        "api_device_value": info.get("api_device_value"),
        "api_currency_value": info.get("api_currency_value"),
    }


async def _fulfill_manual(order_id: int, cat_id: int, dur_id: int,
                           cat_name: str, dur_name: str, snapshot: dict) -> dict:
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            key_row = await conn.fetchrow(
                """
                SELECT id, key_value FROM product_keys
                WHERE category_id = $1 AND duration_id = $2 AND is_sold = 0
                ORDER BY id ASC LIMIT 1 FOR UPDATE
                """,
                cat_id, dur_id
            )
            if not key_row:
                await _mark_fulfillment_failed(order_id, "no_manual_stock", conn=conn)
                await log_fulfillment(
                    order_id=order_id, category_id=cat_id, duration_id=dur_id,
                    category_name=cat_name, duration_name=dur_name,
                    source_type="manual", resolution_success=True, delivery_success=False,
                    failure_reason="no_manual_stock",
                )
                return {
                    "success": False,
                    "reason": "No manual keys available",
                    "source_type": "manual",
                    "provider_name": "",
                    "cat_name": cat_name,
                    "dur_name": dur_name,
                    "needs_alert": True,
                    "snapshot": snapshot,
                }

            key_value = str(key_row["key_value"])
            await conn.execute("UPDATE product_keys SET is_sold = 1 WHERE id = $1", key_row["id"])
            await conn.execute(
                """
                UPDATE orders
                SET key_id = $1, purchased_key_value = $2,
                    fulfillment_status = 'fulfilled', fulfilled_at = NOW(),
                    delivered_source = 'manual', fallback_used = false
                WHERE id = $3
                """,
                key_row["id"], key_value, order_id
            )

    await log_fulfillment(
        order_id=order_id, category_id=cat_id, duration_id=dur_id,
        category_name=cat_name, duration_name=dur_name,
        source_type="manual", resolution_success=True, delivery_success=True,
        key_value=key_value,
    )
    return {"success": True, "key_value": key_value, "delivered_source": "manual", "fallback_used": False}


async def _fulfill_api_only(order_id: int, cat_id: int, dur_id: int,
                              cat_name: str, dur_name: str, snapshot: dict) -> dict:
    api_result = await fetch_api_key(snapshot, cat_id, dur_id, cat_name, dur_name)

    if api_result["success"]:
        key_value = api_result["key_value"]
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                key_id = await conn.fetchval(
                    """
                    INSERT INTO product_keys (category_id, duration_id, key_value, price, is_sold)
                    VALUES ($1, $2, $3, 0, 1) RETURNING id
                    """,
                    cat_id, dur_id, key_value
                )
                await conn.execute(
                    """
                    UPDATE orders
                    SET key_id = $1, purchased_key_value = $2,
                        fulfillment_status = 'fulfilled', fulfilled_at = NOW(),
                        delivered_source = 'api', fallback_used = false,
                        provider_response_meta = $3
                    WHERE id = $4
                    """,
                    key_id, key_value,
                    (api_result.get("raw_response") or "")[:5000],
                    order_id
                )

        await log_fulfillment(
            order_id=order_id, category_id=cat_id, duration_id=dur_id,
            category_name=cat_name, duration_name=dur_name,
            source_type="api",
            provider_id=snapshot.get("api_provider_id"),
            provider_name=snapshot.get("provider_name"),
            resolution_success=True, delivery_success=True,
            key_value=key_value,
            api_request_url=api_result.get("request_url"),
            api_raw_response=api_result.get("raw_response"),
        )
        return {"success": True, "key_value": key_value, "delivered_source": "api", "fallback_used": False}

    reason = api_result.get("reason", "api_failure")
    await _mark_fulfillment_failed(
        order_id, reason,
        provider_meta=(api_result.get("raw_response") or "")[:5000],
    )
    await log_fulfillment(
        order_id=order_id, category_id=cat_id, duration_id=dur_id,
        category_name=cat_name, duration_name=dur_name,
        source_type="api",
        provider_id=snapshot.get("api_provider_id"),
        provider_name=snapshot.get("provider_name"),
        resolution_success=True, delivery_success=False,
        api_request_url=api_result.get("request_url"),
        api_raw_response=api_result.get("raw_response"),
        failure_reason=reason,
    )
    return {
        "success": False,
        "reason": reason,
        "source_type": "api",
        "provider_name": snapshot.get("provider_name", ""),
        "cat_name": cat_name,
        "dur_name": dur_name,
        "needs_alert": True,
        "http_status": api_result.get("http_status"),
        "request_url": api_result.get("request_url"),
        "response_snippet": (api_result.get("raw_response") or "")[:200],
        "snapshot": snapshot,
    }


async def _fulfill_api_and_manual(order_id: int, cat_id: int, dur_id: int,
                                     cat_name: str, dur_name: str, snapshot: dict) -> dict:
    api_result = await fetch_api_key(snapshot, cat_id, dur_id, cat_name, dur_name)

    if api_result["success"]:
        key_value = api_result["key_value"]
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                key_id = await conn.fetchval(
                    """
                    INSERT INTO product_keys (category_id, duration_id, key_value, price, is_sold)
                    VALUES ($1, $2, $3, 0, 1) RETURNING id
                    """,
                    cat_id, dur_id, key_value
                )
                await conn.execute(
                    """
                    UPDATE orders
                    SET key_id = $1, purchased_key_value = $2,
                        fulfillment_status = 'fulfilled', fulfilled_at = NOW(),
                        delivered_source = 'api', fallback_used = false,
                        provider_response_meta = $3
                    WHERE id = $4
                    """,
                    key_id, key_value,
                    (api_result.get("raw_response") or "")[:5000],
                    order_id
                )
        await log_fulfillment(
            order_id=order_id, category_id=cat_id, duration_id=dur_id,
            category_name=cat_name, duration_name=dur_name,
            source_type="api_and_manual",
            provider_id=snapshot.get("api_provider_id"),
            provider_name=snapshot.get("provider_name"),
            resolution_success=True, delivery_success=True,
            key_value=key_value,
            api_request_url=api_result.get("request_url"),
            api_raw_response=api_result.get("raw_response"),
        )
        return {"success": True, "key_value": key_value, "delivered_source": "api", "fallback_used": False}

    api_reason = api_result.get("reason", "api_failure")
    logger.warning("fulfill_api_and_manual: API failed for order=%s reason=%s, trying manual fallback", order_id, api_reason)

    async with db.pool.acquire() as conn:
        async with conn.transaction():
            key_row = await conn.fetchrow(
                """
                SELECT id, key_value FROM product_keys
                WHERE category_id = $1 AND duration_id = $2 AND is_sold = 0
                ORDER BY id ASC LIMIT 1 FOR UPDATE
                """,
                cat_id, dur_id
            )
            if key_row:
                key_value = str(key_row["key_value"])
                await conn.execute("UPDATE product_keys SET is_sold = 1 WHERE id = $1", key_row["id"])
                await conn.execute(
                    """
                    UPDATE orders
                    SET key_id = $1, purchased_key_value = $2,
                        fulfillment_status = 'fulfilled', fulfilled_at = NOW(),
                        delivered_source = 'manual_fallback', fallback_used = true,
                        fulfillment_error = $3
                    WHERE id = $4
                    """,
                    key_row["id"], key_value,
                    f"API failed: {api_reason}",
                    order_id
                )
                await log_fulfillment(
                    order_id=order_id, category_id=cat_id, duration_id=dur_id,
                    category_name=cat_name, duration_name=dur_name,
                    source_type="api_and_manual",
                    provider_id=snapshot.get("api_provider_id"),
                    provider_name=snapshot.get("provider_name"),
                    resolution_success=True, delivery_success=True,
                    key_value=key_value,
                    api_request_url=api_result.get("request_url"),
                    api_raw_response=api_result.get("raw_response"),
                    failure_reason=f"API failed ({api_reason}), manual fallback used",
                )
                return {"success": True, "key_value": key_value, "delivered_source": "manual_fallback", "fallback_used": True}

    full_reason = f"API failed: {api_reason}, and no manual fallback key available"
    await _mark_fulfillment_failed(
        order_id, full_reason,
        provider_meta=(api_result.get("raw_response") or "")[:5000],
    )
    await log_fulfillment(
        order_id=order_id, category_id=cat_id, duration_id=dur_id,
        category_name=cat_name, duration_name=dur_name,
        source_type="api_and_manual",
        provider_id=snapshot.get("api_provider_id"),
        provider_name=snapshot.get("provider_name"),
        resolution_success=True, delivery_success=False,
        api_request_url=api_result.get("request_url"),
        api_raw_response=api_result.get("raw_response"),
        failure_reason=full_reason,
    )
    return {
        "success": False,
        "reason": full_reason,
        "source_type": "api_and_manual",
        "provider_name": snapshot.get("provider_name", ""),
        "cat_name": cat_name,
        "dur_name": dur_name,
        "needs_alert": True,
        "manual_fallback_attempted": True,
        "http_status": api_result.get("http_status"),
        "request_url": api_result.get("request_url"),
        "response_snippet": (api_result.get("raw_response") or "")[:200],
        "snapshot": snapshot,
    }


async def _mark_fulfillment_failed(order_id: int, reason: str, conn=None, provider_meta: str = None):
    sql = """
        UPDATE orders
        SET fulfillment_status = 'fulfillment_failed',
            fulfillment_error = $1,
            provider_response_meta = COALESCE($2, provider_response_meta)
        WHERE id = $3
    """
    if conn:
        await conn.execute(sql, reason, provider_meta, order_id)
    else:
        await db.execute(sql, reason, provider_meta, order_id)


async def create_fulfillment_issue(order_id: int, user_row: dict, result: dict) -> int | None:
    try:
        snapshot = result.get("snapshot") or {}
        row = await db.fetch_one(
            """INSERT INTO fulfillment_issues
                (order_id, user_id, category_id, duration_id, source_rule_id,
                 provider_id, source_type, failure_reason, failure_code, payload_snapshot)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
               ON CONFLICT DO NOTHING
               RETURNING id""",
            order_id,
            user_row.get("id"),
            snapshot.get("category_id"),
            snapshot.get("duration_id"),
            snapshot.get("rule_id"),
            snapshot.get("api_provider_id"),
            result.get("source_type", "unknown"),
            result.get("reason", "Unknown"),
            result.get("failure_code"),
            json.dumps({
                "cat_name": result.get("cat_name"),
                "dur_name": result.get("dur_name"),
                "provider_name": result.get("provider_name"),
                "http_status": result.get("http_status"),
                "request_url": result.get("request_url"),
                "response_snippet": result.get("response_snippet"),
                "manual_fallback_attempted": result.get("manual_fallback_attempted"),
            }),
        )
        issue_id = row["id"] if row else None
        if issue_id:
            logger.info("create_fulfillment_issue: created issue_id=%s for order_id=%s", issue_id, order_id)
        return issue_id
    except Exception as e:
        logger.error("create_fulfillment_issue: failed for order_id=%s: %s", order_id, e)
        return None


async def send_owner_fulfillment_alert(bot, order_id: int, user_row: dict,
                                        result: dict):
    from bot.config import ADMIN_CHAT_ID
    if not ADMIN_CHAT_ID:
        logger.warning("send_owner_fulfillment_alert: ADMIN_CHAT_ID not set, skipping alert")
        return

    issue_id = await create_fulfillment_issue(order_id, user_row, result)

    source_type = result.get("source_type", "unknown")
    source_labels = {"manual": "Manual Only", "api": "API Only", "api_and_manual": "API & Manual"}
    source_label = source_labels.get(source_type, source_type)

    username = user_row.get("username") or ""
    user_label = f"@{username}" if username else f"UserID {user_row.get('telegram_id', '?')}"

    lines = [
        "🚨 <b>Fulfillment Failed</b>",
    ]
    if issue_id:
        lines.append(f"Issue ID: {issue_id}")
    lines.extend([
        f"Order ID: {order_id}",
        f"User: {user_label}",
        f"Category: {result.get('cat_name', 'Unknown')}",
        f"Duration: {result.get('dur_name', 'Unknown')}",
        f"Source Type: {source_label}",
    ])
    if result.get("provider_name"):
        lines.append(f"Provider: {result['provider_name']}")
    reason = result.get('reason', 'Unknown error')
    lines.append(f"Reason: {reason}")
    if result.get("http_status"):
        lines.append(f"HTTP Status: {result['http_status']}")
    if result.get("request_url"):
        lines.append(f"Request URL: <code>{result['request_url'][:300]}</code>")
    if result.get("response_snippet"):
        lines.append(f"Response: <code>{result['response_snippet'][:200]}</code>")

    if result.get("manual_fallback_attempted"):
        lines.append("Manual Fallback: Attempted — Failed (no stock)")

    lines.append("\n📋 <i>Check Source Config → Issues tab to recover</i>")

    alert_text = "\n".join(lines)

    try:
        await bot.send_message(chat_id=ADMIN_CHAT_ID, text=alert_text, parse_mode="HTML")
        await db.execute("UPDATE orders SET owner_alert_sent_at = NOW() WHERE id = $1", order_id)
    except Exception:
        logger.exception("send_owner_fulfillment_alert: failed for order_id=%s", order_id)


async def log_fulfillment(
    order_id: int = None,
    category_id: int = None,
    duration_id: int = None,
    category_name: str = None,
    duration_name: str = None,
    source_type: str = None,
    provider_id: int = None,
    provider_name: str = None,
    resolution_success: bool = False,
    delivery_success: bool = False,
    key_value: str = None,
    api_request_url: str = None,
    api_raw_response: str = None,
    failure_reason: str = None,
):
    try:
        await db.execute(
            """
            INSERT INTO source_fulfillment_logs
                (order_id, category_id, duration_id, category_name, duration_name,
                 source_type, provider_id, provider_name,
                 resolution_success, delivery_success,
                 key_value, api_request_url, api_raw_response, failure_reason)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
            """,
            order_id, category_id, duration_id, category_name, duration_name,
            source_type, provider_id, provider_name,
            resolution_success, delivery_success,
            key_value, api_request_url,
            (api_raw_response or "")[:5000] if api_raw_response else None,
            failure_reason,
        )
    except Exception as e:
        logger.error("log_fulfillment: failed to log: %s", e)
