import logging
from datetime import datetime, timezone, timedelta
from bot import database as db

logger = logging.getLogger(__name__)

_SYNC_COOLDOWN = timedelta(minutes=30)


async def sync_profile_photo(bot, telegram_id: int, user_db_id: int, force: bool = False):
    try:
        if not force:
            row = await db.fetch_one(
                "SELECT profile_photo_updated_at FROM users WHERE id = $1 LIMIT 1",
                user_db_id,
            )
            if row and row.get("profile_photo_updated_at"):
                last = row["profile_photo_updated_at"]
                if hasattr(last, 'tzinfo') and last.tzinfo is None:
                    last = last.replace(tzinfo=timezone.utc)
                if (datetime.now(timezone.utc) - last) < _SYNC_COOLDOWN:
                    return

        photos = await bot.get_user_profile_photos(telegram_id, limit=1)
        if not photos or not photos.photos:
            await db.execute(
                "UPDATE users SET profile_photo_url = NULL, profile_photo_file_id = NULL, profile_photo_updated_at = NOW() WHERE id = $1",
                user_db_id,
            )
            return

        best = photos.photos[0][-1]
        file_id = best.file_id

        current = await db.fetch_val(
            "SELECT profile_photo_file_id FROM users WHERE id = $1", user_db_id
        )
        if current == file_id:
            await db.execute(
                "UPDATE users SET profile_photo_updated_at = NOW() WHERE id = $1",
                user_db_id,
            )
            return

        tg_file = await bot.get_file(file_id)
        file_path = tg_file.file_path

        await db.execute(
            "UPDATE users SET profile_photo_url = $1, profile_photo_file_id = $2, profile_photo_updated_at = NOW() WHERE id = $3",
            file_path,
            file_id,
            user_db_id,
        )
        logger.debug("Profile photo updated for user %s", telegram_id)
    except Exception as e:
        logger.warning("Failed to sync profile photo for user %s: %s", telegram_id, e)
