import logging
from datetime import datetime, timezone
from bot import database as db

logger = logging.getLogger(__name__)

_active_plan_cache = None
_active_rules_cache = None
_cache_loaded_at = None
_cache_version = None
_CACHE_TTL_SECONDS = 30


async def _get_db_cache_version():
    try:
        row = await db.fetch_one(
            "SELECT value FROM bot_settings WHERE key = '_discount_cache_version' LIMIT 1"
        )
        return row["value"] if row else None
    except Exception:
        return None


async def _load_active_plan():
    global _active_plan_cache, _active_rules_cache, _cache_loaded_at, _cache_version

    now = datetime.now(timezone.utc)

    if _cache_loaded_at and (now - _cache_loaded_at).total_seconds() < _CACHE_TTL_SECONDS:
        db_version = await _get_db_cache_version()
        if db_version is not None and db_version != _cache_version:
            logger.info("Discount cache invalidated by admin (version changed: %s -> %s)", _cache_version, db_version)
        else:
            return _active_plan_cache, _active_rules_cache

    plan = await db.fetch_one(
        """SELECT * FROM discount_plans
           WHERE is_active = true
           ORDER BY id DESC LIMIT 1"""
    )

    db_version = await _get_db_cache_version()
    _cache_version = db_version

    if not plan:
        _active_plan_cache = None
        _active_rules_cache = []
        _cache_loaded_at = now
        return None, []

    plan = dict(plan)

    if plan.get("starts_at"):
        sa = plan["starts_at"]
        if hasattr(sa, 'tzinfo') and sa.tzinfo is None:
            sa = sa.replace(tzinfo=timezone.utc)
        if sa > now:
            _active_plan_cache = None
            _active_rules_cache = []
            _cache_loaded_at = now
            return None, []

    if plan.get("expires_at"):
        exp = plan["expires_at"]
        if hasattr(exp, 'tzinfo') and exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp < now:
            _active_plan_cache = None
            _active_rules_cache = []
            _cache_loaded_at = now
            return None, []

    rules = await db.fetch_all(
        "SELECT * FROM discount_rules WHERE plan_id = $1 ORDER BY id ASC",
        plan["id"]
    )
    rules = [dict(r) for r in rules]

    _active_plan_cache = plan
    _active_rules_cache = rules
    _cache_loaded_at = now
    return plan, rules


def invalidate_cache():
    global _active_plan_cache, _active_rules_cache, _cache_loaded_at, _cache_version
    _active_plan_cache = None
    _active_rules_cache = None
    _cache_loaded_at = None
    _cache_version = None


async def get_active_discount_plan():
    plan, _ = await _load_active_plan()
    return plan


async def is_discount_valid_now() -> bool:
    plan = await get_active_discount_plan()
    return plan is not None


async def resolve_user_discount_price(duration_id: int, category_id: int, base_price: float) -> float | None:
    result = await resolve_user_discount_with_plan(duration_id, category_id, base_price)
    if result is None:
        return None
    return result["price"]


async def resolve_user_discount_with_plan(duration_id: int, category_id: int, base_price: float) -> dict | None:
    plan, rules = await _load_active_plan()
    if not plan or not rules:
        return None

    scope = plan.get("apply_scope", "all_categories")

    best_rule = None

    if scope == "all_categories":
        for r in rules:
            if r.get("category_id") is None and r.get("duration_id") is None:
                best_rule = r
                break
            if r.get("category_id") is None and r.get("duration_id") == duration_id:
                best_rule = r
                break

    elif scope == "one_category":
        target_cat = None
        for r in rules:
            if r.get("category_id"):
                target_cat = r["category_id"]
                break
        if target_cat and target_cat != category_id:
            return None
        for r in rules:
            if r.get("duration_id") == duration_id:
                best_rule = r
                break
        if not best_rule:
            for r in rules:
                if r.get("duration_id") is None:
                    best_rule = r
                    break

    elif scope == "per_categories":
        for r in rules:
            if r.get("category_id") == category_id and r.get("duration_id") == duration_id:
                best_rule = r
                break
        if not best_rule:
            for r in rules:
                if r.get("category_id") == category_id and r.get("duration_id") is None:
                    best_rule = r
                    break

    elif scope == "per_category_duration_prices":
        for r in rules:
            if r.get("category_id") == category_id and r.get("duration_id") == duration_id:
                best_rule = r
                break
        if not best_rule:
            for r in rules:
                if r.get("category_id") == category_id and r.get("duration_id") is None:
                    best_rule = r
                    break
        if not best_rule:
            for r in rules:
                if r.get("category_id") is None and r.get("duration_id") is None:
                    best_rule = r
                    break

    if not best_rule:
        return None

    price = _apply_rule(best_rule, base_price)
    return {
        "price": price,
        "plan_id": plan.get("id"),
        "plan_name": plan.get("name"),
    }


def _apply_rule(rule: dict, base_price: float) -> float:
    if rule.get("override_price") is not None:
        return max(0.0, float(rule["override_price"]))

    dt = rule.get("discount_type") or ""
    dv = float(rule.get("discount_value") or 0)

    if dt == "percent":
        return max(0.0, base_price - (base_price * dv / 100))
    elif dt == "fixed":
        return max(0.0, base_price - dv)

    return base_price
