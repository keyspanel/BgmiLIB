import re
import logging
from html import escape
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
from bot import database as db
from bot import settings
from bot.services.reseller import get_final_duration_price, get_pricing_details
from bot.cleanup import (
    safe_delete_message,
    save_user_category_message_id,
    clear_user_category_message_id,
    save_user_durations_message_id,
)

logger = logging.getLogger(__name__)

STYLE_MAP = {
    1: "default",
    2: "primary",
    3: "success",
    4: "danger",
}

VALID_STYLES = set(STYLE_MAP.values())


def get_telegram_style(button_style) -> str | None:
    if not button_style:
        return None
    s = str(button_style).strip()
    if not s:
        return None
    # Accept style name strings directly (e.g. "primary", "danger" from Force Join page)
    if s in VALID_STYLES:
        return s
    # Accept numeric style codes (e.g. "2", "4" from Bot Settings page)
    try:
        return STYLE_MAP.get(int(s))
    except (TypeError, ValueError):
        return None


def extract_custom_emoji_and_clean_name(raw: str) -> dict:
    raw = raw.strip()
    emoji_id = None

    match = re.search(r'\{(\d{5,32})\}', raw)
    if match:
        emoji_id = match.group(1)
        raw = re.sub(r'\{\d{5,32}\}', '', raw)

    clean_name = re.sub(r'\s+', ' ', raw).strip()
    return {"name": clean_name, "emoji_id": emoji_id}


def build_inline_button(text: str, callback_data: str, button_style=None, emoji_id: str | None = None) -> InlineKeyboardButton:
    kwargs = {}
    style = get_telegram_style(button_style)
    if style:
        kwargs["style"] = style
    if emoji_id:
        kwargs["icon_custom_emoji_id"] = emoji_id
    return InlineKeyboardButton(
        text=text,
        callback_data=callback_data,
        api_kwargs=kwargs if kwargs else None,
    )


def _fmt_price(p: float) -> str:
    return str(int(p)) if p == int(p) else f"{p:.2f}"


def _discount_btn_text(dur_name: str, currency: str, final: float, original: float) -> str:
    savings_pct = int(round((1 - final / original) * 100)) if original > 0 else 0
    pct_tag = f" (-{savings_pct}%)" if savings_pct > 0 else ""
    return f"{dur_name} \u2022 {currency}{_fmt_price(final)}{pct_tag}  was {currency}{_fmt_price(original)}"


async def send_categories(bot: Bot, chat_id: int) -> dict | None:
    cats = await db.fetch_all(
        """SELECT c.id, c.name, c.button_style
           FROM categories c
           WHERE c.is_hidden = 0
             AND EXISTS (
                 SELECT 1 FROM durations d
                 WHERE d.category_id = c.id
                   AND d.is_hidden = 0
                   AND (
                     EXISTS (
                       SELECT 1 FROM product_keys pk
                       WHERE pk.duration_id = d.id AND pk.is_sold = 0
                     )
                     OR EXISTS (
                       SELECT 1 FROM source_rules sr
                       JOIN api_providers ap ON ap.id = sr.api_provider_id
                       WHERE sr.category_id = c.id
                         AND sr.duration_id = d.id
                         AND sr.source_type IN ('api', 'api_and_manual')
                         AND sr.is_active = true
                         AND ap.is_active = true
                     )
                   )
                 LIMIT 1
             )
           ORDER BY c.sort_order ASC, c.id ASC"""
    )

    if not cats:
        store_empty = settings.get_resolved("bot_store_empty")
        title = settings.get("msg_store_unavailable_title")
        msg = await bot.send_message(
            chat_id=chat_id,
            text=f"{title}\n\n{store_empty}",
            parse_mode="HTML"
        )
        return {"ok": True, "message_id": msg.message_id}

    buttons = []
    for c in cats:
        parsed = extract_custom_emoji_and_clean_name(c["name"])
        visible_name = parsed["name"] or "Category"
        btn = build_inline_button(
            text=visible_name,
            callback_data=f"cat_{c['id']}",
            button_style=c.get("button_style"),
            emoji_id=parsed["emoji_id"],
        )
        buttons.append([btn])

    header_values = {
        "store_title_raw": settings.get_resolved("bot_store_title"),
        "store_subtitle_raw": settings.get_resolved("bot_store_subtitle"),
        "categories_footer_raw": settings.get_resolved("msg_categories_footer"),
    }
    text = settings.fmt("tpl_store_header", header_values)

    msg = await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=InlineKeyboardMarkup(buttons),
        parse_mode="HTML"
    )
    return {"ok": True, "message_id": msg.message_id}


async def send_durations(bot: Bot, chat_id: int, message_id: int, cat_id: int, user_row: dict) -> dict:
    category = await db.fetch_one(
        "SELECT name, file_id FROM categories WHERE id = $1 AND is_hidden = 0 LIMIT 1",
        cat_id
    )
    if not category:
        await safe_delete_message(bot, chat_id, message_id)
        await clear_user_category_message_id(user_row["id"])
        return {"ok": False, "reason": "invalid_category"}

    parsed_cat = extract_custom_emoji_and_clean_name(category["name"])
    cat_visible = parsed_cat["name"] or "Category"

    durs = await db.fetch_all(
        """SELECT d.id, d.name, d.button_style, d.price
           FROM durations d
           WHERE d.category_id = $1
             AND d.is_hidden = 0
             AND (
               EXISTS (
                 SELECT 1 FROM product_keys pk
                 WHERE pk.duration_id = d.id AND pk.is_sold = 0
               )
               OR EXISTS (
                 SELECT 1 FROM source_rules sr
                 JOIN api_providers ap ON ap.id = sr.api_provider_id
                 WHERE sr.category_id = $1
                   AND sr.duration_id = d.id
                   AND sr.source_type IN ('api', 'api_and_manual')
                   AND sr.is_active = true
                   AND ap.is_active = true
               )
             )
           ORDER BY d.sort_order ASC, d.id ASC""",
        cat_id
    )
    if not durs:
        await safe_delete_message(bot, chat_id, message_id)
        await clear_user_category_message_id(user_row["id"])
        return {"ok": False, "reason": "no_durations"}

    discount_plan_id = 0
    discount_plan_name = ""
    is_reseller = bool(user_row.get("reseller_id"))
    if not is_reseller:
        from bot.services.user_discount import get_active_discount_plan
        active_plan = await get_active_discount_plan()
        if active_plan:
            discount_plan_id = active_plan["id"]
            discount_plan_name = active_plan.get("name", "")

    currency = settings.get("currency_symbol")
    has_any_discount = False
    buttons = []
    for d in durs:
        dur_base_price = float(d.get("price") or 0)
        details = await get_pricing_details(d["id"], cat_id, user_row, base_price=dur_base_price)
        final_price = details["final_price"]
        base_price = details["base_price"]
        is_discounted = details["pricing_source"] == "user_discount" and base_price != final_price

        parsed_dur = extract_custom_emoji_and_clean_name(d["name"])
        dur_visible = parsed_dur["name"] or "Duration"

        if is_discounted:
            has_any_discount = True
            btn_text = _discount_btn_text(dur_visible, currency, final_price, base_price)
        else:
            btn_text = f"{dur_visible} [ {currency}{_fmt_price(final_price)} ]"

        cb_data = f"buy_{cat_id}_{d['id']}_{discount_plan_id}"
        btn = build_inline_button(
            text=btn_text,
            callback_data=cb_data,
            button_style=d.get("button_style"),
            emoji_id=parsed_dur["emoji_id"],
        )
        buttons.append([btn])

    cat_link_btns_raw = settings.get_category_duration(cat_id, "duration_link_buttons")
    cat_link_btns = settings.parse_link_buttons_raw(cat_link_btns_raw) if cat_link_btns_raw else []
    for lb in cat_link_btns:
        api_kw: dict = {}
        if lb.get("icon_custom_emoji_id"):
            api_kw["icon_custom_emoji_id"] = lb["icon_custom_emoji_id"]
        if lb.get("style"):
            s = get_telegram_style(lb["style"])
            if s:
                api_kw["style"] = s
        buttons.append([InlineKeyboardButton(
            text=lb["text"], url=lb["url"],
            api_kwargs=api_kw if api_kw else None
        )])

    btn_categories = settings.get("bot_btn_categories")
    cat_kwargs = settings.build_button_kwargs("categories_btn_style", "categories_btn_emoji_id")
    buttons.append([InlineKeyboardButton(text=btn_categories, callback_data="categories_menu", api_kwargs=cat_kwargs)])
    reply_markup = InlineKeyboardMarkup(buttons)

    caption_values = {
        "duration_title_raw": settings.get_category_duration(cat_id, "msg_select_duration_title"),
        "category": cat_visible,
        "duration_sub_raw": settings.get_category_duration(cat_id, "msg_select_duration_sub"),
    }

    cat_tpl = settings.get_category_duration(cat_id, "tpl_duration_caption")
    caption = settings.render_template_str(cat_tpl, caption_values)

    if has_any_discount and discount_plan_name:
        banner = settings.get("msg_discount_duration_banner")
        caption += "\n\n" + banner.replace("{plan_name}", escape(discount_plan_name))

    file_id = (category.get("file_id") or "").strip()

    await safe_delete_message(bot, chat_id, message_id)
    await clear_user_category_message_id(user_row["id"])

    if file_id:
        try:
            new_msg = await bot.send_document(
                chat_id=chat_id,
                document=file_id,
                caption=caption,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
            await save_user_durations_message_id(user_row["id"], new_msg.message_id)
            return {"ok": True, "new_message_id": new_msg.message_id}
        except Exception as e:
            logger.error(f"send_document failed for category {cat_id}: {e}")
            try:
                fallback_msg = await bot.send_message(
                    chat_id=chat_id,
                    text=caption,
                    reply_markup=reply_markup,
                    parse_mode="HTML"
                )
                await save_user_durations_message_id(user_row["id"], fallback_msg.message_id)
                return {"ok": True, "new_message_id": fallback_msg.message_id}
            except Exception as e2:
                logger.error(f"Fallback send_message also failed: {e2}")
                return {"ok": False, "reason": "send_failed"}
    else:
        try:
            new_msg = await bot.send_message(
                chat_id=chat_id,
                text=caption,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
            await save_user_durations_message_id(user_row["id"], new_msg.message_id)
            return {"ok": True, "new_message_id": new_msg.message_id}
        except Exception as e:
            logger.error(f"send_message failed for durations: {e}")
            return {"ok": False, "reason": "send_failed"}
