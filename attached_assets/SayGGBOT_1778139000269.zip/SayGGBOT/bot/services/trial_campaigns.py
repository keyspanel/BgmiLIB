import asyncio
import html as html_mod
import json
import logging
import re
from datetime import datetime, timedelta, timezone

import httpx
from telegram import Bot

from bot import database as db
from bot.config import BOT_TOKEN, BRAND_NAME

logger = logging.getLogger(__name__)

IST = timezone(timedelta(hours=5, minutes=30))

def _clean_cat_name(name):
    return re.sub(r'\s*\{\d{5,32}\}\s*', '', name or '').strip()

def _safe_var_name(cat_name):
    clean = _clean_cat_name(cat_name)
    return re.sub(r'[^a-zA-Z0-9]', '', clean)


class _TrialKeyMissingError(Exception):
    def __init__(self, missing_categories):
        self.missing_categories = missing_categories
        names = ", ".join(m["category_name"] for m in missing_categories)
        super().__init__(f"Missing trial keys for categories: {names}")


def _fmt_dt(dt_val):
    if not dt_val:
        return ""
    if isinstance(dt_val, datetime):
        aware = dt_val.replace(tzinfo=timezone.utc) if dt_val.tzinfo is None else dt_val
        return aware.astimezone(IST).strftime("%d %b %Y, %I:%M %p IST")
    return str(dt_val)


def _render_template(text, variables):
    for key, val in variables.items():
        text = text.replace(f"{{{key}}}", str(val))
    return text


async def _get_trial_target_user_ids(target_audience: str, bot: Bot):
    if target_audience == "all_users":
        rows = await db.fetch_all("SELECT telegram_id FROM users WHERE is_banned = 0")
    elif target_audience == "paid_users":
        rows = await db.fetch_all(
            "SELECT DISTINCT u.telegram_id FROM users u JOIN orders o ON o.user_id = u.id WHERE u.is_banned = 0 AND o.status IN ('paid','completed','delivered')"
        )
    elif target_audience == "active_users":
        rows = await db.fetch_all(
            "SELECT telegram_id FROM users WHERE is_banned = 0 AND created_at >= NOW() - INTERVAL '30 days'"
        )
    elif target_audience == "resellers":
        rows = await db.fetch_all(
            "SELECT telegram_id FROM users WHERE is_banned = 0 AND reseller_id IS NOT NULL"
        )
    elif target_audience == "purchasers":
        rows = await db.fetch_all(
            "SELECT DISTINCT u.telegram_id FROM users u JOIN orders o ON o.user_id = u.id WHERE u.is_banned = 0 AND o.status = 'delivered'"
        )
    elif target_audience == "channels":
        return []
    else:
        rows = await db.fetch_all("SELECT telegram_id FROM users WHERE is_banned = 0")
    return [r["telegram_id"] for r in rows]


async def _get_trial_channel_ids(campaign):
    channel_ids = []
    if not campaign.get("send_to_channels"):
        return channel_ids
    try:
        ch_json = json.loads(campaign.get("channel_targets_json") or "[]")
        if ch_json:
            config_ids = [int(x) for x in ch_json if str(x).isdigit()]
            if config_ids:
                ch_rows = await db.fetch_all(
                    "SELECT resolved_chat_id FROM configured_channels WHERE id = ANY($1::int[]) AND is_enabled = true AND is_validated = true",
                    config_ids,
                )
                for r in ch_rows:
                    cid = r.get("resolved_chat_id")
                    if cid:
                        channel_ids.append(int(cid))
    except Exception as e:
        logger.warning(f"Trial campaign: failed to resolve channels: {e}")
    return channel_ids


async def _pick_trial_keys_for_run(campaign, run_id):
    category_ids = json.loads(campaign.get("category_ids_json") or "[]")
    duration_hours = campaign.get("trial_duration_hours", 1)
    max_devices = campaign.get("max_devices")
    camp_id = campaign["id"]

    async with db.pool.acquire() as conn:
        async with conn.transaction():
            picked_keys = []
            missing_categories = []

            for cat_id in category_ids:
                query = """
                    SELECT id, key_value, duration_hours, max_devices, category_id
                    FROM trial_keys
                    WHERE category_id = $1 AND duration_hours = $2 AND status = 'available'
                """
                args = [cat_id, duration_hours]

                if max_devices:
                    query += " AND max_devices >= $3"
                    args.append(max_devices)

                query += " ORDER BY id ASC LIMIT 1 FOR UPDATE SKIP LOCKED"

                key_row = await conn.fetchrow(query, *args)

                if not key_row:
                    cat_name_row = await conn.fetchrow("SELECT name FROM categories WHERE id = $1", cat_id)
                    if cat_name_row:
                        cat_name = cat_name_row["name"]
                    else:
                        snap_json = campaign.get("category_names_snapshot_json")
                        snap_list = json.loads(snap_json) if snap_json else []
                        snap_match = next((s for s in snap_list if s.get("id") == cat_id), None)
                        cat_name = snap_match["name"] if snap_match else f"Deleted Category (ID {cat_id})"
                    missing_categories.append({"category_id": cat_id, "category_name": cat_name})
                    logger.error(
                        f"Trial Campaign #{camp_id}: no available trial key for category={cat_id} "
                        f"duration={duration_hours}h — run cannot proceed"
                    )
                    continue

                await conn.execute(
                    "UPDATE trial_keys SET status = 'used', used_in_trial_campaign_run_id = $1, used_at = NOW(), updated_at = NOW() WHERE id = $2",
                    run_id, key_row["id"],
                )

                cat_snap_row = await conn.fetchrow("SELECT COALESCE(c.name, tk.category_name_snapshot) AS snap FROM trial_keys tk LEFT JOIN categories c ON c.id = tk.category_id WHERE tk.id = $1", key_row["id"])
                cat_snap = cat_snap_row["snap"] if cat_snap_row and cat_snap_row["snap"] else f"Deleted Category (ID {cat_id})"

                await conn.execute(
                    """INSERT INTO trial_campaign_run_keys
                       (run_id, campaign_id, category_id, trial_key_id, key_value_snapshot, duration_hours, max_devices, category_name_snapshot)
                       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)""",
                    run_id, camp_id, cat_id, key_row["id"], key_row["key_value"],
                    key_row["duration_hours"], key_row["max_devices"], cat_snap,
                )

                picked_keys.append({
                    "category_id": cat_id,
                    "trial_key_id": key_row["id"],
                    "key_value": key_row["key_value"],
                    "duration_hours": key_row["duration_hours"],
                    "max_devices": key_row["max_devices"],
                })

            if missing_categories:
                raise _TrialKeyMissingError(missing_categories)

            return picked_keys, []


def _build_category_blocks(picked_keys, category_names):
    blocks = []
    for pk in picked_keys:
        cat_id = pk["category_id"]
        clean_name = _clean_cat_name(category_names.get(cat_id, f"Deleted Category (ID {cat_id})"))
        blocks.append(
            f"• <b>{clean_name}</b>\n"
            f"  Key: <code>{pk['key_value']}</code>"
        )
    return "\n".join(blocks)


def _build_channel_category_blocks(picked_keys, category_names, reveal_keys):
    blocks = []
    for pk in picked_keys:
        cat_id = pk["category_id"]
        clean_name = _clean_cat_name(category_names.get(cat_id, f"Deleted Category (ID {cat_id})"))
        if reveal_keys:
            blocks.append(
                f"• <b>{clean_name}</b>\n"
                f"  Key: <code>{pk['key_value']}</code>"
            )
        else:
            blocks.append(f"• <b>{clean_name}</b>\n  Trial Key — Available via bot")
    return "\n".join(blocks)


def _build_full_variable_map(campaign, picked_keys, category_ids, category_names,
                              linked_promo_name, linked_promo_start,
                              category_blocks_user, category_blocks_channel,
                              is_channel=False, user_name="there"):
    clean_names = [_clean_cat_name(category_names.get(cid, "")) for cid in category_ids]
    categories_str = ", ".join(n for n in clean_names if n)

    per_key_vars = {}
    for pk in picked_keys:
        cat_id = pk["category_id"]
        cat_name = category_names.get(cat_id, f"Cat{cat_id}")
        safe = _safe_var_name(cat_name)
        per_key_vars[f"TrialKey{safe}"] = pk["key_value"]

    cat_blocks = category_blocks_channel if is_channel else category_blocks_user

    variables = {
        "CampaignName": campaign.get("name", ""),
        "campaign_name": campaign.get("name", ""),
        "user_name": user_name,
        "bot_name": BRAND_NAME,
        "trial_duration": str(campaign.get("trial_duration_hours", "")),
        "TrialDurationHours": str(campaign.get("trial_duration_hours", "")),
        "trial_devices": str(campaign.get("max_devices") or "Unlimited"),
        "expire_time": _fmt_dt(campaign.get("expire_at")),
        "ExpireTime": _fmt_dt(campaign.get("expire_at")),
        "start_time": _fmt_dt(campaign.get("start_at")),
        "datetime": _fmt_dt(datetime.utcnow()),
        "categories": categories_str,
        "TrialCategoryNames": categories_str,
        "TrialCategoryCount": str(len(category_ids)),
        "TrialCategoryBlocks": cat_blocks,
        "NextPromoName": linked_promo_name,
        "NextPromoStartTime": linked_promo_start,
        **per_key_vars,
    }

    if len(picked_keys) == 1:
        variables["trial_key"] = picked_keys[0]["key_value"]
        variables["category_name"] = _clean_cat_name(
            category_names.get(picked_keys[0]["category_id"], "")
        )
    elif picked_keys:
        variables["trial_key"] = picked_keys[0]["key_value"]
        variables["category_name"] = _clean_cat_name(
            category_names.get(picked_keys[0]["category_id"], "")
        )

    return variables


async def _fetch_category_media(category_ids):
    if not category_ids:
        return {}
    rows = await db.fetch_all(
        "SELECT id, name, file_id FROM categories WHERE id = ANY($1::int[])",
        category_ids,
    )
    media = {}
    for r in rows:
        fid = r.get("file_id")
        if fid and str(fid).strip():
            media[r["id"]] = {
                "file_id": str(fid).strip(),
                "name": _clean_cat_name(r.get("name", "")),
            }
    return media


def _compile_trial_caption(html_text, limit=1024):
    from bot.services.campaigns import _parse_html_to_entities, _validate_entities, _utf16_len
    if not html_text:
        return "", []
    plain_text, raw_entities = _parse_html_to_entities(html_text)
    validated = _validate_entities(plain_text, raw_entities)
    u16_total = _utf16_len(plain_text)
    if u16_total > limit:
        cut_u16 = limit - 2
        acc = 0
        cut_py = len(plain_text)
        for i, ch in enumerate(plain_text):
            cp = ord(ch)
            w = 2 if cp > 0xFFFF else 1
            if acc + w > cut_u16:
                cut_py = i
                break
            acc += w
        plain_text = plain_text[:cut_py] + "\u2026"
        validated = [e for e in validated if e["offset"] + e["length"] <= acc]
    custom_count = sum(1 for e in validated if e["type"] == "custom_emoji")
    if custom_count > 0 or len(validated) > 0:
        logger.debug(
            f"compile_caption: text_len={len(plain_text)} u16={u16_total} "
            f"entities={len(validated)} custom_emoji={custom_count}"
        )
    return plain_text, validated


async def _send_media_group_documents(chat_id, media_items, camp_id, run_id):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMediaGroup"
    media_payload = []
    total_custom = 0
    for item in media_items:
        raw_cap = item.get("caption") or f"\U0001F4E6 <b>{html_mod.escape(item['name'])}</b>"
        plain_cap, cap_entities = _compile_trial_caption(raw_cap)
        entry = {"type": "document", "media": item["file_id"], "caption": plain_cap}
        if cap_entities:
            entry["caption_entities"] = cap_entities
            total_custom += sum(1 for e in cap_entities if e["type"] == "custom_emoji")
        media_payload.append(entry)

    payload = {"chat_id": chat_id, "media": media_payload}

    logger.info(
        f"Trial #{camp_id}: sendMediaGroup to {chat_id}: "
        f"docs={len(media_items)} custom_emoji_total={total_custom} "
        f"caption_entities_present={'yes' if any(e.get('caption_entities') for e in media_payload) else 'no'}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()

    if result.get("ok"):
        msg_ids = [m.get("message_id", 0) for m in result.get("result", [])]
        logger.info(f"Trial #{camp_id}: media group sent to {chat_id}, {len(msg_ids)} docs")
        return {"ok": True, "message_ids": msg_ids, "grouped": True}

    err = result.get("description", "unknown")
    logger.warning(f"Trial #{camp_id}: media group failed to {chat_id}: {err}")
    return {"ok": False, "error": err, "grouped": False}


async def _send_media_group_chunked(chat_id, media_items, camp_id, run_id):
    if len(media_items) == 0:
        return {"ok": True, "chunks_sent": 0, "total_files": 0, "last_message_ids": []}
    if len(media_items) == 1:
        cap_html = media_items[0].get("caption") or f"\U0001F4E6 <b>{html_mod.escape(media_items[0]['name'])}</b>"
        r = await _send_single_document(chat_id, media_items[0]["file_id"], cap_html, camp_id)
        return {"ok": r["ok"], "chunks_sent": 1 if r["ok"] else 0, "total_files": 1,
                "last_message_ids": [r.get("message_id", 0)] if r["ok"] else [],
                "error": r.get("error"), "used_single_doc": True}

    chunks = [media_items[i:i + 10] for i in range(0, len(media_items), 10)]
    all_ok = True
    chunks_sent = 0
    last_msg_ids = []
    last_error = None
    for ci, chunk in enumerate(chunks):
        if len(chunk) == 1:
            cap_html = chunk[0].get("caption") or f"\U0001F4E6 <b>{html_mod.escape(chunk[0]['name'])}</b>"
            r = await _send_single_document(chat_id, chunk[0]["file_id"], cap_html, camp_id)
            if r["ok"]:
                chunks_sent += 1
                last_msg_ids = [r.get("message_id", 0)]
            else:
                all_ok = False
                last_error = r.get("error")
        else:
            r = await _send_media_group_documents(chat_id, chunk, camp_id, run_id)
            if r["ok"]:
                chunks_sent += 1
                last_msg_ids = r.get("message_ids", [])
            else:
                all_ok = False
                last_error = r.get("error")
        if ci < len(chunks) - 1:
            await asyncio.sleep(0.5)

    return {"ok": all_ok, "chunks_sent": chunks_sent, "chunk_count": len(chunks),
            "total_files": len(media_items), "last_message_ids": last_msg_ids,
            "partial": chunks_sent > 0 and not all_ok,
            "error": last_error if not all_ok else None}


async def _edit_message_reply_markup(chat_id, message_id, keyboard, camp_id):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/editMessageReplyMarkup"
    payload = {"chat_id": chat_id, "message_id": message_id,
               "reply_markup": {"inline_keyboard": keyboard}}
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()
    if result.get("ok"):
        return {"ok": True}
    err = result.get("description", "unknown")
    logger.warning(f"Trial #{camp_id}: editMessageReplyMarkup failed on msg {message_id}: {err}")
    return {"ok": False, "error": err}


async def _send_single_document(chat_id, file_id, caption_html, camp_id):
    plain_cap, cap_entities = _compile_trial_caption(caption_html)
    custom_count = sum(1 for e in cap_entities if e["type"] == "custom_emoji")
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
    payload = {
        "chat_id": chat_id,
        "document": file_id,
        "caption": plain_cap,
    }
    if cap_entities:
        payload["caption_entities"] = cap_entities
    logger.info(
        f"Trial #{camp_id}: sendDocument to {chat_id}: "
        f"caption_len={len(plain_cap)} entities={len(cap_entities)} "
        f"custom_emoji={custom_count} method=sendDocument single_file=yes"
    )
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()
    if result.get("ok"):
        msg_id = result.get("result", {}).get("message_id", 0)
        return {"ok": True, "message_id": msg_id}
    err = result.get("description", "unknown")
    logger.warning(f"Trial #{camp_id}: single doc send failed to {chat_id}: {err}")
    return {"ok": False, "error": err}


async def _send_single_document_with_buttons(chat_id, file_id, caption_html, buttons_json, camp_id):
    plain_cap, cap_entities = _compile_trial_caption(caption_html)
    keyboard = _build_trial_inline_keyboard(buttons_json) if buttons_json else None
    custom_count = sum(1 for e in cap_entities if e["type"] == "custom_emoji")
    btn_icon_count = 0
    btn_style_count = 0
    if keyboard:
        for row in keyboard:
            for btn in row:
                if btn.get("icon_custom_emoji_id"):
                    btn_icon_count += 1
                if btn.get("style"):
                    btn_style_count += 1
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
    payload = {
        "chat_id": chat_id,
        "document": file_id,
        "caption": plain_cap,
    }
    if cap_entities:
        payload["caption_entities"] = cap_entities
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    logger.info(
        f"Trial #{camp_id}: sendDocument+buttons to {chat_id}: "
        f"caption_len={len(plain_cap)} caption_entities={len(cap_entities)} "
        f"caption_custom_emoji={custom_count} buttons={sum(len(r) for r in keyboard) if keyboard else 0} "
        f"icon_custom_emoji_id_count={btn_icon_count} style_count={btn_style_count} "
        f"payload_keys={list(payload.keys())}"
    )
    if keyboard:
        for row in keyboard:
            for btn in row:
                logger.info(
                    f"Trial #{camp_id}:   button: text={btn.get('text')!r} "
                    f"url={btn.get('url', '(none)')[:40]} "
                    f"icon_custom_emoji_id={btn.get('icon_custom_emoji_id', '(none)')} "
                    f"style={btn.get('style', '(none)')}"
                )
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()
    if result.get("ok"):
        return {"ok": True, "message_id": result.get("result", {}).get("message_id", 0)}
    err = result.get("description", "unknown")
    logger.warning(f"Trial #{camp_id}: doc+buttons send failed to {chat_id}: {err}")
    return {"ok": False, "error": err}


async def _send_trial_documents(chat_id, media_items, camp_id, run_id):
    if len(media_items) == 0:
        return {"ok": True, "media_sent": False, "media_count": 0, "grouped": False}

    any_has_buttons = any(item.get("buttons_json") for item in media_items)

    if len(media_items) >= 2 and not any_has_buttons:
        result = await _send_media_group_documents(chat_id, media_items, camp_id, run_id)
        if result["ok"]:
            return {"ok": True, "media_sent": True, "media_count": len(media_items), "grouped": True}
        logger.info(f"Trial #{camp_id}: media group fallback to sequential for {chat_id}")

    sent_count = 0
    last_error = None
    for item in media_items:
        cap_html = item.get("caption") or f"\U0001F4E6 <b>{html_mod.escape(item['name'])}</b>"
        buttons_json = item.get("buttons_json")
        if buttons_json:
            r = await _send_single_document_with_buttons(chat_id, item["file_id"], cap_html, buttons_json, camp_id)
        else:
            r = await _send_single_document(chat_id, item["file_id"], cap_html, camp_id)
        if r["ok"]:
            sent_count += 1
        else:
            last_error = r.get("error")

    if sent_count > 0:
        return {"ok": True, "media_sent": True, "media_count": sent_count, "grouped": False,
                "fallback": len(media_items) >= 2}
    return {"ok": False, "media_sent": False, "error": last_error, "media_count": 0, "grouped": False}


def _build_trial_inline_keyboard(buttons_json_str):
    if not buttons_json_str:
        return None
    try:
        buttons = json.loads(buttons_json_str)
        if not isinstance(buttons, list) or not buttons:
            return None
    except (json.JSONDecodeError, TypeError):
        return None

    active = [b for b in buttons if b.get("enabled", True) is not False]
    if not active:
        return None

    row_map = {}
    for b in active:
        url = (b.get("url") or "").strip()
        if not url or (not url.startswith("http") and not url.startswith("tg://")):
            continue
        r = b.get("row", 1) or 1
        row_map.setdefault(r, [])
        btn_data = {
            "text": (b.get("text") or "Button").strip() or "Button",
            "url": url,
        }
        style = (b.get("style") or "").strip().lower()
        if style in ("primary", "success", "danger"):
            btn_data["style"] = style
        emoji_id = (b.get("icon_custom_emoji_id") or "").strip()
        if emoji_id:
            btn_data["icon_custom_emoji_id"] = emoji_id
        logger.debug(
            f"build_trial_keyboard: text={btn_data['text']!r} url={url[:40]} "
            f"icon_custom_emoji_id={btn_data.get('icon_custom_emoji_id', '(none)')} "
            f"style={btn_data.get('style', '(none)')}"
        )
        row_map[r].append(btn_data)

    keyboard = []
    for r in sorted(row_map.keys()):
        keyboard.append(row_map[r])
    total_btns = sum(len(row) for row in keyboard) if keyboard else 0
    icon_count = sum(1 for row in (keyboard or []) for b in row if b.get("icon_custom_emoji_id"))
    style_count = sum(1 for row in (keyboard or []) for b in row if b.get("style"))
    logger.info(
        f"build_trial_keyboard: rows={len(keyboard)} buttons={total_btns} "
        f"icon_custom_emoji_ids={icon_count} styles={style_count}"
    )
    return keyboard if keyboard else None


def _merge_inline_keyboards(*keyboards):
    merged_rows = []
    seen_pairs = set()
    for kb in keyboards:
        if not kb:
            continue
        for row in kb:
            deduped_row = []
            for btn in row:
                pair = (btn.get("text", ""), btn.get("url", ""))
                if pair in seen_pairs:
                    continue
                seen_pairs.add(pair)
                deduped_row.append(btn)
            if deduped_row:
                merged_rows.append(deduped_row)
    MAX_ROWS = 20
    if len(merged_rows) > MAX_ROWS:
        logger.warning(f"Button merge: truncating {len(merged_rows)} rows to {MAX_ROWS}")
        merged_rows = merged_rows[:MAX_ROWS]
    return merged_rows if merged_rows else None


async def _send_text_with_merged_keyboard(chat_id, text, keyboard, camp_id, run_id):
    from bot.services.campaigns import _parse_html_to_entities, _validate_entities
    plain_text, entities = _parse_html_to_entities(text)
    validated = _validate_entities(plain_text, entities)
    custom_count = sum(1 for e in validated if e["type"] == "custom_emoji")
    btn_icon_count = 0
    btn_style_count = 0
    if keyboard:
        for row in keyboard:
            for btn in row:
                if btn.get("icon_custom_emoji_id"):
                    btn_icon_count += 1
                if btn.get("style"):
                    btn_style_count += 1
    payload = {
        "chat_id": chat_id,
        "text": plain_text,
        "disable_web_page_preview": True,
    }
    if validated:
        payload["entities"] = validated
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    logger.info(
        f"Trial #{camp_id}: sendMessage(merged) to {chat_id}: "
        f"text_len={len(plain_text)} entities={len(validated)} custom_emoji={custom_count} "
        f"first_5_entities={validated[:5]} "
        f"buttons={sum(len(r) for r in keyboard) if keyboard else 0} "
        f"icon_custom_emoji_id_count={btn_icon_count} style_count={btn_style_count} "
        f"payload_keys={list(payload.keys())}"
    )
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()
    ok = result.get("ok", False)
    if ok:
        return {"ok": True, "message_id": result.get("result", {}).get("message_id", 0)}
    err = result.get("description", "unknown error")
    logger.error(f"Trial #{camp_id}: merged text send failed to {chat_id}: {err}")
    return {"ok": False, "error": err}


async def _deliver_mode_1(chat_id, media_items, rendered_summary, summary_buttons_json, send_summary,
                           camp_id, run_id, target_label):
    media_ok = False
    media_error = None
    strategy = "separate_file_messages"
    if media_items:
        try:
            mr = await _send_trial_documents(chat_id, media_items, camp_id, run_id)
            media_ok = mr.get("media_sent", False)
            if media_ok:
                strategy = "separate_file_messages"
            if mr.get("error"):
                media_error = mr.get("error")
        except Exception as e:
            media_error = str(e)[:200]
            logger.warning(f"Trial #{camp_id}: mode1 media error to {target_label} {chat_id}: {e}")

    summary_ok = False
    summary_error = None
    if send_summary and rendered_summary.strip():
        try:
            result = await _send_trial_message(chat_id, rendered_summary, camp_id, run_id, summary_buttons_json)
            summary_ok = result.get("ok", False)
            if not summary_ok:
                summary_error = result.get("error")
        except Exception as e:
            summary_error = str(e)[:200]

    return {
        "strategy": strategy,
        "media_ok": media_ok, "media_error": media_error,
        "summary_ok": summary_ok, "summary_error": summary_error,
        "sent": summary_ok or media_ok,
    }


async def _deliver_mode_2(chat_id, media_items, rendered_summary, summary_buttons_json, send_summary,
                           camp_id, run_id, target_label):
    strategy = "media_group_plus_summary"
    all_keyboards = []

    for item in media_items:
        kb = _build_trial_inline_keyboard(item.get("buttons_json")) if item.get("buttons_json") else None
        if kb:
            all_keyboards.append(kb)

    if send_summary and rendered_summary.strip():
        summary_kb = _build_trial_inline_keyboard(summary_buttons_json)
        if summary_kb:
            all_keyboards.append(summary_kb)

    media_ok = False
    media_error = None
    button_attached = False
    chunk_count = 0

    if media_items:
        try:
            mgr = await _send_media_group_chunked(chat_id, media_items, camp_id, run_id)
            media_ok = mgr.get("ok", False)
            chunk_count = mgr.get("chunk_count", mgr.get("chunks_sent", 0))
            if not media_ok:
                media_error = mgr.get("error")
                if mgr.get("chunks_sent", 0) == 0:
                    logger.info(f"Trial #{camp_id}: mode2 media_group failed for {chat_id}, falling back to sequential sends")
                    fb = await _send_trial_documents(chat_id, media_items, camp_id, run_id)
                    media_ok = fb.get("media_sent", False)
                    if media_ok:
                        strategy = "media_group_fallback_sequential"
                        media_error = None
                    else:
                        media_error = fb.get("error") or media_error
                else:
                    logger.warning(f"Trial #{camp_id}: mode2 partial media_group for {chat_id}, {mgr.get('chunks_sent')}/{mgr.get('chunk_count')} chunks sent")
            if media_ok and mgr.get("last_message_ids"):
                try:
                    apk_keyboards = []
                    for item in media_items:
                        kb = _build_trial_inline_keyboard(item.get("buttons_json")) if item.get("buttons_json") else None
                        if kb:
                            apk_keyboards.append(kb)
                    if apk_keyboards:
                        merged_apk_kb = _merge_inline_keyboards(*apk_keyboards)
                        if merged_apk_kb:
                            last_id = mgr["last_message_ids"][-1]
                            ebr = await _edit_message_reply_markup(chat_id, last_id, merged_apk_kb, camp_id)
                            if ebr["ok"]:
                                button_attached = True
                                logger.info(f"Trial #{camp_id}: mode2 attached APK buttons to msg {last_id}")
                except Exception as e:
                    logger.warning(f"Trial #{camp_id}: mode2 editReplyMarkup failed: {e}")
        except Exception as e:
            media_error = str(e)[:200]
            logger.warning(f"Trial #{camp_id}: mode2 media send error to {target_label} {chat_id}: {e}")

    summary_ok = False
    summary_error = None
    has_summary_content = send_summary and rendered_summary.strip()
    remaining_keyboards = []
    if not button_attached:
        remaining_keyboards = all_keyboards
    else:
        if has_summary_content:
            skb = _build_trial_inline_keyboard(summary_buttons_json)
            if skb:
                remaining_keyboards = [skb]

    if has_summary_content or (remaining_keyboards and not button_attached):
        combined_text = rendered_summary.strip() if has_summary_content else ""
        if not combined_text and not button_attached:
            combined_text = "📋 <b>Trial Delivery</b>"
        if combined_text:
            if len(combined_text) > 4096:
                combined_text = combined_text[:4090] + "\n…"
            try:
                merged_kb = _merge_inline_keyboards(*remaining_keyboards) if remaining_keyboards else None
                result = await _send_text_with_merged_keyboard(chat_id, combined_text, merged_kb, camp_id, run_id)
                summary_ok = result.get("ok", False)
                if not summary_ok:
                    summary_error = result.get("error")
            except Exception as e:
                summary_error = str(e)[:200]

    logger.info(
        f"Trial #{camp_id}: mode2 delivery to {target_label} {chat_id}: "
        f"strategy={strategy} files={len(media_items)} chunks={chunk_count} "
        f"media_ok={media_ok} buttons_attached={button_attached} summary_ok={summary_ok}"
    )

    return {
        "strategy": strategy,
        "media_ok": media_ok, "media_error": media_error,
        "summary_ok": summary_ok, "summary_error": summary_error,
        "sent": media_ok or summary_ok,
        "button_attached": button_attached,
        "chunk_count": chunk_count,
    }


async def _deliver_mode_3(chat_id, media_items, rendered_summary, summary_buttons_json, send_summary,
                           camp_id, run_id, target_label):
    strategy = "media_group_then_summary"
    media_ok = False
    media_error = None
    chunk_count = 0
    button_attached = False

    if media_items:
        try:
            mgr = await _send_media_group_chunked(chat_id, media_items, camp_id, run_id)
            media_ok = mgr.get("ok", False)
            chunk_count = mgr.get("chunk_count", mgr.get("chunks_sent", 0))
            if not media_ok:
                media_error = mgr.get("error")
                if mgr.get("chunks_sent", 0) == 0:
                    logger.info(f"Trial #{camp_id}: mode3 media_group failed for {chat_id}, falling back to sequential sends")
                    fb = await _send_trial_documents(chat_id, media_items, camp_id, run_id)
                    media_ok = fb.get("media_sent", False)
                    if media_ok:
                        strategy = "media_group_fallback_sequential"
                        media_error = None
                    else:
                        media_error = fb.get("error") or media_error
                else:
                    logger.warning(f"Trial #{camp_id}: mode3 partial media_group for {chat_id}, {mgr.get('chunks_sent')}/{mgr.get('chunk_count')} chunks sent")
            if media_ok and mgr.get("last_message_ids"):
                try:
                    apk_keyboards = []
                    for item in media_items:
                        kb = _build_trial_inline_keyboard(item.get("buttons_json")) if item.get("buttons_json") else None
                        if kb:
                            apk_keyboards.append(kb)
                    if apk_keyboards:
                        merged_apk_kb = _merge_inline_keyboards(*apk_keyboards)
                        if merged_apk_kb:
                            last_id = mgr["last_message_ids"][-1]
                            ebr = await _edit_message_reply_markup(chat_id, last_id, merged_apk_kb, camp_id)
                            if ebr["ok"]:
                                button_attached = True
                                logger.info(f"Trial #{camp_id}: mode3 attached APK buttons to msg {last_id}")
                except Exception as e:
                    logger.warning(f"Trial #{camp_id}: mode3 editReplyMarkup failed: {e}")
        except Exception as e:
            media_error = str(e)[:200]
            logger.warning(f"Trial #{camp_id}: mode3 media send error to {target_label} {chat_id}: {e}")

    summary_ok = False
    summary_error = None
    if send_summary and rendered_summary.strip():
        try:
            result = await _send_trial_message(chat_id, rendered_summary, camp_id, run_id, summary_buttons_json)
            summary_ok = result.get("ok", False)
            if not summary_ok:
                summary_error = result.get("error")
        except Exception as e:
            summary_error = str(e)[:200]

    logger.info(
        f"Trial #{camp_id}: mode3 delivery to {target_label} {chat_id}: "
        f"strategy={strategy} files={len(media_items)} chunks={chunk_count} "
        f"media_ok={media_ok} buttons_attached={button_attached} summary_ok={summary_ok}"
    )

    return {
        "strategy": strategy,
        "media_ok": media_ok, "media_error": media_error,
        "summary_ok": summary_ok, "summary_error": summary_error,
        "sent": media_ok or summary_ok,
        "button_attached": button_attached,
        "chunk_count": chunk_count,
    }


async def _send_trial_message(chat_id, text, camp_id, run_id, inline_buttons_json=None):
    from bot.services.campaigns import _parse_html_to_entities, _validate_entities

    plain_text, entities = _parse_html_to_entities(text)
    validated = _validate_entities(plain_text, entities)
    custom_count = sum(1 for e in validated if e["type"] == "custom_emoji")

    payload = {
        "chat_id": chat_id,
        "text": plain_text,
        "disable_web_page_preview": True,
    }
    if validated:
        payload["entities"] = validated

    keyboard = _build_trial_inline_keyboard(inline_buttons_json)
    btn_icon_count = 0
    btn_style_count = 0
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
        for row in keyboard:
            for btn in row:
                if btn.get("icon_custom_emoji_id"):
                    btn_icon_count += 1
                if btn.get("style"):
                    btn_style_count += 1

    logger.info(
        f"Trial #{camp_id}: sendMessage(summary) to {chat_id}: "
        f"text_len={len(plain_text)} entities={len(validated)} custom_emoji={custom_count} "
        f"first_5_entities={validated[:5]} "
        f"buttons={sum(len(r) for r in keyboard) if keyboard else 0} "
        f"icon_custom_emoji_id_count={btn_icon_count} style_count={btn_style_count} "
        f"method=sendMessage parse_mode=entities "
        f"payload_keys={list(payload.keys())} send_succeeded=pending"
    )

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()

    ok = result.get("ok", False)
    if ok:
        msg_id = result.get("result", {}).get("message_id", 0)
        ret_ents = result.get("result", {}).get("entities", [])
        ret_custom = sum(1 for e in ret_ents if e.get("type") == "custom_emoji")
        stripped = custom_count - ret_custom
        logger.info(
            f"Trial #{camp_id}: sendMessage(summary) OK to {chat_id}: msg_id={msg_id} "
            f"entities_sent={len(validated)} entities_returned={len(ret_ents)} "
            f"custom_emoji_sent={custom_count} custom_emoji_returned={ret_custom} "
            f"custom_emoji_stripped={stripped}"
        )
        if stripped > 0:
            logger.warning(
                f"Trial #{camp_id}: Telegram accepted but stripped {stripped} custom_emoji "
                f"entity(ies) from summary to {chat_id}"
            )
        return {"ok": True, "message_id": msg_id}

    err_desc = result.get("description", "unknown error")
    logger.error(
        f"Trial Campaign #{camp_id}: send failed to {chat_id}: {err_desc} "
        f"(had {custom_count} custom_emoji, {btn_icon_count} button icons)"
    )
    return {"ok": False, "error": err_desc}


async def _execute_trial_run(bot: Bot, campaign, run_type):
    campaign = dict(campaign)
    camp_id = campaign["id"]

    run_id = await db.fetch_val(
        """INSERT INTO trial_campaign_runs (campaign_id, run_type, status)
           VALUES ($1, $2, 'running') RETURNING id""",
        camp_id, run_type,
    )

    logger.info(f"Trial Campaign #{camp_id} RUN_START: type={run_type} run_id={run_id}")

    category_ids = json.loads(campaign.get("category_ids_json") or "[]")
    cat_rows = await db.fetch_all(
        "SELECT id, name FROM categories WHERE id = ANY($1::int[])", category_ids
    )
    category_names = {r["id"]: r["name"] for r in cat_rows}
    snap_json = campaign.get("category_names_snapshot_json")
    if snap_json:
        try:
            for s in json.loads(snap_json):
                if s.get("id") not in category_names:
                    category_names[s["id"]] = s["name"]
        except (json.JSONDecodeError, TypeError):
            pass

    picked_keys = []
    if run_type == "trial_start":
        try:
            picked_keys, _ = await _pick_trial_keys_for_run(campaign, run_id)
        except _TrialKeyMissingError as e:
            error_msg = str(e)
            await db.execute(
                "UPDATE trial_campaign_runs SET status = 'failed', error_text = $1, completed_at = NOW() WHERE id = $2",
                error_msg, run_id,
            )
            logger.error(f"Trial Campaign #{camp_id} RUN_FAILED: {error_msg}")

            from bot.config import ADMIN_CHAT_ID
            if ADMIN_CHAT_ID:
                try:
                    missing_names = ", ".join(m["category_name"] for m in e.missing_categories)
                    await bot.send_message(
                        chat_id=ADMIN_CHAT_ID,
                        text=f"⚠️ <b>Trial Campaign Failed</b>\n\n"
                             f"Campaign: <b>{campaign.get('name', '')}</b> (#{camp_id})\n"
                             f"Missing keys: {missing_names}\n\n"
                             f"Add more trial keys for the missing categories.",
                        parse_mode="HTML",
                    )
                except Exception:
                    pass
            return {"run_id": run_id, "status": "failed", "error": error_msg,
                    "total_targets": 0, "total_sent": 0, "total_failed": 0}

        key_log = ", ".join(f"cat={pk['category_id']}→key={pk['trial_key_id']}" for pk in picked_keys)
        logger.info(f"Trial Campaign #{camp_id} KEYS_LOCKED: run={run_id} keys=[{key_log}]")

    if run_type == "trial_start":
        tpl_id = campaign.get("start_template_id")
    else:
        tpl_id = campaign.get("expire_template_id")

    template = None
    if tpl_id:
        template = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", tpl_id)

    if template:
        body_text = template["body_text"]
    elif run_type == "trial_start":
        body_text = (
            "🎉 <b>Free Trial Activated!</b>\n\n"
            "Hey <b>{user_name}</b>, your trial has been activated.\n\n"
            "Available apps:\n"
            "{TrialCategoryBlocks}\n\n"
            "⏱ Duration: <b>{trial_duration} hours</b>\n"
            "📱 Devices: <b>{trial_devices}</b>\n"
            "⏰ Expires: <b>{expire_time}</b>\n\n"
            "Enjoy your trial from <b>{bot_name}</b>!"
        )
    else:
        body_text = (
            "⌛ <b>{campaign_name}</b> has expired\n\n"
            "Hey <b>{user_name}</b>, your free trial has ended.\n\n"
            "Expired at: <b>{expire_time}</b>\n\n"
            "Used apps:\n{categories}\n\n"
            "Want to continue? Purchase the full version from <b>{bot_name}</b>."
        )

    category_blocks_user = _build_category_blocks(picked_keys, category_names) if picked_keys else ""
    reveal = campaign.get("reveal_keys_in_channels", False)
    category_blocks_channel = _build_channel_category_blocks(picked_keys, category_names, reveal) if picked_keys else ""

    linked_promo_name = ""
    linked_promo_start = ""
    if campaign.get("linked_promo_campaign_id"):
        linked = await db.fetch_one(
            "SELECT name, start_at FROM scheduled_campaigns WHERE id = $1",
            campaign["linked_promo_campaign_id"],
        )
        if linked:
            linked_promo_name = linked.get("name", "")
            linked_promo_start = _fmt_dt(linked.get("start_at"))

    apk_captions_raw = {}
    apk_buttons_raw = {}
    inline_buttons_json_str = None
    send_summary_enabled = True

    apk_cfg_raw = campaign.get("apk_delivery_config_json")
    apk_delivery_cfg = {}
    if apk_cfg_raw:
        try:
            parsed = json.loads(apk_cfg_raw) if isinstance(apk_cfg_raw, str) else apk_cfg_raw
            if isinstance(parsed, dict):
                apk_delivery_cfg = parsed
            else:
                logger.warning(f"Trial #{camp_id}: apk_delivery_config_json is not a dict, ignoring")
        except (json.JSONDecodeError, TypeError):
            apk_delivery_cfg = {}

    global_apk_enabled = apk_delivery_cfg.get("send_apks_enabled", True)
    _raw_cats = apk_delivery_cfg.get("categories", {})
    cat_delivery_cfg = _raw_cats if isinstance(_raw_cats, dict) else {}

    if template:
        start_cfg_str = template.get("start_delivery_config_json")
        if start_cfg_str and run_type == "trial_start":
            try:
                start_cfg = json.loads(start_cfg_str)
                send_summary_enabled = start_cfg.get("send_summary", True)
            except (json.JSONDecodeError, TypeError):
                pass
        inline_buttons_json_str = template.get("inline_buttons_json") or None

    if run_type == "trial_start":
        db_caption_rows = await db.fetch_all(
            "SELECT category_id, body_text, inline_buttons_json FROM campaign_templates "
            "WHERE template_type = 'trial_apk_caption' AND is_active = true AND category_id IS NOT NULL "
            "ORDER BY updated_at DESC"
        )
        seen_cats: set = set()
        if db_caption_rows:
            for row in db_caption_rows:
                cid_str = str(row["category_id"])
                if cid_str in seen_cats:
                    continue
                seen_cats.add(cid_str)
                if row.get("body_text"):
                    apk_captions_raw[cid_str] = row["body_text"]
                if row.get("inline_buttons_json"):
                    apk_buttons_raw[cid_str] = row["inline_buttons_json"]

    cat_media = {}
    apk_delivery_log = []
    if run_type == "trial_start" and global_apk_enabled:
        all_cat_media = await _fetch_category_media(category_ids)
        for cid in category_ids:
            cid_str = str(cid)
            cat_cfg = cat_delivery_cfg.get(cid_str, {})
            if not isinstance(cat_cfg, dict):
                cat_cfg = {}
            cat_enabled = cat_cfg.get("send_enabled", True)
            if not cat_enabled:
                apk_delivery_log.append({"category_id": cid, "reason": "skipped_category_off"})
                logger.info(f"Trial #{camp_id}: category {cid} apk_delivery_skipped: skipped_category_off")
                continue
            if cid not in all_cat_media:
                apk_delivery_log.append({"category_id": cid, "reason": "skipped_no_file"})
                logger.info(f"Trial #{camp_id}: category {cid} apk_delivery_skipped: skipped_no_file")
                continue
            file_info = all_cat_media[cid]
            file_id = file_info["file_id"]
            file_cfgs = cat_cfg.get("files", {})
            if not isinstance(file_cfgs, dict):
                file_cfgs = {}
            file_toggle = file_cfgs.get(file_id, {})
            if not isinstance(file_toggle, dict):
                file_toggle = {}
            file_enabled = file_toggle.get("send_enabled", True)
            if not file_enabled:
                apk_delivery_log.append({"category_id": cid, "file_id": file_id, "reason": "skipped_file_off"})
                logger.info(f"Trial #{camp_id}: category {cid} file {file_id[:20]}.. apk_delivery_skipped: skipped_file_off")
                continue
            cat_media[cid] = file_info
            apk_delivery_log.append({"category_id": cid, "file_id": file_id, "reason": "sent_file"})
        media_count = len(cat_media)
        logger.info(
            f"Trial #{camp_id}: categories={len(category_ids)} keys={len(picked_keys)} "
            f"media_available={media_count} cats_with_media={list(cat_media.keys())}"
        )
    elif run_type == "trial_start" and not global_apk_enabled:
        for cid in category_ids:
            apk_delivery_log.append({"category_id": cid, "reason": "skipped_global_off"})
        logger.info(f"Trial #{camp_id}: apk_delivery_skipped_global_off for all {len(category_ids)} categories")

    delivery_mode = campaign.get("delivery_mode", "mode_1_separate")
    if delivery_mode not in ("mode_1_separate", "mode_2_single_combined", "mode_3_combined_plus_summary"):
        logger.warning(f"Trial #{camp_id}: invalid_delivery_mode '{delivery_mode}', defaulting to mode_1_separate")
        delivery_mode = "mode_1_separate"

    send_to_users = campaign.get("send_to_users", True)
    send_to_channels = campaign.get("send_to_channels", False)

    user_ids = await _get_trial_target_user_ids(campaign.get("target_audience", "all_users"), bot) if send_to_users else []
    channel_ids = await _get_trial_channel_ids(campaign) if send_to_channels else []

    user_name_map = {}
    if user_ids:
        try:
            name_rows = await db.fetch_all(
                "SELECT telegram_id, first_name, username FROM users WHERE telegram_id = ANY($1::bigint[])",
                list(user_ids),
            )
            for row in name_rows:
                display = (row.get("first_name") or "").strip() or (row.get("username") or "").strip() or "there"
                user_name_map[row["telegram_id"]] = display
        except Exception:
            pass

    total_targets = len(user_ids) + len(channel_ids)
    total_sent = 0
    total_failed = 0
    media_sends_ok = 0
    media_sends_fail = 0

    base_media_items = []
    for cid in category_ids:
        if cid in cat_media:
            base_media_items.append({**cat_media[cid], "category_id": cid})

    def _resolve_media_captions(media_items_base, user_vars):
        resolved = []
        picked_map = {pk["category_id"]: pk for pk in picked_keys}
        for item in media_items_base:
            cid = item["category_id"]
            caption_tpl = apk_captions_raw.get(str(cid), "")
            cat_buttons = apk_buttons_raw.get(str(cid))
            if caption_tpl and caption_tpl.strip():
                cap_vars = {}
                for k, v in user_vars.items():
                    cap_vars[k] = html_mod.escape(str(v)) if k not in ("TrialCategoryBlocks",) else v
                pk = picked_map.get(cid)
                clean_name = _clean_cat_name(category_names.get(cid, ""))
                if pk:
                    esc_key = html_mod.escape(pk["key_value"])
                    cap_vars["trial_key"] = esc_key
                    cap_vars["category_key"] = esc_key
                    cap_vars["category_name"] = html_mod.escape(clean_name)
                    cap_vars["category_file_name"] = html_mod.escape(clean_name)
                rendered_cap = _render_template(caption_tpl, cap_vars)
                resolved.append({**item, "caption": rendered_cap, "buttons_json": cat_buttons})
            else:
                resolved.append({**item, "buttons_json": cat_buttons})
        return resolved

    deliver_fn = _deliver_mode_1
    if run_type == "trial_start":
        if delivery_mode == "mode_2_single_combined":
            deliver_fn = _deliver_mode_2
        elif delivery_mode == "mode_3_combined_plus_summary":
            deliver_fn = _deliver_mode_3

    strategies_used = set()

    logger.info(
        f"Trial #{camp_id}: delivery_mode={delivery_mode} run_type={run_type} "
        f"apk_blocks={len(base_media_items)} users={len(user_ids)} channels={len(channel_ids)}"
    )

    async def _deliver_to_target(chat_id, target_type, target_vars, target_idx):
        nonlocal total_sent, total_failed, media_sends_ok
        rendered = _render_template(body_text, target_vars)
        media_items = _resolve_media_captions(base_media_items, target_vars) if run_type == "trial_start" else []
        should_send_summary = send_summary_enabled if run_type == "trial_start" else True

        try:
            dr = await deliver_fn(
                chat_id, media_items, rendered, inline_buttons_json_str,
                should_send_summary, camp_id, run_id, target_type,
            )
        except Exception as e:
            logger.error(f"Trial #{camp_id}: delivery failed to {target_type} {chat_id}: {e}")
            await db.execute(
                """INSERT INTO trial_campaign_delivery_logs
                   (run_id, campaign_id, target_type, telegram_id, message_kind, delivery_status, error_text)
                   VALUES ($1, $2, $3, $4, $5, 'failed', $6)""",
                run_id, camp_id, target_type, chat_id, run_type, str(e)[:500],
            )
            total_failed += 1
            return

        strategies_used.add(dr.get("strategy", "unknown"))
        error_parts = []
        if dr.get("media_error"):
            error_parts.append(f"media: {dr['media_error']}")
        if dr.get("summary_error") and dr["summary_error"] != "no_content":
            error_parts.append(f"text: {dr['summary_error']}")
        error_text = "; ".join(error_parts) if error_parts else None

        if dr.get("sent"):
            total_sent += 1
            if dr.get("media_ok"):
                media_sends_ok += 1
            await db.execute(
                """INSERT INTO trial_campaign_delivery_logs
                   (run_id, campaign_id, target_type, telegram_id, message_kind, delivery_status, error_text)
                   VALUES ($1, $2, $3, $4, $5, 'sent', $6)""",
                run_id, camp_id, target_type, chat_id, run_type, error_text,
            )
        else:
            total_failed += 1
            await db.execute(
                """INSERT INTO trial_campaign_delivery_logs
                   (run_id, campaign_id, target_type, telegram_id, message_kind, delivery_status, error_text)
                   VALUES ($1, $2, $3, $4, $5, 'failed', $6)""",
                run_id, camp_id, target_type, chat_id, run_type, error_text or "delivery_failed",
            )

        if (target_idx + 1) % 25 == 0:
            await asyncio.sleep(1)

    for i, tg_id in enumerate(user_ids):
        user_vars = _build_full_variable_map(
            campaign, picked_keys, category_ids, category_names,
            linked_promo_name, linked_promo_start,
            category_blocks_user, category_blocks_channel,
            is_channel=False, user_name=user_name_map.get(tg_id, "there"),
        )
        await _deliver_to_target(tg_id, "user", user_vars, i)

    channels_sent = 0
    channels_failed = 0
    if channel_ids:
        for j, ch_id in enumerate(channel_ids):
            ch_vars = _build_full_variable_map(
                campaign, picked_keys, category_ids, category_names,
                linked_promo_name, linked_promo_start,
                category_blocks_user, category_blocks_channel,
                is_channel=True, user_name="there",
            )
            prev_sent = total_sent
            await _deliver_to_target(ch_id, "channel", ch_vars, j)
            if total_sent > prev_sent:
                channels_sent += 1
            else:
                channels_failed += 1

    run_notes = (
        f"delivery_mode={delivery_mode} media_count={len(base_media_items)} "
        f"media_sends_ok={media_sends_ok} strategies={','.join(strategies_used) or 'none'}"
    )

    await db.execute(
        """UPDATE trial_campaign_runs
           SET status = 'completed', total_targets = $1, total_sent = $2, total_failed = $3,
               channels_targeted = $4, channels_sent = $5, channels_failed = $6, completed_at = NOW(),
               error_text = CASE WHEN error_text IS NULL THEN $7 ELSE error_text || '; ' || $7 END
           WHERE id = $8""",
        total_targets, total_sent, total_failed,
        len(channel_ids), channels_sent, channels_failed,
        run_notes, run_id,
    )

    logger.info(
        f"Trial Campaign #{camp_id} RUN_COMPLETE: type={run_type} run={run_id} "
        f"sent={total_sent}/{total_targets} failed={total_failed} "
        f"channels={channels_sent}/{len(channel_ids)} {run_notes}"
    )

    return {
        "run_id": run_id,
        "status": "completed",
        "total_targets": total_targets,
        "total_sent": total_sent,
        "total_failed": total_failed,
    }


def _compute_trial_next_times(campaign, start_at, expire_at, now):
    repeat = campaign.get("repeat_mode", "once")
    if repeat == "once":
        return None, None

    if isinstance(start_at, str):
        start_at = datetime.fromisoformat(start_at.replace("Z", "+00:00"))
    if isinstance(expire_at, str):
        expire_at = datetime.fromisoformat(expire_at.replace("Z", "+00:00"))

    duration = expire_at - start_at

    if repeat == "daily":
        delta = timedelta(days=1)
    elif repeat == "weekly":
        delta = timedelta(weeks=1)
    elif repeat == "monthly":
        delta = timedelta(days=30)
    else:
        return None, None

    next_start = start_at + delta
    while next_start <= now:
        next_start += delta
    next_expire = next_start + duration

    return next_start, next_expire


async def process_trial_starts(bot: Bot):
    now = datetime.utcnow()
    rows = await db.fetch_all(
        """SELECT * FROM trial_campaigns
           WHERE is_enabled = true AND status = 'scheduled'
             AND next_run_at IS NOT NULL AND next_run_at <= $1
           ORDER BY next_run_at ASC LIMIT 5""",
        now,
    )
    for row in rows:
        campaign = dict(row)
        camp_id = campaign["id"]
        logger.info(f"Trial Campaign #{camp_id} '{campaign['name']}' starting...")

        claimed = await db.fetch_val(
            "UPDATE trial_campaigns SET status = 'active', last_run_at = NOW(), updated_at = NOW() WHERE id = $1 AND status = 'scheduled' RETURNING id",
            camp_id,
        )
        if not claimed:
            continue

        try:
            result = await _execute_trial_run(bot, campaign, "trial_start")
            if result.get("status") == "failed":
                await db.execute(
                    "UPDATE trial_campaigns SET status = 'scheduled', updated_at = NOW() WHERE id = $1",
                    camp_id,
                )
            else:
                logger.info(f"Trial Campaign #{camp_id} trial_start sent: {result['total_sent']}/{result['total_targets']}")
        except Exception as e:
            logger.error(f"Trial Campaign #{camp_id} trial_start failed: {e}", exc_info=True)
            await db.execute(
                "UPDATE trial_campaigns SET status = 'scheduled', updated_at = NOW() WHERE id = $1",
                camp_id,
            )


async def process_trial_expiries(bot: Bot):
    now = datetime.utcnow()
    rows = await db.fetch_all(
        """SELECT * FROM trial_campaigns
           WHERE is_enabled = true AND status = 'active'
             AND next_expire_at IS NOT NULL AND next_expire_at <= $1
           ORDER BY next_expire_at ASC LIMIT 5""",
        now,
    )
    for row in rows:
        campaign = dict(row)
        camp_id = campaign["id"]
        logger.info(f"Trial Campaign #{camp_id} '{campaign['name']}' expiry triggered")

        updated = await db.fetch_val(
            "UPDATE trial_campaigns SET status = 'expiring', updated_at = NOW() WHERE id = $1 AND status = 'active' RETURNING id",
            camp_id,
        )
        if not updated:
            continue

        try:
            result = await _execute_trial_run(bot, campaign, "trial_expire")
            logger.info(
                f"Trial Campaign #{camp_id} trial_expire sent: "
                f"{result['total_sent']}/{result['total_targets']}"
            )
        except Exception as e:
            logger.error(f"Trial Campaign #{camp_id} trial_expire failed: {e}", exc_info=True)

        if campaign.get("linked_promo_campaign_id"):
            try:
                linked_id = campaign["linked_promo_campaign_id"]
                linked = await db.fetch_one("SELECT * FROM scheduled_campaigns WHERE id = $1", linked_id)
                if linked and linked.get("status") == "scheduled":
                    await db.execute(
                        "UPDATE scheduled_campaigns SET next_run_at = NOW(), updated_at = NOW() WHERE id = $1",
                        linked_id,
                    )
                    logger.info(f"Trial Campaign #{camp_id}: linked promo campaign #{linked_id} triggered")
            except Exception as e:
                logger.warning(f"Trial Campaign #{camp_id}: failed to trigger linked promo: {e}")

        repeat = campaign.get("repeat_mode", "once")
        if repeat != "once":
            start_at = campaign.get("start_at") or campaign.get("next_run_at")
            expire_at = campaign.get("expire_at") or campaign.get("next_expire_at")
            if start_at and expire_at:
                try:
                    next_start, next_expire = _compute_trial_next_times(campaign, start_at, expire_at, now)
                    if next_start and next_expire:
                        await db.execute(
                            """UPDATE trial_campaigns
                               SET status = 'scheduled', next_run_at = $1, next_expire_at = $2,
                                   last_expired_at = NOW(), updated_at = NOW()
                               WHERE id = $3""",
                            next_start, next_expire, camp_id,
                        )
                        logger.info(f"Trial Campaign #{camp_id} rescheduled: next={next_start}")
                        continue
                except Exception as e:
                    logger.error(f"Trial Campaign #{camp_id}: reschedule failed: {e}")

        await db.execute(
            "UPDATE trial_campaigns SET status = 'expired', last_expired_at = NOW(), updated_at = NOW() WHERE id = $1",
            camp_id,
        )
        logger.info(f"Trial Campaign #{camp_id}: marked as expired")


async def _recover_stale_trial_expiring(bot: Bot):
    stale = await db.fetch_all(
        """SELECT id, name FROM trial_campaigns
           WHERE status = 'expiring' AND updated_at < NOW() - INTERVAL '10 minutes'
           LIMIT 5""",
    )
    for row in stale:
        camp_id = row["id"]
        logger.warning(f"Trial Campaign #{camp_id} stuck in 'expiring' — forcing to 'expired'")
        await db.execute(
            "UPDATE trial_campaigns SET status = 'expired', last_expired_at = NOW(), updated_at = NOW() WHERE id = $1 AND status = 'expiring'",
            camp_id,
        )


async def run_trial_campaign_scheduler(bot: Bot):
    while True:
        try:
            await process_trial_starts(bot)
        except Exception as e:
            logger.error(f"Trial campaign scheduler (starts) error: {e}", exc_info=True)
        try:
            await process_trial_expiries(bot)
        except Exception as e:
            logger.error(f"Trial campaign scheduler (expiries) error: {e}", exc_info=True)
        try:
            await _recover_stale_trial_expiring(bot)
        except Exception as e:
            logger.error(f"Trial campaign scheduler (recovery) error: {e}")
        await asyncio.sleep(20)
