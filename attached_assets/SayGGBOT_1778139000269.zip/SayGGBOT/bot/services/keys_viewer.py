import logging
from html import escape
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
from bot import database as db
from bot.config import SITE_URL
from bot import settings
from bot.cleanup import (
    cleanup_user_purchased_keys_viewer,
    save_user_purchased_keys_viewer_message_id,
)

logger = logging.getLogger(__name__)


def get_keys_portal_url(user_row: dict) -> str:
    base = SITE_URL.rstrip("/") if SITE_URL else ""
    token = user_row.get("token") or ""
    return f"{base}/keys-portal?token={token}"


async def get_purchased_keys_count(user_id: int) -> int:
    val = await db.fetch_val(
        "SELECT COUNT(*) FROM purchased_keys_history WHERE user_id = $1",
        user_id
    )
    return int(val or 0)


async def get_purchased_key_at(user_id: int, offset: int) -> dict | None:
    row = await db.fetch_one(
        """SELECT * FROM purchased_keys_history
           WHERE user_id = $1
           ORDER BY purchased_at DESC, id DESC
           LIMIT 1 OFFSET $2""",
        user_id, offset
    )
    return dict(row) if row else None


def build_purchased_keys_keyboard(user_row: dict, item: dict, page: int, total: int) -> InlineKeyboardMarkup:
    rows = []

    show_manage = total > 5 or bool(user_row.get("reseller_id"))
    if show_manage and SITE_URL:
        from telegram import WebAppInfo
        manage_kwargs = settings.build_button_kwargs("manage_keys_btn_style", "manage_keys_btn_emoji_id")
        rows.append([InlineKeyboardButton(
            text=settings.get('bot_btn_manage_keys'),
            web_app=WebAppInfo(url=get_keys_portal_url(user_row)),
            api_kwargs=manage_kwargs,
        )])

    copy_kwargs = settings.build_button_kwargs("copy_key_btn_style", "copy_key_btn_emoji_id")
    rows.append([InlineKeyboardButton(
        text=settings.get('bot_btn_copy_key'),
        copy_text={"text": str(item.get("key_value", ""))},
        api_kwargs=copy_kwargs,
    )])

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton(text=settings.get("btn_prev_page"), callback_data=f"pkeys_{page - 1}"))
    if page < total:
        nav.append(InlineKeyboardButton(text=settings.get("btn_next_page"), callback_data=f"pkeys_{page + 1}"))
    if nav:
        rows.append(nav)

    return InlineKeyboardMarkup(rows)


def render_purchased_keys_text(item: dict, page: int, total: int, is_reseller: bool) -> str:
    title = settings.get('bot_keys_reseller_title') if is_reseller else settings.get('bot_keys_title')

    buyer_name = ((item.get("first_name") or "") + " " + (item.get("last_name") or "")).strip()
    if not buyer_name:
        buyer_name = f"@{item['username']}" if item.get("username") else f"User {item.get('telegram_id', '')}"

    txn_ref = str(item.get("txn_ref") or "").strip()
    if txn_ref:
        ref_label = settings.get("msg_reference_label")
        ref_section = f"\n\n<b>{escape(ref_label)}:</b> <code>{escape(txn_ref)}</code>"
    else:
        ref_section = ""

    item_values = {
        "index": str(page),
        "total": str(total),
        "order_id": str(item.get("order_id", 0)),
        "category": str(item.get("category_name") or ""),
        "duration": str(item.get("duration_name") or ""),
        "currency_raw": settings.get("currency_symbol"),
        "amount": f"{float(item.get('amount', 0)):.2f}",
        "purchased_time": str(item.get("verified_at") or item.get("purchased_at", "")),
        "buyer": buyer_name,
        "key": str(item.get("key_value", "")),
        "reference_section_raw": ref_section,
    }

    body = settings.fmt("tpl_keys_item", item_values)
    return settings.build_sections(title, body)


async def send_purchased_keys_viewer(bot: Bot, chat_id: int, user_row: dict, page: int = 1):
    await cleanup_user_purchased_keys_viewer(bot, user_row, chat_id)

    total = await get_purchased_keys_count(user_row["id"])
    no_keys_title = settings.get("msg_no_keys_found_title")
    if total <= 0:
        no_msg = await bot.send_message(
            chat_id=chat_id,
            text=f"{no_keys_title}\n\n{settings.get('bot_keys_empty')}",
            parse_mode="HTML"
        )
        await save_user_purchased_keys_viewer_message_id(user_row["id"], no_msg.message_id)
        return

    page = max(1, min(page, total))
    item = await get_purchased_key_at(user_row["id"], page - 1)
    if not item:
        logger.warning("send_purchased_keys_viewer: key item not found for user_id=%s page=%s total=%s", user_row["id"], page, total)
        err_msg = await bot.send_message(
            chat_id=chat_id,
            text=f"{no_keys_title}\n\n{settings.get('msg_keys_load_error')}",
            parse_mode="HTML"
        )
        await save_user_purchased_keys_viewer_message_id(user_row["id"], err_msg.message_id)
        return

    is_reseller = bool(user_row.get("reseller_id") or item.get("is_reseller_purchase"))
    text = render_purchased_keys_text(item, page, total, is_reseller)
    kb = build_purchased_keys_keyboard(user_row, item, page, total)

    msg = await bot.send_message(chat_id=chat_id, text=text, reply_markup=kb, parse_mode="HTML")
    await save_user_purchased_keys_viewer_message_id(user_row["id"], msg.message_id)

    try:
        await bot.pin_chat_message(chat_id=chat_id, message_id=msg.message_id, disable_notification=True)
    except Exception:
        pass


async def edit_purchased_keys_viewer(bot: Bot, chat_id: int, message_id: int, user_row: dict, page: int = 1):
    total = await get_purchased_keys_count(user_row["id"])
    no_keys_title = settings.get("msg_no_keys_found_title")
    if total <= 0:
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=message_id,
                text=f"{no_keys_title}\n\n{settings.get('bot_keys_empty')}",
                parse_mode="HTML"
            )
        except Exception:
            pass
        return

    page = max(1, min(page, total))
    item = await get_purchased_key_at(user_row["id"], page - 1)
    if not item:
        logger.warning("edit_purchased_keys_viewer: key item not found for user_id=%s page=%s total=%s", user_row["id"], page, total)
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=message_id,
                text=f"{no_keys_title}\n\n{settings.get('msg_keys_load_error')}",
                parse_mode="HTML"
            )
        except Exception:
            pass
        return

    is_reseller = bool(user_row.get("reseller_id") or item.get("is_reseller_purchase"))
    text = render_purchased_keys_text(item, page, total, is_reseller)
    kb = build_purchased_keys_keyboard(user_row, item, page, total)

    try:
        await bot.edit_message_text(
            chat_id=chat_id, message_id=message_id,
            text=text, reply_markup=kb, parse_mode="HTML"
        )
    except Exception:
        pass

    await save_user_purchased_keys_viewer_message_id(user_row["id"], message_id)
