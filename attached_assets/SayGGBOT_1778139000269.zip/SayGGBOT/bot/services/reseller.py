import logging
from html import escape
from bot import database as db
from bot import settings

logger = logging.getLogger(__name__)


async def get_final_duration_price(duration_id: int, category_id: int, user_row: dict) -> float:
    details = await get_pricing_details(duration_id, category_id, user_row)
    return details["final_price"]


async def get_pricing_details(duration_id: int, category_id: int, user_row: dict, base_price: float | None = None) -> dict:
    if base_price is None:
        base_price = await db.fetch_val(
            "SELECT price FROM durations WHERE id = $1 LIMIT 1",
            duration_id
        )
        base_price = float(base_price or 0)

    result = {
        "final_price": max(0.0, base_price),
        "base_price": base_price,
        "pricing_source": "base",
        "applied_discount_plan_id": None,
        "applied_discount_plan_name": None,
    }

    reseller_id = user_row.get("reseller_id")
    if reseller_id:
        reseller_price = await _resolve_reseller_price(duration_id, category_id, reseller_id, base_price)
        result["final_price"] = reseller_price
        result["pricing_source"] = "reseller"
        return result

    from bot.services.user_discount import resolve_user_discount_with_plan
    discount_result = await resolve_user_discount_with_plan(duration_id, category_id, base_price)
    if discount_result is not None:
        result["final_price"] = max(0.0, discount_result["price"])
        result["pricing_source"] = "user_discount"
        result["applied_discount_plan_id"] = discount_result.get("plan_id")
        result["applied_discount_plan_name"] = discount_result.get("plan_name")
        return result

    try:
        from bot.services.campaigns import get_active_campaign_discount
        camp_result = await get_active_campaign_discount(category_id, duration_id, base_price)
        if camp_result is not None:
            result["final_price"] = max(0.0, camp_result["price"])
            result["pricing_source"] = "campaign"
            result["applied_discount_plan_id"] = camp_result.get("campaign_id")
            result["applied_discount_plan_name"] = camp_result.get("campaign_name")
            return result
    except Exception as e:
        logger.warning(f"Campaign discount check error: {e}")

    return result


async def _resolve_reseller_price(duration_id: int, category_id: int, reseller_id: int, base_price: float) -> float:

    rule = await db.fetch_one(
        """SELECT * FROM reseller_prices
           WHERE reseller_id = $1
             AND (category_id IS NULL OR category_id = $2)
             AND (duration_id IS NULL OR duration_id = $3)
           ORDER BY
             (category_id IS NULL) ASC,
             (duration_id IS NULL) ASC,
             id DESC
           LIMIT 1""",
        reseller_id, category_id, duration_id
    )

    if rule:
        if rule["price"] is not None:
            return max(0.0, float(rule["price"]))
        dt = rule.get("discount_type") or ""
        dv = float(rule.get("discount_value") or 0)
        if dt == "percent":
            return max(0.0, base_price - (base_price * dv / 100))
        if dt == "fixed":
            return max(0.0, base_price - dv)

    reseller = await db.fetch_one(
        "SELECT * FROM resellers WHERE id = $1 LIMIT 1",
        reseller_id
    )
    if reseller:
        if reseller.get("total_price") is not None:
            return max(0.0, float(reseller["total_price"]))
        dt = reseller.get("discount_type") or "percent"
        dv = float(reseller.get("discount_value") or 0)
        if dt == "percent":
            return max(0.0, base_price - (base_price * dv / 100))
        if dt == "fixed":
            return max(0.0, base_price - dv)

    return max(0.0, base_price)


async def get_base_duration_price(duration_id: int) -> float:
    base_price = await db.fetch_val(
        "SELECT price FROM durations WHERE id = $1 LIMIT 1",
        duration_id
    )
    return float(base_price or 0)


async def build_reseller_offer_summary(reseller_id: int, currency: str = None) -> str:
    currency = currency or settings.get('currency_symbol')

    rules = await db.fetch_all(
        """SELECT rp.*, c.name AS category_name, d.name AS duration_name
           FROM reseller_prices rp
           LEFT JOIN categories c ON rp.category_id = c.id
           LEFT JOIN durations d ON rp.duration_id = d.id
           WHERE rp.reseller_id = $1
           ORDER BY COALESCE(c.name, ''), COALESCE(d.name, ''), rp.id ASC""",
        reseller_id
    )

    if not rules:
        legacy = await db.fetch_one(
            "SELECT * FROM resellers WHERE id = $1 LIMIT 1",
            reseller_id
        )
        if not legacy:
            return "• Standard reseller pricing active"
        if legacy.get("total_price") is not None:
            return f"• Fixed reseller price: <b>{currency}{float(legacy['total_price']):.2f}</b>"
        dt = legacy.get("discount_type") or ""
        dv = float(legacy.get("discount_value") or 0)
        if dt == "percent":
            return f"• Global discount: <b>{dv:.2f}% OFF</b>"
        if dt == "fixed":
            return f"• Global discount: <b>{currency}{dv:.2f} OFF</b>"
        return "• Standard reseller pricing active"

    lines = []
    for rule in rules:
        cn = rule.get("category_name") or ""
        dn = rule.get("duration_name") or ""
        if cn and dn:
            scope = f"{cn} → {dn}"
        elif cn:
            scope = f"{cn} → All Durations"
        elif dn:
            scope = f"All Categories → {dn}"
        else:
            scope = "All Categories → All Durations"

        if rule["price"] is not None:
            value = f"{currency}{float(rule['price']):.2f}"
        elif (rule.get("discount_type") or "") == "percent":
            value = f"{float(rule.get('discount_value') or 0):.2f}% OFF"
        elif (rule.get("discount_type") or "") == "fixed":
            value = f"{currency}{float(rule.get('discount_value') or 0):.2f} OFF"
        else:
            value = "Custom pricing"

        lines.append(f"• <b>{escape(scope)}:</b> {escape(value)}")

    return "\n".join(lines)


async def assign_reseller_code(user_row: dict, code: str) -> dict:
    currency = settings.get('currency_symbol')

    reseller = await db.fetch_one(
        "SELECT * FROM resellers WHERE code = $1 LIMIT 1",
        code
    )
    if not reseller:
        return {
            "result": "invalid_code",
            "text": settings.get("msg_reseller_invalid_code"),
        }

    if reseller.get("expires_at"):
        from datetime import datetime, timezone
        exp = reseller["expires_at"]
        if hasattr(exp, 'tzinfo') and exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp < datetime.now(timezone.utc):
            return {
                "result": "expired",
                "text": settings.get("msg_reseller_code_expired"),
            }

    if reseller.get("max_users"):
        used = await db.fetch_val(
            "SELECT COUNT(*) FROM reseller_users WHERE reseller_id = $1",
            reseller["id"]
        )
        if used >= reseller["max_users"]:
            return {
                "result": "usage_limit",
                "text": settings.get("msg_reseller_usage_limit"),
            }

    current_reseller = None
    if user_row.get("reseller_id"):
        current_reseller = await db.fetch_one(
            "SELECT * FROM resellers WHERE id = $1 LIMIT 1",
            user_row["reseller_id"]
        )

    if user_row.get("reseller_id") and user_row["reseller_id"] == reseller["id"]:
        await db.execute("UPDATE users SET awaiting_code = 0 WHERE id = $1", user_row["id"])
        offer_summary = await build_reseller_offer_summary(reseller["id"], currency)
        code_esc = escape(str(reseller["code"]))
        expires = escape(str(reseller["expires_at"])) if reseller.get("expires_at") else "Unlimited"

        tpl_values = {
            "reseller_title_raw": settings.get("msg_reseller_already_active_title"),
            "code": str(reseller["code"]),
            "expires": str(reseller["expires_at"]) if reseller.get("expires_at") else "Unlimited",
            "offer_summary_raw": offer_summary,
        }
        text = settings.fmt("tpl_reseller_already_active", tpl_values)
        return {
            "result": "already_active",
            "text": text,
        }

    try:
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute("DELETE FROM reseller_users WHERE user_id = $1", user_row["id"])
                await conn.execute(
                    "UPDATE users SET reseller_id = $1, awaiting_code = 0 WHERE id = $2",
                    reseller["id"], user_row["id"]
                )
                await conn.execute(
                    "INSERT INTO reseller_users (reseller_id, user_id) VALUES ($1, $2)",
                    reseller["id"], user_row["id"]
                )
    except Exception as e:
        logger.error(f"assign_reseller_code transaction error for user {user_row['id']}, code {code}: {e}")
        return {
            "result": "error",
            "text": settings.get("msg_reseller_activation_failed"),
        }

    offer_summary = await build_reseller_offer_summary(reseller["id"], currency)

    switched_section = ""
    if current_reseller and current_reseller.get("code"):
        label = settings.get("msg_reseller_switched_label")
        switched_section = f"<b>{escape(label)}:</b> <code>{escape(str(current_reseller['code']))}</code>\n"

    expires = escape(str(reseller["expires_at"])) if reseller.get("expires_at") else "Unlimited"
    max_users = str(reseller["max_users"]) + " users" if reseller.get("max_users") else "Unlimited"

    tpl_values = {
        "reseller_title_raw": settings.get("msg_reseller_activated_title"),
        "code": str(reseller["code"]),
        "switched_section_raw": switched_section,
        "expires": expires,
        "max_users": max_users,
        "offer_summary_raw": offer_summary,
        "reseller_footer_raw": settings.get("msg_reseller_activated_footer"),
    }
    text = settings.fmt("tpl_reseller_activated", tpl_values)

    return {
        "result": "activated",
        "text": text,
    }
