import asyncio
import json
import logging
import random
import re
import string
import unicodedata
from datetime import datetime, timedelta, timezone
from html import unescape as html_unescape

import httpx

IST = timezone(timedelta(hours=5, minutes=30))
from telegram import Bot
from bot import database as db
from bot.config import BOT_TOKEN

logger = logging.getLogger(__name__)

_active_campaign_cache = None
_campaign_cache_at = None
_CAMPAIGN_CACHE_TTL = 15


def _generate_code(length=8):
    chars = string.ascii_lowercase + string.digits
    return "promo_" + "".join(random.choices(chars, k=length))


def _bot_username_cached():
    return None


_bot_me = None


async def _get_bot_username(bot: Bot):
    global _bot_me
    if _bot_me:
        return _bot_me
    me = await bot.get_me()
    _bot_me = me.username
    return _bot_me


async def get_active_campaign_discount(category_id: int, duration_id: int, base_price: float):
    global _active_campaign_cache, _campaign_cache_at

    now = datetime.utcnow()
    if _campaign_cache_at and (now - _campaign_cache_at).total_seconds() < _CAMPAIGN_CACHE_TTL:
        campaigns = _active_campaign_cache
    else:
        campaigns = await db.fetch_all(
            """SELECT sc.*, cr.discount_mode, cr.fixed_value, cr.min_value, cr.max_value,
                      cr.applies_to_category_id, cr.applies_to_duration_id
               FROM scheduled_campaigns sc
               LEFT JOIN campaign_discount_rules cr ON cr.campaign_id = sc.id
               WHERE sc.status = 'active' AND sc.is_enabled = true
               ORDER BY sc.id DESC"""
        )
        _active_campaign_cache = [dict(c) for c in campaigns] if campaigns else []
        _campaign_cache_at = now
        campaigns = _active_campaign_cache

    if not campaigns:
        return None

    for c in campaigns:
        scope_cat = c.get("applies_to_category_id")
        scope_dur = c.get("applies_to_duration_id")
        if scope_cat is not None and scope_cat != category_id:
            continue
        if scope_dur is not None and scope_dur != duration_id:
            continue
        mode = c.get("campaign_mode", "fixed_plan")
        if mode == "message_only":
            continue
        disc_mode = c.get("discount_mode")
        if not disc_mode:
            continue
        discount_val = 0.0
        if disc_mode == "fixed_percent":
            discount_val = float(c.get("fixed_value") or 0)
        elif disc_mode == "random_percent":
            # FIX: run_type stored as 'promo_start', not 'start'
            run_row = await db.fetch_one(
                """SELECT generated_discount_value FROM campaign_runs
                   WHERE campaign_id = $1 AND run_type = 'promo_start' AND status = 'completed'
                     AND generated_discount_value IS NOT NULL
                   ORDER BY executed_at DESC LIMIT 1""",
                c["id"],
            )
            if run_row and run_row["generated_discount_value"]:
                discount_val = float(run_row["generated_discount_value"])
            else:
                continue
        elif disc_mode == "fixed_price_override":
            override = float(c.get("fixed_value") or 0)
            return {
                "price": max(0.0, override),
                "campaign_id": c["id"],
                "campaign_name": c["name"],
                "discount_type": "override",
                "discount_value": override,
            }
        if discount_val > 0:
            final = max(0.0, base_price - (base_price * discount_val / 100))
            return {
                "price": final,
                "campaign_id": c["id"],
                "campaign_name": c["name"],
                "discount_type": "percent",
                "discount_value": discount_val,
            }
    return None


def invalidate_campaign_cache():
    global _active_campaign_cache, _campaign_cache_at
    _active_campaign_cache = None
    _campaign_cache_at = None


async def record_deep_link_event(
    campaign_id, deep_link_code, telegram_user_id, username, event_type,
    order_id=None, revenue=None,
    campaign_run_id=None, deep_link_id=None, is_late_conversion=False,
):
    try:
        # Idempotency: skip if this order was already attributed as a purchase
        if event_type == "purchase" and order_id is not None:
            exists = await db.fetch_val(
                "SELECT id FROM campaign_link_events WHERE order_id = $1 AND event_type = 'purchase' LIMIT 1",
                order_id,
            )
            if exists:
                logger.info(f"Campaign attribution: order #{order_id} already recorded, skipping duplicate")
                return
        await db.execute(
            """INSERT INTO campaign_link_events
               (campaign_id, deep_link_code, telegram_user_id, username, event_type, order_id, revenue_amount,
                campaign_run_id, deep_link_id, is_late_conversion)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)""",
            campaign_id, deep_link_code, telegram_user_id, username or "", event_type, order_id, revenue,
            campaign_run_id, deep_link_id, is_late_conversion,
        )
        # Update per-link counters on campaign_deep_links
        if deep_link_id:
            try:
                if event_type == "open":
                    await db.execute(
                        "UPDATE campaign_deep_links SET opens_count = opens_count + 1 WHERE id = $1",
                        deep_link_id,
                    )
                elif event_type == "start":
                    await db.execute(
                        "UPDATE campaign_deep_links SET starts_count = starts_count + 1 WHERE id = $1",
                        deep_link_id,
                    )
            except Exception as ce:
                logger.warning(f"Failed to update deep link counters: {ce}")
        # Update daily stats — late conversions do NOT add to revenue totals
        try:
            today = datetime.utcnow().date()
            if event_type == "open":
                await db.execute(
                    """INSERT INTO campaign_daily_stats (stat_date, campaign_id, total_opens)
                       VALUES ($1, $2, 1)
                       ON CONFLICT (stat_date, campaign_id)
                       DO UPDATE SET total_opens = campaign_daily_stats.total_opens + 1, updated_at = NOW()""",
                    today, campaign_id,
                )
            elif event_type == "purchase" and revenue is not None and not is_late_conversion:
                await db.execute(
                    """INSERT INTO campaign_daily_stats (stat_date, campaign_id, total_purchases, total_revenue)
                       VALUES ($1, $2, 1, $3)
                       ON CONFLICT (stat_date, campaign_id)
                       DO UPDATE SET total_purchases = campaign_daily_stats.total_purchases + 1,
                                     total_revenue = campaign_daily_stats.total_revenue + $3,
                                     updated_at = NOW()""",
                    today, campaign_id, revenue or 0,
                )
        except Exception as stat_err:
            logger.warning(f"Failed to update campaign daily stats: {stat_err}")
    except Exception as e:
        logger.error(f"Failed to record campaign link event: {e}")


async def upsert_campaign_attribution(
    user_id: int, telegram_id: int, campaign_id: int, deep_link_code: str,
    attribution_days: int = 30,
    campaign_run_id=None, deep_link_id=None, attribution_end_at=None,
):
    """Create or refresh a user's campaign attribution. Called when user opens a deep link.
    If attribution_end_at is provided (from the campaign run), it is used as the expiry window.
    Otherwise falls back to a rolling attribution_days window.
    """
    try:
        if attribution_end_at is not None:
            expires_at = attribution_end_at
        else:
            expires_at = datetime.utcnow() + timedelta(days=attribution_days)
        await db.execute(
            """INSERT INTO campaign_attributions
               (user_id, telegram_id, campaign_id, deep_link_code, first_opened_at, last_opened_at, total_opens,
                attribution_expires_at, campaign_run_id, deep_link_id, attribution_end_at)
               VALUES ($1, $2, $3, $4, NOW(), NOW(), 1, $5, $6, $7, $5)
               ON CONFLICT (user_id, campaign_id)
               DO UPDATE SET
                   last_opened_at = NOW(),
                   total_opens = campaign_attributions.total_opens + 1,
                   deep_link_code = EXCLUDED.deep_link_code,
                   attribution_expires_at = EXCLUDED.attribution_expires_at,
                   campaign_run_id = EXCLUDED.campaign_run_id,
                   deep_link_id = EXCLUDED.deep_link_id,
                   attribution_end_at = EXCLUDED.attribution_end_at,
                   updated_at = NOW()""",
            user_id, telegram_id, campaign_id, deep_link_code, expires_at,
            campaign_run_id, deep_link_id,
        )
        logger.info(
            f"Campaign attribution upserted: user_id={user_id}, campaign_id={campaign_id}, "
            f"run_id={campaign_run_id}, expires={expires_at}"
        )
    except Exception as e:
        logger.error(f"Failed to upsert campaign attribution: {e}")


async def get_active_attribution(user_id: int):
    """Retrieve the most recent non-expired attribution for a user tied to an ACTIVE deep link."""
    try:
        row = await db.fetch_one(
            """SELECT ca.*, cdl.code AS link_code, cdl.status AS dl_status,
                      cdl.id AS cdl_id, cdl.campaign_run_id AS dl_run_id,
                      cdl.attribution_end_at AS dl_attribution_end_at
               FROM campaign_attributions ca
               JOIN campaign_deep_links cdl ON cdl.code = ca.deep_link_code
               WHERE ca.user_id = $1
                 AND (ca.attribution_expires_at IS NULL OR ca.attribution_expires_at > NOW())
                 AND cdl.status = 'active'
               ORDER BY ca.last_opened_at DESC LIMIT 1""",
            user_id,
        )
        return dict(row) if row else None
    except Exception as e:
        logger.warning(f"Failed to get active attribution for user {user_id}: {e}")
        return None


async def find_any_attribution(user_id: int, dl_code: str):
    """Look up any attribution by user and code, even expired — used for late-conversion tracking."""
    try:
        row = await db.fetch_one(
            """SELECT ca.*, cdl.id AS cdl_id, cdl.status AS dl_status,
                      cdl.campaign_run_id AS dl_run_id, cdl.attribution_end_at AS dl_attribution_end_at
               FROM campaign_attributions ca
               JOIN campaign_deep_links cdl ON cdl.code = ca.deep_link_code
               WHERE ca.user_id = $1 AND ca.deep_link_code = $2
               LIMIT 1""",
            user_id, dl_code,
        )
        return dict(row) if row else None
    except Exception as e:
        logger.warning(f"Failed to find any attribution for user {user_id}: {e}")
        return None


async def record_attributed_purchase(
    user_id: int, campaign_id: int, order_id: int, revenue: float,
    deep_link_id=None, is_late_conversion=False,
):
    """Increment attributed_orders/revenue on the attribution record.
    Also updates the per-link revenue counters on campaign_deep_links.
    Late conversions go into late_* columns, not into the main revenue/purchases counters.
    """
    try:
        await db.execute(
            """UPDATE campaign_attributions
               SET attributed_orders = attributed_orders + 1,
                   attributed_revenue = attributed_revenue + $1,
                   updated_at = NOW()
               WHERE user_id = $2 AND campaign_id = $3""",
            revenue, user_id, campaign_id,
        )
        if deep_link_id:
            if is_late_conversion:
                await db.execute(
                    """UPDATE campaign_deep_links
                       SET late_purchases_count = late_purchases_count + 1,
                           late_revenue_total   = late_revenue_total + $1
                       WHERE id = $2""",
                    revenue, deep_link_id,
                )
            else:
                await db.execute(
                    """UPDATE campaign_deep_links
                       SET purchases_count = purchases_count + 1,
                           revenue_total   = revenue_total + $1
                       WHERE id = $2""",
                    revenue, deep_link_id,
                )
    except Exception as e:
        logger.warning(f"Failed to record attributed purchase: {e}")


async def resolve_deep_link(code: str):
    """Resolve a deep link code to an ACTIVE campaign link. Returns None if expired or missing."""
    row = await db.fetch_one(
        """SELECT cdl.*, sc.id AS campaign_id, sc.name AS campaign_name, sc.status AS campaign_status,
                  sc.expire_at AS campaign_expire_at
           FROM campaign_deep_links cdl
           JOIN scheduled_campaigns sc ON sc.id = cdl.campaign_id
           WHERE cdl.code = $1 AND cdl.status = 'active'
           LIMIT 1""",
        code,
    )
    return dict(row) if row else None


async def resolve_any_deep_link(code: str):
    """Resolve any deep link code regardless of status — used for late-conversion detection."""
    row = await db.fetch_one(
        """SELECT cdl.*, sc.id AS campaign_id, sc.name AS campaign_name, sc.status AS campaign_status,
                  sc.expire_at AS campaign_expire_at
           FROM campaign_deep_links cdl
           JOIN scheduled_campaigns sc ON sc.id = cdl.campaign_id
           WHERE cdl.code = $1
           LIMIT 1""",
        code,
    )
    return dict(row) if row else None


async def generate_fresh_deep_link(campaign_id: int, run_id: int, bot_username: str, attribution_end_at=None):
    """Generate a brand-new deep link for a campaign run.
    Each promo_start produces its own unique link so stats stay per-run.
    """
    code = _generate_code()
    full_url = f"https://t.me/{bot_username}?start={code}" if bot_username else ""
    now = datetime.utcnow()
    link_id = await db.fetch_val(
        """INSERT INTO campaign_deep_links
           (campaign_id, campaign_run_id, code, deep_link_url, is_active, status,
            activated_at, attribution_start_at, attribution_end_at, created_at)
           VALUES ($1, $2, $3, $4, true, 'active', $5, $5, $6, $5) RETURNING id""",
        campaign_id, run_id, code, full_url, now, attribution_end_at,
    )
    logger.info(
        f"Campaign #{campaign_id} run #{run_id}: fresh deep link generated — "
        f"code={code} attribution_end={attribution_end_at}"
    )
    return {
        "id": link_id,
        "campaign_id": campaign_id,
        "campaign_run_id": run_id,
        "code": code,
        "deep_link_url": full_url,
        "status": "active",
        "activated_at": now,
        "attribution_start_at": now,
        "attribution_end_at": attribution_end_at,
    }


async def expire_campaign_run_deep_link(campaign_id: int):
    """Mark the active deep link for a campaign as expired.
    Also cuts all open attribution windows so no new revenue can be attributed.
    Called at promo_expiry AFTER the expiry message has been sent.
    """
    now = datetime.utcnow()
    link = await db.fetch_one(
        """SELECT * FROM campaign_deep_links
           WHERE campaign_id = $1 AND status = 'active'
           ORDER BY created_at DESC LIMIT 1""",
        campaign_id,
    )
    if not link:
        logger.warning(f"Campaign #{campaign_id}: no active deep link to expire")
        return None
    link_id = link["id"]
    await db.execute(
        """UPDATE campaign_deep_links
           SET status = 'expired', is_active = false,
               expired_at = $1,
               attribution_end_at = COALESCE(attribution_end_at, $1)
           WHERE id = $2""",
        now, link_id,
    )
    # Cut all open attribution windows for this campaign to NOW
    await db.execute(
        """UPDATE campaign_attributions
           SET attribution_expires_at = $1,
               attribution_end_at     = $1,
               updated_at             = NOW()
           WHERE campaign_id = $2
             AND (attribution_expires_at IS NULL OR attribution_expires_at > $1)""",
        now, campaign_id,
    )
    logger.info(
        f"Campaign #{campaign_id}: deep link #{link_id} ({link['code']}) expired. "
        f"All open attributions cut to {now}."
    )
    return link_id


async def _compute_next_times(campaign, base_start, base_expire, after_dt):
    repeat = campaign.get("repeat_mode", "once")
    if repeat == "once":
        return None, None

    if repeat == "daily":
        delta = timedelta(days=1)
    elif repeat == "weekly":
        delta = timedelta(weeks=1)
    elif repeat == "monthly":
        delta = timedelta(days=30)
    else:
        return None, None

    next_start = base_start + delta
    next_expire = base_expire + delta
    while next_start <= after_dt:
        next_start += delta
        next_expire += delta
    return next_start, next_expire


def _render_template(body_text, variables):
    result = body_text
    for k, v in variables.items():
        result = result.replace("{" + k + "}", str(v))
    return result


_TAG_RE = re.compile(
    r'<(/?)('
    r'b|strong|i|em|u|ins|s|strike|del|'
    r'code|pre|tg-spoiler|blockquote|'
    r'a|tg-emoji'
    r')(\s[^>]*)?>',
    re.IGNORECASE,
)
_ATTR_RE = re.compile(r'([\w-]+)\s*=\s*"([^"]*)"')


def _utf16_len(text: str) -> int:
    count = 0
    for ch in text:
        cp = ord(ch)
        count += 2 if cp > 0xFFFF else 1
    return count


def _py_offset_to_utf16(text: str, py_offset: int) -> int:
    count = 0
    for i, ch in enumerate(text):
        if i >= py_offset:
            break
        cp = ord(ch)
        count += 2 if cp > 0xFFFF else 1
    return count


def _parse_html_to_entities(html_text: str):
    tag_map = {
        "b": "bold", "strong": "bold",
        "i": "italic", "em": "italic",
        "u": "underline", "ins": "underline",
        "s": "strikethrough", "strike": "strikethrough", "del": "strikethrough",
        "code": "code", "pre": "pre",
        "tg-spoiler": "spoiler",
        "blockquote": "blockquote",
    }
    entities = []
    stack = []
    plain = []
    py_pos = 0
    last_end = 0

    for m in _TAG_RE.finditer(html_text):
        chunk = html_text[last_end:m.start()]
        if chunk:
            decoded = html_unescape(chunk)
            plain.append(decoded)
            py_pos += len(decoded)
        last_end = m.end()

        is_close = m.group(1) == "/"
        tag_name = m.group(2).lower()
        attrs_str = m.group(3) or ""

        if tag_name in ("a", "tg-emoji"):
            attrs = dict(_ATTR_RE.findall(attrs_str))

        if is_close:
            for idx in range(len(stack) - 1, -1, -1):
                if stack[idx]["tag"] == tag_name:
                    opened = stack.pop(idx)
                    py_length = py_pos - opened["py_offset"]
                    if py_length > 0:
                        ent = {"type": opened["etype"], "py_offset": opened["py_offset"], "py_length": py_length}
                        if "url" in opened:
                            ent["url"] = opened["url"]
                        if "custom_emoji_id" in opened:
                            ent["custom_emoji_id"] = opened["custom_emoji_id"]
                        if "language" in opened:
                            ent["language"] = opened["language"]
                        entities.append(ent)
                    break
        else:
            if tag_name == "tg-emoji":
                emoji_id = attrs.get("emoji-id", "")
                stack.append({"tag": tag_name, "py_offset": py_pos, "etype": "custom_emoji", "custom_emoji_id": emoji_id})
            elif tag_name == "a":
                href = attrs.get("href", "")
                if href.startswith("tg://"):
                    stack.append({"tag": tag_name, "py_offset": py_pos, "etype": "text_mention", "url": href})
                else:
                    stack.append({"tag": tag_name, "py_offset": py_pos, "etype": "text_link", "url": href})
            elif tag_name == "pre":
                lang = attrs.get("language", "") if attrs_str else ""
                entry = {"tag": tag_name, "py_offset": py_pos, "etype": "pre"}
                if lang:
                    entry["language"] = lang
                stack.append(entry)
            elif tag_name in tag_map:
                stack.append({"tag": tag_name, "py_offset": py_pos, "etype": tag_map[tag_name]})

    tail = html_text[last_end:]
    if tail:
        decoded = html_unescape(tail)
        plain.append(decoded)

    final_text = "".join(plain)

    utf16_entities = []
    for ent in entities:
        py_off = ent["py_offset"]
        py_len = ent["py_length"]
        span_text = final_text[py_off:py_off + py_len]
        u16_offset = _py_offset_to_utf16(final_text, py_off)
        u16_length = _utf16_len(span_text)
        tg_ent = {"type": ent["type"], "offset": u16_offset, "length": u16_length}
        if "url" in ent:
            tg_ent["url"] = ent["url"]
        if "custom_emoji_id" in ent:
            tg_ent["custom_emoji_id"] = ent["custom_emoji_id"]
        if "language" in ent:
            tg_ent["language"] = ent["language"]
        utf16_entities.append(tg_ent)

    return final_text, utf16_entities


def _u16_slice(text: str, u16_off: int, u16_len: int) -> str:
    acc = 0
    start_py = None
    end_py = None
    for i, ch in enumerate(text):
        if acc == u16_off:
            start_py = i
        cp = ord(ch)
        acc += 2 if cp > 0xFFFF else 1
        if acc == u16_off + u16_len:
            end_py = i + 1
            break
    if start_py is not None and end_py is not None:
        return text[start_py:end_py]
    return ""


def _validate_entities(text: str, entities: list) -> list:
    total_u16 = _utf16_len(text)
    valid = []

    char_boundaries = set()
    acc = 0
    for ch in text:
        char_boundaries.add(acc)
        cp = ord(ch)
        acc += 2 if cp > 0xFFFF else 1
    char_boundaries.add(acc)

    prev_off = -1
    for ent in entities:
        off = ent["offset"]
        length = ent["length"]
        end = off + length

        if off < 0 or length <= 0 or end > total_u16:
            logger.warning(
                f"Entity validation REJECTED: type={ent['type']} offset={off} "
                f"length={length} end={end} text_u16_len={total_u16} — out of bounds"
            )
            continue

        if off not in char_boundaries:
            logger.warning(
                f"Entity validation REJECTED: type={ent['type']} offset={off} "
                f"length={length} — offset lands inside a surrogate pair"
            )
            continue

        if end not in char_boundaries:
            logger.warning(
                f"Entity validation REJECTED: type={ent['type']} offset={off} "
                f"length={length} end={end} — end lands inside a surrogate pair"
            )
            continue

        span = _u16_slice(text, off, length)
        if ent["type"] == "custom_emoji" and span:
            span_u16 = _utf16_len(span)
            if span_u16 != length:
                logger.warning(
                    f"Entity validation REJECTED: type=custom_emoji offset={off} "
                    f"length={length} — span '{span!r}' u16_len={span_u16} mismatch"
                )
                continue

        valid.append(ent)

    return valid





_EMOJI_RE = re.compile(
    "["
    "\U0001F600-\U0001F64F"
    "\U0001F300-\U0001F5FF"
    "\U0001F680-\U0001F6FF"
    "\U0001F1E0-\U0001F1FF"
    "\U0001F900-\U0001F9FF"
    "\U0001FA00-\U0001FA6F"
    "\U0001FA70-\U0001FAFF"
    "\U00002702-\U000027B0"
    "\U000024C2-\U0001F251"
    "\U00002600-\U000026FF"
    "\U00002700-\U000027BF"
    "\U0000FE00-\U0000FE0F"
    "\U0000200D"
    "\U000020E3"
    "\U00003030\U000000A9\U000000AE"
    "\U00002B05-\U00002B07"
    "\U00002934-\U00002935"
    "\U000025AA-\U000025AB"
    "\U000025B6\U000025C0"
    "\U000025FB-\U000025FE"
    "\U00002B1B-\U00002B1C"
    "\U00002B50\U00002B55"
    "\U0000231A-\U0000231B"
    "\U000023E9-\U000023F3"
    "\U000023F8-\U000023FA"
    "\U0000203C\U00002049"
    "\U0000200D"
    "\U00002139"
    "\U0000E000-\U0000F8FF"
    "\U000025AA-\U000025AB"
    "]+",
    flags=re.UNICODE,
)


def _is_emoji_char(ch: str) -> bool:
    if _EMOJI_RE.match(ch):
        return True
    cat = unicodedata.category(ch)
    if cat == "So":
        return True
    return False


def _render_channel_safe(html_text: str):
    plain_text, entities = _parse_html_to_entities(html_text)

    removed_custom = sum(1 for e in entities if e["type"] == "custom_emoji")
    channel_entities = [e for e in entities if e["type"] != "custom_emoji"]

    keep_mask = [not _is_emoji_char(ch) for ch in plain_text]
    removed_emoji_count = sum(1 for k in keep_mask if not k)

    old_py_to_new = [0] * (len(plain_text) + 1)
    new_pos = 0
    for i in range(len(plain_text)):
        old_py_to_new[i] = new_pos
        if keep_mask[i]:
            new_pos += 1
    old_py_to_new[len(plain_text)] = new_pos

    stripped_text = "".join(ch for ch, keep in zip(plain_text, keep_mask) if keep)

    def _u16_to_py(text, u16_off):
        acc = 0
        for i, ch in enumerate(text):
            if acc == u16_off:
                return i
            acc += 2 if ord(ch) > 0xFFFF else 1
        return len(text)

    remapped = []
    for ent in channel_entities:
        py_start = _u16_to_py(plain_text, ent["offset"])
        py_end = _u16_to_py(plain_text, ent["offset"] + ent["length"])

        new_start = old_py_to_new[py_start]
        new_end = old_py_to_new[py_end]
        new_span = stripped_text[new_start:new_end]

        if not new_span.strip() and ent["type"] not in ("pre", "code"):
            continue

        u16_off = _py_offset_to_utf16(stripped_text, new_start)
        u16_len = _utf16_len(new_span)
        if u16_len <= 0:
            continue

        new_ent = {"type": ent["type"], "offset": u16_off, "length": u16_len}
        if "url" in ent:
            new_ent["url"] = ent["url"]
        if "language" in ent:
            new_ent["language"] = ent["language"]
        remapped.append(new_ent)

    lines = stripped_text.split('\n')
    clean_lines = []
    for line in lines:
        collapsed = re.sub(r'[ \t]+', ' ', line).strip()
        if collapsed:
            clean_lines.append(collapsed)
        elif clean_lines and clean_lines[-1]:
            clean_lines.append('')
    while clean_lines and not clean_lines[-1]:
        clean_lines.pop()

    cleaned_text = '\n'.join(clean_lines)

    if cleaned_text != stripped_text:
        clean_py_map = [0] * (len(stripped_text) + 1)
        si = 0
        ci = 0
        s = stripped_text
        c = cleaned_text
        while si < len(s):
            if ci < len(c) and s[si] == c[ci]:
                clean_py_map[si] = ci
                ci += 1
            else:
                clean_py_map[si] = ci
            si += 1
        clean_py_map[len(s)] = len(c)

        final_entities = []
        for ent in remapped:
            py_s = _u16_to_py(stripped_text, ent["offset"])
            py_e = _u16_to_py(stripped_text, ent["offset"] + ent["length"])

            cs = clean_py_map[py_s]
            ce = clean_py_map[py_e]
            span = cleaned_text[cs:ce]

            if not span.strip() and ent["type"] not in ("pre", "code"):
                continue

            cu16_off = _py_offset_to_utf16(cleaned_text, cs)
            cu16_len = _utf16_len(span)
            if cu16_len <= 0:
                continue

            new_ent = {"type": ent["type"], "offset": cu16_off, "length": cu16_len}
            if "url" in ent:
                new_ent["url"] = ent["url"]
            if "language" in ent:
                new_ent["language"] = ent["language"]
            final_entities.append(new_ent)

        remapped = final_entities
        stripped_text = cleaned_text

    validated = _validate_entities(stripped_text, remapped)
    return stripped_text, validated, removed_custom, removed_emoji_count


async def _send_channel_message_direct(chat_id, html_text, raw_reply_markup, camp_id, mk, run_id):
    plain_text, entities, removed_custom, removed_emoji = _render_channel_safe(html_text)

    text_u16_len = _utf16_len(plain_text)

    ent_summary = []
    for e in entities:
        span = _u16_slice(plain_text, e["offset"], e["length"])
        s = f"  {e['type']} off={e['offset']} len={e['length']} span={span!r}"
        if e.get("url"):
            s += f" url={e['url'][:60]}"
        ent_summary.append(s)

    markup_summary = json.dumps(raw_reply_markup, ensure_ascii=False)[:500] if raw_reply_markup else "(none)"

    payload = {
        "chat_id": chat_id,
        "text": plain_text,
        "disable_web_page_preview": True,
    }
    if entities:
        payload["entities"] = entities
    if raw_reply_markup is not None:
        payload["reply_markup"] = raw_reply_markup

    payload_json = json.dumps(payload, ensure_ascii=False)

    logger.info(
        f"Campaign #{camp_id} CHANNEL_DIRECT_SEND: channel={chat_id} run={mk}\n"
        f"  message_mode=plain_channel\n"
        f"  removed_custom_emoji_count={removed_custom}\n"
        f"  removed_unicode_emoji_count={removed_emoji}\n"
        f"  remaining_entity_count={len(entities)}\n"
        f"  direct_channel_send=true\n"
        f"  text_u16_len={text_u16_len}\n"
        f"  text_preview={plain_text[:300]!r}\n"
        + "\n".join(ent_summary) + "\n"
        f"  reply_markup={markup_summary}\n"
        f"  payload_len={len(payload_json)}"
    )

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()

    ok = result.get("ok", False)
    if ok:
        msg_id = result.get("result", {}).get("message_id", 0)
        logger.info(
            f"Campaign #{camp_id} CHANNEL_DIRECT_OK: channel={chat_id} msg_id={msg_id}\n"
            f"  direct_channel_send=true removed_custom={removed_custom} removed_emoji={removed_emoji}"
        )
        return {"ok": True, "message_id": msg_id}

    err_code = result.get("error_code", 0)
    err_desc = result.get("description", "unknown error")
    logger.error(
        f"Campaign #{camp_id} CHANNEL_DIRECT_FAILED: channel={chat_id} code={err_code} desc={err_desc}\n"
        f"  direct_channel_send=true\n"
        f"  text_preview={plain_text[:300]!r}\n"
        f"  reply_markup={markup_summary}\n"
        f"  payload_json={payload_json[:500]}\n"
        f"  tg_response={json.dumps(result, ensure_ascii=False)[:500]}"
    )
    return {"ok": False, "error": err_desc, "error_code": err_code}


async def _copy_message_to_channel(channel_id, source_chat_id, source_message_id, camp_id, mk, run_id):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/copyMessage"
    payload = {
        "chat_id": channel_id,
        "from_chat_id": source_chat_id,
        "message_id": source_message_id,
    }
    logger.info(
        f"Campaign #{camp_id} CHANNEL_COPY_SEND: channel={channel_id} "
        f"source_chat={source_chat_id} source_msg={source_message_id} run={mk}"
    )
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()
    ok = result.get("ok", False)
    if ok:
        msg_id = result.get("result", {}).get("message_id", 0)
        logger.info(
            f"Campaign #{camp_id} CHANNEL_COPY_OK: channel={channel_id} msg_id={msg_id}"
        )
        return {"ok": True, "message_id": msg_id}
    err_code = result.get("error_code", 0)
    err_desc = result.get("description", "unknown error")
    logger.error(
        f"Campaign #{camp_id} CHANNEL_COPY_FAILED: channel={channel_id} "
        f"code={err_code} desc={err_desc}"
    )
    return {"ok": False, "error": err_desc, "error_code": err_code}


async def _forward_message_to_channel(channel_id, source_chat_id, source_message_id, camp_id, mk, run_id):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/forwardMessage"
    payload = {
        "chat_id": channel_id,
        "from_chat_id": source_chat_id,
        "message_id": source_message_id,
    }
    logger.info(
        f"Campaign #{camp_id} CHANNEL_FORWARD_SEND: channel={channel_id} "
        f"source_chat={source_chat_id} source_msg={source_message_id} run={mk}"
    )
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()
    ok = result.get("ok", False)
    if ok:
        msg_id = result.get("result", {}).get("message_id", 0)
        logger.info(
            f"Campaign #{camp_id} CHANNEL_FORWARD_OK: channel={channel_id} msg_id={msg_id}"
        )
        return {"ok": True, "message_id": msg_id}
    err_code = result.get("error_code", 0)
    err_desc = result.get("description", "unknown error")
    logger.error(
        f"Campaign #{camp_id} CHANNEL_FORWARD_FAILED: channel={channel_id} "
        f"code={err_code} desc={err_desc}"
    )
    return {"ok": False, "error": err_desc, "error_code": err_code}


async def _send_source_message(html_text, raw_reply_markup, camp_id, mk, run_id):
    from bot.config import ADMIN_CHAT_ID
    if not ADMIN_CHAT_ID:
        logger.error(
            f"Campaign #{camp_id} SOURCE_MSG_FAILED: ADMIN_CHAT_ID not configured. "
            f"copy/forward channel mode requires a source chat. run={mk}"
        )
        return None
    result = await _send_campaign_message_raw(
        chat_id=ADMIN_CHAT_ID,
        html_text=html_text,
        raw_reply_markup=raw_reply_markup,
        camp_id=camp_id, mk=mk, run_id=run_id, target_type="source",
    )
    if result.get("ok"):
        logger.info(
            f"Campaign #{camp_id} SOURCE_MSG_OK: chat={ADMIN_CHAT_ID} msg_id={result['message_id']} run={mk}"
        )
        return {"chat_id": ADMIN_CHAT_ID, "message_id": result["message_id"]}
    logger.error(
        f"Campaign #{camp_id} SOURCE_MSG_FAILED: chat={ADMIN_CHAT_ID} error={result.get('error')} run={mk}"
    )
    return None


_VALID_DELIVERY_MODES = ("copy", "forward", "direct")


async def get_channel_delivery_mode() -> str:
    try:
        row = await db.fetch_one(
            "SELECT value FROM bot_settings WHERE key = 'campaign_channel_delivery_mode'"
        )
        if row and row["value"] in _VALID_DELIVERY_MODES:
            return row["value"]
    except Exception as e:
        logger.warning(f"Failed to read channel delivery mode: {e}")
    return "direct"


async def _send_campaign_to_channels(
    channel_ids: list,
    channel_rendered: str,
    raw_markup,
    camp_id: int,
    mk: str,
    run_id: int,
    mode: str,
    bot: Bot,
) -> dict:
    channels_sent = 0
    channels_failed = 0
    source_chat_id = None
    source_message_id = None

    delivery_method_label = {
        "copy": "copy_message",
        "forward": "forward_message",
        "direct": "direct_channel",
    }.get(mode, "direct_channel")

    logger.info(
        f"Campaign #{camp_id} CHANNEL_DISPATCH: mode={mode} "
        f"channels={len(channel_ids)} delivery_method={delivery_method_label} run={mk}"
    )

    if mode in ("copy", "forward") and channel_ids:
        source = await _send_source_message(
            html_text=channel_rendered,
            raw_reply_markup=raw_markup,
            camp_id=camp_id, mk=mk, run_id=run_id,
        )
        if source is None:
            logger.error(
                f"Campaign #{camp_id} CHANNEL_SKIP_ALL: source message failed, "
                f"skipping all {len(channel_ids)} channel(s) in {mode} mode. run={mk}"
            )
            for ch in channel_ids:
                ch_id = int(ch) if str(ch).lstrip("-").isdigit() else ch
                await db.execute(
                    """INSERT INTO campaign_delivery_logs
                       (campaign_run_id, campaign_id, target_type, telegram_id, message_kind,
                        delivery_status, error_text, delivery_method)
                       VALUES ($1, $2, 'channel', $3, $4, 'failed', $5, $6)""",
                    run_id, camp_id, ch_id if isinstance(ch_id, int) else 0, mk,
                    f"source message failed - ADMIN_CHAT_ID missing or send error",
                    delivery_method_label,
                )
                channels_failed += 1
            return {
                "channels_sent": 0,
                "channels_failed": channels_failed,
                "source_chat_id": None,
                "source_message_id": None,
                "delivery_method": delivery_method_label,
            }
        source_chat_id = source["chat_id"]
        source_message_id = source["message_id"]

    for ch in channel_ids:
        ch_id = int(ch) if str(ch).lstrip("-").isdigit() else ch
        try:
            if mode == "copy":
                ch_result = await _copy_message_to_channel(
                    channel_id=ch_id,
                    source_chat_id=source_chat_id,
                    source_message_id=source_message_id,
                    camp_id=camp_id, mk=mk, run_id=run_id,
                )
            elif mode == "forward":
                ch_result = await _forward_message_to_channel(
                    channel_id=ch_id,
                    source_chat_id=source_chat_id,
                    source_message_id=source_message_id,
                    camp_id=camp_id, mk=mk, run_id=run_id,
                )
            else:
                ch_result = await _send_channel_message_direct(
                    chat_id=ch_id,
                    html_text=channel_rendered,
                    raw_reply_markup=raw_markup,
                    camp_id=camp_id, mk=mk, run_id=run_id,
                )

            if ch_result["ok"]:
                await db.execute(
                    """INSERT INTO campaign_delivery_logs
                       (campaign_run_id, campaign_id, target_type, telegram_id, message_kind,
                        delivery_status, telegram_message_id, delivery_method, source_message_id)
                       VALUES ($1, $2, 'channel', $3, $4, 'sent', $5, $6, $7)""",
                    run_id, camp_id, ch_id if isinstance(ch_id, int) else 0, mk,
                    ch_result["message_id"], delivery_method_label,
                    source_message_id,
                )
                channels_sent += 1
            else:
                await db.execute(
                    """INSERT INTO campaign_delivery_logs
                       (campaign_run_id, campaign_id, target_type, telegram_id, message_kind,
                        delivery_status, error_text, delivery_method, source_message_id)
                       VALUES ($1, $2, 'channel', $3, $4, 'failed', $5, $6, $7)""",
                    run_id, camp_id, ch_id if isinstance(ch_id, int) else 0, mk,
                    f"{delivery_method_label} failed: {ch_result.get('error', '')}".strip()[:500],
                    delivery_method_label, source_message_id,
                )
                channels_failed += 1
        except Exception as e:
            logger.error(
                f"Campaign #{camp_id} channel_{mode}_exception: "
                f"channel={ch_id} error={e} run={mk}"
            )
            await db.execute(
                """INSERT INTO campaign_delivery_logs
                   (campaign_run_id, campaign_id, target_type, telegram_id, message_kind,
                    delivery_status, error_text, delivery_method, source_message_id)
                   VALUES ($1, $2, 'channel', $3, $4, 'failed', $5, $6, $7)""",
                run_id, camp_id, ch_id if isinstance(ch_id, int) else 0, mk,
                str(e)[:500], delivery_method_label, source_message_id,
            )
            channels_failed += 1

    logger.info(
        f"Campaign #{camp_id} CHANNEL_DISPATCH_SUMMARY: mode={mode} "
        f"targeted={len(channel_ids)} sent={channels_sent} failed={channels_failed} "
        f"source_chat={source_chat_id} source_msg={source_message_id} run={mk}"
    )

    return {
        "channels_sent": channels_sent,
        "channels_failed": channels_failed,
        "source_chat_id": source_chat_id,
        "source_message_id": source_message_id,
        "delivery_method": delivery_method_label,
    }


async def _send_campaign_message_raw(chat_id, html_text, raw_reply_markup, camp_id, mk, run_id, target_type="channel"):
    plain_text, entities = _parse_html_to_entities(html_text)

    text_u16_len = _utf16_len(plain_text)
    validated = _validate_entities(plain_text, entities)
    rejected_count = len(entities) - len(validated)

    ent_summary = []
    for e in validated:
        span = _u16_slice(plain_text, e["offset"], e["length"])
        s = f"  {e['type']} off={e['offset']} len={e['length']} end={e['offset']+e['length']} span={span!r}"
        if e.get("custom_emoji_id"):
            s += f" emoji_id={e['custom_emoji_id']}"
        ent_summary.append(s)

    markup_summary = json.dumps(raw_reply_markup, ensure_ascii=False)[:500] if raw_reply_markup else "(none)"

    payload = {
        "chat_id": chat_id,
        "text": plain_text,
        "disable_web_page_preview": True,
    }
    if validated:
        payload["entities"] = validated
    if raw_reply_markup is not None:
        payload["reply_markup"] = raw_reply_markup

    payload_json = json.dumps(payload, ensure_ascii=False)

    custom_emoji_count = sum(1 for e in validated if e["type"] == "custom_emoji")
    emoji_chars_in_text = sum(1 for ch in plain_text if _is_emoji_char(ch))

    logger.info(
        f"Campaign #{camp_id} SEND_DEBUG: {target_type}={chat_id} run={mk}\n"
        f"  message_mode=rich_user\n"
        f"  custom_emoji_count={custom_emoji_count}\n"
        f"  emoji_count={emoji_chars_in_text}\n"
        f"  entity_count={len(validated)}\n"
        f"  text_py_len={len(plain_text)} text_u16_len={text_u16_len}\n"
        f"  text_repr={plain_text!r}\n"
        f"  entities_total={len(entities)} validated={len(validated)} rejected={rejected_count}\n"
        + "\n".join(ent_summary) + "\n"
        f"  reply_markup={markup_summary}\n"
        f"  parse_mode_present=False\n"
        f"  payload_len={len(payload_json)}\n"
        f"  payload_json={payload_json[:800]}"
    )

    if rejected_count > 0:
        logger.error(
            f"Campaign #{camp_id} entity_validation_failed: "
            f"{target_type}={chat_id} rejected={rejected_count} of {len(entities)} entities "
            f"text_u16_len={text_u16_len} run={mk}"
        )

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        result = resp.json()

    ok = result.get("ok", False)
    if ok:
        msg_id = result.get("result", {}).get("message_id", 0)
        ret_ents = result.get("result", {}).get("entities", [])
        ret_markup = result.get("result", {}).get("reply_markup", {})

        stripped_emoji = len([e for e in validated if e["type"] == "custom_emoji"]) - len([e for e in ret_ents if e.get("type") == "custom_emoji"])
        ret_btns = []
        for row in ret_markup.get("inline_keyboard", []):
            for b in row:
                info = b.get("text", "?")
                if b.get("style"):
                    info += f" style={b['style']}"
                if b.get("icon_custom_emoji_id"):
                    info += f" icon={b['icon_custom_emoji_id']}"
                ret_btns.append(info)

        logger.info(
            f"Campaign #{camp_id} SEND_OK: {target_type}={chat_id} msg_id={msg_id}\n"
            f"  entities_sent={len(validated)} entities_returned={len(ret_ents)} custom_emoji_stripped={stripped_emoji}\n"
            f"  buttons_returned=[{', '.join(ret_btns)}]\n"
            f"  tg_response_entities={json.dumps(ret_ents, ensure_ascii=False)[:300]}"
        )
        if stripped_emoji > 0:
            logger.warning(
                f"Campaign #{camp_id} CUSTOM_EMOJI_STRIPPED: {target_type}={chat_id} "
                f"Telegram accepted payload but stripped {stripped_emoji} custom_emoji entity(ies). "
                f"This is a Telegram Bot API limitation for {target_type} targets. "
                f"Custom emoji entities work in private/group/supergroup chats only."
            )
        return {"ok": True, "message_id": msg_id}

    err_code = result.get("error_code", 0)
    err_desc = result.get("description", "unknown error")

    if err_code == 400 and ("entity" in err_desc.lower() or "emoji" in err_desc.lower()):
        fail_type = "send_failed_custom_emoji_payload"
    elif err_code == 400 and "button" in err_desc.lower():
        fail_type = "send_failed_button_payload"
    elif err_code == 400:
        fail_type = "send_failed_bad_request"
    elif err_code == 403:
        fail_type = "send_failed_forbidden"
    elif "entity" in err_desc.lower():
        fail_type = "send_failed_invalid_entities"
    else:
        fail_type = f"send_failed_{err_code}"

    logger.error(
        f"Campaign #{camp_id} {fail_type}: "
        f"{target_type}={chat_id} code={err_code} desc={err_desc}\n"
        f"  entities_count={len(validated)} run={mk} text_u16_len={text_u16_len}\n"
        f"  reply_markup={markup_summary}\n"
        f"  payload_json={payload_json[:500]}\n"
        f"  tg_response={json.dumps(result, ensure_ascii=False)[:500]}"
    )
    return {"ok": False, "error": err_desc, "fail_type": fail_type, "error_code": err_code}


_VALID_STYLES = {"primary", "success", "danger"}


def _normalize_button(raw: dict) -> dict:
    b = dict(raw)
    b.setdefault("id", "")
    b.setdefault("type", "url")
    b.setdefault("text", "Button")
    b.setdefault("url", "")
    b.setdefault("row", 1)
    b.setdefault("enabled", True)
    b["icon_custom_emoji_id"] = (b.get("icon_custom_emoji_id") or b.get("emoji_id") or "").strip()
    raw_style = (b.get("style") or "").strip().lower()
    b["style"] = raw_style if raw_style in _VALID_STYLES else ""
    if b.get("type") == "deep_link" and not b.get("url"):
        b["url"] = "{deep_link}"
    return b


def _resolve_button_url(b: dict, deep_link_url: str, pfx: str) -> str | None:
    raw_url = (b.get("url") or "").strip()
    if raw_url == "{deep_link}" or (not raw_url and b.get("type") == "deep_link"):
        final_url = deep_link_url or "https://t.me"
    elif "{deep_link}" in raw_url and deep_link_url:
        final_url = raw_url.replace("{deep_link}", deep_link_url)
    elif not raw_url:
        final_url = deep_link_url or "https://t.me"
        logger.warning(f"{pfx}: button '{b['text']}' has no URL — using deep_link")
    else:
        final_url = raw_url

    if not final_url.startswith(("http://", "https://", "tg://")):
        logger.warning(f"{pfx}: button '{b['text']}' invalid URL '{final_url[:80]}' — skipping")
        return None
    return final_url


def _compile_raw_reply_markup(buttons_json, deep_link_url="",
                               campaign_id=None, template_id=None, run_type=None):
    pfx = f"[btn_compile] camp={campaign_id} tpl={template_id} run={run_type}"

    if not buttons_json:
        return None
    try:
        raw_list = json.loads(buttons_json) if isinstance(buttons_json, str) else buttons_json
    except (json.JSONDecodeError, TypeError) as e:
        logger.warning(f"{pfx}: invalid buttons JSON — {e}")
        return None

    if not raw_list or not isinstance(raw_list, list):
        return None

    buttons = [_normalize_button(b) for b in raw_list]
    buttons = [b for b in buttons if b.get("enabled", True) is not False]
    if not buttons:
        return None

    logger.info(f"{pfx}: {len(buttons)} enabled button(s) — building raw keyboard")

    rows_map: dict = {}
    for b in buttons:
        rn = int(b.get("row") or 1)
        rows_map.setdefault(rn, []).append(b)

    tg_rows = []
    total = 0
    for rn in sorted(rows_map.keys()):
        tg_row = []
        for b in rows_map[rn]:
            final_url = _resolve_button_url(b, deep_link_url, pfx)
            if final_url is None:
                continue

            final_text = (b.get("text") or "Button").strip() or "Button"
            btn_dict: dict = {"text": final_text, "url": final_url}

            style_val = b.get("style", "")
            emoji_id = b.get("icon_custom_emoji_id", "")

            if style_val and style_val in _VALID_STYLES:
                btn_dict["style"] = style_val
            if emoji_id:
                btn_dict["icon_custom_emoji_id"] = emoji_id

            logger.info(
                f"{pfx}: row={rn} text='{final_text}' "
                f"style={btn_dict.get('style', '(none)')} "
                f"icon_custom_emoji_id={btn_dict.get('icon_custom_emoji_id', '(none)')} "
                f"url='{final_url[:70]}'"
            )
            tg_row.append(btn_dict)
            total += 1

        if tg_row:
            tg_rows.append(tg_row)

    if not tg_rows:
        return None

    logger.info(f"{pfx}: {total} button(s) compiled across {len(tg_rows)} row(s)")
    return {"inline_keyboard": tg_rows}


async def _get_target_ids(campaign_id, message_kind, bot: Bot):
    targets = await db.fetch_all(
        "SELECT * FROM campaign_targets WHERE campaign_id = $1 AND message_kind = $2",
        campaign_id, message_kind,
    )
    if not targets and message_kind == "promo_expiry":
        targets = await db.fetch_all(
            "SELECT * FROM campaign_targets WHERE campaign_id = $1 AND message_kind = 'promo_start'",
            campaign_id,
        )
        if targets:
            logger.info(f"Campaign #{campaign_id}: no promo_expiry targets, using promo_start targets as fallback")
    user_ids = set()
    channel_ids = []
    has_channel_target = False

    for t in targets:
        tt = t["target_type"]
        if tt == "all_users":
            rows = await db.fetch_all("SELECT telegram_id FROM users WHERE is_banned = 0")
            user_ids.update(r["telegram_id"] for r in rows)
        elif tt == "paid_users":
            rows = await db.fetch_all(
                "SELECT DISTINCT u.telegram_id FROM users u JOIN orders o ON o.user_id = u.id WHERE o.status = 'delivered' AND u.is_banned = 0"
            )
            user_ids.update(r["telegram_id"] for r in rows)
        elif tt == "resellers":
            rows = await db.fetch_all(
                "SELECT telegram_id FROM users WHERE reseller_id IS NOT NULL AND is_banned = 0"
            )
            user_ids.update(r["telegram_id"] for r in rows)
        elif tt == "active_users":
            rows = await db.fetch_all(
                "SELECT telegram_id FROM users WHERE is_banned = 0 AND created_at > NOW() - INTERVAL '30 days'"
            )
            user_ids.update(r["telegram_id"] for r in rows)
        elif tt == "clicked_users":
            rows = await db.fetch_all(
                "SELECT DISTINCT telegram_user_id FROM campaign_link_events WHERE campaign_id = $1 AND event_type IN ('open','start','click')",
                campaign_id,
            )
            user_ids.update(r["telegram_user_id"] for r in rows)
        elif tt == "purchased_users":
            rows = await db.fetch_all(
                "SELECT DISTINCT telegram_user_id FROM campaign_link_events WHERE campaign_id = $1 AND event_type = 'purchase'",
                campaign_id,
            )
            user_ids.update(r["telegram_user_id"] for r in rows)
        elif tt == "channels":
            has_channel_target = True
            val = (t.get("target_value") or "").strip()
            if val:
                try:
                    channels = json.loads(val)
                    channel_ids.extend(channels)
                except (json.JSONDecodeError, TypeError):
                    channel_ids.append(val)

    if has_channel_target and not channel_ids:
        try:
            campaign_row = await db.fetch_one(
                "SELECT channel_targets_json FROM scheduled_campaigns WHERE id = $1",
                campaign_id,
            )
            if campaign_row:
                raw = campaign_row.get("channel_targets_json") or "[]"
                config_ids = json.loads(raw) if isinstance(raw, str) else (raw or [])
                if config_ids:
                    ch_rows = await db.fetch_all(
                        "SELECT resolved_chat_id FROM configured_channels WHERE id = ANY($1::int[]) AND is_enabled = true AND is_validated = true",
                        config_ids,
                    )
                    for r in ch_rows:
                        cid = r.get("resolved_chat_id")
                        if cid:
                            channel_ids.append(int(cid))
                    logger.info(
                        f"Campaign #{campaign_id}: resolved {len(channel_ids)} channel(s) from channel_targets_json {config_ids}"
                    )
        except Exception as e:
            logger.warning(f"Campaign #{campaign_id}: failed to resolve channel_targets_json: {e}")

    return list(user_ids), channel_ids


async def _activate_campaign_discount(campaign, generated_discount_value=None):
    mode = campaign.get("campaign_mode", "fixed_plan")
    camp_id = campaign["id"]

    if mode == "fixed_plan":
        plan_id = campaign.get("linked_discount_plan_id")
        if plan_id:
            await db.execute("UPDATE discount_plans SET is_active = true WHERE id = $1", plan_id)
            from bot.services.user_discount import invalidate_cache
            invalidate_cache()
        invalidate_campaign_cache()
        return
    if mode == "message_only":
        invalidate_campaign_cache()
        return

    rules = await db.fetch_all(
        "SELECT * FROM campaign_discount_rules WHERE campaign_id = $1", camp_id
    )
    if not rules:
        invalidate_campaign_cache()
        return

    old_auto_plan_id = campaign.get("auto_discount_plan_id")
    if old_auto_plan_id:
        try:
            await db.execute("UPDATE discount_plans SET is_active = false WHERE id = $1", old_auto_plan_id)
        except Exception:
            pass

    rule_cat_ids = set()
    has_duration = False
    for r in rules:
        rd = dict(r)
        if rd.get("applies_to_category_id") is not None:
            rule_cat_ids.add(rd["applies_to_category_id"])
        if rd.get("applies_to_duration_id") is not None:
            has_duration = True

    if not rule_cat_ids:
        apply_scope = "all_categories"
    elif len(rule_cat_ids) == 1 and not has_duration:
        apply_scope = "one_category"
    else:
        apply_scope = "per_category_duration_prices"

    plan_name = f"[Campaign] {campaign.get('name', 'Auto')}"
    plan_id = await db.fetch_val(
        """INSERT INTO discount_plans (name, description, is_active, apply_scope, is_campaign_generated)
           VALUES ($1, $2, true, $3, true) RETURNING id""",
        plan_name, f"Auto-generated by campaign #{camp_id}", apply_scope,
    )

    for rule_row in rules:
        rule = dict(rule_row)
        disc_mode = rule.get("discount_mode", "fixed_percent")
        cat_id = rule.get("applies_to_category_id")
        dur_id = rule.get("applies_to_duration_id")

        discount_type = None
        discount_value = None
        override_price = None

        if disc_mode == "fixed_percent":
            discount_type = "percent"
            discount_value = float(rule.get("fixed_value") or 0)
        elif disc_mode == "random_percent":
            discount_type = "percent"
            if generated_discount_value is not None:
                discount_value = generated_discount_value
            else:
                mn = float(rule.get("min_value") or 0)
                mx = float(rule.get("max_value") or mn)
                discount_value = round(random.uniform(mn, mx), 1)
        elif disc_mode == "fixed_price_override":
            discount_type = "fixed"
            override_price = float(rule.get("fixed_value") or 0)
            discount_value = None

        if discount_type or override_price is not None:
            await db.execute(
                """INSERT INTO discount_rules (plan_id, category_id, duration_id, discount_type, discount_value, override_price)
                   VALUES ($1, $2, $3, $4, $5, $6)""",
                plan_id, cat_id, dur_id, discount_type, discount_value, override_price,
            )

    await db.execute(
        "UPDATE scheduled_campaigns SET auto_discount_plan_id = $1 WHERE id = $2",
        plan_id, camp_id,
    )

    from bot.services.user_discount import invalidate_cache
    invalidate_cache()
    invalidate_campaign_cache()
    logger.info(f"Campaign #{camp_id}: created auto discount plan #{plan_id} (scope={apply_scope})")


async def _deactivate_campaign_discount(campaign):
    mode = campaign.get("campaign_mode", "fixed_plan")
    camp_id = campaign.get("id")
    from bot.services.user_discount import invalidate_cache

    if mode == "fixed_plan":
        plan_id = campaign.get("linked_discount_plan_id")
        if plan_id:
            await db.execute("UPDATE discount_plans SET is_active = false WHERE id = $1", plan_id)
            invalidate_cache()
        invalidate_campaign_cache()
        return

    auto_plan_id = campaign.get("auto_discount_plan_id")
    if not auto_plan_id:
        fresh = await db.fetch_one(
            "SELECT auto_discount_plan_id FROM scheduled_campaigns WHERE id = $1", camp_id
        )
        if fresh:
            auto_plan_id = fresh.get("auto_discount_plan_id")

    if auto_plan_id:
        await db.execute("UPDATE discount_plans SET is_active = false WHERE id = $1", auto_plan_id)
        logger.info(f"Campaign #{camp_id}: deactivated auto discount plan #{auto_plan_id}")

    invalidate_cache()
    invalidate_campaign_cache()


async def _get_pricing_examples(campaign):
    cat_scope = []
    dur_scope = []
    try:
        cat_scope = json.loads(campaign.get("category_scope_json") or "[]")
        dur_scope = json.loads(campaign.get("duration_scope_json") or "[]")
    except (json.JSONDecodeError, TypeError):
        pass

    examples = []
    query = "SELECT d.id, d.name AS dur_name, d.price, c.name AS cat_name, c.id AS cat_id FROM durations d JOIN categories c ON c.id = d.category_id WHERE d.is_hidden = 0 AND c.is_hidden = 0"
    args = []
    if cat_scope:
        placeholders = ", ".join(f"${i+1}" for i in range(len(cat_scope)))
        query += f" AND c.id IN ({placeholders})"
        args = cat_scope
    query += " ORDER BY c.sort_order, d.sort_order LIMIT 10"
    rows = await db.fetch_all(query, *args)

    for r in rows:
        examples.append({
            "category_name": r["cat_name"],
            "duration_name": r["dur_name"],
            "original_price": float(r["price"]),
            "category_id": r["cat_id"],
            "duration_id": r["id"],
        })
    return examples


async def _execute_campaign_run(bot: Bot, campaign, run_type, generated_discount_value=None):
    campaign = dict(campaign)
    camp_id = campaign["id"]
    bot_username = await _get_bot_username(bot)

    rules = await db.fetch_all("SELECT * FROM campaign_discount_rules WHERE campaign_id = $1 LIMIT 1", camp_id)
    actual_discount_value = 0.0
    actual_discount_type = "none"

    if rules:
        rule = dict(rules[0])
        disc_mode = rule.get("discount_mode", "fixed_percent")
        if disc_mode == "fixed_percent":
            actual_discount_value = float(rule.get("fixed_value") or 0)
            actual_discount_type = "percent"
        elif disc_mode == "random_percent":
            if generated_discount_value is not None:
                actual_discount_value = generated_discount_value
            else:
                mn = float(rule.get("min_value") or 0)
                mx = float(rule.get("max_value") or mn)
                actual_discount_value = round(random.uniform(mn, mx), 1)
            actual_discount_type = "percent"
        elif disc_mode == "fixed_price_override":
            actual_discount_value = float(rule.get("fixed_value") or 0)
            actual_discount_type = "override"

    examples = await _get_pricing_examples(campaign)
    final_prices = {}
    for ex in examples:
        bp = ex["original_price"]
        if actual_discount_type == "percent" and actual_discount_value > 0:
            fp = max(0.0, bp - (bp * actual_discount_value / 100))
        elif actual_discount_type == "override":
            fp = actual_discount_value
        else:
            fp = bp
        key = f"{ex['category_name']}_{ex['duration_name']}"
        final_prices[key] = {"original": bp, "final": round(fp, 2), "category": ex["category_name"], "duration": ex["duration_name"]}

    run_id = await db.fetch_val(
        """INSERT INTO campaign_runs
           (campaign_id, run_type, status, generated_discount_value, generated_discount_type, generated_final_price_json)
           VALUES ($1, $2, 'running', $3, $4, $5) RETURNING id""",
        camp_id, run_type, actual_discount_value if actual_discount_value else None,
        actual_discount_type, json.dumps(final_prices),
    )

    # ── Deep link per run ───────────────────────────────────────────────────
    deep_link_code = ""
    deep_link_url  = ""
    active_deep_link_id = None

    if run_type == "promo_start":
        # Generate a fresh deep link tied to this specific run.
        # Attribution window = campaign's scheduled expiry (so purchases after expiry don't count).
        campaign_expire_at = campaign.get("expire_at")
        fresh = await generate_fresh_deep_link(camp_id, run_id, bot_username, attribution_end_at=campaign_expire_at)
        deep_link_code      = fresh["code"]
        deep_link_url       = fresh["deep_link_url"]
        active_deep_link_id = fresh["id"]
        logger.info(
            f"Campaign #{camp_id} promo_start run #{run_id}: "
            f"fresh link {deep_link_code} (expires {campaign_expire_at})"
        )
    else:
        # promo_expiry: use the existing active link for the message (deep_link placeholder in template)
        existing = await db.fetch_one(
            """SELECT * FROM campaign_deep_links
               WHERE campaign_id = $1 AND status = 'active'
               ORDER BY created_at DESC LIMIT 1""",
            camp_id,
        )
        if existing:
            deep_link_code      = existing["code"]
            deep_link_url       = f"https://t.me/{bot_username}?start={deep_link_code}" if bot_username else ""
            active_deep_link_id = existing["id"]
    # ────────────────────────────────────────────────────────────────────────

    if run_type == "promo_start":
        tpl_id = campaign.get("promo_template_id")
    else:
        tpl_id = campaign.get("expiry_template_id")

    template = None
    if tpl_id:
        template = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", tpl_id)

    body_text = template["body_text"] if template else f"{'🎉 Promo Active!' if run_type == 'promo_start' else '⏰ Promo Ended!'}"

    first_example = next(iter(final_prices.values()), {})
    if run_type == "promo_start":
        current_p = first_example.get("final", 0)
    else:
        current_p = first_example.get("original", 0)

    # ── Build product lines blocks ──────────────────────────────────────────
    def _fmtp(amount):
        try:
            return f"₹{float(amount):.2f}"
        except (TypeError, ValueError):
            return str(amount)

    start_lines = []
    expiry_lines = []
    for fp_data in final_prices.values():
        cat = fp_data["category"]
        dur = fp_data["duration"]
        orig = fp_data["original"]
        final = fp_data["final"]
        save = max(0.0, orig - final)
        start_lines.append(
            f"• <b>{cat} · {dur}</b>\n"
            f"   <s>Original: {_fmtp(orig)}</s>\n"
            f"   <b>Now: {_fmtp(final)}</b>   (You save {_fmtp(save)})"
        )
        expiry_lines.append(
            f"• <b>{cat} · {dur}</b>\n"
            f"   <s>Discounted: {_fmtp(final)}</s>\n"
            f"   <b>Current: {_fmtp(orig)}</b>"
        )

    product_discount_lines = "\n\n".join(start_lines) if start_lines else ""
    product_expiry_lines = "\n\n".join(expiry_lines) if expiry_lines else ""

    # ── Format schedule datetimes ───────────────────────────────────────────
    def _fmt_dt(dt_val):
        if not dt_val:
            return ""
        if isinstance(dt_val, datetime):
            aware = dt_val.replace(tzinfo=timezone.utc) if dt_val.tzinfo is None else dt_val
            return aware.astimezone(IST).strftime("%d %b %Y, %I:%M %p IST")
        return str(dt_val)

    # ── Base variables (same for all recipients) ────────────────────────────
    base_variables = {
        "campaign_name":        campaign.get("name", ""),
        "discount_percent":     f"{actual_discount_value:.0f}" if actual_discount_value else "0",
        "original_price":       _fmtp(first_example.get("original", 0)) if first_example else "0",
        "discounted_price":     _fmtp(first_example.get("final", 0)) if first_example else "0",
        "current_price":        _fmtp(current_p) if first_example else "0",
        "expires_at":           _fmt_dt(campaign.get("expire_at")),
        "starts_at":            _fmt_dt(campaign.get("start_at")),
        "deep_link":            deep_link_url,
        "category_name":        first_example.get("category", "") if first_example else "",
        "duration_name":        first_example.get("duration", "") if first_example else "",
        "product_discount_lines": product_discount_lines,
        "product_expiry_lines":   product_expiry_lines,
    }

    buttons_json = template.get("inline_buttons_json") if template else None
    raw_markup = _compile_raw_reply_markup(
        buttons_json, deep_link_url,
        campaign_id=camp_id, template_id=tpl_id, run_type=run_type,
    )

    mk = "promo_start" if run_type == "promo_start" else "promo_expiry"

    run_delivery_mode = await get_channel_delivery_mode()
    logger.info(
        f"Campaign #{camp_id} MODE_LOCKED: channel_delivery_mode={run_delivery_mode} "
        f"(locked for this run) run_type={run_type}"
    )

    user_ids, channel_ids = await _get_target_ids(camp_id, mk, bot)

    # ── Fetch user display names for personalised {user_name} ──────────────
    user_name_map: dict = {}
    if user_ids:
        try:
            name_rows = await db.fetch_all(
                "SELECT telegram_id, first_name, username FROM users WHERE telegram_id = ANY($1::bigint[])",
                list(user_ids),
            )
            for row in name_rows:
                display = (row.get("first_name") or "").strip() or (row.get("username") or "").strip() or "there"
                user_name_map[row["telegram_id"]] = display
        except Exception:
            pass

    total_targets = len(user_ids) + len(channel_ids)
    total_sent = 0
    total_failed = 0

    for i, tg_id in enumerate(user_ids):
        user_vars = dict(base_variables)
        user_vars["user_name"] = user_name_map.get(tg_id, "there")
        rendered_text = _render_template(body_text, user_vars)
        try:
            result = await _send_campaign_message_raw(
                chat_id=tg_id,
                html_text=rendered_text,
                raw_reply_markup=raw_markup,
                camp_id=camp_id, mk=mk, run_id=run_id, target_type="user",
            )
            if result["ok"]:
                await db.execute(
                    """INSERT INTO campaign_delivery_logs
                       (campaign_run_id, campaign_id, target_type, telegram_id, message_kind, delivery_status, telegram_message_id, delivery_method)
                       VALUES ($1, $2, 'user', $3, $4, 'sent', $5, 'direct')""",
                    run_id, camp_id, tg_id, mk, result["message_id"],
                )
                total_sent += 1
            else:
                await db.execute(
                    """INSERT INTO campaign_delivery_logs
                       (campaign_run_id, campaign_id, target_type, telegram_id, message_kind, delivery_status, error_text, delivery_method)
                       VALUES ($1, $2, 'user', $3, $4, 'failed', $5, 'direct')""",
                    run_id, camp_id, tg_id, mk,
                    f"{result.get('fail_type', 'unknown')}: {result.get('error', '')}".strip()[:500],
                )
                total_failed += 1
        except Exception as e:
            await db.execute(
                """INSERT INTO campaign_delivery_logs
                   (campaign_run_id, campaign_id, target_type, telegram_id, message_kind, delivery_status, error_text, delivery_method)
                   VALUES ($1, $2, 'user', $3, $4, 'failed', $5, 'direct')""",
                run_id, camp_id, tg_id, mk, str(e)[:500],
            )
            total_failed += 1
        if (i + 1) % 25 == 0:
            await asyncio.sleep(1)

    # ── Channel delivery via configurable mode dispatcher ────────────────
    channels_sent_count = 0
    channels_failed_count = 0
    run_source_chat_id = None
    run_source_message_id = None
    run_delivery_method = "direct_channel"

    if channel_ids:
        channel_vars = dict(base_variables)
        channel_vars["user_name"] = "there"
        channel_rendered = _render_template(body_text, channel_vars)

        ch_result = await _send_campaign_to_channels(
            channel_ids=channel_ids,
            channel_rendered=channel_rendered,
            raw_markup=raw_markup,
            camp_id=camp_id, mk=mk, run_id=run_id,
            mode=run_delivery_mode,
            bot=bot,
        )
        channels_sent_count = ch_result["channels_sent"]
        channels_failed_count = ch_result["channels_failed"]
        run_source_chat_id = ch_result.get("source_chat_id")
        run_source_message_id = ch_result.get("source_message_id")
        run_delivery_method = ch_result.get("delivery_method", "direct_channel")
        total_sent += channels_sent_count
        total_failed += channels_failed_count

    await db.execute(
        """UPDATE campaign_runs
           SET status = 'completed', total_targets = $1, total_sent = $2, total_failed = $3,
               channel_delivery_method = $4,
               channels_targeted = $5, channels_copied = $6, channels_failed = $7,
               source_chat_id = $8, source_message_id = $9
           WHERE id = $10""",
        total_targets, total_sent, total_failed,
        run_delivery_method,
        len(channel_ids), channels_sent_count, channels_failed_count,
        run_source_chat_id, run_source_message_id,
        run_id,
    )

    # Expire the active deep link AFTER messages are sent so the link URL still works during delivery
    if run_type == "promo_expiry":
        try:
            await expire_campaign_run_deep_link(camp_id)
        except Exception as exp_err:
            logger.warning(f"Campaign #{camp_id}: deep link expiry error: {exp_err}")

    return {
        "run_id": run_id,
        "total_targets": total_targets,
        "total_sent": total_sent,
        "total_failed": total_failed,
        "discount_value": actual_discount_value,
        "discount_type": actual_discount_type,
        "deep_link_id": active_deep_link_id,
        "deep_link_code": deep_link_code,
    }


async def process_campaign_starts(bot: Bot):
    now = datetime.utcnow()
    rows = await db.fetch_all(
        """SELECT * FROM scheduled_campaigns
           WHERE is_enabled = true AND status = 'scheduled'
             AND next_run_at IS NOT NULL AND next_run_at <= $1
           ORDER BY next_run_at ASC LIMIT 5""",
        now,
    )
    for row in rows:
        campaign = dict(row)
        camp_id = campaign["id"]
        logger.info(f"Campaign #{camp_id} '{campaign['name']}' starting...")

        lock = await db.fetch_val(
            "SELECT id FROM scheduled_campaigns WHERE id = $1 AND status = 'scheduled' FOR UPDATE SKIP LOCKED",
            camp_id,
        )
        if not lock:
            continue

        rules = await db.fetch_all("SELECT * FROM campaign_discount_rules WHERE campaign_id = $1 LIMIT 1", camp_id)
        generated_discount_value = None
        if rules:
            rule = dict(rules[0])
            if rule.get("discount_mode") == "random_percent":
                mn = float(rule.get("min_value") or 0)
                mx = float(rule.get("max_value") or mn)
                generated_discount_value = round(random.uniform(mn, mx), 1)

        await db.execute(
            "UPDATE scheduled_campaigns SET status = 'active', last_run_at = NOW(), updated_at = NOW() WHERE id = $1",
            camp_id,
        )

        await _activate_campaign_discount(campaign, generated_discount_value)

        try:
            result = await _execute_campaign_run(bot, campaign, "promo_start", generated_discount_value)
            logger.info(f"Campaign #{camp_id} promo sent: {result['total_sent']}/{result['total_targets']}")
        except Exception as e:
            logger.error(f"Campaign #{camp_id} promo send failed, rolling back activation: {e}")
            try:
                await _deactivate_campaign_discount(campaign)
                await db.execute(
                    "UPDATE scheduled_campaigns SET status = 'scheduled', updated_at = NOW() WHERE id = $1",
                    camp_id,
                )
                logger.info(f"Campaign #{camp_id} rolled back to scheduled after send failure")
            except Exception as rb_err:
                logger.error(f"Campaign #{camp_id} rollback also failed: {rb_err}")


async def _notify_admin_campaign_failure(bot: Bot, camp_id: int, camp_name: str, error: str):
    """Send admin notification when a campaign expiry or send fails."""
    from bot.config import ADMIN_CHAT_ID
    if not ADMIN_CHAT_ID:
        return
    try:
        text = (
            f"⚠️ <b>Campaign Expiry Failed</b>\n\n"
            f"Campaign: <b>{camp_name}</b> (#{camp_id})\n"
            f"Error: <code>{error[:400]}</code>\n\n"
            f"Discount was deactivated. Expiry message was NOT sent to users.\n"
            f"Please check the campaign logs in admin panel."
        )
        await bot.send_message(chat_id=ADMIN_CHAT_ID, text=text, parse_mode="HTML")
    except Exception as notify_err:
        logger.error(f"Campaign #{camp_id}: failed to notify admin: {notify_err}")


async def process_campaign_expiries(bot: Bot):
    now = datetime.utcnow()
    rows = await db.fetch_all(
        """SELECT * FROM scheduled_campaigns
           WHERE is_enabled = true AND status = 'active'
             AND next_expire_at IS NOT NULL AND next_expire_at <= $1
           ORDER BY next_expire_at ASC LIMIT 5""",
        now,
    )
    for row in rows:
        campaign = dict(row)
        camp_id = campaign["id"]
        camp_name = campaign.get("name", f"#{camp_id}")

        logger.info(
            f"Campaign #{camp_id} '{camp_name}' expiry triggered | "
            f"next_expire_at={campaign.get('next_expire_at')} | "
            f"timezone={campaign.get('timezone')} | "
            f"repeat={campaign.get('repeat_mode')} | "
            f"expiry_template_id={campaign.get('expiry_template_id')}"
        )

        # ── Atomic guard: set status = 'expiring' before any processing ────
        # This prevents duplicate expiry runs if the scheduler loops before
        # the current expiry completes.
        updated = await db.fetch_val(
            """UPDATE scheduled_campaigns
               SET status = 'expiring', updated_at = NOW()
               WHERE id = $1 AND status = 'active'
               RETURNING id""",
            camp_id,
        )
        if not updated:
            logger.warning(f"Campaign #{camp_id}: could not claim expiry slot (status changed?), skipping")
            continue

        logger.info(f"Campaign #{camp_id}: status set to 'expiring' — deactivating discount...")

        # ── Log the expiry attempt ────────────────────────────────────────
        expiry_log_id = None
        try:
            expiry_log_id = await db.fetch_val(
                """INSERT INTO campaign_expiry_logs (campaign_id, status)
                   VALUES ($1, 'running') RETURNING id""",
                camp_id,
            )
        except Exception as log_err:
            logger.warning(f"Campaign #{camp_id}: could not create expiry log: {log_err}")

        # ── Step 1: Deactivate discount ───────────────────────────────────
        discount_deactivated = False
        try:
            await _deactivate_campaign_discount(campaign)
            discount_deactivated = True
            logger.info(f"Campaign #{camp_id}: discount deactivated successfully")
        except Exception as disc_err:
            logger.error(f"Campaign #{camp_id}: discount deactivation failed: {disc_err}", exc_info=True)
            # Continue anyway - we still want to send expiry message and update status

        # ── Step 2: Send expiry message ───────────────────────────────────
        expiry_result = None
        expiry_error = None
        try:
            logger.info(f"Campaign #{camp_id}: executing expiry message run...")
            expiry_result = await _execute_campaign_run(bot, campaign, "promo_expiry")
            logger.info(
                f"Campaign #{camp_id} expiry msg sent: "
                f"{expiry_result['total_sent']}/{expiry_result['total_targets']} | "
                f"failed={expiry_result['total_failed']}"
            )
        except Exception as send_err:
            expiry_error = str(send_err)
            logger.error(f"Campaign #{camp_id}: expiry message send failed: {send_err}", exc_info=True)
            try:
                await _notify_admin_campaign_failure(bot, camp_id, camp_name, expiry_error)
                # Mark admin notified in campaign_runs if we have a run_id
                await db.execute(
                    "UPDATE campaign_runs SET status = 'failed', error_text = $1 WHERE campaign_id = $2 AND status = 'running' AND run_type = 'promo_expiry'",
                    expiry_error[:1000], camp_id,
                )
            except Exception:
                pass

        # ── Update expiry log ─────────────────────────────────────────────
        if expiry_log_id:
            try:
                recipients = expiry_result["total_targets"] if expiry_result else 0
                sent = expiry_result["total_sent"] if expiry_result else 0
                failed = expiry_result["total_failed"] if expiry_result else 0
                log_status = "completed" if expiry_result else "failed"
                await db.execute(
                    """UPDATE campaign_expiry_logs
                       SET status = $1, completed_at = NOW(),
                           discount_deactivated = $2,
                           recipients_resolved = $3, sent = $4, failed = $5,
                           error_text = $6
                       WHERE id = $7""",
                    log_status, discount_deactivated,
                    recipients, sent, failed,
                    expiry_error, expiry_log_id,
                )
            except Exception as log_upd_err:
                logger.warning(f"Campaign #{camp_id}: could not update expiry log: {log_upd_err}")

        # ── Update campaign daily stats for expiry sends ──────────────────
        if expiry_result and expiry_result.get("total_sent", 0) > 0:
            try:
                today = now.date()
                await db.execute(
                    """INSERT INTO campaign_daily_stats (stat_date, campaign_id, promo_expiry_sent)
                       VALUES ($1, $2, $3)
                       ON CONFLICT (stat_date, campaign_id)
                       DO UPDATE SET promo_expiry_sent = campaign_daily_stats.promo_expiry_sent + $3,
                                     updated_at = NOW()""",
                    today, camp_id, expiry_result["total_sent"],
                )
            except Exception:
                pass

        # ── Step 3: Decide next status (reschedule vs expire) ─────────────
        repeat = campaign.get("repeat_mode", "once")
        if repeat != "once":
            start_at = campaign.get("start_at") or campaign.get("next_run_at")
            expire_at = campaign.get("expire_at") or campaign.get("next_expire_at")
            if start_at and expire_at:
                try:
                    next_start, next_expire = await _compute_next_times(campaign, start_at, expire_at, now)
                    if next_start and next_expire:
                        await db.execute(
                            """UPDATE scheduled_campaigns
                               SET status = 'scheduled', next_run_at = $1, next_expire_at = $2,
                                   last_expired_at = NOW(), updated_at = NOW()
                               WHERE id = $3""",
                            next_start, next_expire, camp_id,
                        )
                        logger.info(f"Campaign #{camp_id} rescheduled: next start={next_start}, next expire={next_expire}")
                        continue
                    else:
                        logger.warning(f"Campaign #{camp_id}: _compute_next_times returned None, marking expired")
                except Exception as sched_err:
                    logger.error(f"Campaign #{camp_id}: failed to compute next times: {sched_err}", exc_info=True)

        await db.execute(
            "UPDATE scheduled_campaigns SET status = 'expired', last_expired_at = NOW(), updated_at = NOW() WHERE id = $1",
            camp_id,
        )
        logger.info(f"Campaign #{camp_id}: marked as expired")


async def _recover_stale_expiring(bot: Bot):
    """Recover campaigns stuck in 'expiring' status for > 10 minutes (crash recovery)."""
    stale = await db.fetch_all(
        """SELECT id, name, repeat_mode, start_at, expire_at, next_run_at, next_expire_at
           FROM scheduled_campaigns
           WHERE status = 'expiring' AND updated_at < NOW() - INTERVAL '10 minutes'
           LIMIT 5""",
    )
    for row in stale:
        camp_id = row["id"]
        logger.warning(f"Campaign #{camp_id} stuck in 'expiring' for >10 min — forcing to 'expired'")
        await db.execute(
            "UPDATE scheduled_campaigns SET status = 'expired', last_expired_at = NOW(), updated_at = NOW() WHERE id = $1 AND status = 'expiring'",
            camp_id,
        )


async def run_campaign_scheduler(bot: Bot):
    while True:
        try:
            await process_campaign_starts(bot)
        except Exception as e:
            logger.error(f"Campaign scheduler (starts) error: {e}", exc_info=True)
        try:
            await process_campaign_expiries(bot)
        except Exception as e:
            logger.error(f"Campaign scheduler (expiries) error: {e}", exc_info=True)
        try:
            await _recover_stale_expiring(bot)
        except Exception as e:
            logger.error(f"Campaign scheduler (recovery) error: {e}")
        await asyncio.sleep(20)
