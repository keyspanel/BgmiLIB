import asyncio
import json
import logging
from datetime import datetime, timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))
from html import escape

from bot import database as db
from bot import settings
from bot.services.categories import send_categories
from bot.cleanup import (
    save_broadcast_categories_message_id,
    cleanup_broadcast_categories_message,
)

logger = logging.getLogger(__name__)

MAX_EXAMPLES = 6


def _clean_emoji_name(raw: str) -> str:
    import re
    raw = (raw or "").strip()
    raw = re.sub(r"\{\d{5,32}\}", "", raw)
    return re.sub(r"\s+", " ", raw).strip()


def _safe_format(template: str, values: dict) -> str:
    safe = {}
    for k, v in values.items():
        s = str(v) if v is not None else ""
        if k.endswith("_raw"):
            safe[k.removesuffix("_raw")] = s
        else:
            safe[k] = escape(s)
    try:
        return template.format_map(safe)
    except (KeyError, ValueError, IndexError):
        result = template
        for k, v in safe.items():
            result = result.replace(f"{{{k}}}", v)
        return result


async def build_pricing_examples(plan: dict, rules: list) -> str:
    scope = plan.get("apply_scope", "all_categories")
    currency = settings.get("currency_symbol")

    durations_rows = await db.fetch_all("""
        SELECT d.id AS duration_id, d.name AS duration_name, d.price AS base_price,
               d.category_id, c.name AS category_name
        FROM durations d
        JOIN categories c ON c.id = d.category_id
        WHERE d.is_hidden = 0 AND c.is_hidden = 0
        ORDER BY c.sort_order ASC, d.sort_order ASC
    """)

    examples = []
    for dur in durations_rows:
        matched_rule = None
        base_price = float(dur["base_price"])
        cat_id = dur["category_id"]
        dur_id = dur["duration_id"]

        if scope == "all_categories":
            matched_rule = next((r for r in rules if not r.get("category_id") and not r.get("duration_id")), None)
            if not matched_rule:
                matched_rule = next((r for r in rules if not r.get("category_id") and r.get("duration_id") == dur_id), None)
        elif scope == "one_category":
            target_cat = next((r.get("category_id") for r in rules if r.get("category_id")), None)
            if target_cat and target_cat == cat_id:
                matched_rule = next((r for r in rules if r.get("duration_id") == dur_id), None)
                if not matched_rule:
                    matched_rule = next((r for r in rules if not r.get("duration_id")), None)
        elif scope == "per_categories":
            matched_rule = next((r for r in rules if r.get("category_id") == cat_id and r.get("duration_id") == dur_id), None)
            if not matched_rule:
                matched_rule = next((r for r in rules if r.get("category_id") == cat_id and not r.get("duration_id")), None)
        elif scope == "per_category_duration_prices":
            matched_rule = next((r for r in rules if r.get("category_id") == cat_id and r.get("duration_id") == dur_id), None)
            if not matched_rule:
                matched_rule = next((r for r in rules if r.get("category_id") == cat_id and not r.get("duration_id")), None)
            if not matched_rule:
                matched_rule = next((r for r in rules if not r.get("category_id") and not r.get("duration_id")), None)

        if not matched_rule:
            continue

        final_price = base_price
        if matched_rule.get("override_price") is not None:
            final_price = max(0.0, float(matched_rule["override_price"]))
        elif matched_rule.get("discount_type") == "percent":
            dv = float(matched_rule.get("discount_value") or 0)
            final_price = max(0.0, base_price - (base_price * dv / 100))
        elif matched_rule.get("discount_type") == "fixed":
            dv = float(matched_rule.get("discount_value") or 0)
            final_price = max(0.0, base_price - dv)

        if final_price == base_price:
            continue

        cat_name = _clean_emoji_name(dur["category_name"])
        dur_name = _clean_emoji_name(dur["duration_name"])
        savings = base_price - final_price
        examples.append(
            f"\u2022 <b>{escape(cat_name)}</b> \u00b7 {escape(dur_name)}\n"
            f"   Original: <s>{currency}{base_price:.2f}</s>\n"
            f"   Now: <b>{currency}{final_price:.2f}</b>   <i>(You save {currency}{savings:.2f})</i>"
        )

        if len(examples) >= MAX_EXAMPLES:
            break

    return "\n\n".join(examples) if examples else "Discounted prices are now available!"


async def render_broadcast_message(plan_id: int, template_override: str = None) -> dict:
    plan = await db.fetch_one("SELECT * FROM discount_plans WHERE id = $1", plan_id)
    if not plan:
        return {"error": "Plan not found"}

    rules = await db.fetch_all(
        "SELECT * FROM discount_rules WHERE plan_id = $1 ORDER BY id ASC", plan_id
    )

    pricing_examples = await build_pricing_examples(plan, rules)

    expiry_time = ""
    if plan.get("expires_at"):
        try:
            dt = plan["expires_at"]
            if isinstance(dt, str):
                dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            expiry_time = dt.astimezone(IST).strftime("%d %b %Y, %I:%M %p")
        except Exception:
            expiry_time = str(plan["expires_at"])
    else:
        expiry_time = "No expiry set"

    brand = settings.get_brand_name()
    now = datetime.now(IST).strftime("%d %b %Y, %I:%M %p")

    values = {
        "plan_name": plan.get("name", ""),
        "description": plan.get("description", ""),
        "pricing_examples_raw": pricing_examples,
        "expiry_time": expiry_time,
        "brand": brand,
        "current_time": now,
        "first_name": "{first_name}",
    }

    if template_override and template_override.strip():
        body = _safe_format(template_override, values)
    else:
        plan_template = (plan.get("broadcast_template") or "").strip()
        if plan_template:
            body = _safe_format(plan_template, values)
        else:
            title = settings.get("tpl_discount_broadcast_title")
            body_tpl = settings.get("tpl_discount_broadcast_body")
            footer = settings.get("tpl_discount_broadcast_footer")
            title_rendered = _safe_format(title, values)
            body_rendered = _safe_format(body_tpl, values)
            footer_rendered = _safe_format(footer, values)
            body = f"{title_rendered}\n\n{body_rendered}\n{footer_rendered}"

    buttons_json = settings.get("discount_broadcast_buttons")
    buttons = []
    try:
        buttons = json.loads(buttons_json) if buttons_json else []
    except (json.JSONDecodeError, TypeError):
        buttons = []

    return {
        "text": body,
        "buttons": buttons,
        "plan_name": plan.get("name", ""),
        "plan_id": plan_id,
    }


def _build_inline_keyboard(buttons: list):
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    if not buttons:
        return None
    rows = []
    for btn in buttons:
        if not isinstance(btn, dict):
            continue
        text = btn.get("text", "").strip()
        url = btn.get("url", "").strip()
        if not text or not url:
            continue
        api_kwargs = {}
        style = btn.get("style", "").strip()
        if style in ("primary", "success", "danger"):
            api_kwargs["style"] = style
        emoji_id = btn.get("icon_custom_emoji_id", "").strip()
        if emoji_id:
            api_kwargs["icon_custom_emoji_id"] = emoji_id
        rows.append([InlineKeyboardButton(
            text=text,
            url=url,
            api_kwargs=api_kwargs if api_kwargs else None,
        )])
    return InlineKeyboardMarkup(rows) if rows else None


async def _safe_pin_message(bot, chat_id: int, message_id: int):
    try:
        await bot.pin_chat_message(
            chat_id=chat_id,
            message_id=message_id,
            disable_notification=True,
        )
    except Exception as e:
        logger.warning(f"Failed to pin broadcast message {message_id} in chat {chat_id}: {e}")


async def _safe_unpin_message(bot, chat_id: int, message_id: int):
    try:
        await bot.unpin_chat_message(
            chat_id=chat_id,
            message_id=message_id,
        )
    except Exception as e:
        logger.debug(f"Failed to unpin message {message_id} in chat {chat_id}: {e}")


async def send_discount_broadcast(bot, plan_id: int, template_override: str = None, queue_id: int = None) -> dict:
    await settings.force_reload_settings()

    rendered = await render_broadcast_message(plan_id, template_override)
    if "error" in rendered:
        return rendered

    message_text = rendered["text"]
    buttons = rendered.get("buttons", [])
    reply_markup = _build_inline_keyboard(buttons)

    send_categories_after = settings.get("discount_broadcast_send_categories") == "1"
    pin_enabled = settings.get("broadcast_pin_message") == "1"
    logger.info(f"Broadcast plan {plan_id}: send_categories_after={send_categories_after}, pin={pin_enabled}, queue_id={queue_id}")

    normal_users = await db.fetch_all(
        "SELECT id, telegram_id, first_name, broadcast_categories_message_id FROM users WHERE (reseller_id IS NULL OR reseller_id = 0) AND is_banned = 0"
    )

    total = len(normal_users)
    sent = 0
    failed = 0
    skipped = 0

    for user in normal_users:
        tid = user["telegram_id"]
        user_id = user["id"]
        first_name = user.get("first_name") or ""
        personalized = message_text.replace("{first_name}", escape(first_name))

        try:
            broadcast_msg = await bot.send_message(
                chat_id=tid,
                text=personalized,
                parse_mode="HTML",
                reply_markup=reply_markup,
            )
            sent += 1

            if queue_id:
                try:
                    await db.execute(
                        """INSERT INTO discount_broadcast_messages
                           (queue_id, plan_id, user_id, telegram_id, broadcast_message_id)
                           VALUES ($1, $2, $3, $4, $5)""",
                        queue_id, plan_id, user_id, tid, broadcast_msg.message_id
                    )
                except Exception as store_err:
                    logger.warning(f"Failed to store broadcast msg id for {tid}: {store_err}")

            if pin_enabled:
                await _safe_pin_message(bot, tid, broadcast_msg.message_id)
                try:
                    from bot.handlers.broadcast_wizard import register_broadcast_pin
                    register_broadcast_pin(tid, broadcast_msg.message_id)
                except Exception:
                    pass

            if send_categories_after:
                old_bc_mid = int(user.get("broadcast_categories_message_id") or 0)
                if old_bc_mid > 0:
                    from bot.cleanup import safe_delete_message
                    await safe_delete_message(bot, tid, old_bc_mid)

                try:
                    cat_resp = await send_categories(bot, tid)
                    cat_mid = cat_resp.get("message_id") if cat_resp else None
                    if cat_mid:
                        await save_broadcast_categories_message_id(user_id, cat_mid)
                    else:
                        await save_broadcast_categories_message_id(user_id, None)
                except Exception as e:
                    logger.warning(f"Broadcast: categories send failed for {tid}: {e}")
                    await save_broadcast_categories_message_id(user_id, None)
            else:
                old_bc_mid = int(user.get("broadcast_categories_message_id") or 0)
                if old_bc_mid > 0:
                    from bot.cleanup import safe_delete_message
                    await safe_delete_message(bot, tid, old_bc_mid)
                    await save_broadcast_categories_message_id(user_id, None)

        except Exception as e:
            err_str = str(e).lower()
            if "blocked" in err_str or "deactivated" in err_str or "not found" in err_str:
                skipped += 1
            else:
                failed += 1
            logger.debug(f"Broadcast send failed for {tid}: {e}")

        if (sent + failed + skipped) % 25 == 0:
            await asyncio.sleep(1)

    result = {
        "sent": sent,
        "failed": failed,
        "skipped": skipped,
        "total": total,
        "plan_name": rendered.get("plan_name", ""),
        "categories_sent": send_categories_after,
    }
    logger.info(f"Broadcast complete for plan {plan_id}: {result}")
    return result


async def _delete_message_rows(bot, rows: list) -> dict:
    deleted = 0
    failed = 0
    for row in rows:
        tid = row["telegram_id"]
        for mid_key in ("broadcast_message_id", "pin_service_message_id"):
            try:
                mid = row[mid_key]
            except (KeyError, IndexError):
                mid = None
            if not mid:
                continue
            try:
                await bot.delete_message(chat_id=tid, message_id=mid)
                deleted += 1
            except Exception:
                failed += 1
        if (deleted + failed) % 25 == 0:
            await asyncio.sleep(1)
    return {"deleted": deleted, "failed": failed, "total": len(rows)}


async def delete_broadcast_messages(bot, queue_id: int) -> dict:
    rows = await db.fetch_all(
        "SELECT telegram_id, broadcast_message_id, pin_service_message_id FROM discount_broadcast_messages WHERE queue_id = $1",
        queue_id
    )
    result = await _delete_message_rows(bot, rows)
    await db.execute("DELETE FROM discount_broadcast_messages WHERE queue_id = $1", queue_id)
    return result


async def delete_plan_broadcast_messages(bot, plan_id: int) -> dict:
    rows = await db.fetch_all(
        "SELECT telegram_id, broadcast_message_id, pin_service_message_id FROM discount_broadcast_messages WHERE plan_id = $1",
        plan_id
    )
    result = await _delete_message_rows(bot, rows)
    await db.execute("DELETE FROM discount_broadcast_messages WHERE plan_id = $1", plan_id)
    return result
