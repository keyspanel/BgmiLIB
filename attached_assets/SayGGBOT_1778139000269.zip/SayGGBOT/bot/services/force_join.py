import asyncio
import time
import logging
from datetime import datetime, timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))
from html import escape
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
from bot import database as db
from bot import settings
from bot.cleanup import safe_delete_message

logger = logging.getLogger(__name__)

PENDING_ORDERS = {}
AUTO_CHECK_TASKS = {}

_channels_cache = None
_channels_cache_ts = 0
_CACHE_TTL = 10

_AUTO_CHECK_INTERVAL = 5
_AUTO_CHECK_MAX_ATTEMPTS = 60


async def _load_channels() -> list[dict]:
    global _channels_cache, _channels_cache_ts
    now = time.time()
    if _channels_cache is not None and (now - _channels_cache_ts) < _CACHE_TTL:
        return _channels_cache

    try:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS force_join_channels (
                id SERIAL PRIMARY KEY,
                channel_identifier TEXT NOT NULL,
                channel_id BIGINT,
                channel_username TEXT,
                channel_title TEXT NOT NULL DEFAULT '',
                invite_link TEXT NOT NULL DEFAULT '',
                is_active BOOLEAN NOT NULL DEFAULT true,
                sort_order INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'pending',
                status_detail TEXT NOT NULL DEFAULT '',
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        """)
    except Exception:
        pass

    rows = await db.fetch_all(
        "SELECT * FROM force_join_channels WHERE is_active = true ORDER BY sort_order ASC, id ASC"
    )
    _channels_cache = [dict(r) for r in rows]
    _channels_cache_ts = now
    return _channels_cache


def invalidate_cache():
    global _channels_cache, _channels_cache_ts
    _channels_cache = None
    _channels_cache_ts = 0


def is_force_join_enabled() -> bool:
    return settings.get("force_join_enabled") == "1"


async def get_active_channels() -> list[dict]:
    if not is_force_join_enabled():
        return []
    return await _load_channels()


def _get_join_link(ch: dict) -> str:
    if ch.get("invite_link"):
        return ch["invite_link"]
    username = ch.get("channel_username") or ""
    if username:
        return f"https://t.me/{username.lstrip('@')}"
    identifier = ch.get("channel_identifier", "")
    if identifier.startswith("https://"):
        return identifier
    if identifier.startswith("@"):
        return f"https://t.me/{identifier[1:]}"
    return ""


def _get_chat_id_for_check(ch: dict):
    cid = ch.get("channel_id")
    if cid is not None and cid != 0:
        return int(cid)
    username = ch.get("channel_username")
    if username:
        return f"@{username.lstrip('@')}"
    identifier = ch.get("channel_identifier", "")
    if identifier.startswith("@"):
        return identifier
    cleaned = identifier.lstrip("-")
    if cleaned.isdigit() and len(cleaned) > 0:
        return int(identifier)
    return None


def _get_channel_label(ch: dict) -> str:
    return ch.get("channel_title") or ch.get("channel_username") or ch.get("channel_identifier", "Channel")


async def check_membership(bot: Bot, user_id: int, channels: list[dict]) -> tuple[bool, list[dict]]:
    missing = []
    for ch in channels:
        chat_id = _get_chat_id_for_check(ch)
        if chat_id is None:
            logger.warning(f"Force join: no resolvable chat_id for channel '{ch.get('channel_identifier')}' (id={ch.get('channel_id')})")
            missing.append(ch)
            continue
        try:
            member = await bot.get_chat_member(chat_id=chat_id, user_id=user_id)
            if member.status in ("member", "administrator", "creator", "restricted"):
                continue
            missing.append(ch)
        except Exception as e:
            logger.warning(f"Force join: get_chat_member failed for chat_id={chat_id} user={user_id}: {e}")
            missing.append(ch)
    return len(missing) == 0, missing


def save_pending(telegram_id: int, cat_id: int, dur_id: int, discount_plan_id: int,
                 prompt_msg_id: int, cat_name: str = "", dur_name: str = "",
                 first_name: str = "", username: str = ""):
    PENDING_ORDERS[telegram_id] = {
        "cat_id": cat_id,
        "dur_id": dur_id,
        "discount_plan_id": discount_plan_id,
        "prompt_msg_id": prompt_msg_id,
        "success_msg_id": None,
        "cat_name": cat_name,
        "dur_name": dur_name,
        "first_name": first_name,
        "username": username,
        "ts": time.time(),
    }


def get_pending(telegram_id: int) -> dict | None:
    p = PENDING_ORDERS.get(telegram_id)
    if not p:
        return None
    if time.time() - p["ts"] > 3600:
        PENDING_ORDERS.pop(telegram_id, None)
        return None
    return p


def clear_pending(telegram_id: int):
    PENDING_ORDERS.pop(telegram_id, None)


async def cleanup_force_join_prompt(bot: Bot, chat_id: int, telegram_id: int):
    p = PENDING_ORDERS.get(telegram_id)
    if p and p.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, p["prompt_msg_id"])
        p["prompt_msg_id"] = None


async def cleanup_force_join_success(bot: Bot, chat_id: int, telegram_id: int):
    p = PENDING_ORDERS.get(telegram_id)
    if p and p.get("success_msg_id"):
        await safe_delete_message(bot, chat_id, p["success_msg_id"])
        p["success_msg_id"] = None


def _build_btn_api_kwargs(style_key: str, emoji_key: str) -> dict | None:
    return settings.build_button_kwargs(style_key, emoji_key)


def _render_template(template: str, telegram_id: int, first_name: str = "",
                     username: str = "", cat_name: str = "", dur_name: str = "") -> str:
    safe_first = escape(first_name) if first_name else ""
    safe_username = escape(username) if username else ""

    if safe_first:
        user_mention = f'<a href="tg://user?id={telegram_id}">{safe_first}</a>'
    elif safe_username:
        user_mention = f'<a href="tg://user?id={telegram_id}">@{safe_username}</a>'
    else:
        user_mention = f'<a href="tg://user?id={telegram_id}">there</a>'

    brand = escape(settings.get("bot_store_title") or "Store")
    now_ist = datetime.now(IST)
    current_time = now_ist.strftime("%I:%M %p")

    replacements = {
        "{user_mention}": user_mention,
        "{first_name}": safe_first or "there",
        "{username}": safe_username or "",
        "{category}": escape(cat_name) if cat_name else "—",
        "{duration}": escape(dur_name) if dur_name else "—",
        "{brand}": brand,
        "{current_time}": current_time,
    }

    result = template
    for placeholder, value in replacements.items():
        result = result.replace(placeholder, value)

    return result


def _build_join_buttons(channels: list[dict]) -> list[list[InlineKeyboardButton]]:
    btn_text_tpl = settings.get("force_join_join_btn_text")
    api_kwargs = _build_btn_api_kwargs("force_join_join_btn_style", "force_join_join_btn_emoji_id")
    buttons = []
    for ch in channels:
        link = _get_join_link(ch)
        label = _get_channel_label(ch)
        display_text = btn_text_tpl.replace("{channel}", label) if "{channel}" in btn_text_tpl else f"{btn_text_tpl} {label}"
        if link:
            buttons.append([InlineKeyboardButton(display_text, url=link, api_kwargs=api_kwargs)])
    return buttons


def _should_show_verify_btn() -> bool:
    return settings.get("force_join_show_verify_btn") != "0"


async def send_force_join_prompt(bot: Bot, chat_id: int, telegram_id: int,
                                  channels: list[dict], missing: list[dict],
                                  cat_id: int, dur_id: int, discount_plan_id: int,
                                  cat_name: str = "", dur_name: str = "",
                                  first_name: str = "", username: str = ""):
    await cleanup_force_join_prompt(bot, chat_id, telegram_id)
    await cleanup_force_join_success(bot, chat_id, telegram_id)

    title = settings.get("force_join_title")
    body_tpl = settings.get("force_join_body")

    body = _render_template(body_tpl, telegram_id, first_name, username, cat_name, dur_name)

    buttons = _build_join_buttons(missing)

    if _should_show_verify_btn():
        verify_text = settings.get("force_join_btn_verify")
        verify_kwargs = _build_btn_api_kwargs("force_join_verify_btn_style", "force_join_verify_btn_emoji_id")
        buttons.append([InlineKeyboardButton(verify_text, callback_data="fj_verify", api_kwargs=verify_kwargs)])

    keyboard = InlineKeyboardMarkup(buttons)

    sent = await bot.send_message(
        chat_id=chat_id,
        text=f"{title}\n\n{body}",
        parse_mode="HTML",
        reply_markup=keyboard,
    )

    save_pending(telegram_id, cat_id, dur_id, discount_plan_id, sent.message_id,
                 cat_name=cat_name, dur_name=dur_name,
                 first_name=first_name, username=username)

    start_auto_check(bot, chat_id, telegram_id)

    return sent


def cancel_auto_check(telegram_id: int):
    task = AUTO_CHECK_TASKS.pop(telegram_id, None)
    if task and not task.done():
        task.cancel()


def start_auto_check(bot: Bot, chat_id: int, telegram_id: int):
    cancel_auto_check(telegram_id)
    task = asyncio.create_task(_auto_check_loop(bot, chat_id, telegram_id))
    AUTO_CHECK_TASKS[telegram_id] = task


async def _auto_check_loop(bot: Bot, chat_id: int, telegram_id: int):
    try:
        for attempt in range(_AUTO_CHECK_MAX_ATTEMPTS):
            await asyncio.sleep(_AUTO_CHECK_INTERVAL)

            pending = get_pending(telegram_id)
            if not pending:
                logger.debug(f"Auto-check: no pending order for {telegram_id}, stopping")
                break

            if not is_force_join_enabled():
                logger.debug(f"Auto-check: force join disabled, stopping for {telegram_id}")
                break

            channels = await _load_channels()
            if not channels:
                logger.debug(f"Auto-check: no channels configured, stopping for {telegram_id}")
                break

            try:
                all_joined, missing = await check_membership(bot, telegram_id, channels)
            except Exception as e:
                logger.warning(f"Auto-check membership error for {telegram_id}: {e}")
                continue

            if all_joined:
                await _auto_check_success(bot, chat_id, telegram_id)
                return

        pending = get_pending(telegram_id)
        if pending:
            logger.info(f"Auto-check: max attempts reached for {telegram_id}")
            if not _should_show_verify_btn():
                try:
                    channels = await _load_channels()
                    missing_now = channels
                    try:
                        _, missing_now = await check_membership(bot, telegram_id, channels)
                    except Exception:
                        pass
                    if missing_now:
                        buttons = _build_join_buttons(missing_now)
                        verify_text = settings.get("force_join_btn_verify")
                        verify_kwargs = _build_btn_api_kwargs("force_join_verify_btn_style", "force_join_verify_btn_emoji_id")
                        buttons.append([InlineKeyboardButton(verify_text, callback_data="fj_verify", api_kwargs=verify_kwargs)])
                        prompt_mid = pending.get("prompt_msg_id")
                        if prompt_mid:
                            try:
                                await bot.edit_message_reply_markup(
                                    chat_id=chat_id,
                                    message_id=prompt_mid,
                                    reply_markup=InlineKeyboardMarkup(buttons),
                                )
                            except Exception:
                                pass
                except Exception as e:
                    logger.warning(f"Auto-check fallback verify add failed for {telegram_id}: {e}")

    except asyncio.CancelledError:
        pass
    except Exception as e:
        logger.error(f"Auto-check loop error for {telegram_id}: {e}")
    finally:
        AUTO_CHECK_TASKS.pop(telegram_id, None)


async def _auto_check_success(bot: Bot, chat_id: int, telegram_id: int):
    pending = get_pending(telegram_id)
    if not pending:
        return

    cat_id = pending["cat_id"]
    dur_id = pending["dur_id"]
    discount_plan_id = pending.get("discount_plan_id", 0)

    await cleanup_force_join_prompt(bot, chat_id, telegram_id)
    await cleanup_force_join_success(bot, chat_id, telegram_id)

    if cat_id == 0 and dur_id == 0:
        clear_pending(telegram_id)
        from bot.services.categories import send_categories
        await send_categories(bot, chat_id)
        return

    try:
        user_row = await db.fetch_one("SELECT * FROM users WHERE telegram_id = $1", telegram_id)
        if not user_row:
            logger.error(f"Auto-check: user not found for {telegram_id}")
            clear_pending(telegram_id)
            return

        is_reseller = bool(user_row.get("reseller_id"))
        if not is_reseller and discount_plan_id > 0:
            from bot.services.user_discount import get_active_discount_plan, invalidate_cache
            invalidate_cache()
            active_plan = await get_active_discount_plan()
            active_plan_id = active_plan["id"] if active_plan else 0
            if active_plan_id != discount_plan_id:
                clear_pending(telegram_id)
                title = settings.get("discount_offer_ended_title")
                body = settings.get("discount_offer_ended_body")
                await bot.send_message(
                    chat_id=chat_id,
                    text=f"{title}\n\n{body}",
                    parse_mode="HTML"
                )
                return

        from bot.payment import handle_buy
        await handle_buy(bot, user_row, chat_id, cat_id, dur_id)
        clear_pending(telegram_id)
    except Exception as e:
        logger.error(f"Auto-check resume error for {telegram_id}: {e}")
        clear_pending(telegram_id)


async def handle_verify_callback(bot: Bot, user_row: dict, chat_id: int, query):
    telegram_id = user_row["telegram_id"]

    cancel_auto_check(telegram_id)

    pending = get_pending(telegram_id)

    channels = await get_active_channels()

    if not channels:
        await query.answer("Force Join is no longer required!", show_alert=False)
        await cleanup_force_join_prompt(bot, chat_id, telegram_id)
        # Fallback: if pending expired, cleanup_force_join_prompt found nothing in PENDING_ORDERS.
        # Delete the tapped message directly so it doesn't linger.
        if not pending:
            await safe_delete_message(bot, chat_id, query.message.message_id)
        clear_pending(telegram_id)
        if pending:
            expired_msg = settings.get("force_join_expired_msg")
            await bot.send_message(chat_id=chat_id, text=expired_msg, parse_mode="HTML")
        return None

    all_joined, missing = await check_membership(bot, telegram_id, channels)

    if not all_joined:
        missing_names = []
        for ch in missing:
            name = _get_channel_label(ch)
            missing_names.append(f"• {name}")
        missing_text = "\n".join(missing_names)

        msg = settings.get("force_join_missing_msg")
        full_text = f"{msg}\n\n{missing_text}"

        await query.answer("You still need to join all required channels.", show_alert=True)

        buttons = _build_join_buttons(missing)
        if _should_show_verify_btn():
            verify_text = settings.get("force_join_btn_verify")
            verify_kwargs = _build_btn_api_kwargs("force_join_verify_btn_style", "force_join_verify_btn_emoji_id")
            buttons.append([InlineKeyboardButton(verify_text, callback_data="fj_verify", api_kwargs=verify_kwargs)])

        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=query.message.message_id,
                text=full_text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons),
            )
        except Exception:
            pass

        start_auto_check(bot, chat_id, telegram_id)
        return None

    await query.answer()
    await cleanup_force_join_prompt(bot, chat_id, telegram_id)
    # Fallback: if pending expired, PENDING_ORDERS no longer has this user's entry,
    # so cleanup_force_join_prompt was a no-op. Delete the tapped message directly.
    if not pending:
        await safe_delete_message(bot, chat_id, query.message.message_id)
        expired_msg = settings.get("force_join_expired_msg")
        await bot.send_message(chat_id=chat_id, text=expired_msg, parse_mode="HTML")
        clear_pending(telegram_id)
        return None

    clear_pending(telegram_id)

    return pending


async def cleanup_force_join_for_start(bot: Bot, chat_id: int, telegram_id: int):
    cancel_auto_check(telegram_id)
    await cleanup_force_join_prompt(bot, chat_id, telegram_id)
    await cleanup_force_join_success(bot, chat_id, telegram_id)
    clear_pending(telegram_id)


