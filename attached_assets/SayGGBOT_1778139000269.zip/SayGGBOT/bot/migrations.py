import logging
from bot import database as db

logger = logging.getLogger(__name__)

REQUIRED_USER_COLUMNS = [
    ("token", "VARCHAR(64)"),
    ("start_categories_message_id", "BIGINT"),
    ("active_durations_message_id", "BIGINT"),
    ("active_keys_viewer_message_id", "BIGINT"),
    ("active_payment_order_id", "BIGINT"),
    ("active_payment_error_message_id", "BIGINT"),
    ("active_expiry_notice_message_id", "BIGINT"),
    ("awaiting_code", "SMALLINT DEFAULT 0"),
    ("last_user_start_message_id", "BIGINT"),
    ("last_bot_welcome_message_id", "BIGINT"),
    ("last_start_date", "DATE"),
    ("broadcast_categories_message_id", "BIGINT"),
    ("last_mykeys_user_message_id", "BIGINT"),
    ("last_mykeys_pin_notice_message_id", "BIGINT"),
    ("last_howto_user_message_id", "BIGINT"),
    ("last_howto_bot_message_id", "BIGINT"),
    ("reseller_level_trigger_msg_id", "BIGINT"),
    ("reseller_prompt_msg_id", "BIGINT"),
    ("reseller_success_result_msg_id", "BIGINT"),
    ("reseller_wrong_code_msg_id", "BIGINT"),
    ("reseller_wrong_result_msg_id", "BIGINT"),
    ("last_key_delivery_message_id", "BIGINT"),
    ("profile_photo_url", "TEXT"),
    ("profile_photo_file_id", "VARCHAR(255)"),
    ("profile_photo_updated_at", "TIMESTAMP"),
    ("campaign_deep_link_code", "VARCHAR(64)"),
]

REQUIRED_ORDER_COLUMNS = [
    ("qr_message_id", "BIGINT"),
    ("delivered_at", "TIMESTAMP"),
    ("purchased_key_value", "TEXT"),
    ("purchased_amount", "NUMERIC"),
    ("purchaser_role", "VARCHAR(50)"),
    ("purchaser_label", "VARCHAR(255)"),
    ("paid_utr", "VARCHAR(255)"),
    ("paid_amount", "NUMERIC(10,2)"),
    ("gateway_txn_id", "VARCHAR(255)"),
    ("gateway_bank_txn_id", "VARCHAR(255)"),
    ("pricing_source", "VARCHAR(50)"),
    ("base_amount", "NUMERIC(10,2)"),
    ("applied_discount_plan_id", "INT"),
    ("applied_discount_plan_name", "VARCHAR(255)"),
    ("fulfillment_status", "VARCHAR(30) DEFAULT 'pending'"),
    ("fulfillment_attempted_at", "TIMESTAMP"),
    ("fulfilled_at", "TIMESTAMP"),
    ("fulfillment_error", "TEXT"),
    ("provider_response_meta", "TEXT"),
    ("fallback_used", "BOOLEAN DEFAULT false"),
    ("delivered_source", "VARCHAR(30)"),
    ("owner_alert_sent_at", "TIMESTAMP"),
    ("source_rule_snapshot", "TEXT"),
]

REQUIRED_PKH_COLUMNS = [
    ("pricing_source", "VARCHAR(50)"),
    ("base_amount", "NUMERIC(10,2)"),
    ("applied_discount_plan_id", "INT"),
    ("applied_discount_plan_name", "VARCHAR(255)"),
    ("purchased_at", "TIMESTAMP"),
]

REQUIRED_DISCOUNT_PLAN_COLUMNS = [
    ("description", "TEXT DEFAULT ''"),
    ("broadcast_template", "TEXT DEFAULT ''"),
]

REQUIRED_BROADCAST_QUEUE_COLUMNS = [
    ("queue_type", "VARCHAR(30) DEFAULT 'broadcast'"),
    ("delete_target_queue_id", "INT"),
]


async def ensure_columns(table: str, columns: list[tuple[str, str]]):
    for col_name, col_type in columns:
        exists = await db.fetch_val(
            """SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public'
                 AND table_name = $1
                 AND column_name = $2""",
            table, col_name
        )
        if not exists:
            try:
                await db.execute(
                    f'ALTER TABLE "{table}" ADD COLUMN "{col_name}" {col_type}'
                )
                logger.info(f"Migration: added column {table}.{col_name} ({col_type})")
            except Exception as e:
                logger.error(f"Migration: failed to add {table}.{col_name}: {e}")


async def ensure_unique_index(table: str, column: str, index_name: str):
    exists = await db.fetch_val(
        """SELECT 1 FROM pg_indexes
           WHERE schemaname = 'public'
             AND tablename = $1
             AND indexname = $2""",
        table, index_name
    )
    if not exists:
        try:
            await db.execute(
                f'CREATE UNIQUE INDEX "{index_name}" ON "{table}" ("{column}")'
            )
            logger.info(f"Migration: created unique index {index_name} on {table}.{column}")
        except Exception as e:
            logger.error(f"Migration: failed to create index {index_name}: {e}")


async def ensure_core_tables():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            is_hidden SMALLINT NOT NULL DEFAULT 0,
            button_style SMALLINT NOT NULL DEFAULT 4,
            file_id VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_categories_visible_sort
        ON categories (is_hidden, sort_order, id)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS durations (
            id SERIAL PRIMARY KEY,
            category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
            name VARCHAR(100) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            button_style SMALLINT NOT NULL DEFAULT 4,
            price NUMERIC(10,2) NOT NULL DEFAULT 0,
            is_hidden SMALLINT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_durations_cat_sort
        ON durations (category_id, sort_order, id)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS resellers (
            id SERIAL PRIMARY KEY,
            code VARCHAR(6) NOT NULL,
            expires_at TIMESTAMP DEFAULT NULL,
            max_users INT DEFAULT NULL,
            total_price NUMERIC(10,2) DEFAULT NULL,
            discount_type VARCHAR(10) NOT NULL DEFAULT 'percent',
            discount_value NUMERIC(10,2) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_resellers_code ON resellers (code)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            telegram_id BIGINT NOT NULL,
            username VARCHAR(255) DEFAULT NULL,
            first_name VARCHAR(255) DEFAULT NULL,
            last_name VARCHAR(255) DEFAULT NULL,
            token VARCHAR(64) DEFAULT NULL,
            is_banned SMALLINT NOT NULL DEFAULT 0,
            reseller_id INT DEFAULT NULL REFERENCES resellers(id) ON DELETE SET NULL,
            awaiting_code SMALLINT NOT NULL DEFAULT 0,
            start_categories_message_id BIGINT DEFAULT NULL,
            active_payment_order_id BIGINT DEFAULT NULL,
            active_keys_viewer_message_id BIGINT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_users_telegram_id ON users (telegram_id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_reseller_id ON users (reseller_id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_banned ON users (is_banned)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_awaiting_code ON users (awaiting_code)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS product_keys (
            id SERIAL PRIMARY KEY,
            category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
            duration_id INT NOT NULL REFERENCES durations(id) ON DELETE CASCADE,
            key_value VARCHAR(255) NOT NULL,
            price NUMERIC(10,2) NOT NULL DEFAULT 0,
            is_sold SMALLINT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_product_keys_key_value ON product_keys (key_value)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_product_keys_stock_lookup
        ON product_keys (category_id, duration_id, is_sold, id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_product_keys_is_sold ON product_keys (is_sold, id)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id SERIAL PRIMARY KEY,
            user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            key_id INT DEFAULT NULL REFERENCES product_keys(id) ON DELETE SET NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            amount NUMERIC(10,2) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            qr_message_id BIGINT DEFAULT NULL,
            last_error_message_id BIGINT DEFAULT NULL,
            txn_ref VARCHAR(64) DEFAULT NULL,
            verified_at TIMESTAMP DEFAULT NULL,
            purchased_category_name VARCHAR(150) DEFAULT NULL,
            purchased_duration_name VARCHAR(150) DEFAULT NULL,
            purchased_key_value TEXT DEFAULT NULL,
            purchased_amount NUMERIC(10,2) DEFAULT NULL,
            purchaser_role VARCHAR(50) NOT NULL DEFAULT 'customer',
            purchaser_label VARCHAR(255) DEFAULT NULL,
            paid_utr VARCHAR(255) DEFAULT NULL,
            delivered_at TIMESTAMP DEFAULT NULL,
            gateway_txn_id VARCHAR(255) DEFAULT NULL,
            gateway_bank_txn_id VARCHAR(255) DEFAULT NULL,
            paid_amount NUMERIC(10,2) DEFAULT NULL
        )
    """)
    await db.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_orders_txn_ref ON orders (txn_ref)
        WHERE txn_ref IS NOT NULL
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders (user_id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_orders_status_created ON orders (status, created_at)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_orders_user_status_id ON orders (user_id, status, id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_orders_purchaser_role ON orders (purchaser_role, id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_orders_delivered_at ON orders (delivered_at)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS reseller_users (
            id SERIAL PRIMARY KEY,
            reseller_id INT NOT NULL REFERENCES resellers(id) ON DELETE CASCADE,
            user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            assigned_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS uq_reseller_users_pair
        ON reseller_users (reseller_id, user_id)
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS purchased_keys_history (
            id BIGSERIAL PRIMARY KEY,
            user_id INT NOT NULL,
            order_id INT DEFAULT NULL,
            telegram_id BIGINT NOT NULL,
            username VARCHAR(255) DEFAULT NULL,
            first_name VARCHAR(255) DEFAULT NULL,
            last_name VARCHAR(255) DEFAULT NULL,
            is_reseller_purchase SMALLINT NOT NULL DEFAULT 0,
            category_name VARCHAR(150) NOT NULL,
            duration_name VARCHAR(150) NOT NULL,
            key_value VARCHAR(255) NOT NULL,
            amount NUMERIC(10,2) NOT NULL DEFAULT 0,
            txn_ref VARCHAR(64) DEFAULT NULL,
            gateway_txn_id VARCHAR(128) DEFAULT NULL,
            gateway_bank_txn_id VARCHAR(128) DEFAULT NULL,
            verified_at TIMESTAMP DEFAULT NULL,
            purchased_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_pkh_user_time
        ON purchased_keys_history (user_id, purchased_at, id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_pkh_tg_time
        ON purchased_keys_history (telegram_id, purchased_at, id)
    """)
    await db.execute("""
        CREATE INDEX IF NOT EXISTS idx_pkh_key_value ON purchased_keys_history (key_value)
    """)


async def ensure_bot_settings_table():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS bot_settings (
            key VARCHAR(100) PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        )
    """)


async def ensure_discount_tables():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS discount_plans (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL DEFAULT 'Untitled Offer',
            description TEXT DEFAULT '',
            is_active BOOLEAN NOT NULL DEFAULT false,
            apply_scope VARCHAR(50) NOT NULL DEFAULT 'all_categories',
            starts_at TIMESTAMP,
            expires_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS discount_rules (
            id SERIAL PRIMARY KEY,
            plan_id INT NOT NULL REFERENCES discount_plans(id) ON DELETE CASCADE,
            category_id INT,
            duration_id INT,
            discount_type VARCHAR(30),
            discount_value NUMERIC(10,2),
            override_price NUMERIC(10,2)
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_discount_rules_plan ON discount_rules(plan_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_discount_plans_active ON discount_plans(is_active) WHERE is_active = true")
    except Exception as e:
        logger.warning(f"Discount index creation note: {e}")


async def ensure_broadcast_queue_table():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS broadcast_queue (
            id SERIAL PRIMARY KEY,
            plan_id INT NOT NULL,
            template_override TEXT DEFAULT '',
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            result JSONB,
            created_at TIMESTAMP DEFAULT NOW(),
            completed_at TIMESTAMP
        )
    """)


async def ensure_broadcast_messages_table():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS discount_broadcast_messages (
            id SERIAL PRIMARY KEY,
            queue_id INT NOT NULL,
            plan_id INT NOT NULL,
            user_id INT,
            telegram_id BIGINT NOT NULL,
            broadcast_message_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_dbm_queue ON discount_broadcast_messages(queue_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_dbm_plan ON discount_broadcast_messages(plan_id)")
    except Exception as e:
        logger.warning(f"Broadcast messages index note: {e}")



REQUIRED_SOURCE_FULFILLMENT_LOG_COLUMNS = [
    ("order_id", "INT"),
    ("category_id", "INT"),
    ("duration_id", "INT"),
    ("category_name", "VARCHAR(255)"),
    ("duration_name", "VARCHAR(255)"),
    ("source_type", "VARCHAR(20)"),
    ("provider_id", "INT"),
    ("provider_name", "VARCHAR(255)"),
    ("resolution_success", "BOOLEAN DEFAULT false"),
    ("delivery_success", "BOOLEAN DEFAULT false"),
    ("key_value", "TEXT"),
    ("api_request_url", "TEXT"),
    ("api_raw_response", "TEXT"),
    ("failure_reason", "TEXT"),
    ("user_telegram_id", "BIGINT"),
    ("user_display_name", "VARCHAR(255)"),
    ("delivered_source", "VARCHAR(30)"),
    ("fallback_used", "BOOLEAN DEFAULT false"),
    ("response_time_ms", "INT"),
    ("http_status", "INT"),
]


async def ensure_source_tables():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS api_providers (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            base_url TEXT NOT NULL,
            token TEXT DEFAULT NULL,
            is_active BOOLEAN NOT NULL DEFAULT true,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await ensure_columns("api_providers", [("token", "TEXT")])
    await db.execute("""
        CREATE TABLE IF NOT EXISTS source_rules (
            id SERIAL PRIMARY KEY,
            category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
            duration_id INT NOT NULL REFERENCES durations(id) ON DELETE CASCADE,
            source_type VARCHAR(20) NOT NULL,
            api_provider_id INT REFERENCES api_providers(id) ON DELETE SET NULL,
            api_game_value VARCHAR(255) DEFAULT NULL,
            api_duration_value VARCHAR(255) DEFAULT NULL,
            api_device_value VARCHAR(255) DEFAULT NULL,
            api_currency_value VARCHAR(255) DEFAULT NULL,
            is_active BOOLEAN NOT NULL DEFAULT true,
            last_test_result TEXT DEFAULT NULL,
            last_test_success BOOLEAN DEFAULT NULL,
            last_test_at TIMESTAMP DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS uq_source_rules_cat_dur
            ON source_rules (category_id, duration_id)
        """)
    except Exception as e:
        logger.warning(f"Source rules index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS source_fulfillment_logs (
            id BIGSERIAL PRIMARY KEY,
            order_id INT DEFAULT NULL,
            category_id INT DEFAULT NULL,
            duration_id INT DEFAULT NULL,
            category_name VARCHAR(255) DEFAULT NULL,
            duration_name VARCHAR(255) DEFAULT NULL,
            source_type VARCHAR(20) DEFAULT NULL,
            provider_id INT DEFAULT NULL,
            provider_name VARCHAR(255) DEFAULT NULL,
            resolution_success BOOLEAN NOT NULL DEFAULT false,
            delivery_success BOOLEAN NOT NULL DEFAULT false,
            key_value TEXT DEFAULT NULL,
            api_request_url TEXT DEFAULT NULL,
            api_raw_response TEXT DEFAULT NULL,
            failure_reason TEXT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    await db.execute("""
        CREATE TABLE IF NOT EXISTS fulfillment_issues (
            id SERIAL PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT DEFAULT NULL,
            category_id INT DEFAULT NULL,
            duration_id INT DEFAULT NULL,
            source_rule_id INT DEFAULT NULL,
            provider_id INT DEFAULT NULL,
            source_type VARCHAR(30) DEFAULT NULL,
            failure_reason TEXT DEFAULT NULL,
            failure_code VARCHAR(100) DEFAULT NULL,
            payload_snapshot JSONB DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            recovery_key TEXT DEFAULT NULL,
            recovery_note TEXT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            resolved_at TIMESTAMP DEFAULT NULL,
            resolved_by VARCHAR(255) DEFAULT NULL,
            send_attempts INT NOT NULL DEFAULT 0,
            last_send_error TEXT DEFAULT NULL
        )
    """)

    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sfl_order ON source_fulfillment_logs(order_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sfl_cat ON source_fulfillment_logs(category_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sfl_created ON source_fulfillment_logs(created_at)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_fi_order ON fulfillment_issues(order_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_fi_status ON fulfillment_issues(status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_fi_created ON fulfillment_issues(created_at)")
    except Exception as e:
        logger.warning(f"Source fulfillment log index note: {e}")


REQUIRED_ORDER_CAMPAIGN_COLUMNS = [
    ("campaign_id", "INT"),
    ("campaign_deep_link_code", "VARCHAR(64)"),
    ("paid_amount", "NUMERIC(10,2)"),
]


async def ensure_campaign_tables():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_templates (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL DEFAULT 'Untitled',
            template_type VARCHAR(30) NOT NULL DEFAULT 'promo_start',
            body_text TEXT NOT NULL DEFAULT '',
            parse_mode VARCHAR(20) NOT NULL DEFAULT 'HTML',
            custom_emoji_json TEXT,
            inline_buttons_json TEXT,
            button_style_json TEXT,
            media_type VARCHAR(30),
            media_url TEXT,
            is_active BOOLEAN NOT NULL DEFAULT true,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)

    await db.execute("""
        CREATE TABLE IF NOT EXISTS scheduled_campaigns (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL DEFAULT 'Untitled Campaign',
            description TEXT DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            campaign_mode VARCHAR(30) NOT NULL DEFAULT 'fixed_plan',
            linked_discount_plan_id INT,
            category_scope_json TEXT DEFAULT '[]',
            duration_scope_json TEXT DEFAULT '[]',
            repeat_mode VARCHAR(20) NOT NULL DEFAULT 'once',
            timezone VARCHAR(50) NOT NULL DEFAULT 'Asia/Kolkata',
            start_at TIMESTAMP NOT NULL DEFAULT NOW(),
            expire_at TIMESTAMP NOT NULL DEFAULT NOW(),
            next_run_at TIMESTAMP,
            next_expire_at TIMESTAMP,
            is_enabled BOOLEAN NOT NULL DEFAULT false,
            promo_template_id INT REFERENCES campaign_templates(id) ON DELETE SET NULL,
            expiry_template_id INT REFERENCES campaign_templates(id) ON DELETE SET NULL,
            send_to_users BOOLEAN NOT NULL DEFAULT true,
            send_to_channels BOOLEAN NOT NULL DEFAULT false,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            last_run_at TIMESTAMP,
            last_expired_at TIMESTAMP
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sc_status ON scheduled_campaigns(status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sc_next_run ON scheduled_campaigns(next_run_at) WHERE is_enabled = true")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sc_next_expire ON scheduled_campaigns(next_expire_at) WHERE is_enabled = true")
    except Exception as e:
        logger.warning(f"Campaign index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_discount_rules (
            id SERIAL PRIMARY KEY,
            campaign_id INT NOT NULL REFERENCES scheduled_campaigns(id) ON DELETE CASCADE,
            discount_mode VARCHAR(30) NOT NULL DEFAULT 'fixed_percent',
            fixed_value NUMERIC(10,2),
            min_value NUMERIC(10,2),
            max_value NUMERIC(10,2),
            applies_to_category_id INT,
            applies_to_duration_id INT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cdr_campaign ON campaign_discount_rules(campaign_id)")
    except Exception as e:
        logger.warning(f"Campaign discount rules index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_targets (
            id SERIAL PRIMARY KEY,
            campaign_id INT NOT NULL REFERENCES scheduled_campaigns(id) ON DELETE CASCADE,
            target_type VARCHAR(30) NOT NULL DEFAULT 'all_users',
            target_value TEXT,
            message_kind VARCHAR(20) NOT NULL DEFAULT 'promo_start',
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_ct_campaign ON campaign_targets(campaign_id)")
    except Exception as e:
        logger.warning(f"Campaign targets index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_deep_links (
            id SERIAL PRIMARY KEY,
            campaign_id INT NOT NULL REFERENCES scheduled_campaigns(id) ON DELETE CASCADE,
            code VARCHAR(64) NOT NULL,
            deep_link_url TEXT NOT NULL DEFAULT '',
            is_active BOOLEAN NOT NULL DEFAULT true,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_cdl_code ON campaign_deep_links(code)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cdl_campaign ON campaign_deep_links(campaign_id)")
    except Exception as e:
        logger.warning(f"Campaign deep links index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_runs (
            id SERIAL PRIMARY KEY,
            campaign_id INT NOT NULL REFERENCES scheduled_campaigns(id) ON DELETE CASCADE,
            run_type VARCHAR(30) NOT NULL DEFAULT 'promo_start',
            executed_at TIMESTAMP NOT NULL DEFAULT NOW(),
            status VARCHAR(20) NOT NULL DEFAULT 'running',
            generated_discount_value NUMERIC(10,2),
            generated_discount_type VARCHAR(30),
            generated_final_price_json TEXT,
            total_targets INT NOT NULL DEFAULT 0,
            total_sent INT NOT NULL DEFAULT 0,
            total_failed INT NOT NULL DEFAULT 0,
            revenue_generated NUMERIC(12,2),
            metadata TEXT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cr_campaign ON campaign_runs(campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cr_executed ON campaign_runs(executed_at)")
    except Exception as e:
        logger.warning(f"Campaign runs index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_delivery_logs (
            id BIGSERIAL PRIMARY KEY,
            campaign_run_id INT NOT NULL REFERENCES campaign_runs(id) ON DELETE CASCADE,
            campaign_id INT NOT NULL,
            target_type VARCHAR(20) NOT NULL DEFAULT 'user',
            telegram_id BIGINT,
            username VARCHAR(255),
            message_kind VARCHAR(20) NOT NULL DEFAULT 'promo_start',
            delivery_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            telegram_message_id BIGINT,
            error_text TEXT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cdl_run ON campaign_delivery_logs(campaign_run_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cdl_camp ON campaign_delivery_logs(campaign_id)")
    except Exception as e:
        logger.warning(f"Campaign delivery logs index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_link_events (
            id BIGSERIAL PRIMARY KEY,
            campaign_id INT NOT NULL REFERENCES scheduled_campaigns(id) ON DELETE CASCADE,
            deep_link_code VARCHAR(64) NOT NULL,
            telegram_user_id BIGINT NOT NULL,
            username VARCHAR(255),
            event_type VARCHAR(20) NOT NULL DEFAULT 'open',
            order_id INT,
            revenue_amount NUMERIC(12,2),
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_campaign ON campaign_link_events(campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_code ON campaign_link_events(deep_link_code)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_user ON campaign_link_events(telegram_user_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_order ON campaign_link_events(order_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_event_type ON campaign_link_events(event_type)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_created ON campaign_link_events(created_at)")
    except Exception as e:
        logger.warning(f"Campaign link events index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_attributions (
            id SERIAL PRIMARY KEY,
            user_id INT NOT NULL,
            telegram_id BIGINT NOT NULL,
            campaign_id INT NOT NULL,
            deep_link_code VARCHAR(64) NOT NULL,
            first_opened_at TIMESTAMP NOT NULL DEFAULT NOW(),
            last_opened_at TIMESTAMP NOT NULL DEFAULT NOW(),
            total_opens INT NOT NULL DEFAULT 1,
            attributed_orders INT NOT NULL DEFAULT 0,
            attributed_revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
            attribution_expires_at TIMESTAMP,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_ca_user_campaign ON campaign_attributions(user_id, campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_ca_campaign ON campaign_attributions(campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_ca_telegram ON campaign_attributions(telegram_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_ca_expires ON campaign_attributions(attribution_expires_at)")
    except Exception as e:
        logger.warning(f"Campaign attributions index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_daily_stats (
            id SERIAL PRIMARY KEY,
            stat_date DATE NOT NULL,
            campaign_id INT,
            total_opens INT NOT NULL DEFAULT 0,
            unique_opens INT NOT NULL DEFAULT 0,
            total_purchases INT NOT NULL DEFAULT 0,
            total_revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
            promo_start_sent INT NOT NULL DEFAULT 0,
            promo_expiry_sent INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_cds_date_camp ON campaign_daily_stats(stat_date, campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cds_date ON campaign_daily_stats(stat_date)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cds_campaign ON campaign_daily_stats(campaign_id)")
    except Exception as e:
        logger.warning(f"Campaign daily stats index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS campaign_expiry_logs (
            id SERIAL PRIMARY KEY,
            campaign_id INT NOT NULL,
            campaign_run_id INT,
            started_at TIMESTAMP NOT NULL DEFAULT NOW(),
            completed_at TIMESTAMP,
            status VARCHAR(20) NOT NULL DEFAULT 'running',
            discount_deactivated BOOLEAN NOT NULL DEFAULT false,
            recipients_resolved INT NOT NULL DEFAULT 0,
            sent INT NOT NULL DEFAULT 0,
            failed INT NOT NULL DEFAULT 0,
            error_text TEXT,
            metadata TEXT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cel_campaign ON campaign_expiry_logs(campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cel_started ON campaign_expiry_logs(started_at)")
    except Exception as e:
        logger.warning(f"Campaign expiry logs index note: {e}")


async def run_migrations():
    logger.info("Running bot database migrations...")
    await ensure_core_tables()
    await ensure_columns("users", REQUIRED_USER_COLUMNS)
    await ensure_columns("orders", REQUIRED_ORDER_COLUMNS)
    await ensure_unique_index("purchased_keys_history", "order_id", "idx_pkh_order_id")
    await ensure_bot_settings_table()
    await ensure_discount_tables()
    await ensure_columns("discount_plans", REQUIRED_DISCOUNT_PLAN_COLUMNS)
    await ensure_columns("purchased_keys_history", REQUIRED_PKH_COLUMNS)
    await ensure_broadcast_queue_table()
    await ensure_columns("broadcast_queue", REQUIRED_BROADCAST_QUEUE_COLUMNS)
    await ensure_broadcast_messages_table()
    await ensure_columns("discount_broadcast_messages", [
        ("pin_service_message_id", "BIGINT"),
    ])
    await ensure_source_tables()
    await ensure_columns("source_fulfillment_logs", REQUIRED_SOURCE_FULFILLMENT_LOG_COLUMNS)
    await _migrate_source_type_constraint()
    await ensure_campaign_tables()
    await ensure_columns("orders", REQUIRED_ORDER_CAMPAIGN_COLUMNS)
    await ensure_columns("scheduled_campaigns", [
        ("auto_discount_plan_id", "INT"),
        ("channel_targets_json", "TEXT DEFAULT '[]'"),
    ])
    await ensure_columns("discount_plans", [
        ("is_campaign_generated", "BOOLEAN DEFAULT false"),
    ])
    await ensure_columns("campaign_link_events", [
        ("attributed", "BOOLEAN DEFAULT false"),
    ])
    await ensure_columns("campaign_runs", [
        ("error_text", "TEXT"),
        ("admin_notified", "BOOLEAN DEFAULT false"),
        ("source_chat_id", "BIGINT"),
        ("source_message_id", "BIGINT"),
        ("channel_delivery_method", "VARCHAR(30) DEFAULT 'forward_message'"),
        ("channels_targeted", "INT DEFAULT 0"),
        ("channels_copied", "INT DEFAULT 0"),
        ("channels_failed", "INT DEFAULT 0"),
    ])
    await db.execute(
        "ALTER TABLE campaign_runs ALTER COLUMN channel_delivery_method SET DEFAULT 'forward_message'"
    )
    await ensure_columns("campaign_delivery_logs", [
        ("delivery_method", "VARCHAR(30) DEFAULT 'direct'"),
        ("source_message_id", "BIGINT"),
    ])
    await ensure_columns("campaign_templates", [
        ("updated_by", "VARCHAR(255) DEFAULT 'web'"),
        ("edited_via", "VARCHAR(10) DEFAULT 'web'"),
        ("body_entities_json", "TEXT"),
        ("apk_captions_json", "TEXT"),
        ("start_delivery_config_json", "TEXT"),
        ("category_id", "INT"),
    ])
    try:
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_ct_apk_caption_lookup "
            "ON campaign_templates (template_type, category_id, is_active) "
            "WHERE template_type = 'trial_apk_caption'"
        )
    except Exception as e:
        logger.warning(f"APK caption index note: {e}")
    await _ensure_template_versions_table()
    await ensure_columns("template_versions", [
        ("body_entities_json", "TEXT"),
    ])

    # ── Deep link lifecycle upgrade ──────────────────────────────────────────
    await ensure_columns("campaign_deep_links", [
        ("campaign_run_id", "INT"),
        ("status", "VARCHAR(20) NOT NULL DEFAULT 'active'"),
        ("activated_at", "TIMESTAMP"),
        ("expired_at", "TIMESTAMP"),
        ("attribution_start_at", "TIMESTAMP"),
        ("attribution_end_at", "TIMESTAMP"),
        ("opens_count", "INT NOT NULL DEFAULT 0"),
        ("unique_opens_count", "INT NOT NULL DEFAULT 0"),
        ("starts_count", "INT NOT NULL DEFAULT 0"),
        ("purchases_count", "INT NOT NULL DEFAULT 0"),
        ("revenue_total", "NUMERIC(12,2) NOT NULL DEFAULT 0"),
        ("late_purchases_count", "INT NOT NULL DEFAULT 0"),
        ("late_revenue_total", "NUMERIC(12,2) NOT NULL DEFAULT 0"),
    ])
    await ensure_columns("campaign_link_events", [
        ("campaign_run_id", "INT"),
        ("deep_link_id", "INT"),
        ("is_late_conversion", "BOOLEAN NOT NULL DEFAULT false"),
    ])
    await ensure_columns("campaign_attributions", [
        ("campaign_run_id", "INT"),
        ("deep_link_id", "INT"),
        ("attribution_end_at", "TIMESTAMP"),
    ])
    await ensure_columns("orders", [
        ("campaign_run_id", "INT"),
        ("campaign_deep_link_id", "INT"),
        ("is_campaign_late_conversion", "BOOLEAN NOT NULL DEFAULT false"),
    ])
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cdl_run_id ON campaign_deep_links(campaign_run_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cdl_status ON campaign_deep_links(status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_dlid ON campaign_link_events(deep_link_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_cle_late ON campaign_link_events(is_late_conversion)")
    except Exception as e:
        logger.warning(f"Deep link upgrade index note: {e}")

    await ensure_trial_tables()
    await ensure_columns("trial_campaigns", [
        ("apk_delivery_config_json", "TEXT"),
        ("delivery_mode", "VARCHAR(30) NOT NULL DEFAULT 'mode_1_separate'"),
        ("category_names_snapshot_json", "TEXT"),
    ])

    await ensure_columns("trial_keys", [
        ("category_name_snapshot", "VARCHAR(255)"),
    ])
    await ensure_columns("campaign_templates", [
        ("category_name_snapshot", "VARCHAR(255)"),
    ])
    await ensure_columns("trial_campaign_run_keys", [
        ("category_name_snapshot", "VARCHAR(255)"),
    ])

    await _migrate_trial_keys_fk_to_set_null()
    await _backfill_category_name_snapshots()
    await _add_missing_performance_indexes()
    await _fix_orders_user_fk_cascade()
    await _create_reseller_prices_table()
    await _ensure_category_duration_settings_table()

    logger.info("Bot database migrations complete")


async def ensure_trial_tables():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS trial_keys (
            id SERIAL PRIMARY KEY,
            category_id INT REFERENCES categories(id) ON DELETE SET NULL,
            category_name_snapshot VARCHAR(255),
            duration_hours INT NOT NULL DEFAULT 1,
            max_devices INT NOT NULL DEFAULT 1,
            key_value VARCHAR(500) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'available',
            used_in_trial_campaign_run_id INT,
            used_at TIMESTAMP,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_trial_keys_value ON trial_keys(key_value)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_trial_keys_cat_dur ON trial_keys(category_id, duration_hours, status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_trial_keys_status ON trial_keys(status)")
    except Exception as e:
        logger.warning(f"Trial keys index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS trial_campaigns (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL DEFAULT 'Untitled Trial',
            description TEXT DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            category_ids_json TEXT NOT NULL DEFAULT '[]',
            trial_duration_hours INT NOT NULL DEFAULT 1,
            max_devices INT,
            repeat_mode VARCHAR(20) NOT NULL DEFAULT 'once',
            timezone VARCHAR(50) NOT NULL DEFAULT 'Asia/Kolkata',
            start_at TIMESTAMP NOT NULL DEFAULT NOW(),
            expire_at TIMESTAMP NOT NULL DEFAULT NOW(),
            next_run_at TIMESTAMP,
            next_expire_at TIMESTAMP,
            is_enabled BOOLEAN NOT NULL DEFAULT false,
            start_template_id INT REFERENCES campaign_templates(id) ON DELETE SET NULL,
            expire_template_id INT REFERENCES campaign_templates(id) ON DELETE SET NULL,
            send_to_users BOOLEAN NOT NULL DEFAULT true,
            send_to_channels BOOLEAN NOT NULL DEFAULT false,
            channel_targets_json TEXT DEFAULT '[]',
            reveal_keys_in_channels BOOLEAN NOT NULL DEFAULT false,
            linked_promo_campaign_id INT,
            target_audience VARCHAR(30) NOT NULL DEFAULT 'all_users',
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
            last_run_at TIMESTAMP,
            last_expired_at TIMESTAMP
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tc_status ON trial_campaigns(status)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tc_next_run ON trial_campaigns(next_run_at) WHERE is_enabled = true")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tc_next_expire ON trial_campaigns(next_expire_at) WHERE is_enabled = true")
    except Exception as e:
        logger.warning(f"Trial campaigns index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS trial_campaign_runs (
            id SERIAL PRIMARY KEY,
            campaign_id INT NOT NULL REFERENCES trial_campaigns(id) ON DELETE CASCADE,
            run_type VARCHAR(30) NOT NULL DEFAULT 'trial_start',
            status VARCHAR(20) NOT NULL DEFAULT 'running',
            total_targets INT NOT NULL DEFAULT 0,
            total_sent INT NOT NULL DEFAULT 0,
            total_failed INT NOT NULL DEFAULT 0,
            channels_targeted INT NOT NULL DEFAULT 0,
            channels_sent INT NOT NULL DEFAULT 0,
            channels_failed INT NOT NULL DEFAULT 0,
            error_text TEXT,
            started_at TIMESTAMP NOT NULL DEFAULT NOW(),
            completed_at TIMESTAMP,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tcr_campaign ON trial_campaign_runs(campaign_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tcr_started ON trial_campaign_runs(started_at)")
    except Exception as e:
        logger.warning(f"Trial campaign runs index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS trial_campaign_run_keys (
            id SERIAL PRIMARY KEY,
            run_id INT NOT NULL REFERENCES trial_campaign_runs(id) ON DELETE CASCADE,
            campaign_id INT NOT NULL,
            category_id INT NOT NULL,
            category_name_snapshot VARCHAR(255),
            trial_key_id INT NOT NULL REFERENCES trial_keys(id) ON DELETE CASCADE,
            key_value_snapshot VARCHAR(500) NOT NULL,
            duration_hours INT NOT NULL,
            max_devices INT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tcrk_run ON trial_campaign_run_keys(run_id)")
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_tcrk_run_cat ON trial_campaign_run_keys(run_id, category_id)")
    except Exception as e:
        logger.warning(f"Trial campaign run keys index note: {e}")

    await db.execute("""
        CREATE TABLE IF NOT EXISTS trial_campaign_delivery_logs (
            id BIGSERIAL PRIMARY KEY,
            run_id INT NOT NULL REFERENCES trial_campaign_runs(id) ON DELETE CASCADE,
            campaign_id INT NOT NULL,
            target_type VARCHAR(20) NOT NULL DEFAULT 'user',
            telegram_id BIGINT,
            message_kind VARCHAR(30) NOT NULL DEFAULT 'trial_start',
            delivery_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            telegram_message_id BIGINT,
            error_text TEXT,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tcdl_run ON trial_campaign_delivery_logs(run_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tcdl_campaign ON trial_campaign_delivery_logs(campaign_id)")
    except Exception as e:
        logger.warning(f"Trial campaign delivery logs index note: {e}")


async def _ensure_template_versions_table():
    await db.execute("""
        CREATE TABLE IF NOT EXISTS template_versions (
            id SERIAL PRIMARY KEY,
            template_id INTEGER NOT NULL,
            body_text TEXT NOT NULL DEFAULT '',
            inline_buttons_json TEXT,
            changed_by VARCHAR(255) DEFAULT 'web',
            changed_via VARCHAR(10) DEFAULT 'web',
            change_note TEXT DEFAULT '',
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
    """)
    try:
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tv_template ON template_versions(template_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tv_created ON template_versions(created_at)")
    except Exception as e:
        logger.warning(f"Template versions index note: {e}")


async def _migrate_trial_keys_fk_to_set_null():
    try:
        existing = await db.fetch_val(
            """SELECT 1 FROM information_schema.table_constraints
               WHERE constraint_name = 'trial_keys_category_id_fkey'
                 AND table_name = 'trial_keys'"""
        )
        if not existing:
            logger.info("Migration: trial_keys FK already removed or renamed, skipping")
            return
        confkey = await db.fetch_val(
            """SELECT confdeltype FROM pg_constraint WHERE conname = 'trial_keys_category_id_fkey'"""
        )
        if confkey and confkey == 'n':
            logger.info("Migration: trial_keys FK already SET NULL, skipping")
            return
        await db.execute("ALTER TABLE trial_keys ALTER COLUMN category_id DROP NOT NULL")
        await db.execute("ALTER TABLE trial_keys DROP CONSTRAINT trial_keys_category_id_fkey")
        await db.execute(
            "ALTER TABLE trial_keys ADD CONSTRAINT trial_keys_category_id_fkey "
            "FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL"
        )
        logger.info("Migration: changed trial_keys.category_id FK from CASCADE to SET NULL")
    except Exception as e:
        logger.warning(f"Trial keys FK migration note: {e}")


async def _backfill_category_name_snapshots():
    try:
        updated_tk = await db.execute("""
            UPDATE trial_keys tk SET category_name_snapshot = c.name
            FROM categories c WHERE c.id = tk.category_id
            AND tk.category_name_snapshot IS NULL
        """)
        logger.info(f"Migration: backfilled trial_keys snapshots")

        updated_ct = await db.execute("""
            UPDATE campaign_templates ct SET category_name_snapshot = c.name
            FROM categories c WHERE c.id = ct.category_id
            AND ct.category_name_snapshot IS NULL AND ct.category_id IS NOT NULL
        """)
        logger.info(f"Migration: backfilled campaign_templates snapshots")

        updated_rk = await db.execute("""
            UPDATE trial_campaign_run_keys rk SET category_name_snapshot = c.name
            FROM categories c WHERE c.id = rk.category_id
            AND rk.category_name_snapshot IS NULL
        """)
        logger.info(f"Migration: backfilled trial_campaign_run_keys snapshots")

        orphaned_ct = await db.execute("""
            UPDATE campaign_templates SET category_name_snapshot =
                COALESCE(
                    NULLIF(regexp_replace(name, '^APK Caption — ', ''), name),
                    'Deleted Category (ID ' || category_id || ')'
                )
            WHERE template_type = 'trial_apk_caption'
              AND category_name_snapshot IS NULL
              AND category_id IS NOT NULL
              AND NOT EXISTS (SELECT 1 FROM categories c WHERE c.id = campaign_templates.category_id)
        """)
        logger.info(f"Migration: backfilled orphaned campaign_templates snapshots")

        orphaned_rk = await db.execute("""
            UPDATE trial_campaign_run_keys SET category_name_snapshot =
                'Deleted Category (ID ' || category_id || ')'
            WHERE category_name_snapshot IS NULL
              AND NOT EXISTS (SELECT 1 FROM categories c WHERE c.id = trial_campaign_run_keys.category_id)
        """)
        logger.info(f"Migration: backfilled orphaned run_keys snapshots")

        await db.execute("""
            UPDATE trial_campaigns tc SET category_names_snapshot_json = (
                SELECT json_agg(json_build_object('id', cid, 'name', COALESCE(c.name, 'Deleted Category (ID ' || cid || ')')))::text
                FROM json_array_elements_text(tc.category_ids_json::json) AS cid_text,
                LATERAL (SELECT cid_text::int AS cid) parsed
                LEFT JOIN categories c ON c.id = parsed.cid
            )
            WHERE tc.category_ids_json IS NOT NULL
              AND tc.category_ids_json != '[]'
              AND tc.category_names_snapshot_json IS NULL
        """)
        logger.info(f"Migration: backfilled trial_campaigns category name snapshots")
    except Exception as e:
        logger.warning(f"Category name snapshot backfill note: {e}")


async def _add_missing_performance_indexes():
    idx_defs = [
        ("idx_cdl_delivery_status", "campaign_delivery_logs", "(delivery_status)"),
        ("idx_tcdl_delivery_status", "trial_campaign_delivery_logs", "(delivery_status)"),
        ("idx_orders_campaign_id", "orders", "(campaign_id)"),
        ("idx_tcdl_target_type", "trial_campaign_delivery_logs", "(target_type)"),
    ]
    for idx_name, tbl, cols in idx_defs:
        try:
            await db.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {tbl} {cols}")
        except Exception as e:
            logger.warning(f"Index {idx_name} note: {e}")
    logger.info("Migration: performance indexes verified")


async def _fix_orders_user_fk_cascade():
    try:
        row = await db.fetch_one("""
            SELECT confdeltype FROM pg_constraint
            WHERE conname = 'orders_user_id_fkey'
        """)
        del_type = row.get("confdeltype", "") if row else ""
        if isinstance(del_type, (bytes, memoryview)):
            del_type = bytes(del_type).decode()
        if del_type == "c":
            await db.execute("ALTER TABLE orders ALTER COLUMN user_id DROP NOT NULL")
            await db.execute("ALTER TABLE orders DROP CONSTRAINT orders_user_id_fkey")
            await db.execute(
                "ALTER TABLE orders ADD CONSTRAINT orders_user_id_fkey "
                "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL"
            )
            logger.info("Migration: changed orders.user_id FK from CASCADE to SET NULL")
        else:
            logger.info("Migration: orders.user_id FK already safe")
    except Exception as e:
        logger.warning(f"Orders user FK migration note: {e}")


async def _create_reseller_prices_table():
    try:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reseller_prices (
                id SERIAL PRIMARY KEY,
                reseller_id INT NOT NULL REFERENCES resellers(id) ON DELETE CASCADE,
                category_id INT REFERENCES categories(id) ON DELETE CASCADE,
                duration_id INT REFERENCES durations(id) ON DELETE CASCADE,
                price NUMERIC(10,2) DEFAULT NULL,
                discount_type VARCHAR(10) DEFAULT NULL,
                discount_value NUMERIC(10,2) DEFAULT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_reseller_prices_reseller
            ON reseller_prices (reseller_id)
        """)
        logger.info("Migration: reseller_prices table ensured")
    except Exception as e:
        logger.warning(f"reseller_prices migration note: {e}")


async def _ensure_category_duration_settings_table():
    try:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS category_duration_settings (
                category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
                setting_key VARCHAR(100) NOT NULL,
                value TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (category_id, setting_key)
            )
        """)
        await db.execute("""
            CREATE INDEX IF NOT EXISTS idx_catdur_category
            ON category_duration_settings (category_id)
        """)
        logger.info("Migration: category_duration_settings table ensured")
    except Exception as e:
        logger.warning(f"category_duration_settings migration note: {e}")


async def _migrate_source_type_constraint():
    try:
        await db.execute("""
            ALTER TABLE source_rules DROP CONSTRAINT IF EXISTS source_rules_source_type_check
        """)
    except Exception:
        pass
    try:
        await db.execute("""
            ALTER TABLE source_rules ADD CONSTRAINT source_rules_source_type_check
            CHECK (source_type IN ('manual', 'api', 'api_and_manual'))
        """)
    except Exception as e:
        logger.warning("source_type constraint migration note: %s", e)
