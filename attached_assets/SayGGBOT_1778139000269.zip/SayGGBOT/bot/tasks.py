import asyncio
import logging
from telegram import Bot
from bot import database as db
from bot import settings
from bot.cleanup import (
    safe_delete_message,
    clear_active_payment_pointer_if_matches,
    send_expiry_notice,
    cleanup_user_active_payment_error,
)

logger = logging.getLogger(__name__)


async def expire_old_orders(bot: Bot):
    minutes = settings.get_int('order_timeout_minutes', 15)
    if minutes <= 0:
        minutes = 15

    async with db.pool.acquire() as conn:
        async with conn.transaction():
            rows = await conn.fetch(
                """SELECT o.id, o.user_id, o.key_id, o.qr_message_id,
                          o.amount, o.txn_ref, o.purchased_category_name, o.purchased_duration_name,
                          u.telegram_id, u.first_name, u.username,
                          u.active_payment_error_message_id
                   FROM orders o
                   JOIN users u ON u.id = o.user_id
                   WHERE o.status IN ('pending', 'awaiting_payment')
                     AND o.created_at < (NOW() - INTERVAL '%s minutes')
                   FOR UPDATE OF o""" % minutes
            )

            if not rows:
                return

            order_ids = [r["id"] for r in rows]
            key_ids = [r["key_id"] for r in rows if r["key_id"]]

            placeholders = ", ".join(f"${i+1}" for i in range(len(order_ids)))
            await conn.execute(
                f"UPDATE orders SET status = 'cancelled' WHERE id IN ({placeholders})",
                *order_ids
            )

            if key_ids:
                key_ph = ", ".join(f"${i+1}" for i in range(len(key_ids)))
                await conn.execute(
                    f"UPDATE product_keys SET is_sold = 0 WHERE id IN ({key_ph}) AND is_sold = 2",
                    *key_ids
                )

    for row in rows:
        qr_mid = row.get("qr_message_id") or 0
        tg_chat = row.get("telegram_id") or 0
        user_id = row["user_id"]

        if tg_chat > 0 and qr_mid > 0:
            await safe_delete_message(bot, tg_chat, qr_mid)

        err_mid = int(row.get("active_payment_error_message_id") or 0)
        if tg_chat > 0 and err_mid > 0:
            await safe_delete_message(bot, tg_chat, err_mid)
            from bot.cleanup import clear_user_active_payment_error_message_id
            await clear_user_active_payment_error_message_id(user_id)

        await clear_active_payment_pointer_if_matches(user_id, row["id"])

        if tg_chat > 0:
            try:
                from bot.payment import build_order_context
                expiry_ctx = build_order_context(
                    {"id": row["id"], "txn_ref": row.get("txn_ref"),
                     "amount": row.get("amount"), "status": "cancelled",
                     "purchased_category_name": row.get("purchased_category_name"),
                     "purchased_duration_name": row.get("purchased_duration_name")},
                    {"first_name": row.get("first_name"), "username": row.get("username"),
                     "telegram_id": tg_chat},
                )
                await send_expiry_notice(bot, tg_chat, user_id, expiry_ctx)
            except Exception as e:
                logger.error("Failed to send expiry notice to %s: %s", tg_chat, e)

    logger.info(f"Expired {len(rows)} old orders")


async def run_expire_loop(bot: Bot):
    while True:
        try:
            await expire_old_orders(bot)
        except Exception as e:
            logger.error(f"expire_old_orders error: {e}")
        await asyncio.sleep(60)


async def process_pending_broadcasts(bot: Bot):
    claimed = await db.fetch_one(
        """UPDATE broadcast_queue SET status = 'sending'
           WHERE id = (
             SELECT id FROM broadcast_queue
             WHERE status = 'pending'
             ORDER BY id ASC LIMIT 1
             FOR UPDATE SKIP LOCKED
           )
           RETURNING id, plan_id, template_override, queue_type, delete_target_queue_id"""
    )
    if not claimed:
        return

    queue_id = claimed["id"]
    plan_id = claimed["plan_id"]
    queue_type = claimed.get("queue_type") or "broadcast"

    import json

    if queue_type == "delete_messages":
        target_queue_id = claimed.get("delete_target_queue_id")
        try:
            from bot.services.broadcast import delete_broadcast_messages, delete_plan_broadcast_messages
            if target_queue_id:
                result = await delete_broadcast_messages(bot, target_queue_id)
            else:
                result = await delete_plan_broadcast_messages(bot, plan_id)
            await db.execute(
                "UPDATE broadcast_queue SET status = 'completed', result = $1, completed_at = NOW() WHERE id = $2",
                json.dumps(result), queue_id
            )
            logger.info(f"Delete messages queue #{queue_id} completed: {result}")
        except Exception as e:
            error_result = {"error": str(e)}
            await db.execute(
                "UPDATE broadcast_queue SET status = 'failed', result = $1, completed_at = NOW() WHERE id = $2",
                json.dumps(error_result), queue_id
            )
            logger.error(f"Delete messages queue #{queue_id} failed: {e}")
        return

    template_override = claimed.get("template_override") or ""
    try:
        from bot.services.broadcast import send_discount_broadcast
        result = await send_discount_broadcast(bot, plan_id, template_override or None, queue_id=queue_id)

        if "error" in result:
            await db.execute(
                "UPDATE broadcast_queue SET status = 'failed', result = $1, completed_at = NOW() WHERE id = $2",
                json.dumps(result), queue_id
            )
            logger.warning(f"Broadcast queue #{queue_id} failed (logical): {result}")
        else:
            await db.execute(
                "UPDATE broadcast_queue SET status = 'completed', result = $1, completed_at = NOW() WHERE id = $2",
                json.dumps(result), queue_id
            )
            logger.info(f"Broadcast queue #{queue_id} completed: {result}")
    except Exception as e:
        error_result = {"error": str(e)}
        await db.execute(
            "UPDATE broadcast_queue SET status = 'failed', result = $1, completed_at = NOW() WHERE id = $2",
            json.dumps(error_result), queue_id
        )
        logger.error(f"Broadcast queue #{queue_id} failed: {e}")


async def run_broadcast_poller(bot: Bot):
    while True:
        try:
            await process_pending_broadcasts(bot)
        except Exception as e:
            logger.error(f"broadcast_poller error: {e}")
        await asyncio.sleep(3)
