import asyncio
import json
import logging
import urllib.request
import urllib.parse
import hashlib
import hmac
import secrets
from datetime import datetime, timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))
from html import escape

from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup

from bot import database as db
from bot.config import (
    PAYTM_UPI_ID,
    PAYTM_MERCHANT_ID,
    PAYTM_MERCHANT_KEY,
    PAYTM_ENV,
    ADMIN_CHAT_ID,
)
from bot import settings
from bot.telegram_api import generate_upi_qr, append_purchase_log
from bot.cleanup import (
    cleanup_user_active_payment,
    save_user_active_payment_order_id,
    clear_user_active_payment_order_id,
    cancel_order_and_release_key,
    clear_active_payment_pointer_if_matches,
    safe_delete_message,
    cleanup_user_active_payment_error,
    save_payment_error_message,
    save_last_key_delivery_message_id,
)
from bot.services.reseller import get_final_duration_price, get_pricing_details

logger = logging.getLogger(__name__)


def format_readable_time(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(IST).strftime("%d %b %Y, %I:%M %p")


def safe_float(value, default=0.0, label="value") -> float:
    if value is None:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        logger.warning("safe_float: could not parse %s=%r, using %s", label, value, default)
        return default


def build_unique_txn_ref(order_id: int) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    rand = secrets.token_hex(4).upper()
    return f"KS{ts}{order_id}{rand}"


def build_order_context(
    order_dict: dict | None = None,
    user_row: dict | None = None,
    *,
    key_value: str = "",
    extra: dict | None = None,
) -> dict:
    user = user_row or {}
    order = order_dict or {}

    first_name = (user.get("first_name") or "").strip() or "there"
    username = (user.get("username") or "").strip()
    tg_id = user.get("telegram_id") or 0
    display_esc = escape(first_name)
    name_link = f'<a href="tg://user?id={tg_id}">{display_esc}</a>' if tg_id else display_esc

    currency = settings.get("currency_symbol")
    amount_val = safe_float(order.get("amount"), 0.0, "ctx_amount")
    base_val = safe_float(order.get("base_amount") or order.get("amount"), 0.0, "ctx_base")

    cat_name = str(
        order.get("purchased_category_name")
        or order.get("live_category_name")
        or order.get("category_name")
        or ""
    )
    dur_name = str(
        order.get("purchased_duration_name")
        or order.get("live_duration_name")
        or order.get("duration_name")
        or ""
    )

    created = order.get("created_at")
    created_str = format_readable_time(created) if created else ""

    ctx = {
        "first_name": first_name,
        "username": username,
        "name_link_raw": name_link,
        "brand_raw": settings.get_brand_name(),
        "order_id": str(order.get("id") or ""),
        "txn_ref": str(order.get("txn_ref") or ""),
        "status": str(order.get("status") or ""),
        "payment_method": "UPI",
        "currency_raw": currency,
        "amount": f"{amount_val:,.2f}" if amount_val else "",
        "base_amount": f"{base_val:,.2f}" if base_val else "",
        "total_amount": f"{amount_val:,.2f}" if amount_val else "",
        "category": cat_name,
        "duration": dur_name,
        "created_at": created_str,
        "created_time": created_str,
        "expires_at": "",
        "key": key_value,
        "keys": key_value,
        "key_value": key_value,
    }

    if extra:
        ctx.update(extra)

    return ctx


def build_user_context(user_row: dict | None = None) -> dict:
    user = user_row or {}
    first_name = (user.get("first_name") or "").strip() or "there"
    username = (user.get("username") or "").strip()
    tg_id = user.get("telegram_id") or 0
    display_esc = escape(first_name)
    name_link = f'<a href="tg://user?id={tg_id}">{display_esc}</a>' if tg_id else display_esc
    return {
        "first_name": first_name,
        "username": username,
        "name_link_raw": name_link,
        "brand_raw": settings.get_brand_name(),
        "currency_raw": settings.get("currency_symbol"),
    }


def build_verify_alert_text(user_row: dict) -> str:
    first_name = (user_row.get("first_name") or "").strip()
    if not first_name:
        first_name = "there"
    return settings.fmt("msg_verify_not_received", {"first_name": first_name})


async def get_active_payment_order_id(user_id: int):
    row = await db.fetch_one(
        "SELECT active_payment_order_id FROM users WHERE id = $1 LIMIT 1",
        user_id
    )
    if not row:
        return None
    return row.get("active_payment_order_id")


def verify_payment(order_row: dict) -> dict:
    merchant_id = (PAYTM_MERCHANT_ID or "").strip()
    merchant_key = (PAYTM_MERCHANT_KEY or "").strip()
    expected_amount = safe_float(order_row.get("amount"), 0.0, "expected_amount")
    txn_ref = (order_row.get("txn_ref") or "").strip()

    if not txn_ref:
        logger.error("verify_payment: missing txn_ref for order=%s", order_row.get("id"))
        return {
            "ok": False,
            "paid": False,
            "status": "MISSING_TXN_REF",
            "failure_type": "gateway_error",
            "reason": "missing_txn_ref",
            "detail": "Order reference is missing.",
            "paid_amount": 0.0,
            "expected_amount": expected_amount,
            "txn_id": None,
            "bank_txn_id": None,
            "raw": None,
        }

    logger.info(
        "verify_payment: order=%s txn_ref=%s expected_amount=%.2f env=%s",
        order_row.get("id"),
        txn_ref,
        expected_amount,
        PAYTM_ENV,
    )

    if not merchant_id or not merchant_key:
        logger.error(
            "verify_payment: credentials missing merchant_id=%s merchant_key=%s",
            bool(merchant_id),
            bool(merchant_key),
        )
        return {
            "ok": False,
            "paid": False,
            "status": "CONFIG_ERROR",
            "failure_type": "gateway_error",
            "reason": "merchant_credentials_missing",
            "detail": "Payment gateway credentials are not configured.",
            "paid_amount": 0.0,
            "expected_amount": expected_amount,
            "txn_id": None,
            "bank_txn_id": None,
            "raw": None,
        }

    payload = {
        "MID": merchant_id,
        "ORDERID": txn_ref,
    }

    json_data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    checksum = hmac.new(
        merchant_key.encode(),
        json_data.encode(),
        hashlib.sha256
    ).hexdigest()

    if PAYTM_ENV in ("staging", "test"):
        base = "https://securegw-stage.paytm.in"
    else:
        base = "https://securegw.paytm.in"

    url = (
        f"{base}/merchant-status/getTxnStatus"
        f"?JsonData={urllib.parse.quote(json_data)}"
        f"&CHECKSUMHASH={checksum}"
    )

    logger.info("verify_payment: calling gateway for txn_ref=%s", txn_ref)

    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            response_raw = resp.read().decode()
    except Exception as e:
        logger.exception("verify_payment: gateway request failed for txn_ref=%s", txn_ref)
        return {
            "ok": False,
            "paid": False,
            "status": "REQUEST_FAILED",
            "failure_type": "gateway_error",
            "reason": "api_request_failed",
            "detail": f"Could not reach payment gateway: {type(e).__name__}",
            "paid_amount": 0.0,
            "expected_amount": expected_amount,
            "txn_id": None,
            "bank_txn_id": None,
            "raw": None,
        }

    try:
        response = json.loads(response_raw)
    except json.JSONDecodeError:
        logger.error("verify_payment: invalid JSON for txn_ref=%s raw=%s", txn_ref, response_raw[:500])
        return {
            "ok": False,
            "paid": False,
            "status": "INVALID_RESPONSE",
            "failure_type": "gateway_error",
            "reason": "invalid_json_response",
            "detail": "Payment gateway returned an invalid response.",
            "paid_amount": 0.0,
            "expected_amount": expected_amount,
            "txn_id": None,
            "bank_txn_id": None,
            "raw": response_raw,
        }

    status = str(response.get("STATUS") or "")
    resp_code = str(response.get("RESPCODE") or "")
    resp_msg = str(response.get("RESPMSG") or "Unknown status")
    resp_order_id = str(response.get("ORDERID") or "")
    resp_mid = str(response.get("MID") or "")
    paid_amount = safe_float(response.get("TXNAMOUNT"), 0.0, "TXNAMOUNT")
    txn_id = response.get("TXNID")
    bank_txn_id = response.get("BANKTXNID")

    logger.info(
        "verify_payment: response txn_ref=%s status=%s resp_code=%s resp_msg=%s resp_order_id=%s resp_mid=%s paid_amount=%.2f expected_amount=%.2f txn_id=%r bank_txn_id=%r",
        txn_ref,
        status,
        resp_code,
        resp_msg,
        resp_order_id,
        resp_mid,
        paid_amount,
        expected_amount,
        txn_id,
        bank_txn_id,
    )

    order_id_matches = (resp_order_id == txn_ref)
    mid_matches = (resp_mid == merchant_id)
    amount_matches = abs(paid_amount - expected_amount) < 0.01

    payment_verified = (
        status == "TXN_SUCCESS" and
        resp_code == "01" and
        order_id_matches and
        mid_matches and
        amount_matches
    )

    if not payment_verified:
        reasons = []
        if status != "TXN_SUCCESS":
            reasons.append(f"status={status}")
        if resp_code != "01":
            reasons.append(f"resp_code={resp_code}")
        if not order_id_matches:
            reasons.append(f"orderid_mismatch(resp={resp_order_id!r}, expected={txn_ref!r})")
        if not mid_matches:
            reasons.append(f"mid_mismatch(resp={resp_mid!r}, expected={merchant_id!r})")
        if not amount_matches:
            reasons.append(f"amount_mismatch(paid={paid_amount}, expected={expected_amount})")

        reason_str = "; ".join(reasons) if reasons else "not_verified"
        logger.warning("verify_payment: NOT verified txn_ref=%s reason=%s", txn_ref, reason_str)

        if not order_id_matches or not mid_matches:
            failure_type = "payment_not_found"
        elif status == "PENDING":
            failure_type = "payment_pending"
        elif status == "TXN_FAILURE":
            failure_type = "payment_failed"
        elif status == "TXN_SUCCESS" and not amount_matches:
            failure_type = "amount_mismatch"
        elif status in ("NO_RECORD_FOUND", "") or resp_code == "501":
            failure_type = "payment_not_found"
        else:
            failure_type = "verification_issue"

        return {
            "ok": True,
            "paid": False,
            "status": status,
            "failure_type": failure_type,
            "reason": reason_str,
            "detail": resp_msg,
            "paid_amount": paid_amount,
            "expected_amount": expected_amount,
            "txn_id": txn_id,
            "bank_txn_id": bank_txn_id,
            "raw": response,
        }

    logger.info("verify_payment: VERIFIED txn_ref=%s paid_amount=%.2f", txn_ref, paid_amount)
    return {
        "ok": True,
        "paid": True,
        "status": status,
        "reason": "verified",
        "message": resp_msg,
        "paid_amount": paid_amount,
        "expected_amount": expected_amount,
        "txn_id": txn_id,
        "bank_txn_id": bank_txn_id,
        "raw": response,
    }


def format_buyer_label(user_row: dict) -> str:
    username = (user_row.get("username") or "").strip()
    if username:
        return f"@{username}"

    first_name = (user_row.get("first_name") or "").strip()
    if first_name:
        return f"{first_name} [{user_row['telegram_id']}]"

    return f"UserID {user_row['telegram_id']}"


def purchaser_role(user_row: dict) -> str:
    return "reseller" if user_row.get("reseller_id") else "customer"


async def handle_buy(bot: Bot, user_row: dict, chat_id: int, cat_id: int, dur_id: int):
    from bot.services.source_resolver import resolve_source, log_fulfillment
    import json as _json

    await cleanup_user_active_payment(bot, user_row, chat_id)
    await cleanup_user_active_payment_error(bot, user_row, chat_id)

    source_info = await resolve_source(cat_id, dur_id)

    dur_check = await db.fetch_one(
        "SELECT d.name AS dur_name, c.name AS cat_name FROM durations d JOIN categories c ON c.id = d.category_id WHERE d.id = $1 AND d.category_id = $2 LIMIT 1",
        dur_id, cat_id
    )
    cat_name_for_log = str(dur_check["cat_name"]) if dur_check else "Unknown"
    dur_name_for_log = str(dur_check["dur_name"]) if dur_check else "Unknown"

    if not source_info["found"]:
        reason = source_info.get("reason", "no_source_rule")
        logger.warning("handle_buy: no active source rule for cat=%s dur=%s reason=%s", cat_id, dur_id, reason)
        await log_fulfillment(
            category_id=cat_id, duration_id=dur_id,
            category_name=cat_name_for_log, duration_name=dur_name_for_log,
            resolution_success=False, failure_reason=reason,
        )
        buy_ctx = build_user_context(user_row)
        buy_ctx["category"] = cat_name_for_log
        buy_ctx["duration"] = dur_name_for_log
        if reason == "source_rule_inactive":
            await bot.send_message(chat_id=chat_id, text="⚠️ Source for this product is currently inactive. Please try again later.", parse_mode="HTML")
        else:
            await bot.send_message(chat_id=chat_id, text=settings.fmt("msg_no_keys_available", buy_ctx), parse_mode="HTML")
        return

    source_type = source_info["source_type"]

    final_price = 0.0
    order_id = 0
    txn_ref = ""
    dur_row = None

    source_snapshot = _json.dumps({
        "source_type": source_type,
        "rule_id": source_info.get("rule_id"),
        "category_id": cat_id,
        "duration_id": dur_id,
        "api_provider_id": source_info.get("api_provider_id"),
        "provider_name": source_info.get("provider_name"),
        "provider_base_url": source_info.get("provider_base_url"),
        "provider_token": source_info.get("provider_token"),
        "provider_is_active": source_info.get("provider_is_active"),
        "api_game_value": source_info.get("api_game_value"),
        "api_duration_value": source_info.get("api_duration_value"),
        "api_device_value": source_info.get("api_device_value"),
        "api_currency_value": source_info.get("api_currency_value"),
    })

    if source_type in ("api", "api_and_manual"):
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                dur_row = await conn.fetchrow(
                    """
                    SELECT d.id, d.name, d.price, c.name AS category_name
                    FROM durations d JOIN categories c ON c.id = d.category_id
                    WHERE d.id = $1 AND d.category_id = $2 AND d.is_hidden = 0 AND c.is_hidden = 0
                    LIMIT 1 FOR UPDATE
                    """,
                    dur_id, cat_id
                )
                if not dur_row:
                    await bot.send_message(chat_id=chat_id, text=settings.fmt("msg_invalid_cat_dur", buy_ctx), parse_mode="HTML")
                    return

                pricing = await get_pricing_details(dur_id, cat_id, user_row)
                final_price = max(0.0, pricing["final_price"])

                order_id = await conn.fetchval(
                    """
                    INSERT INTO orders (user_id, key_id, status, amount,
                        pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name,
                        fulfillment_status, source_rule_snapshot,
                        purchased_category_name, purchased_duration_name)
                    VALUES ($1, NULL, 'pending', $2, $3, $4, $5, $6, 'pending', $7, $8, $9) RETURNING id
                    """,
                    user_row["id"], final_price,
                    pricing["pricing_source"], pricing["base_price"],
                    pricing["applied_discount_plan_id"], pricing["applied_discount_plan_name"],
                    source_snapshot, cat_name_for_log, dur_name_for_log,
                )

                txn_ref = build_unique_txn_ref(order_id)
                await conn.execute("UPDATE orders SET txn_ref = $1 WHERE id = $2", txn_ref, order_id)

    else:
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                dur_row = await conn.fetchrow(
                    """
                    SELECT d.id, d.name, d.price, c.name AS category_name
                    FROM durations d
                    JOIN categories c ON c.id = d.category_id
                    WHERE d.id = $1
                      AND d.category_id = $2
                      AND d.is_hidden = 0
                      AND c.is_hidden = 0
                    LIMIT 1
                    FOR UPDATE
                    """,
                    dur_id, cat_id
                )
                if not dur_row:
                    await bot.send_message(chat_id=chat_id, text=settings.fmt("msg_invalid_cat_dur", buy_ctx), parse_mode="HTML")
                    return

                pricing = await get_pricing_details(dur_id, cat_id, user_row)
                final_price = max(0.0, pricing["final_price"])

                order_id = await conn.fetchval(
                    """
                    INSERT INTO orders (user_id, key_id, status, amount,
                        pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name,
                        fulfillment_status, source_rule_snapshot,
                        purchased_category_name, purchased_duration_name)
                    VALUES ($1, NULL, 'pending', $2, $3, $4, $5, $6, 'pending', $7, $8, $9)
                    RETURNING id
                    """,
                    user_row["id"], final_price,
                    pricing["pricing_source"],
                    pricing["base_price"],
                    pricing["applied_discount_plan_id"],
                    pricing["applied_discount_plan_name"],
                    source_snapshot, cat_name_for_log, dur_name_for_log,
                )

                txn_ref = build_unique_txn_ref(order_id)

                await conn.execute(
                    "UPDATE orders SET txn_ref = $1 WHERE id = $2",
                    txn_ref, order_id
                )

    payment_amount = final_price

    upi_id = (PAYTM_UPI_ID or "").strip()
    if not upi_id:
        await cancel_order_and_release_key(order_id)
        await bot.send_message(
            chat_id=chat_id,
            text=settings.fmt("msg_upi_not_configured", build_user_context(user_row)),
            parse_mode="HTML"
        )
        return

    amount_str = f"{payment_amount:.2f}"
    payee_name = settings.get('payment_label_name') or "Merchant"

    upi_string = (
        f"upi://pay?pa={upi_id}"
        f"&pn={urllib.parse.quote(payee_name)}"
        f"&am={amount_str}"
        f"&cu=INR"
        f"&tr={txn_ref}"
        f"&tn={urllib.parse.quote(f'Purchase Order #{order_id}')}"
    )

    qr_buf = generate_upi_qr(upi_string)

    cat_name_raw = str(dur_row.get("category_name") or "Category")
    dur_name_raw = str(dur_row.get("name") or "Duration")
    from bot.services.categories import extract_custom_emoji_and_clean_name
    cat_display = extract_custom_emoji_and_clean_name(cat_name_raw)["name"] or cat_name_raw
    dur_display = extract_custom_emoji_and_clean_name(dur_name_raw)["name"] or dur_name_raw

    now = datetime.now(IST)
    timeout_min = settings.get_int('order_timeout_minutes', 15) if settings.get_int('order_timeout_minutes', 15) > 0 else 15
    expiry_time = now + timedelta(minutes=timeout_min)

    is_reseller = bool(user_row.get("reseller_id"))
    base_price = safe_float(dur_row.get("price"), 0.0, "base_price")

    invoice_order = {
        "id": order_id, "txn_ref": txn_ref, "amount": payment_amount,
        "base_amount": base_price, "status": "pending",
        "purchased_category_name": cat_name_raw, "purchased_duration_name": dur_name_raw,
        "created_at": now,
    }
    tpl_values = build_order_context(invoice_order, user_row, extra={
        "category": cat_display,
        "duration": dur_display,
        "total_amount": f"{final_price:.2f}",
        "created_time": format_readable_time(now),
        "expiry_time": format_readable_time(expiry_time),
        "expires_at": format_readable_time(expiry_time),
        "upi_id": upi_id,
        "verify_btn": settings.get("bot_btn_verify"),
    })

    if is_reseller:
        payment_text = settings.fmt("tpl_reseller_caption", tpl_values)
    else:
        payment_text = settings.fmt("tpl_payment_caption", tpl_values)

    verify_kwargs = settings.build_button_kwargs("verify_btn_style", "verify_btn_emoji_id")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(text=settings.get('bot_btn_verify'), callback_data=f"verify_{order_id}", api_kwargs=verify_kwargs)]
    ])

    try:
        if qr_buf:
            msg = await bot.send_photo(
                chat_id=chat_id,
                photo=qr_buf,
                caption=payment_text,
                reply_markup=kb,
                parse_mode="HTML"
            )
        else:
            msg = await bot.send_message(
                chat_id=chat_id,
                text=payment_text,
                reply_markup=kb,
                parse_mode="HTML"
            )

        await db.execute(
            "UPDATE orders SET qr_message_id = $1 WHERE id = $2",
            msg.message_id,
            order_id
        )
        await save_user_active_payment_order_id(user_row["id"], order_id)

    except Exception:
        logger.exception("handle_buy: failed to send payment message for order_id=%s", order_id)
        await cancel_order_and_release_key(order_id)
        await clear_user_active_payment_order_id(user_row["id"])
        await bot.send_message(
            chat_id=chat_id,
            text=settings.fmt("msg_payment_qr_failed", build_user_context(user_row)),
            parse_mode="HTML"
        )


async def _answer_callback(bot: Bot, callback_query_id: str, text: str, show_alert: bool = False):
    try:
        await bot.answer_callback_query(
            callback_query_id,
            text=text,
            show_alert=show_alert
        )
    except Exception:
        pass


FAILURE_TYPE_SETTINGS = {
    "payment_not_found": "msg_payment_not_found",
    "payment_pending": "msg_payment_pending",
    "payment_failed": "msg_payment_failed",
    "amount_mismatch": "msg_amount_mismatch",
    "verification_issue": "msg_verification_issue",
    "gateway_error": "msg_gateway_error",
}


def _get_failure_message(failure_type: str, context: dict | None = None) -> str:
    setting_key = FAILURE_TYPE_SETTINGS.get(failure_type, "msg_verification_issue")
    if context:
        return settings.fmt(setting_key, context)
    return settings.get(setting_key)


async def handle_verify(bot: Bot, user_row: dict, chat_id: int, order_id: int, callback_query_id: str):
    active_order_id = await get_active_payment_order_id(user_row["id"])
    if active_order_id and int(active_order_id) != int(order_id):
        await _answer_callback(
            bot, callback_query_id,
            settings.get("msg_inactive_verify_btn"),
            show_alert=True
        )
        return

    order = await db.fetch_one(
        """
        SELECT
            o.*,
            u.telegram_id,
            u.username,
            u.first_name,
            u.last_name,
            k.key_value,
            k.is_sold AS key_is_sold,
            c.name AS live_category_name,
            d.name AS live_duration_name
        FROM orders o
        JOIN users u ON u.id = o.user_id
        LEFT JOIN product_keys k ON o.key_id = k.id
        LEFT JOIN categories c ON k.category_id = c.id
        LEFT JOIN durations d ON k.duration_id = d.id
        WHERE o.id = $1
        LIMIT 1
        """,
        order_id
    )

    user_ctx = build_user_context(user_row)

    if not order:
        await _answer_callback(bot, callback_query_id, settings.get("cb_order_not_found"), show_alert=True)
        await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_order_not_found", user_ctx))
        return

    order_dict = dict(order)
    ctx = build_order_context(order_dict, user_row)

    if order_dict["user_id"] != user_row["id"]:
        await _answer_callback(bot, callback_query_id, settings.get("cb_order_not_yours"), show_alert=True)
        await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_order_not_yours", ctx))
        return

    if order_dict["status"] == "paid":
        await _answer_callback(bot, callback_query_id, settings.get("cb_already_paid"), show_alert=False)
        await clear_active_payment_pointer_if_matches(user_row["id"], order_id)
        await cleanup_user_active_payment_error(bot, user_row, chat_id)
        await bot.send_message(chat_id=chat_id, text=settings.fmt("msg_already_paid", ctx), parse_mode="HTML")
        return

    if order_dict["status"] == "cancelled":
        await _answer_callback(bot, callback_query_id, settings.get("cb_order_expired"), show_alert=True)
        qr_mid = order_dict.get("qr_message_id") or 0
        if qr_mid > 0:
            await safe_delete_message(bot, chat_id, qr_mid)
        await clear_active_payment_pointer_if_matches(user_row["id"], order_id)
        await cleanup_user_active_payment_error(bot, user_row, chat_id)
        await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_order_expired", ctx))
        return

    if order_dict["status"] not in ("pending", "awaiting_payment"):
        await _answer_callback(bot, callback_query_id, settings.get("cb_order_inactive"), show_alert=True)
        await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_order_inactive", ctx))
        return

    loop = asyncio.get_event_loop()
    try:
        verify = await loop.run_in_executor(None, verify_payment, order_dict)
    except Exception:
        logger.exception("handle_verify: verify executor failed for order_id=%s", order_id)
        await _answer_callback(bot, callback_query_id, settings.get("cb_verify_error"), show_alert=True)
        await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_verify_error", ctx))
        return

    if not verify.get("ok"):
        logger.warning(
            "handle_verify: verify not ok order_id=%s reason=%s detail=%s",
            order_id, verify.get("reason"), verify.get("detail"),
        )
        failure_type = verify.get("failure_type", "gateway_error")
        user_msg = _get_failure_message(failure_type, ctx)
        title = settings.fmt("msg_verify_failed_title", ctx)
        await _answer_callback(bot, callback_query_id, build_verify_alert_text(user_row), show_alert=True)
        await save_payment_error_message(
            bot, user_row, chat_id,
            f"{title}\n\n{user_msg}"
        )
        return

    if not verify.get("paid"):
        logger.info(
            "handle_verify: payment not matched order_id=%s status=%s reason=%s failure_type=%s detail=%s",
            order_id, verify.get("status"), verify.get("reason"), verify.get("failure_type"), verify.get("detail"),
        )
        failure_type = verify.get("failure_type", "payment_not_found")
        user_msg = _get_failure_message(failure_type, ctx)
        title = settings.fmt("msg_payment_not_received_title", ctx)
        await _answer_callback(bot, callback_query_id, build_verify_alert_text(user_row), show_alert=True)
        await save_payment_error_message(
            bot, user_row, chat_id,
            f"{title}\n\n{user_msg}"
        )
        return

    from bot.services.source_resolver import fulfill_paid_order, send_owner_fulfillment_alert

    qr_message_id = order_dict.get("qr_message_id") or 0
    buyer_role = purchaser_role(user_row)

    try:
        async with db.pool.acquire() as conn:
            async with conn.transaction():
                locked_row = await conn.fetchrow(
                    "SELECT * FROM orders WHERE id = $1 AND user_id = $2 LIMIT 1 FOR UPDATE",
                    order_id, user_row["id"]
                )

                if not locked_row:
                    await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_order_not_found", ctx))
                    return

                locked = dict(locked_row)
                locked_ctx = build_order_context(locked, user_row)

                if locked["status"] == "paid":
                    await clear_active_payment_pointer_if_matches(user_row["id"], order_id)
                    await cleanup_user_active_payment_error(bot, user_row, chat_id)
                    await bot.send_message(chat_id=chat_id, text=settings.fmt("msg_already_paid", locked_ctx), parse_mode="HTML")
                    return

                if locked["status"] == "cancelled":
                    qr_mid = locked.get("qr_message_id") or 0
                    if qr_mid > 0:
                        await safe_delete_message(bot, chat_id, qr_mid)
                    await clear_active_payment_pointer_if_matches(user_row["id"], order_id)
                    await cleanup_user_active_payment_error(bot, user_row, chat_id)
                    await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_order_expired", locked_ctx))
                    return

                qr_message_id = locked.get("qr_message_id") or 0

                buyer_label = format_buyer_label(user_row)
                buyer_role = purchaser_role(user_row)

                paid_amt = safe_float(
                    verify.get("paid_amount"),
                    safe_float(locked.get("amount"), 0.0, "locked_amount"),
                    "paid_amount"
                )
                paid_utr = verify.get("bank_txn_id") or verify.get("txn_id")

                await conn.execute(
                    """
                    UPDATE orders
                    SET
                        status = 'paid',
                        verified_at = NOW(),
                        purchaser_role = $1,
                        purchaser_label = $2,
                        paid_utr = $3,
                        paid_amount = $4,
                        gateway_txn_id = $5,
                        gateway_bank_txn_id = $6
                    WHERE id = $7
                    """,
                    buyer_role, buyer_label, paid_utr, paid_amt,
                    verify.get("txn_id"), verify.get("bank_txn_id"),
                    order_id,
                )

    except Exception:
        logger.exception("handle_verify: payment update failed for order_id=%s", order_id)
        await save_payment_error_message(bot, user_row, chat_id, settings.fmt("msg_verify_generic_error", ctx))
        return

    try:
        fulfillment = await fulfill_paid_order(order_id)
    except Exception:
        logger.exception("handle_verify: fulfill_paid_order crashed for order_id=%s", order_id)
        try:
            await db.execute(
                "UPDATE orders SET fulfillment_status = 'fulfillment_failed', fulfillment_error = 'Internal fulfillment error' WHERE id = $1",
                order_id
            )
        except Exception:
            pass
        fulfillment = {
            "success": False,
            "reason": "Internal fulfillment error",
            "needs_alert": True,
            "source_type": "unknown",
            "cat_name": str(locked.get("purchased_category_name") or "Unknown"),
            "dur_name": str(locked.get("purchased_duration_name") or "Unknown"),
        }

    if not fulfillment.get("success"):
        logger.error("handle_verify: fulfillment failed for order_id=%s reason=%s", order_id, fulfillment.get("reason"))

        if fulfillment.get("needs_alert"):
            fulfillment["cat_name"] = fulfillment.get("cat_name") or str(locked.get("purchased_category_name") or "Unknown")
            fulfillment["dur_name"] = fulfillment.get("dur_name") or str(locked.get("purchased_duration_name") or "Unknown")
            await send_owner_fulfillment_alert(bot, order_id, user_row, fulfillment)

        if qr_message_id > 0:
            await safe_delete_message(bot, chat_id, qr_message_id)
        await clear_active_payment_pointer_if_matches(user_row["id"], order_id)
        await cleanup_user_active_payment_error(bot, user_row, chat_id)

        pending_ctx = build_order_context(order_dict, user_row)
        await bot.send_message(
            chat_id=chat_id,
            text=settings.fmt("msg_fulfillment_pending", pending_ctx),
            parse_mode="HTML"
        )
        return

    key_value = fulfillment["key_value"]

    reloaded = await db.fetch_one("SELECT * FROM orders WHERE id = $1", order_id)
    if reloaded:
        reloaded = dict(reloaded)

    category_name = str(reloaded.get("purchased_category_name") or "Unknown") if reloaded else "Unknown"
    duration_name = str(reloaded.get("purchased_duration_name") or "Unknown") if reloaded else "Unknown"

    try:
        await db.execute(
            "UPDATE orders SET delivered_at = NOW(), purchased_key_value = $1 WHERE id = $2",
            key_value, order_id
        )
        if reloaded and reloaded.get("key_id"):
            async with db.pool.acquire() as conn:
                await archive_delivered_key(conn, order_id)
    except Exception:
        logger.exception("handle_verify: post-fulfillment update failed for order_id=%s", order_id)

    try:
        from bot.services.campaigns import (
            resolve_deep_link, resolve_any_deep_link,
            record_deep_link_event,
            get_active_attribution, find_any_attribution,
            record_attributed_purchase,
        )
        from datetime import datetime as _dt

        # Revenue = actual paid amount (not expected amount)
        revenue = float(reloaded.get("paid_amount") or reloaded.get("amount") or 0) if reloaded else 0

        dl_code          = user_row.get("campaign_deep_link_code") or ""
        campaign_id      = None
        deep_link_id     = None
        campaign_run_id  = None
        attribution_end  = None
        is_late          = False

        # ── Primary: resolve the stored deep link code ───────────────────────
        if dl_code:
            # First try to get the ACTIVE link (standard attribution path)
            link_data = await resolve_deep_link(dl_code)
            if link_data:
                campaign_id     = link_data["campaign_id"]
                deep_link_id    = link_data.get("id")
                campaign_run_id = link_data.get("campaign_run_id")
                attribution_end = link_data.get("attribution_end_at")
                # Sanity check: ensure attribution window is still open
                if attribution_end is not None:
                    now_utc = _dt.utcnow()
                    # Normalise datetime (asyncpg may return aware or naive)
                    ae = attribution_end
                    if hasattr(ae, "tzinfo") and ae.tzinfo is not None:
                        from datetime import timezone as _tz
                        ae = ae.astimezone(_tz.utc).replace(tzinfo=None)
                    if ae < now_utc:
                        is_late = True
                        logger.info(
                            f"Campaign attribution: order #{order_id} — active link but "
                            f"attribution_end_at {ae} < now {now_utc} → late conversion"
                        )
            else:
                # Link is expired or missing; try fetching it regardless of status
                any_link = await resolve_any_deep_link(dl_code)
                if any_link and any_link.get("status") == "expired":
                    campaign_id     = any_link["campaign_id"]
                    deep_link_id    = any_link.get("id")
                    campaign_run_id = any_link.get("campaign_run_id")
                    attribution_end = any_link.get("attribution_end_at")
                    is_late         = True
                    logger.info(
                        f"Campaign attribution: order #{order_id} — link {dl_code!r} is expired → late conversion "
                        f"for campaign #{campaign_id}"
                    )

        # ── Fallback: persistent attribution table (active links only) ───────
        if not campaign_id:
            attr = await get_active_attribution(user_row["id"])
            if attr:
                campaign_id     = attr["campaign_id"]
                dl_code         = attr.get("deep_link_code") or dl_code
                deep_link_id    = attr.get("cdl_id") or attr.get("deep_link_id")
                campaign_run_id = attr.get("dl_run_id") or attr.get("campaign_run_id")
                attribution_end = attr.get("dl_attribution_end_at") or attr.get("attribution_end_at")
                logger.info(
                    f"Campaign attribution: found active attribution for user {user_row['id']} "
                    f"→ campaign #{campaign_id} via table lookup (run #{campaign_run_id})"
                )
                if attribution_end is not None:
                    now_utc = _dt.utcnow()
                    ae = attribution_end
                    if hasattr(ae, "tzinfo") and ae.tzinfo is not None:
                        from datetime import timezone as _tz
                        ae = ae.astimezone(_tz.utc).replace(tzinfo=None)
                    if ae < now_utc:
                        is_late = True

        # ── Also check any attribution (late-conversion fallback) ─────────────
        if not campaign_id and dl_code:
            any_attr = await find_any_attribution(user_row["id"], dl_code)
            if any_attr:
                campaign_id     = any_attr["campaign_id"]
                deep_link_id    = any_attr.get("cdl_id")
                campaign_run_id = any_attr.get("dl_run_id")
                is_late         = True
                logger.info(
                    f"Campaign attribution: order #{order_id} — found expired attribution for "
                    f"user {user_row['id']} → campaign #{campaign_id} (late)"
                )

        if campaign_id and dl_code:
            if is_late:
                logger.info(
                    f"Campaign attribution: order #{order_id} → campaign #{campaign_id} "
                    f"LATE CONVERSION (revenue={revenue}, run={campaign_run_id})"
                )
            else:
                logger.info(
                    f"Campaign attribution: order #{order_id} → campaign #{campaign_id} "
                    f"ATTRIBUTED revenue={revenue} run={campaign_run_id}"
                )
            await record_deep_link_event(
                campaign_id, dl_code,
                user_row.get("telegram_id", 0), user_row.get("username", ""),
                "purchase",
                order_id=order_id,
                revenue=revenue,
                campaign_run_id=campaign_run_id,
                deep_link_id=deep_link_id,
                is_late_conversion=is_late,
            )
            await record_attributed_purchase(
                user_row["id"], campaign_id, order_id, revenue,
                deep_link_id=deep_link_id,
                is_late_conversion=is_late,
            )
            # Tag the order with full attribution info
            try:
                await db.execute(
                    """UPDATE orders
                       SET campaign_id                    = $1,
                           campaign_deep_link_code        = $2,
                           paid_amount                    = $3,
                           campaign_run_id                = $4,
                           campaign_deep_link_id          = $5,
                           is_campaign_late_conversion    = $6
                       WHERE id = $7""",
                    campaign_id, dl_code, revenue,
                    campaign_run_id, deep_link_id, is_late,
                    order_id,
                )
            except Exception as tag_err:
                logger.warning(f"Failed to tag order #{order_id} with campaign data: {tag_err}")
        else:
            # Still record the paid_amount on the order
            if revenue > 0:
                try:
                    await db.execute(
                        "UPDATE orders SET paid_amount = $1 WHERE id = $2", revenue, order_id
                    )
                except Exception:
                    pass

        # Keep campaign_deep_link_code on user so late conversions can still be detected
        # (the attribution table already enforces the expiry window).

    except Exception as e:
        logger.warning("Campaign attribution error for order %s: %s", order_id, e, exc_info=True)

    if qr_message_id > 0:
        await safe_delete_message(bot, chat_id, qr_message_id)

    await clear_active_payment_pointer_if_matches(user_row["id"], order_id)
    await cleanup_user_active_payment_error(bot, user_row, chat_id)

    from bot.services.categories import extract_custom_emoji_and_clean_name
    cat_clean = extract_custom_emoji_and_clean_name(category_name)["name"] or category_name
    dur_clean = extract_custom_emoji_and_clean_name(duration_name)["name"] or duration_name

    apk_file_id = None
    if reloaded and reloaded.get("key_id"):
        try:
            cat_row = await db.fetch_one(
                """SELECT c.file_id FROM categories c
                   JOIN product_keys pk ON pk.category_id = c.id
                   WHERE pk.id = $1 LIMIT 1""",
                reloaded["key_id"]
            )
            if cat_row:
                raw_fid = (cat_row.get("file_id") or "").strip()
                if raw_fid and not raw_fid.startswith(("/", "http://", "https://")):
                    apk_file_id = raw_fid
        except Exception as e:
            logger.warning("handle_verify: APK file_id lookup failed for order_id=%s: %s", order_id, e)

    apk_file_name = ""
    apk_sent = False
    if apk_file_id:
        try:
            apk_ctx = build_order_context(reloaded or order_dict, user_row, key_value=key_value, extra={
                "category": cat_clean, "duration": dur_clean,
            })
            apk_caption = settings.fmt("msg_apk_caption", apk_ctx)
            await bot.send_document(
                chat_id=chat_id,
                document=apk_file_id,
                caption=apk_caption,
                parse_mode="HTML"
            )
            apk_sent = True
            apk_file_name = apk_file_id
        except Exception as e:
            logger.warning("handle_verify: APK delivery failed for order_id=%s: %s", order_id, e)

    now_ist = datetime.now(IST)
    paid_amount = safe_float(verify.get('paid_amount'), safe_float((reloaded or locked).get('amount'), 0.0, 'del_amount'), 'del_paid')
    delivery_values = build_order_context(reloaded or order_dict, user_row, key_value=key_value, extra={
        "category": cat_clean,
        "duration": dur_clean,
        "amount": f"{paid_amount:,.2f}",
        "base_amount": f"{safe_float((reloaded or locked).get('amount'), 0.0, 'del_base'):,.2f}",
        "current_time": format_readable_time(now_ist),
        "file_name": apk_file_name,
        "category_file": apk_file_name,
    })
    delivery_values["verified_title_raw"] = settings.fmt("msg_payment_verified_title", delivery_values)
    delivery_values["key_label_raw"] = settings.fmt("msg_key_label", delivery_values)
    delivery_values["apk_notice_raw"] = settings.fmt("msg_apk_notice", delivery_values) if apk_sent else ""
    delivery_values["footer_raw"] = settings.fmt("bot_payment_success", delivery_values)

    delivery_text = settings.collapse_blank_lines(settings.fmt("tpl_success_body", delivery_values))

    kb_rows = []
    copy_kwargs = settings.build_button_kwargs("copy_key_btn_style", "copy_key_btn_emoji_id")
    kb_rows.append([InlineKeyboardButton(text=settings.get('bot_btn_copy_key'), copy_text={"text": key_value}, api_kwargs=copy_kwargs)])
    link_btns = settings.parse_link_buttons("delivery_link_buttons")
    for lb in link_btns:
        btn_kwargs = {}
        if lb.get("icon_custom_emoji_id"):
            btn_kwargs["icon_custom_emoji_id"] = lb["icon_custom_emoji_id"]
        if lb.get("style"):
            btn_kwargs["style"] = lb["style"]
        kb_rows.append([InlineKeyboardButton(
            text=lb["text"], url=lb["url"],
            api_kwargs=btn_kwargs if btn_kwargs else None,
        )])
    copy_kb = InlineKeyboardMarkup(kb_rows)

    try:
        key_msg = await bot.send_message(
            chat_id=chat_id,
            text=delivery_text,
            reply_markup=copy_kb,
            parse_mode="HTML"
        )
    except Exception as e:
        if "icon_custom_emoji_id" in str(e) or "style" in str(e) or "BUTTON" in str(e).upper():
            logger.warning("handle_verify: styled buttons rejected by Telegram (%s), retrying without styles", e)
            plain_rows = [[InlineKeyboardButton(text=settings.get('bot_btn_copy_key'), copy_text={"text": key_value})]]
            for lb in link_btns:
                plain_rows.append([InlineKeyboardButton(text=lb["text"], url=lb["url"])])
            key_msg = await bot.send_message(
                chat_id=chat_id,
                text=delivery_text,
                reply_markup=InlineKeyboardMarkup(plain_rows),
                parse_mode="HTML"
            )
        else:
            raise

    try:
        await save_last_key_delivery_message_id(user_row["id"], key_msg.message_id)
        await bot.pin_chat_message(chat_id=chat_id, message_id=key_msg.message_id, disable_notification=True)
    except Exception:
        pass

    if ADMIN_CHAT_ID:
        try:
            paid_amt_val = safe_float(verify.get("paid_amount"), 0.0, "admin_paid_amount")
            admin_values = build_order_context(reloaded or order_dict, user_row, key_value=key_value, extra={
                "admin_sale_title_raw": settings.get("bot_admin_sale_title"),
                "buyer_label": format_buyer_label(user_row),
                "category": category_name,
                "duration": duration_name,
                "amount": f"{paid_amt_val:.2f}",
            })
            admin_text = settings.fmt("tpl_admin_sale", admin_values)
            await bot.send_message(chat_id=ADMIN_CHAT_ID, text=admin_text, parse_mode="HTML")
        except Exception:
            logger.exception("handle_verify: failed to notify admin for order_id=%s", order_id)

    paid_amt_log = safe_float(verify.get("paid_amount"), 0.0, "log_paid_amount")
    paid_utr_log = verify.get("bank_txn_id") or verify.get("txn_id")
    log_line = (
        f"[{datetime.now(IST).strftime('%Y-%m-%d %H:%M:%S')}] "
        f"Order #{order_id} | {format_buyer_label(user_row)} | TG:{user_row['telegram_id']} | "
        f"Role:{buyer_role} | Category:{category_name} | Duration:{duration_name} | "
        f"Amount:{paid_amt_log:.2f} | UTR:{paid_utr_log or '-'} | Key:{key_value}"
    )
    append_purchase_log(buyer_role, log_line)


async def archive_delivered_key(conn, order_id: int):
    raw = await conn.fetchrow(
        """
        SELECT
            o.id AS order_id,
            o.user_id,
            o.amount,
            o.txn_ref,
            o.verified_at,
            o.gateway_txn_id,
            o.gateway_bank_txn_id,
            u.telegram_id,
            u.username,
            u.first_name,
            u.last_name,
            u.reseller_id,
            pk.key_value,
            d.name AS duration_name,
            c.name AS category_name
        FROM orders o
        JOIN users u ON u.id = o.user_id
        LEFT JOIN product_keys pk ON pk.id = o.key_id
        LEFT JOIN durations d ON d.id = pk.duration_id
        LEFT JOIN categories c ON c.id = pk.category_id
        WHERE o.id = $1
        LIMIT 1
        """,
        order_id
    )
    if not raw:
        logger.error("archive_delivered_key: order not found %s", order_id)
        return

    row = dict(raw)
    is_reseller = 1 if row.get("reseller_id") else 0

    await conn.execute(
        """
        INSERT INTO purchased_keys_history (
            user_id,
            order_id,
            telegram_id,
            username,
            first_name,
            last_name,
            is_reseller_purchase,
            category_name,
            duration_name,
            key_value,
            amount,
            txn_ref,
            gateway_txn_id,
            gateway_bank_txn_id,
            verified_at
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
        ON CONFLICT (order_id) DO UPDATE SET
            telegram_id = EXCLUDED.telegram_id,
            username = EXCLUDED.username,
            first_name = EXCLUDED.first_name,
            last_name = EXCLUDED.last_name,
            is_reseller_purchase = EXCLUDED.is_reseller_purchase,
            category_name = EXCLUDED.category_name,
            duration_name = EXCLUDED.duration_name,
            key_value = EXCLUDED.key_value,
            amount = EXCLUDED.amount,
            txn_ref = EXCLUDED.txn_ref,
            gateway_txn_id = EXCLUDED.gateway_txn_id,
            gateway_bank_txn_id = EXCLUDED.gateway_bank_txn_id,
            verified_at = EXCLUDED.verified_at
        """,
        row["user_id"],
        row["order_id"],
        row["telegram_id"],
        row["username"],
        row["first_name"],
        row["last_name"],
        is_reseller,
        str(row.get("category_name") or ""),
        str(row.get("duration_name") or ""),
        str(row.get("key_value") or ""),
        safe_float(row.get("amount"), 0.0, "archive_amount"),
        row.get("txn_ref"),
        row.get("gateway_txn_id"),
        row.get("gateway_bank_txn_id"),
        row.get("verified_at"),
    )