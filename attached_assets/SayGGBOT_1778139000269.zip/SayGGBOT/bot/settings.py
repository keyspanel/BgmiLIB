import os
import json
import logging
import re
import time
from html import escape as _escape
from bot import database as db

logger = logging.getLogger(__name__)

_cache: dict[str, str] = {}
_settings_loaded_at: float = 0.0
_SETTINGS_TTL_SECONDS: float = 30.0

SETTING_DEFAULTS = {
    "bot_welcome_msg": "Welcome to {brand}.",
    "bot_welcome_instruction": "Use the menu below to browse categories and purchase keys.",
    "bot_store_title": "{brand} — Digital Key Store",
    "bot_store_subtitle": "Choose a category below to browse available products.",
    "bot_store_empty": "There are no active categories available right now. Please check again later.",
    "bot_btn_my_keys": "\U0001f4e6 My Purchased Keys",
    "bot_btn_how_to": "\U0001f6d2 How to Purchase?",
    "bot_btn_categories": "\U0001f3e0 Categories Menu",
    "bot_btn_verify": "\u2705 Verify Payment",
    "bot_btn_copy_key": "\U0001f4cb Copy Key",
    "bot_btn_manage_keys": "\U0001f5c2 Manage Keys",
    "bot_how_to_text": (
        "<b>\U0001f6d2 How to Purchase</b>\n\n"
        "1) Tap <b>/start</b>\n"
        "2) Select a <b>Category</b>\n"
        "3) Choose a <b>Duration</b>\n"
        "4) Pay using the <b>QR / UPI</b>\n"
        "5) Tap <b>Verify Payment</b>\n\n"
        "\u2705 After verification, your key will be delivered instantly."
    ),
    "bot_payment_success": "Thank you for your purchase.",
    "bot_admin_sale_title": "\U0001f514 <b>New Sale</b>",
    "bot_keys_title": "\U0001f4e6 <b>Your Purchased Keys</b>",
    "bot_keys_reseller_title": "\U0001f4e6 <b>Reseller Purchased Keys</b>",
    "bot_keys_empty": "You don't have any delivered keys yet.",
    "order_timeout_minutes": "15",
    "currency_symbol": "\u20B9",
    "start_preview_url": "",
    "payment_label_name": "",
    "reply_mykeys_style": "",
    "reply_howto_style": "",
    "reply_mykeys_emoji_id": "",
    "reply_howto_emoji_id": "",
    "categories_btn_style": "",
    "categories_btn_emoji_id": "",
    "verify_btn_style": "",
    "verify_btn_emoji_id": "",
    "copy_key_btn_style": "",
    "copy_key_btn_emoji_id": "",
    "manage_keys_btn_style": "",
    "manage_keys_btn_emoji_id": "",

    "msg_banned": "\U0001f6ab You are banned from using this service.",

    "msg_store_unavailable_title": "\U0001f6d2 <b>Store Currently Unavailable</b>",
    "msg_select_duration_title": "\u23f1\ufe0f <b>Select Duration</b>",
    "msg_select_duration_sub": "Select a duration below:",
    "msg_discount_duration_banner": "\U0001f525 <b>{plan_name}</b> \u2014 Special prices applied!",

    "tpl_payment_caption": (
        "\U0001f9fe <b>Payment Invoice</b>\n\n"
        "<b>Category:</b>  {category}\n"
        "<b>Duration:</b>  {duration}\n"
        "<b>Amount:</b>  {currency}{amount}\n"
        "<b>Order ID:</b>  <code>{order_id}</code>\n"
        "<b>Ref:</b>  <code>{txn_ref}</code>\n\n"
        "\U0001f550 <b>Created:</b>  {created_time}\n"
        "\u23f3 <b>Expires:</b>  {expiry_time}\n\n"
        "Scan the QR code or use UPI ID <code>{upi_id}</code> to complete payment.\n\n"
        "After payment, tap <b>{verify_btn}</b> below to verify.\n"
        "Once verified, your key will be delivered instantly."
    ),
    "tpl_reseller_caption": (
        "\U0001f9fe <b>Payment \u2014 Reseller Order</b>\n\n"
        "<b>Category:</b>  {category}\n"
        "<b>Duration:</b>  {duration}\n"
        "<b>Base Price:</b>  {currency}{base_amount}\n"
        "<b>Your Price:</b>  {currency}{amount}\n"
        "<b>Order ID:</b>  <code>{order_id}</code>\n"
        "<b>Ref:</b>  <code>{txn_ref}</code>\n\n"
        "\U0001f550 <b>Created:</b>  {created_time}\n"
        "\u23f3 <b>Expires:</b>  {expiry_time}\n\n"
        "Scan the QR code or use UPI ID <code>{upi_id}</code> to complete payment.\n\n"
        "After payment, tap <b>{verify_btn}</b> below to confirm instantly."
    ),
    "msg_no_keys_available": "\U0001f6ab Sorry, no keys available for this category and duration.",
    "msg_key_taken": "\u26a0\ufe0f This key was just taken. Please try again.",
    "msg_upi_not_configured": "\u26a0\ufe0f UPI ID is not configured. Please contact the administrator.",
    "msg_payment_qr_failed": "\u26a0\ufe0f Failed to send payment QR. Please try again.",
    "msg_invalid_cat_dur": "\u274c Invalid category or duration.",

    "msg_verify_not_received": (
        "Hey {first_name}, payment was not received yet. "
        "I only verify completed gateway payments. "
        "Please pay the QR first, then tap Verify Payment."
    ),
    "msg_inactive_verify_btn": "This verify button is no longer active. Please use the latest payment QR only.",
    "msg_order_not_found": "\u274c <b>Order not found</b>\n\nPlease create a new order.",
    "msg_order_not_yours": "\u26d4 <b>This order does not belong to you.</b>",
    "msg_already_paid": "\u2705 Payment already verified.",
    "msg_order_expired": "\u231b <b>This order has expired.</b>\n\nPlease create a new order.",
    "msg_order_inactive": "\u2139\ufe0f <b>This order is not active anymore.</b>",
    "msg_verify_error": "\u26a0\ufe0f <b>Payment verification encountered an error.</b>\n\nPlease try again in a moment.",
    "msg_verify_failed_title": "\u26a0\ufe0f <b>Payment Verification Failed</b>",
    "msg_payment_not_received_title": "\u274c <b>Payment Not Received</b>",
    "msg_verify_generic_error": "\u26a0\ufe0f <b>Something went wrong during verification.</b>\n\nPlease try again.",

    "msg_payment_not_found": "No payment was found for this order. Please complete the payment first, then tap Verify.",
    "msg_payment_pending": "Your payment is still being processed. Please wait a moment and try again.",
    "msg_payment_failed": "Payment was not successful. Please try again with a new order.",
    "msg_amount_mismatch": "Payment amount does not match the order. Please contact support.",
    "msg_verification_issue": "Payment could not be verified at this time. Please try again.",
    "msg_gateway_error": "Payment verification is temporarily unavailable. Please try again shortly.",

    "msg_payment_verified_title": "\u2705 <b>Payment Verified Successfully</b>",
    "tpl_success_body": (
        "{verified_title}\n\n"
        "<b>Category:</b>  {category}\n"
        "<b>Duration:</b>  {duration}\n"
        "<b>Order ID:</b>  <code>{order_id}</code>\n\n"
        "{key_label}\n"
        "<code>{key}</code>\n\n"
        "{apk_notice}\n\n"
        "{footer}"
    ),
    "msg_key_label": "\U0001f511 <b>Your Key:</b>",
    "msg_apk_caption": "\U0001f4f2 <b>Application for {category}</b>\n\nInstall this app and use your key below to activate.",
    "msg_apk_notice": "\U0001f4f2 The application file has been sent above. Install it and use your key to activate.",
    "delivery_link_buttons": "",
    "duration_link_buttons": "",
    "tpl_admin_sale": (
        "{admin_sale_title}\n"
        "Order #{order_id}\n"
        "User: {buyer_label}\n"
        "Category: {category}\n"
        "Duration: {duration}\n"
        "Amount: {currency}{amount}"
    ),

    "msg_fulfillment_pending": (
        "\u2705 Payment verified! Your key is being processed.\n"
        "The admin has been notified and your key will be delivered shortly."
    ),

    "msg_order_expired_notice": (
        "\u23f3 <b>Order Expired</b>\n\n"
        "Your previous order has expired as payment was not completed in time.\n\n"
        "To continue, browse our categories and place a new order whenever you're ready."
    ),

    "cb_banned": "\U0001f6ab You are banned from using this service.",
    "cb_category_unavailable": "\u274c This category is no longer available.",
    "cb_no_durations": "\u274c No durations available in this category.",
    "cb_category_error": "\u274c Unable to open this category.",
    "cb_generating_qr": "Generating payment QR...",
    "cb_unknown_action": "Unknown action.",
    "cb_order_not_found": "Order not found.",
    "cb_order_not_yours": "This order does not belong to you.",
    "cb_already_paid": "Payment already verified.",
    "cb_order_expired": "This order has expired.",
    "cb_order_inactive": "This order is not active anymore.",
    "cb_verify_error": "Verification error. Please try again.",

    "msg_reseller_prompt": (
        "\U0001f510 <b>Reseller Access Activation</b>\n\n"
        "Send your <b>6-digit reseller code</b> below to activate reseller pricing.\n\n"
        "\U0001f4a1 Only a valid reseller code will activate special pricing.\n"
        "After activation, your reseller prices will appear automatically in the duration buttons.\n\n"
        "<i>Send /cancel to exit.</i>"
    ),
    "msg_invalid_code_format": (
        "\u274c <b>Invalid Code Format</b>\n\n"
        "Reseller codes are exactly <b>6 digits</b>.\n"
        "Please check your code and try again.\n\n"
        "<i>Send /cancel to exit.</i>"
    ),

    "msg_reseller_cancelled": "\u2716 Reseller code activation cancelled.",
    "msg_reseller_invalid_code": "\u274c <b>Invalid Reseller Code</b>\n\nThe code you entered is not valid. Please check and try again.",
    "msg_reseller_code_expired": "\u274c <b>Code Expired</b>\n\nThis reseller code is no longer active.",
    "msg_reseller_usage_limit": "\u274c <b>Usage Limit Reached</b>\n\nThis reseller code has already reached its maximum allowed users.",
    "msg_reseller_already_active_title": "\u2705 <b>Reseller Access Already Active</b>",
    "msg_reseller_activation_failed": "\u26a0\ufe0f <b>Activation Failed</b>\n\nSomething went wrong while activating your code. Please try again.",
    "msg_reseller_activated_title": "\U0001f389 <b>Reseller Access Activated Successfully</b>",
    "msg_reseller_activated_footer": "\u2705 You will now see your reseller prices automatically inside the category duration buttons.",

    "msg_no_keys_found_title": "\U0001f4e6 <b>No Purchased Keys Found</b>",
    "msg_keys_load_error": "Unable to load your keys right now. Please try again.",
    "msg_reference_label": "Reference",
    "msg_reseller_switched_label": "Previous Code Replaced",
    "btn_prev_page": "\u2b05\ufe0f Previous",
    "btn_next_page": "Next \u27a1\ufe0f",

    "msg_categories_footer": "\U0001f447 <b>Select a category to continue</b>",

    "tpl_keys_item": (
        "<b>Key {index} of {total}</b>\n"
        "<b>Order ID:</b> <code>{order_id}</code>\n"
        "<b>Category:</b> {category}\n"
        "<b>Duration:</b> {duration}\n"
        "<b>Amount:</b> {currency}{amount}\n"
        "<b>Purchased:</b> {purchased_time}\n"
        "<b>Buyer:</b> {buyer}\n\n"
        "\U0001f511 <b>Key:</b>\n"
        "<code>{key}</code>"
        "{reference_section}"
    ),

    "welcome_greeting": "\u2728 <b>Hey {name_link}!</b>",

    "tpl_welcome": (
        "{welcome_greeting}\n\n"
        "<b>{welcome_title}</b>\n"
        "{welcome_body}"
    ),

    "tpl_store_header": (
        "\U0001f510 <b>{store_title}</b>\n\n"
        "{store_subtitle}\n\n"
        "{categories_footer}"
    ),

    "tpl_duration_caption": (
        "{duration_title}\n"
        "Category: <b>{category}</b>\n"
        "{duration_sub}"
    ),

    "tpl_reseller_activated": (
        "{reseller_title}\n\n"
        "<b>Code:</b> <code>{code}</code>\n"
        "{switched_section}"
        "<b>Expires:</b> {expires}\n"
        "<b>Usage Limit:</b> {max_users}\n\n"
        "<b>Your Active Offer Details:</b>\n"
        "{offer_summary}\n\n"
        "{reseller_footer}"
    ),

    "tpl_reseller_already_active": (
        "{reseller_title}\n\n"
        "<b>Code:</b> <code>{code}</code>\n"
        "<b>Expires:</b> {expires}\n\n"
        "<b>Active Offer Details:</b>\n"
        "{offer_summary}"
    ),

    "help_btn_style": "2",
    "owner_btn_style": "3",

    "discount_offer_ended_title": "\u23F3 <b>This Offer Has Ended</b>",
    "discount_offer_ended_body": (
        "Sorry, this discount offer is no longer active.\n\n"
        "Tap /start to see current prices \u2014 new deals drop regularly."
    ),

    "tpl_delivery_body": (
        "<b>Category:</b>  {category}\n"
        "<b>Duration:</b>  {duration}\n"
        "<b>Order ID:</b>  <code>{order_id}</code>\n\n"
        "\U0001f511 <b>Your Key:</b>\n"
        "<code>{key_value}</code>"
    ),

    "tpl_discount_broadcast_title": "\U0001F4E2 <b>{plan_name} \u2014 Limited Offer</b>",
    "tpl_discount_broadcast_body": (
        "Hi <b>{first_name}</b> \U0001F44B\n\n"
        "{description}\n\n"
        "\U0001F4B0 <b>Discounted Prices</b>\n"
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
        "{pricing_examples}\n"
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n\n"
        "\u23F0 <b>Offer ends:</b> {expiry_time}"
    ),
    "tpl_discount_broadcast_footer": "Open the store now and claim your deal \u2193",
    "discount_broadcast_buttons": "[]",
    "discount_broadcast_send_categories": "0",
    "msg_broadcast_progress": "\u23F3 Broadcasting\u2026 {sent}/{total} sent",
    "msg_broadcast_complete": (
        "\u2705 <b>Broadcast Complete</b>\n\n"
        "\u2022 Delivered: <b>{sent}</b>\n"
        "\u2022 Failed: <b>{failed}</b>\n"
        "\u2022 Skipped: <b>{skipped}</b>\n"
        "\u2022 Total: <b>{total}</b>"
    ),
    "msg_broadcast_error": "\u274C <b>Broadcast Failed</b>\n{error}",
    "broadcast_pin_message": "0",
    "force_join_enabled": "0",
    "force_join_show_verify_btn": "1",
    "force_join_title": "\U0001f512 <b>Channel Membership Required</b>",
    "force_join_body": (
        "Hey {user_mention},\n\n"
        "You selected <b>{category}</b> — <b>{duration}</b>.\n\n"
        "Before we create your order, please join our required channel(s) below.\n\n"
        "\U0001f4a1 <i>Your order has not been created yet — no need to start over.</i>\n"
        "As soon as you join, I'll automatically detect your membership and continue your order flow seamlessly."
    ),
    "force_join_btn_verify": "\u2705 I Joined — Verify",
    "force_join_missing_msg": "\u26A0\uFE0F <b>You haven't joined all required channels yet.</b>\n\nPlease join the channels below and try again:",
    "force_join_expired_msg": "\u26A0\uFE0F <b>Your pending order has expired.</b>\n\nPlease go back to the store and select a product again.",
    "force_join_join_btn_text": "\U0001f4e2 Join {channel}",
    "force_join_join_btn_style": "",
    "force_join_join_btn_emoji_id": "",
    "force_join_verify_btn_style": "",
    "force_join_verify_btn_emoji_id": "",

}

ENV_KEY_MAP = {
    "bot_welcome_msg": "BOT_WELCOME_MSG",
    "bot_welcome_instruction": "BOT_WELCOME_INSTRUCTION",
    "bot_store_title": "BOT_STORE_TITLE",
    "bot_store_subtitle": "BOT_STORE_SUBTITLE",
    "bot_store_empty": "BOT_STORE_EMPTY",
    "bot_btn_my_keys": "BOT_BTN_MY_KEYS",
    "bot_btn_how_to": "BOT_BTN_HOW_TO",
    "bot_btn_categories": "BOT_BTN_CATEGORIES",
    "bot_btn_verify": "BOT_BTN_VERIFY",
    "bot_btn_copy_key": "BOT_BTN_COPY_KEY",
    "bot_btn_manage_keys": "BOT_BTN_MANAGE_KEYS",
    "bot_how_to_text": "BOT_HOW_TO_TEXT",
    "bot_payment_success": "BOT_PAYMENT_SUCCESS",
    "bot_admin_sale_title": "BOT_ADMIN_SALE_TITLE",
    "bot_keys_title": "BOT_KEYS_TITLE",
    "bot_keys_reseller_title": "BOT_KEYS_RESELLER_TITLE",
    "bot_keys_empty": "BOT_KEYS_EMPTY",
    "order_timeout_minutes": "ORDER_TIMEOUT_MINUTES",
    "currency_symbol": "CURRENCY_SYMBOL",
    "start_preview_url": "START_PREVIEW_URL",
    "payment_label_name": "PAYMENT_LABEL_NAME",
    "reply_mykeys_style": "REPLY_MYKEYS_STYLE",
    "reply_howto_style": "REPLY_HOWTO_STYLE",
    "categories_btn_style": "CATEGORIES_BTN_STYLE",
    "categories_btn_emoji_id": "CATEGORIES_BTN_EMOJI_ID",
    "verify_btn_style": "VERIFY_BTN_STYLE",
    "verify_btn_emoji_id": "VERIFY_BTN_EMOJI_ID",
    "copy_key_btn_style": "COPY_KEY_BTN_STYLE",
    "copy_key_btn_emoji_id": "COPY_KEY_BTN_EMOJI_ID",
    "manage_keys_btn_style": "MANAGE_KEYS_BTN_STYLE",
    "manage_keys_btn_emoji_id": "MANAGE_KEYS_BTN_EMOJI_ID",
}

ENV_FALLBACKS = {
    "currency_symbol": ["CURRENCY"],
    "payment_label_name": ["BRAND_NAME", "SITE_NAME"],
}

ALLOWED_HTML_TAGS = {"b", "i", "u", "s", "a", "code", "pre", "em", "strong", "strike", "del", "ins", "tg-spoiler", "tg-emoji", "blockquote"}


async def load_settings():
    global _cache, _settings_loaded_at
    try:
        rows = await db.fetch_all("SELECT key, value FROM bot_settings")
        _cache = {r["key"]: r["value"] for r in rows}
        _settings_loaded_at = time.monotonic()
        logger.info("Loaded %d bot settings from database", len(_cache))
    except Exception as e:
        logger.warning("Could not load bot_settings (table may not exist yet): %s", e)
        _cache = {}


async def reload_settings():
    now = time.monotonic()
    if _settings_loaded_at > 0 and (now - _settings_loaded_at) < _SETTINGS_TTL_SECONDS:
        return
    await load_settings()
    await load_category_duration_settings()


async def force_reload_settings():
    global _settings_loaded_at
    _settings_loaded_at = 0.0
    await load_settings()
    await load_category_duration_settings()


def get(key: str, default: str | None = None) -> str:
    if key in _cache and _cache[key] is not None and _cache[key] != "":
        return _cache[key]

    env_key = ENV_KEY_MAP.get(key)
    if env_key:
        env_val = os.environ.get(env_key, "")
        if env_val:
            return env_val

    fallbacks = ENV_FALLBACKS.get(key, [])
    for fb_key in fallbacks:
        fb_val = os.environ.get(fb_key, "")
        if fb_val:
            return fb_val

    if default is not None:
        return default

    return SETTING_DEFAULTS.get(key, "")


def get_int(key: str, default: int = 0) -> int:
    val = get(key, str(default))
    try:
        return int(val)
    except (TypeError, ValueError):
        return default


def get_brand_name() -> str:
    return os.environ.get("BRAND_NAME", os.environ.get("SITE_NAME", "KeyStore"))


def get_resolved(key: str, default: str | None = None) -> str:
    val = get(key, default)
    brand = get_brand_name()
    return val.replace("{brand}", brand)


def _sanitize_html(text: str) -> str:
    def _check_tag(match):
        full = match.group(0)
        tag_name = match.group(1).lower().strip().split()[0]
        if tag_name.lstrip("/") in ALLOWED_HTML_TAGS:
            return full
        return _escape(full)
    try:
        return re.sub(r'<(/?\s*[a-zA-Z][a-zA-Z0-9-]*[^>]*)>', _check_tag, text)
    except Exception:
        return text


def render_template(key: str, context: dict, default: str = "") -> str:
    template = get(key) or default
    if not template:
        logger.warning("render_template: no template found for key=%r and no default provided", key)
        return ""

    safe = {}
    for k, v in context.items():
        s = str(v) if v is not None else ""
        if k.endswith("_raw"):
            safe[k.removesuffix("_raw")] = s
        else:
            safe[k] = _escape(s)

    try:
        result = template.format_map(_SafeFormatDict(safe))
    except Exception as e:
        logger.warning("render_template: template %r format_map failed: %s — falling back to manual replace", key, e)
        result = template
        for k, v in safe.items():
            result = result.replace(f"{{{k}}}", v)

    return _sanitize_html(result)


class _SafeFormatDict(dict):
    def __missing__(self, key):
        logger.warning("render_template: missing placeholder {%s} in template", key)
        return ""


def fmt(template_key: str, values: dict, fallback: str = "") -> str:
    return render_template(template_key, values, fallback)


def render_template_str(template: str, context: dict) -> str:
    safe = {}
    for k, v in context.items():
        s = str(v) if v is not None else ""
        if k.endswith("_raw"):
            safe[k.removesuffix("_raw")] = s
        else:
            safe[k] = _escape(s)
    try:
        result = template.format_map(_SafeFormatDict(safe))
    except Exception:
        result = template
        for k, v in safe.items():
            result = result.replace(f"{{{k}}}", v)
    return _sanitize_html(result)


VALID_BUTTON_STYLES = {"default", "primary", "success", "danger"}


def build_button_kwargs(style_key: str, emoji_key: str) -> dict | None:
    from bot.services.categories import get_telegram_style
    kwargs = {}
    style = get_telegram_style(get(style_key))
    if style:
        kwargs["style"] = style
    emoji_id = get(emoji_key).strip()
    if emoji_id and re.fullmatch(r'\d{5,32}', emoji_id):
        kwargs["icon_custom_emoji_id"] = emoji_id
    return kwargs if kwargs else None


def parse_link_buttons(setting_key: str) -> list[dict]:
    raw = get(setting_key, "").strip()
    if not raw:
        return []
    try:
        items = json.loads(raw)
        if not isinstance(items, list):
            return []
        result = []
        for item in items:
            if not isinstance(item, dict):
                continue
            text = (item.get("text") or "").strip()
            url = (item.get("url") or "").strip()
            if not text or not url:
                continue
            if not (url.startswith("https://") or url.startswith("http://") or url.startswith("tg://")):
                continue
            btn = {"text": text, "url": url}
            emoji_id = (item.get("icon_custom_emoji_id") or "").strip()
            if emoji_id:
                btn["icon_custom_emoji_id"] = emoji_id
            style = (item.get("style") or "").strip()
            if style in VALID_BUTTON_STYLES:
                btn["style"] = style
            result.append(btn)
        return result[:4]
    except (json.JSONDecodeError, TypeError):
        logger.warning("parse_link_buttons: invalid JSON in setting %r", setting_key)
        return []


def build_sections(*sections: str) -> str:
    parts = []
    for s in sections:
        s = (s or "").strip()
        if s:
            parts.append(s)
    return "\n\n".join(parts)


def collapse_blank_lines(text: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', text).strip()


CATEGORY_DURATION_KEYS = {
    "tpl_duration_caption",
    "msg_select_duration_title",
    "msg_select_duration_sub",
    "duration_link_buttons",
}

_cat_dur_cache: dict[int, dict[str, str]] = {}


async def load_category_duration_settings():
    from bot import database as _db
    _cat_dur_cache.clear()
    try:
        rows = await _db.fetch_all(
            "SELECT category_id, setting_key, value FROM category_duration_settings"
        )
        for r in rows:
            cid = r["category_id"]
            if cid not in _cat_dur_cache:
                _cat_dur_cache[cid] = {}
            _cat_dur_cache[cid][r["setting_key"]] = r["value"]
    except Exception as e:
        logger.warning("load_category_duration_settings failed: %s", e)


def get_category_duration(cat_id: int, key: str) -> str:
    cat_val = _cat_dur_cache.get(cat_id, {}).get(key, "")
    if cat_val:
        return cat_val
    return get(key)


async def set_category_duration(cat_id: int, key: str, value: str):
    if key not in CATEGORY_DURATION_KEYS:
        return
    from bot import database as _db
    await _db.execute(
        """INSERT INTO category_duration_settings (category_id, setting_key, value)
           VALUES ($1, $2, $3)
           ON CONFLICT (category_id, setting_key) DO UPDATE SET value = $3""",
        cat_id, key, value
    )
    if cat_id not in _cat_dur_cache:
        _cat_dur_cache[cat_id] = {}
    _cat_dur_cache[cat_id][key] = value


async def delete_category_duration(cat_id: int, key: str):
    from bot import database as _db
    await _db.execute(
        "DELETE FROM category_duration_settings WHERE category_id = $1 AND setting_key = $2",
        cat_id, key
    )
    if cat_id in _cat_dur_cache and key in _cat_dur_cache[cat_id]:
        del _cat_dur_cache[cat_id][key]


def get_category_duration_all(cat_id: int) -> dict[str, str]:
    return dict(_cat_dur_cache.get(cat_id, {}))


def parse_link_buttons_raw(raw: str) -> list[dict]:
    raw = raw.strip()
    if not raw:
        return []
    try:
        items = json.loads(raw)
        if not isinstance(items, list):
            return []
        result = []
        for item in items:
            if not isinstance(item, dict):
                continue
            text = (item.get("text") or "").strip()
            url = (item.get("url") or "").strip()
            if not text or not url:
                continue
            if not (url.startswith("https://") or url.startswith("http://") or url.startswith("tg://")):
                continue
            btn = {"text": text, "url": url}
            emoji_id = (item.get("icon_custom_emoji_id") or "").strip()
            if emoji_id:
                btn["icon_custom_emoji_id"] = emoji_id
            style = (item.get("style") or "").strip()
            if style in VALID_BUTTON_STYLES:
                btn["style"] = style
            result.append(btn)
        return result[:4]
    except (json.JSONDecodeError, TypeError):
        return []
