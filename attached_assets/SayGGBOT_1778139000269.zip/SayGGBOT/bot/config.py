import os
import sys
import logging

logger = logging.getLogger(__name__)

DATABASE_URL = os.environ.get("DATABASE_URL", "")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

ADMIN_CHAT_ID = int(os.environ.get("ADMIN_CHAT_ID", "0"))
OWNER_USERNAME = os.environ.get("OWNER_USERNAME", "")
SUPPORT_USERNAME = os.environ.get("SUPPORT_USERNAME", "")

BRAND_NAME = os.environ.get("BRAND_NAME", os.environ.get("SITE_NAME", "KeyStore"))
SITE_URL = os.environ.get("SITE_URL", "")
if not SITE_URL:
    _replit_domain = (
        os.environ.get("REPLIT_DOMAINS", "").split(",")[0].strip()
        or os.environ.get("REPLIT_DEV_DOMAIN", "")
    )
    if _replit_domain:
        SITE_URL = f"https://{_replit_domain}"
SITE_NAME = BRAND_NAME

ORDER_TIMEOUT_MINUTES = int(os.environ.get("ORDER_TIMEOUT_MINUTES", "15"))

PAYTM_UPI_ID = os.environ.get("PAYTM_UPI_ID", "")
PAYTM_MERCHANT_ID = os.environ.get("PAYTM_MERCHANT_ID", "")
PAYTM_MERCHANT_KEY = os.environ.get("PAYTM_MERCHANT_KEY", "")
PAYTM_ENV = os.environ.get("PAYTM_ENV", "production")
PAYMENT_LABEL_NAME = os.environ.get("PAYMENT_LABEL_NAME", BRAND_NAME)

START_PREVIEW_URL = os.environ.get("START_PREVIEW_URL", "")

CURRENCY = os.environ.get("CURRENCY_SYMBOL", os.environ.get("CURRENCY", "\u20B9"))

REPLY_MYKEYS_STYLE = int(os.environ.get("REPLY_MYKEYS_STYLE", "4"))
REPLY_HOWTO_STYLE = int(os.environ.get("REPLY_HOWTO_STYLE", "4"))

WEBHOOK_MODE = os.environ.get("BOT_WEBHOOK_MODE", "polling").lower() == "webhook"
WEBHOOK_PATH = os.environ.get("BOT_WEBHOOK_PATH", "/bot/webhook")
WEBHOOK_PORT = int(os.environ.get("BOT_WEBHOOK_PORT", "8443"))

_webhook_url_env = os.environ.get("BOT_WEBHOOK_URL", "")
if _webhook_url_env:
    WEBHOOK_URL = _webhook_url_env
elif SITE_URL:
    WEBHOOK_URL = SITE_URL
else:
    WEBHOOK_URL = ""

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")

BOT_WELCOME_MSG = os.environ.get(
    "BOT_WELCOME_MSG",
    f"Welcome to {BRAND_NAME}."
)
BOT_WELCOME_INSTRUCTION = os.environ.get(
    "BOT_WELCOME_INSTRUCTION",
    "Use the menu below to browse categories and purchase keys."
)
BOT_STORE_TITLE = os.environ.get(
    "BOT_STORE_TITLE",
    f"{BRAND_NAME} \u2014 Digital Key Store"
)
BOT_STORE_SUBTITLE = os.environ.get(
    "BOT_STORE_SUBTITLE",
    "Choose a category below to browse available products."
)
BOT_STORE_EMPTY = os.environ.get(
    "BOT_STORE_EMPTY",
    "There are no active categories available right now. Please check again later."
)
BOT_BTN_MY_KEYS = os.environ.get("BOT_BTN_MY_KEYS", "\U0001f4e6 My Purchased Keys")
BOT_BTN_HOW_TO = os.environ.get("BOT_BTN_HOW_TO", "\U0001f6d2 How to Purchase?")
BOT_BTN_CATEGORIES = os.environ.get("BOT_BTN_CATEGORIES", "\U0001f3e0 Categories Menu")
BOT_BTN_VERIFY = os.environ.get("BOT_BTN_VERIFY", "\u2705 Verify Payment")
BOT_BTN_COPY_KEY = os.environ.get("BOT_BTN_COPY_KEY", "\U0001f4cb Copy Key")
BOT_BTN_MANAGE_KEYS = os.environ.get("BOT_BTN_MANAGE_KEYS", "\U0001f5c2 Manage Keys")
BOT_HOW_TO_TEXT = os.environ.get(
    "BOT_HOW_TO_TEXT",
    (
        "<b>\U0001f6d2 How to Purchase</b>\n\n"
        "1) Tap <b>/start</b>\n"
        "2) Select a <b>Category</b>\n"
        "3) Choose a <b>Duration</b>\n"
        "4) Pay using the <b>QR / UPI</b>\n"
        "5) Tap <b>Verify Payment</b>\n\n"
        "\u2705 After verification, your key will be delivered instantly."
    )
)
BOT_PAYMENT_SUCCESS = os.environ.get(
    "BOT_PAYMENT_SUCCESS",
    "Thank you for your purchase."
)
BOT_ADMIN_SALE_TITLE = os.environ.get("BOT_ADMIN_SALE_TITLE", "\U0001f514 <b>New Sale</b>")
BOT_KEYS_TITLE = os.environ.get("BOT_KEYS_TITLE", "\U0001f4e6 <b>Your Purchased Keys</b>")
BOT_KEYS_RESELLER_TITLE = os.environ.get("BOT_KEYS_RESELLER_TITLE", "\U0001f4e6 <b>Reseller Purchased Keys</b>")
BOT_KEYS_EMPTY = os.environ.get("BOT_KEYS_EMPTY", "You don't have any delivered keys yet.")


def validate_config():
    errors = []
    if not BOT_TOKEN:
        errors.append("BOT_TOKEN")
    if not DATABASE_URL:
        errors.append("DATABASE_URL")

    if errors:
        for key in errors:
            logger.error(f"FATAL: Required environment variable {key} is not set")
        sys.exit(1)

    if not ADMIN_CHAT_ID:
        logger.warning("ADMIN_CHAT_ID not set - admin notifications disabled")
    if not PAYTM_UPI_ID:
        logger.warning("PAYTM_UPI_ID not set - payment QR will not work")
    if not PAYTM_MERCHANT_ID or not PAYTM_MERCHANT_KEY:
        logger.warning("PAYTM_MERCHANT_ID / PAYTM_MERCHANT_KEY not set - payment verification disabled")
    if not SITE_URL:
        logger.warning("SITE_URL not set - keys portal links will not work")
    if not OWNER_USERNAME:
        logger.warning("OWNER_USERNAME not set")
