import asyncio
import logging
from telegram import Bot
from bot import database as db

logger = logging.getLogger(__name__)


async def safe_delete_message(bot: Bot, chat_id: int, message_id: int) -> bool:
    message_id = int(message_id or 0)
    if message_id <= 0:
        return False

    try:
        await bot.delete_message(chat_id=chat_id, message_id=message_id)
        return True
    except Exception as e:
        desc = str(e).lower()
        if any(x in desc for x in [
            "message to delete not found",
            "message can't be deleted",
            "message cannot be deleted",
            "message identifier is not specified",
        ]):
            return False
        logger.error("safe_delete_message error: %s", e)
        return False


async def save_user_category_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET start_categories_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def clear_user_category_message_id(user_id: int):
    await db.execute(
        "UPDATE users SET start_categories_message_id = NULL WHERE id = $1",
        user_id
    )


async def cleanup_user_category_message(bot: Bot, user_row: dict, chat_id: int):
    message_id = int(user_row.get("start_categories_message_id") or 0)
    if message_id > 0:
        await safe_delete_message(bot, chat_id, message_id)
    await clear_user_category_message_id(user_row["id"])


async def save_user_durations_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET active_durations_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def clear_user_durations_message_id(user_id: int):
    await db.execute(
        "UPDATE users SET active_durations_message_id = NULL WHERE id = $1",
        user_id
    )


async def cleanup_user_durations_message(bot: Bot, user_row: dict, chat_id: int):
    message_id = int(user_row.get("active_durations_message_id") or 0)
    if message_id > 0:
        await safe_delete_message(bot, chat_id, message_id)
    await clear_user_durations_message_id(user_row["id"])


async def save_user_purchased_keys_viewer_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET active_keys_viewer_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def clear_user_purchased_keys_viewer_message_id(user_id: int):
    await db.execute(
        "UPDATE users SET active_keys_viewer_message_id = NULL WHERE id = $1",
        user_id
    )


async def safe_unpin_message(bot: Bot, chat_id: int, message_id: int) -> bool:
    message_id = int(message_id or 0)
    if message_id <= 0:
        return False
    try:
        await bot.unpin_chat_message(chat_id=chat_id, message_id=message_id)
        return True
    except Exception:
        return False


async def save_user_mykeys_pin_notice_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET last_mykeys_pin_notice_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def save_last_key_delivery_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET last_key_delivery_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def cleanup_user_purchased_keys_viewer(bot: Bot, user_row: dict, chat_id: int):
    fresh = await db.fetch_one(
        "SELECT active_keys_viewer_message_id, last_mykeys_user_message_id, last_mykeys_pin_notice_message_id FROM users WHERE id = $1 LIMIT 1",
        user_row["id"]
    )
    viewer_mid = int((fresh.get("active_keys_viewer_message_id") if fresh else None) or 0)
    user_mid = int((fresh.get("last_mykeys_user_message_id") if fresh else None) or 0)
    pin_notice_mid = int((fresh.get("last_mykeys_pin_notice_message_id") if fresh else None) or 0)

    if viewer_mid > 0:
        await safe_unpin_message(bot, chat_id, viewer_mid)

    delete_tasks = []
    if viewer_mid > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, viewer_mid))
    if user_mid > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, user_mid))
    if pin_notice_mid > 0 and pin_notice_mid != viewer_mid:
        delete_tasks.append(safe_delete_message(bot, chat_id, pin_notice_mid))
    if delete_tasks:
        await asyncio.gather(*delete_tasks)

    await asyncio.gather(
        clear_user_purchased_keys_viewer_message_id(user_row["id"]),
        save_user_mykeys_user_message_id(user_row["id"], None),
        save_user_mykeys_pin_notice_message_id(user_row["id"], None),
    )


async def save_user_mykeys_user_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET last_mykeys_user_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def save_user_active_payment_order_id(user_id: int, order_id: int | None):
    await db.execute(
        "UPDATE users SET active_payment_order_id = $1 WHERE id = $2",
        order_id, user_id
    )


async def clear_user_active_payment_order_id(user_id: int):
    await db.execute(
        "UPDATE users SET active_payment_order_id = NULL WHERE id = $1",
        user_id
    )


async def get_user_active_payment_order(user_id: int) -> dict | None:
    row = await db.fetch_one(
        """
        SELECT o.*
        FROM orders o
        WHERE o.id = (
            SELECT active_payment_order_id
            FROM users
            WHERE id = $1
            LIMIT 1
        )
        LIMIT 1
        """,
        user_id
    )
    return dict(row) if row else None


async def cancel_order_and_release_key(order_id: int):
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            locked = await conn.fetchrow(
                "SELECT id, key_id, status FROM orders WHERE id = $1 FOR UPDATE",
                order_id
            )
            if not locked:
                return
            if locked["status"] in ("paid", "cancelled"):
                return

            await conn.execute(
                "UPDATE orders SET status = 'cancelled' WHERE id = $1",
                order_id
            )
            if locked["key_id"]:
                await conn.execute(
                    "UPDATE product_keys SET is_sold = 0 WHERE id = $1 AND is_sold = 2",
                    locked["key_id"]
                )


async def cleanup_user_active_payment(bot: Bot, user_row: dict, chat_id: int):
    order = await get_user_active_payment_order(user_row["id"])
    if order:
        qr_msg_id = int(order.get("qr_message_id") or 0)
        if qr_msg_id > 0:
            await safe_delete_message(bot, chat_id, qr_msg_id)

        if order.get("status") not in ("paid", "cancelled"):
            await cancel_order_and_release_key(order["id"])

    await clear_user_active_payment_order_id(user_row["id"])


async def clear_active_payment_pointer_if_matches(user_id: int, order_id: int):
    await db.execute(
        "UPDATE users SET active_payment_order_id = NULL WHERE id = $1 AND active_payment_order_id = $2",
        user_id, order_id
    )


async def save_user_active_payment_error_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET active_payment_error_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def clear_user_active_payment_error_message_id(user_id: int):
    await db.execute(
        "UPDATE users SET active_payment_error_message_id = NULL WHERE id = $1",
        user_id
    )


async def cleanup_user_active_payment_error(bot: Bot, user_row: dict, chat_id: int):
    message_id = int(user_row.get("active_payment_error_message_id") or 0)
    if message_id > 0:
        await safe_delete_message(bot, chat_id, message_id)
    await clear_user_active_payment_error_message_id(user_row["id"])


async def save_payment_error_message(bot: Bot, user_row: dict, chat_id: int, text: str):
    await cleanup_user_active_payment_error(bot, user_row, chat_id)

    msg = await bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode="HTML"
    )

    await save_user_active_payment_error_message_id(user_row["id"], msg.message_id)
    return msg


async def save_user_expiry_notice_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET active_expiry_notice_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def clear_user_expiry_notice_message_id(user_id: int):
    await db.execute(
        "UPDATE users SET active_expiry_notice_message_id = NULL WHERE id = $1",
        user_id
    )


async def cleanup_user_expiry_notice(bot: Bot, chat_id: int, user_id: int):
    row = await db.fetch_one(
        "SELECT active_expiry_notice_message_id FROM users WHERE id = $1 LIMIT 1",
        user_id
    )
    if row:
        message_id = int(row.get("active_expiry_notice_message_id") or 0)
        if message_id > 0:
            await safe_delete_message(bot, chat_id, message_id)
    await clear_user_expiry_notice_message_id(user_id)


async def send_expiry_notice(bot: Bot, chat_id: int, user_id: int, context: dict | None = None):
    from bot import settings
    await cleanup_user_expiry_notice(bot, chat_id, user_id)

    if context:
        text = settings.fmt("msg_order_expired_notice", context)
    else:
        text = settings.get("msg_order_expired_notice")

    msg = await bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode="HTML"
    )

    await save_user_expiry_notice_message_id(user_id, msg.message_id)
    return msg


async def cleanup_old_start_thread(bot: Bot, user_row: dict, chat_id: int, today):
    import datetime as _dt
    if isinstance(today, str):
        today = _dt.date.fromisoformat(today)
    last_date = user_row.get("last_start_date")
    is_same_day = last_date is not None and last_date == today
    if is_same_day:
        old_start_mid = int(user_row.get("last_user_start_message_id") or 0)
        old_welcome_mid = int(user_row.get("last_bot_welcome_message_id") or 0)
        old_cat_mid = int(user_row.get("start_categories_message_id") or 0)
        delete_tasks = []
        if old_start_mid > 0:
            delete_tasks.append(safe_delete_message(bot, chat_id, old_start_mid))
        if old_welcome_mid > 0:
            delete_tasks.append(safe_delete_message(bot, chat_id, old_welcome_mid))
        if old_cat_mid > 0:
            delete_tasks.append(safe_delete_message(bot, chat_id, old_cat_mid))
        if delete_tasks:
            await asyncio.gather(*delete_tasks)
        if old_cat_mid > 0:
            await clear_user_category_message_id(user_row["id"])


async def save_start_thread(user_id: int, user_start_msg_id: int, bot_welcome_msg_id: int, cat_msg_id: int | None, today):
    import datetime as _dt
    if isinstance(today, str):
        today = _dt.date.fromisoformat(today)
    await db.execute(
        """UPDATE users
           SET last_user_start_message_id = $1,
               last_bot_welcome_message_id = $2,
               start_categories_message_id = $3,
               last_start_date = $4
           WHERE id = $5""",
        user_start_msg_id, bot_welcome_msg_id, cat_msg_id, today, user_id
    )


async def save_user_howto_message_ids(user_id: int, user_msg_id: int | None, bot_msg_id: int | None):
    await db.execute(
        "UPDATE users SET last_howto_user_message_id = $1, last_howto_bot_message_id = $2 WHERE id = $3",
        user_msg_id, bot_msg_id, user_id
    )


async def cleanup_user_howto_messages(bot: Bot, user_row: dict, chat_id: int):
    user_msg_id = int(user_row.get("last_howto_user_message_id") or 0)
    bot_msg_id = int(user_row.get("last_howto_bot_message_id") or 0)
    delete_tasks = []
    if user_msg_id > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, user_msg_id))
    if bot_msg_id > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, bot_msg_id))
    if delete_tasks:
        await asyncio.gather(*delete_tasks)
    await save_user_howto_message_ids(user_row["id"], None, None)


async def save_reseller_temp_thread(user_id: int, trigger_msg_id: int | None, prompt_msg_id: int | None):
    await db.execute(
        "UPDATE users SET reseller_level_trigger_msg_id = $1, reseller_prompt_msg_id = $2 WHERE id = $3",
        trigger_msg_id, prompt_msg_id, user_id
    )


async def save_reseller_wrong_attempt(user_id: int, wrong_code_msg_id: int | None, wrong_result_msg_id: int | None):
    await db.execute(
        "UPDATE users SET reseller_wrong_code_msg_id = $1, reseller_wrong_result_msg_id = $2 WHERE id = $3",
        wrong_code_msg_id, wrong_result_msg_id, user_id
    )


async def save_reseller_success_result_msg_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET reseller_success_result_msg_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def cleanup_reseller_wrong_attempt(bot: Bot, user_id: int, chat_id: int):
    fresh = await db.fetch_one(
        "SELECT reseller_wrong_code_msg_id, reseller_wrong_result_msg_id FROM users WHERE id = $1 LIMIT 1",
        user_id
    )
    if not fresh:
        return
    wc = int(fresh.get("reseller_wrong_code_msg_id") or 0)
    wr = int(fresh.get("reseller_wrong_result_msg_id") or 0)
    if wc > 0:
        await safe_delete_message(bot, chat_id, wc)
    if wr > 0:
        await safe_delete_message(bot, chat_id, wr)
    await save_reseller_wrong_attempt(user_id, None, None)


async def cleanup_reseller_temp_thread(bot: Bot, user_id: int, chat_id: int):
    fresh = await db.fetch_one(
        "SELECT reseller_level_trigger_msg_id, reseller_prompt_msg_id, reseller_wrong_code_msg_id, reseller_wrong_result_msg_id FROM users WHERE id = $1 LIMIT 1",
        user_id
    )
    if not fresh:
        return
    lt = int(fresh.get("reseller_level_trigger_msg_id") or 0)
    pr = int(fresh.get("reseller_prompt_msg_id") or 0)
    wc = int(fresh.get("reseller_wrong_code_msg_id") or 0)
    wr = int(fresh.get("reseller_wrong_result_msg_id") or 0)
    delete_tasks = []
    if lt > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, lt))
    if pr > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, pr))
    if wc > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, wc))
    if wr > 0:
        delete_tasks.append(safe_delete_message(bot, chat_id, wr))
    if delete_tasks:
        await asyncio.gather(*delete_tasks)
    await db.execute(
        "UPDATE users SET reseller_level_trigger_msg_id = NULL, reseller_prompt_msg_id = NULL, reseller_wrong_code_msg_id = NULL, reseller_wrong_result_msg_id = NULL WHERE id = $1",
        user_id
    )


async def save_broadcast_categories_message_id(user_id: int, message_id: int | None):
    await db.execute(
        "UPDATE users SET broadcast_categories_message_id = $1 WHERE id = $2",
        message_id, user_id
    )


async def clear_broadcast_categories_message_id(user_id: int):
    await db.execute(
        "UPDATE users SET broadcast_categories_message_id = NULL WHERE id = $1",
        user_id
    )


async def cleanup_broadcast_categories_message(bot: Bot, user_row: dict, chat_id: int):
    message_id = int(user_row.get("broadcast_categories_message_id") or 0)
    if message_id > 0:
        await safe_delete_message(bot, chat_id, message_id)
    await clear_broadcast_categories_message_id(user_row["id"])


async def cleanup_all_user_browsing_state(bot: Bot, user_row: dict, chat_id: int):
    await asyncio.gather(
        cleanup_user_durations_message(bot, user_row, chat_id),
        cleanup_user_active_payment(bot, user_row, chat_id),
        cleanup_user_active_payment_error(bot, user_row, chat_id),
        cleanup_user_expiry_notice(bot, chat_id, user_row["id"]),
        cleanup_broadcast_categories_message(bot, user_row, chat_id),
    )
