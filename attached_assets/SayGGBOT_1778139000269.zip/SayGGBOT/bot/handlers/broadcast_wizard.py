import re
import time
import asyncio
import logging
from html import escape
from datetime import datetime, timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ForceReply, Update
from telegram.ext import ContextTypes
from bot import database as db
from bot.config import ADMIN_CHAT_ID
from bot.cleanup import safe_delete_message
from bot import settings

logger = logging.getLogger(__name__)

WIZARD_STATES = {}

BROADCAST_PINNED_MESSAGES = {}
_PINNED_MAX = 10000
_PINNED_EVICT_COUNT = 2000

STEP_TARGET = "target"
STEP_CONTENT = "content"
STEP_ACTIONS = "actions"
STEP_BTN_TEXT = "btn_text"
STEP_BTN_URL = "btn_url"
STEP_BTN_STYLE = "btn_style"
STEP_BTN_EMOJI = "btn_emoji"
STEP_SENDING = "sending"

TARGET_EVERYONE = "everyone"
TARGET_RESELLERS = "resellers"
TARGET_PAID = "paid_users"

STYLE_OPTIONS = ["default", "primary", "success", "danger"]


def register_broadcast_pin(chat_id: int, message_id: int):
    if len(BROADCAST_PINNED_MESSAGES) >= _PINNED_MAX:
        keys = list(BROADCAST_PINNED_MESSAGES.keys())[:_PINNED_EVICT_COUNT]
        for k in keys:
            BROADCAST_PINNED_MESSAGES.pop(k, None)
    BROADCAST_PINNED_MESSAGES[chat_id] = message_id


def is_broadcast_pinned_message(chat_id: int, message_id: int) -> bool:
    return BROADCAST_PINNED_MESSAGES.get(chat_id) == message_id


def _get_state(admin_id: int) -> dict | None:
    return WIZARD_STATES.get(admin_id)


def _clear_state(admin_id: int):
    WIZARD_STATES.pop(admin_id, None)


def _init_state(admin_id: int) -> dict:
    pin_default = settings.get("broadcast_pin_message") == "1"
    state = {
        "step": STEP_TARGET,
        "target": None,
        "content_html": None,
        "buttons": [],
        "current_button": {},
        "broadcast_pin": pin_default,
        "msg_ids_to_cleanup": [],
        "temp_error_msg_id": None,
        "content_prompt_msg_id": None,
        "btn_text_prompt_msg_id": None,
        "btn_url_prompt_msg_id": None,
        "preview_msg_id": None,
        "progress_msg_id": None,
        "confirm_msg_id": None,
    }
    WIZARD_STATES[admin_id] = state
    return state


def _track_msg(state: dict, msg_id: int):
    if msg_id and msg_id not in state["msg_ids_to_cleanup"]:
        state["msg_ids_to_cleanup"].append(msg_id)


async def _cleanup_wizard_messages(bot, chat_id: int, state: dict):
    if state.get("temp_error_msg_id"):
        await safe_delete_message(bot, chat_id, state["temp_error_msg_id"])
        state["temp_error_msg_id"] = None
    if state.get("preview_msg_id"):
        await safe_delete_message(bot, chat_id, state["preview_msg_id"])
        state["preview_msg_id"] = None
    for mid in state.get("msg_ids_to_cleanup", []):
        await safe_delete_message(bot, chat_id, mid)
    state["msg_ids_to_cleanup"] = []


async def _clear_temp_error(bot, chat_id: int, state: dict):
    if state.get("temp_error_msg_id"):
        await safe_delete_message(bot, chat_id, state["temp_error_msg_id"])
        state["temp_error_msg_id"] = None


async def _send_temp_error(bot, chat_id: int, state: dict, text: str, reply_markup=None):
    await _clear_temp_error(bot, chat_id, state)
    sent = await bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode="HTML",
        reply_markup=reply_markup,
    )
    state["temp_error_msg_id"] = sent.message_id


def _target_label(target: str) -> str:
    labels = {
        TARGET_EVERYONE: "Everyone",
        TARGET_RESELLERS: "Resellers",
        TARGET_PAID: "Paid Users",
    }
    return labels.get(target, target)


def _target_description(target: str) -> str:
    desc = {
        TARGET_EVERYONE: "All registered users",
        TARGET_RESELLERS: "Users with reseller status",
        TARGET_PAID: "Users with at least one successful purchase",
    }
    return desc.get(target, "")


async def _get_audience_ids(target: str) -> list[int]:
    if target == TARGET_EVERYONE:
        rows = await db.fetch_all(
            "SELECT DISTINCT telegram_id FROM users WHERE is_banned = 0"
        )
    elif target == TARGET_RESELLERS:
        rows = await db.fetch_all(
            "SELECT DISTINCT telegram_id FROM users WHERE is_banned = 0 AND reseller_id IS NOT NULL AND reseller_id > 0"
        )
    elif target == TARGET_PAID:
        rows = await db.fetch_all(
            "SELECT DISTINCT u.telegram_id FROM users u "
            "INNER JOIN purchased_keys_history pkh ON u.telegram_id = pkh.telegram_id "
            "WHERE u.is_banned = 0"
        )
    else:
        rows = []
    return [r["telegram_id"] for r in rows]


def _build_broadcast_keyboard(buttons: list) -> InlineKeyboardMarkup | None:
    if not buttons:
        return None
    rows = []
    for btn in buttons:
        text = btn.get("text", "").strip()
        url = btn.get("url", "").strip()
        if not text or not url:
            continue
        api_kwargs = {}
        style = btn.get("style", "").strip()
        if style in ("primary", "success", "danger"):
            api_kwargs["style"] = style
        emoji_id = btn.get("icon_custom_emoji_id", "").strip()
        if emoji_id:
            api_kwargs["icon_custom_emoji_id"] = emoji_id
        rows.append([InlineKeyboardButton(
            text=text,
            url=url,
            api_kwargs=api_kwargs if api_kwargs else None,
        )])
    return InlineKeyboardMarkup(rows) if rows else None


def _buttons_summary(buttons: list) -> str:
    if not buttons:
        return "  None"
    lines = []
    for i, b in enumerate(buttons, 1):
        style_tag = f" [{b.get('style') or 'default'}]" if b.get("style") else ""
        emoji_tag = f" (emoji: {b.get('icon_custom_emoji_id')})" if b.get("icon_custom_emoji_id") else ""
        lines.append(f"  {i}. <b>{escape(b['text'])}</b> → {escape(b['url'])}{style_tag}{emoji_tag}")
    return "\n".join(lines)


def _is_reply_to(msg, expected_mid: int | None) -> bool:
    if not expected_mid:
        return False
    reply_to = msg.reply_to_message
    return reply_to is not None and reply_to.message_id == expected_mid


def is_broadcast_wizard_active(admin_id: int) -> bool:
    return admin_id in WIZARD_STATES


async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    chat_id = msg.chat_id
    bot = context.bot
    admin_id = msg.from_user.id

    if admin_id != ADMIN_CHAT_ID:
        return

    old_state = _get_state(admin_id)
    if old_state:
        await _cleanup_wizard_messages(bot, chat_id, old_state)
        _clear_state(admin_id)

    state = _init_state(admin_id)
    _track_msg(state, msg.message_id)

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👥 Everyone", callback_data="bw_target_everyone")],
        [InlineKeyboardButton("🏪 Resellers", callback_data="bw_target_resellers")],
        [InlineKeyboardButton("💰 Paid Users", callback_data="bw_target_paid")],
        [InlineKeyboardButton("❌ Leave It", callback_data="bw_target_cancel")],
    ])
    sent = await bot.send_message(
        chat_id=chat_id,
        text=(
            "<b>📢 Broadcast Wizard</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "Select who should receive this broadcast:\n\n"
            "  <b>👥 Everyone</b> — All registered users\n"
            "  <b>🏪 Resellers</b> — Reseller accounts only\n"
            "  <b>💰 Paid Users</b> — Users with purchases\n"
            "  <b>❌ Leave It</b> — Cancel and exit"
        ),
        parse_mode="HTML",
        reply_markup=keyboard,
    )
    _track_msg(state, sent.message_id)


async def handle_broadcast_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = query.message.chat_id
    bot = context.bot
    admin_id = query.from_user.id
    data = query.data or ""

    if admin_id != ADMIN_CHAT_ID:
        await query.answer("Not authorized", show_alert=True)
        return

    state = _get_state(admin_id)
    if not state:
        await query.answer("No active broadcast wizard. Send /broadcast to start.", show_alert=True)
        return

    if data in ("bw_target_cancel", "bw_action_cancel", "bw_confirm_cancel"):
        await query.answer("Broadcast cancelled")
        await _cleanup_wizard_messages(bot, chat_id, state)
        await bot.send_message(
            chat_id=chat_id,
            text="<b>📢 Broadcast Wizard</b>\n\n✅ Cancelled. No messages were sent.",
            parse_mode="HTML",
        )
        _clear_state(admin_id)
        return

    if data.startswith("bw_target_"):
        target_key = data.replace("bw_target_", "")
        target_map = {
            "everyone": TARGET_EVERYONE,
            "resellers": TARGET_RESELLERS,
            "paid": TARGET_PAID,
        }
        target = target_map.get(target_key)
        if not target:
            await query.answer("Invalid target", show_alert=True)
            return

        await query.answer(f"Target: {_target_label(target)}")
        state["target"] = target
        state["step"] = STEP_CONTENT

        await safe_delete_message(bot, chat_id, query.message.message_id)

        sent = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>📢 Broadcast Wizard — Step 2</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                f"🎯 Target: <b>{_target_label(target)}</b>\n"
                f"    <i>{_target_description(target)}</i>\n\n"
                "Send me the broadcast message content now.\n"
                "Reply directly to this message.\n\n"
                "<b>Supported formatting:</b>\n"
                "  • <b>bold</b>  •  <i>italic</i>  •  <u>underline</u>\n"
                "  • <code>inline code</code>  •  preformatted blocks\n"
                "  • hyperlinks  •  custom emojis\n\n"
                "<b>Example:</b>\n"
                "<code>🎉 Weekend Special!\n"
                "\n"
                "Get Vision Day at a discounted price.\n"
                "Tap the button below to browse.</code>"
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=False, input_field_placeholder="Type your broadcast message..."),
        )
        state["content_prompt_msg_id"] = sent.message_id
        _track_msg(state, sent.message_id)
        return

    if data == "bw_action_preview":
        await query.answer()
        await _clear_temp_error(bot, chat_id, state)
        await _send_preview(bot, chat_id, state, query.message.message_id)
        return

    if data in ("bw_action_buttons", "bw_edit_buttons"):
        await query.answer()
        await _clear_temp_error(bot, chat_id, state)
        await _start_button_builder(bot, chat_id, state, query.message.message_id)
        return

    if data == "bw_action_send":
        await query.answer()
        await _clear_temp_error(bot, chat_id, state)
        await _send_confirmation(bot, chat_id, state, query.message.message_id)
        return

    if data.startswith("bw_btn_style_"):
        style = data.replace("bw_btn_style_", "")
        if style not in STYLE_OPTIONS:
            style = "default"
        await query.answer(f"Style: {style}")

        state["current_button"]["style"] = style if style != "default" else ""
        state["step"] = STEP_BTN_EMOJI

        await safe_delete_message(bot, chat_id, query.message.message_id)

        sent = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>🔘 Button Builder — Custom Emoji</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                "Send a <b>custom emoji ID</b> to add an icon\n"
                "to this button, or tap <b>Skip</b>.\n\n"
                "<b>How to find it:</b>\n"
                "Send the custom emoji in any chat, then\n"
                "long-press it to copy its numeric ID.\n\n"
                "<b>Example:</b>\n"
                "<code>5368324170671202286</code>"
            ),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏭ Skip — No Icon", callback_data="bw_btn_emoji_skip")],
            ]),
        )
        _track_msg(state, sent.message_id)
        return

    if data == "bw_btn_emoji_skip":
        await query.answer()
        state["current_button"]["icon_custom_emoji_id"] = ""
        await _finish_current_button(bot, chat_id, state, query.message.message_id)
        return

    if data == "bw_toggle_pin":
        state["broadcast_pin"] = not state["broadcast_pin"]
        new_status = "ON" if state["broadcast_pin"] else "OFF"
        await query.answer(f"📌 Pin: {new_status}")
        await _refresh_current_screen(bot, chat_id, state, query.message)
        return

    if data == "bw_btn_add_another":
        await query.answer()
        await _start_button_builder(bot, chat_id, state, query.message.message_id)
        return

    if data == "bw_btn_done":
        await query.answer()
        await safe_delete_message(bot, chat_id, query.message.message_id)
        await _send_actions_menu(bot, chat_id, state)
        return

    if data == "bw_confirm_send":
        await query.answer("Starting broadcast...")
        await safe_delete_message(bot, chat_id, query.message.message_id)
        await _execute_broadcast(bot, chat_id, admin_id, state)
        return

    await query.answer()


async def handle_broadcast_wizard_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    msg = update.message
    if not msg or not msg.from_user:
        return False

    admin_id = msg.from_user.id
    if admin_id != ADMIN_CHAT_ID:
        return False

    state = _get_state(admin_id)
    if not state:
        return False

    chat_id = msg.chat_id
    bot = context.bot
    text = (msg.text or "").strip()
    step = state["step"]

    if step == STEP_CONTENT:
        if not _is_reply_to(msg, state.get("content_prompt_msg_id")):
            await _send_temp_error(
                bot, chat_id, state,
                (
                    "💡 <b>Reply to the broadcast prompt above</b>\n\n"
                    "Please reply directly to the prompt message\n"
                    "with your broadcast content.\n\n"
                    "<i>Tap the prompt message → Reply</i>"
                ),
            )
            return True

        await _clear_temp_error(bot, chat_id, state)

        if not text:
            await _send_temp_error(
                bot, chat_id, state,
                "⚠️ Broadcast content cannot be empty.\n\nPlease reply to the prompt with a <b>text message</b>.",
            )
            return True

        state["content_html"] = msg.text_html
        state["step"] = STEP_ACTIONS

        await _send_actions_menu(bot, chat_id, state)
        return True

    if step == STEP_BTN_TEXT:
        if not _is_reply_to(msg, state.get("btn_text_prompt_msg_id")):
            await _send_temp_error(
                bot, chat_id, state,
                (
                    "💡 <b>Reply to the button text prompt above</b>\n\n"
                    "Please reply directly to the prompt message\n"
                    "with the button label text."
                ),
            )
            return True

        await _clear_temp_error(bot, chat_id, state)

        if not text:
            await _send_temp_error(
                bot, chat_id, state,
                "⚠️ Button text cannot be empty.\n\nReply to the prompt with a <b>button label</b>.",
            )
            return True

        state["current_button"]["text"] = text
        state["step"] = STEP_BTN_URL

        _track_msg(state, msg.message_id)

        sent = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>🔘 Button Builder — URL</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                f"Button text: <b>{escape(text)}</b>\n\n"
                "Now reply with the <b>destination URL</b>\n"
                "for this button.\n\n"
                "<b>Example:</b>\n"
                "<code>https://t.me/yourchannel</code>"
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=False, input_field_placeholder="Paste the button URL..."),
        )
        state["btn_url_prompt_msg_id"] = sent.message_id
        _track_msg(state, sent.message_id)
        return True

    if step == STEP_BTN_URL:
        if not _is_reply_to(msg, state.get("btn_url_prompt_msg_id")):
            await _send_temp_error(
                bot, chat_id, state,
                (
                    "💡 <b>Reply to the URL prompt above</b>\n\n"
                    "Please reply directly to the prompt message\n"
                    "with the button URL."
                ),
            )
            return True

        await _clear_temp_error(bot, chat_id, state)

        url = text
        if not re.match(r'^https?://', url):
            await _send_temp_error(
                bot, chat_id, state,
                (
                    "⚠️ <b>Invalid URL</b>\n\n"
                    "URLs must start with <code>http://</code> or <code>https://</code>\n\n"
                    "<b>Example:</b>\n"
                    "<code>https://t.me/yourchannel</code>\n"
                    "<code>https://example.com/offer</code>\n\n"
                    "Reply to the prompt above with a valid URL."
                ),
            )
            return True

        state["current_button"]["url"] = url
        state["step"] = STEP_BTN_STYLE

        _track_msg(state, msg.message_id)

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("⬜ Default", callback_data="bw_btn_style_default"),
                InlineKeyboardButton("🔵 Primary", callback_data="bw_btn_style_primary"),
            ],
            [
                InlineKeyboardButton("🟢 Success", callback_data="bw_btn_style_success"),
                InlineKeyboardButton("🔴 Danger", callback_data="bw_btn_style_danger"),
            ],
        ])
        sent = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>🔘 Button Builder — Style</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                f"Button: <b>{escape(state['current_button']['text'])}</b>\n"
                f"URL: <code>{escape(url)}</code>\n\n"
                "Choose the button <b>color/style</b>:\n\n"
                "  <b>⬜ Default</b> — Standard button\n"
                "  <b>🔵 Primary</b> — Blue accent\n"
                "  <b>🟢 Success</b> — Green accent\n"
                "  <b>🔴 Danger</b> — Red accent"
            ),
            parse_mode="HTML",
            reply_markup=keyboard,
        )
        _track_msg(state, sent.message_id)
        return True

    if step == STEP_BTN_EMOJI:
        await _clear_temp_error(bot, chat_id, state)

        emoji_id = text.strip()
        if not re.match(r'^\d{5,32}$', emoji_id):
            await _send_temp_error(
                bot, chat_id, state,
                (
                    "⚠️ <b>Invalid custom emoji ID</b>\n\n"
                    "Must be a numeric ID (5-32 digits).\n\n"
                    "<b>Example:</b>\n"
                    "<code>5368324170671202286</code>\n\n"
                    "Send a valid ID, or tap <b>Skip</b>."
                ),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⏭ Skip — No Icon", callback_data="bw_btn_emoji_skip")],
                ]),
            )
            return True

        state["current_button"]["icon_custom_emoji_id"] = emoji_id
        _track_msg(state, msg.message_id)
        await _finish_current_button(bot, chat_id, state, None)
        return True

    return False


async def _start_button_builder(bot, chat_id: int, state: dict, delete_msg_id: int | None):
    if delete_msg_id:
        await safe_delete_message(bot, chat_id, delete_msg_id)

    state["step"] = STEP_BTN_TEXT
    state["current_button"] = {}

    btn_count = len(state["buttons"])
    btn_num = btn_count + 1

    existing = ""
    if btn_count > 0:
        existing = (
            f"\n<b>Current buttons ({btn_count}):</b>\n"
            f"{_buttons_summary(state['buttons'])}\n"
        )

    sent = await bot.send_message(
        chat_id=chat_id,
        text=(
            f"<b>🔘 Button Builder — Button #{btn_num}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{existing}\n"
            "Reply with the <b>visible text</b> for this button.\n\n"
            "<b>Example:</b>\n"
            "<code>Join Channel</code>\n"
            "<code>Visit Website</code>\n"
            "<code>Get Offer</code>"
        ),
        parse_mode="HTML",
        reply_markup=ForceReply(selective=False, input_field_placeholder="Type the button label..."),
    )
    state["btn_text_prompt_msg_id"] = sent.message_id
    _track_msg(state, sent.message_id)


async def _finish_current_button(bot, chat_id: int, state: dict, delete_msg_id: int | None):
    if delete_msg_id:
        await safe_delete_message(bot, chat_id, delete_msg_id)

    btn = state["current_button"]
    state["buttons"].append(btn)
    state["current_button"] = {}
    state["step"] = STEP_ACTIONS

    btn_count = len(state["buttons"])

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add Another Button", callback_data="bw_btn_add_another")],
        [InlineKeyboardButton("✅ Done — Back to Menu", callback_data="bw_btn_done")],
    ])
    sent = await bot.send_message(
        chat_id=chat_id,
        text=(
            f"<b>✅ Button #{btn_count} Added</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"<b>All buttons ({btn_count}):</b>\n"
            f"{_buttons_summary(state['buttons'])}\n\n"
            "Add another button or continue?"
        ),
        parse_mode="HTML",
        reply_markup=keyboard,
    )
    _track_msg(state, sent.message_id)


def _pin_toggle_label(state: dict) -> str:
    return "📌 Pin: ON ✓" if state["broadcast_pin"] else "📌 Pin: OFF"


def _pin_status_text(state: dict) -> str:
    return "🟢 ON" if state["broadcast_pin"] else "⚪ OFF"


async def _refresh_current_screen(bot, chat_id: int, state: dict, message):
    step = state["step"]
    btn_count = len(state["buttons"])

    if step == STEP_ACTIONS:
        btn_label = f"✏️ Edit Buttons ({btn_count})" if btn_count > 0 else "🔘 Add Inline Buttons"
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("👁 Preview", callback_data="bw_action_preview")],
            [InlineKeyboardButton(btn_label, callback_data="bw_action_buttons")],
            [InlineKeyboardButton(_pin_toggle_label(state), callback_data="bw_toggle_pin")],
            [InlineKeyboardButton("🚀 Send Broadcast", callback_data="bw_action_send")],
            [InlineKeyboardButton("❌ Cancel", callback_data="bw_action_cancel")],
        ])
        text = (
            "<b>📢 Broadcast Wizard — Ready</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
            f"    <i>{_target_description(state['target'])}</i>\n"
            f"📝 Content: ✅ Captured\n"
            f"🔘 Buttons: <b>{btn_count}</b>\n"
            f"📌 Pin message: <b>{_pin_status_text(state)}</b>\n\n"
            "Choose an action:"
        )
    else:
        pin_status = "🟢 ON — message will be pinned" if state["broadcast_pin"] else "⚪ OFF — no pinning"
        has_preview = state.get("preview_msg_id") is not None

        if has_preview:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(_pin_toggle_label(state), callback_data="bw_toggle_pin")],
                [InlineKeyboardButton("🚀 Send Broadcast", callback_data="bw_action_send")],
                [InlineKeyboardButton("✏️ Edit Buttons", callback_data="bw_edit_buttons")],
                [InlineKeyboardButton("❌ Cancel", callback_data="bw_action_cancel")],
            ])
            text = (
                "<b>👁 Preview</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                "⬆️ The message above is exactly what\n"
                "recipients will see.\n\n"
                f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
                f"🔘 Buttons: <b>{btn_count}</b>\n"
                f"📌 Pin message: <b>{_pin_status_text(state)}</b>\n\n"
                "Choose an action:"
            )
        else:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(_pin_toggle_label(state), callback_data="bw_toggle_pin")],
                [InlineKeyboardButton("✅ Confirm — Start Sending", callback_data="bw_confirm_send")],
                [InlineKeyboardButton("❌ Cancel", callback_data="bw_confirm_cancel")],
            ])
            text = (
                "<b>📢 Final Confirmation</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n\n"
                f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
                f"    <i>{_target_description(state['target'])}</i>\n\n"
                f"📌 Pin message: <b>{pin_status}</b>\n\n"
                "⚠️ This action cannot be undone.\n\n"
                "Confirm to proceed:"
            )

    try:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message.message_id,
            text=text,
            parse_mode="HTML",
            reply_markup=keyboard,
        )
    except Exception:
        pass


async def _send_actions_menu(bot, chat_id: int, state: dict):
    btn_count = len(state["buttons"])
    btn_label = f"✏️ Edit Buttons ({btn_count})" if btn_count > 0 else "🔘 Add Inline Buttons"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👁 Preview", callback_data="bw_action_preview")],
        [InlineKeyboardButton(btn_label, callback_data="bw_action_buttons")],
        [InlineKeyboardButton(_pin_toggle_label(state), callback_data="bw_toggle_pin")],
        [InlineKeyboardButton("🚀 Send Broadcast", callback_data="bw_action_send")],
        [InlineKeyboardButton("❌ Cancel", callback_data="bw_action_cancel")],
    ])
    sent = await bot.send_message(
        chat_id=chat_id,
        text=(
            "<b>📢 Broadcast Wizard — Ready</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
            f"    <i>{_target_description(state['target'])}</i>\n"
            f"📝 Content: ✅ Captured\n"
            f"🔘 Buttons: <b>{btn_count}</b>\n"
            f"📌 Pin message: <b>{_pin_status_text(state)}</b>\n\n"
            "Choose an action:"
        ),
        parse_mode="HTML",
        reply_markup=keyboard,
    )
    _track_msg(state, sent.message_id)


async def _send_preview(bot, chat_id: int, state: dict, delete_msg_id: int | None):
    if delete_msg_id:
        await safe_delete_message(bot, chat_id, delete_msg_id)

    if state.get("preview_msg_id"):
        await safe_delete_message(bot, chat_id, state["preview_msg_id"])
        state["preview_msg_id"] = None

    reply_markup = _build_broadcast_keyboard(state["buttons"])
    try:
        preview = await bot.send_message(
            chat_id=chat_id,
            text=state["content_html"],
            parse_mode="HTML",
            reply_markup=reply_markup,
        )
        state["preview_msg_id"] = preview.message_id
    except Exception as e:
        logger.exception("Preview send failed")
        await _send_temp_error(
            bot, chat_id, state,
            (
                "<b>⚠️ Preview Failed</b>\n\n"
                f"Reason: <code>{escape(str(e))}</code>\n\n"
                "This usually means the message content or\n"
                "button configuration has an issue.\n"
                "Check your content and try again."
            ),
        )
        await _send_actions_menu(bot, chat_id, state)
        return

    btn_count = len(state["buttons"])

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(_pin_toggle_label(state), callback_data="bw_toggle_pin")],
        [InlineKeyboardButton("🚀 Send Broadcast", callback_data="bw_action_send")],
        [InlineKeyboardButton("✏️ Edit Buttons", callback_data="bw_edit_buttons")],
        [InlineKeyboardButton("❌ Cancel", callback_data="bw_action_cancel")],
    ])
    controls = await bot.send_message(
        chat_id=chat_id,
        text=(
            "<b>👁 Preview</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "⬆️ The message above is exactly what\n"
            "recipients will see.\n\n"
            f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
            f"🔘 Buttons: <b>{btn_count}</b>\n"
            f"📌 Pin message: <b>{_pin_status_text(state)}</b>\n\n"
            "Choose an action:"
        ),
        parse_mode="HTML",
        reply_markup=keyboard,
    )
    _track_msg(state, controls.message_id)


async def _send_confirmation(bot, chat_id: int, state: dict, delete_msg_id: int | None):
    if delete_msg_id:
        await safe_delete_message(bot, chat_id, delete_msg_id)

    audience_ids = await _get_audience_ids(state["target"])
    user_count = len(audience_ids)
    btn_count = len(state["buttons"])
    pin_status = "🟢 ON — message will be pinned" if state["broadcast_pin"] else "⚪ OFF — no pinning"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(_pin_toggle_label(state), callback_data="bw_toggle_pin")],
        [InlineKeyboardButton("✅ Confirm — Start Sending", callback_data="bw_confirm_send")],
        [InlineKeyboardButton("❌ Cancel", callback_data="bw_confirm_cancel")],
    ])
    sent = await bot.send_message(
        chat_id=chat_id,
        text=(
            "<b>📢 Final Confirmation</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
            f"    <i>{_target_description(state['target'])}</i>\n\n"
            f"👥 Matched users: <b>{user_count}</b>\n"
            f"🔘 Inline buttons: <b>{btn_count}</b>\n"
            f"📌 Pin message: <b>{pin_status}</b>\n\n"
            "⚠️ This action cannot be undone.\n"
            f"The broadcast will be sent to <b>{user_count}</b> users.\n\n"
            "Confirm to proceed:"
        ),
        parse_mode="HTML",
        reply_markup=keyboard,
    )
    _track_msg(state, sent.message_id)
    state["confirm_msg_id"] = sent.message_id


async def _execute_broadcast(bot, chat_id: int, admin_id: int, state: dict):
    state["step"] = STEP_SENDING

    await _cleanup_wizard_messages(bot, chat_id, state)

    audience_ids = await _get_audience_ids(state["target"])
    total = len(audience_ids)

    if total == 0:
        await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>📢 Broadcast Wizard</b>\n\n"
                "⚠️ No users matched this target audience.\n"
                "Broadcast cancelled."
            ),
            parse_mode="HTML",
        )
        _clear_state(admin_id)
        return

    pin_enabled = state.get("broadcast_pin", False)

    progress_msg = await bot.send_message(
        chat_id=chat_id,
        text=(
            "<b>📤 Broadcasting...</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
            f"📌 Pinning: <b>{'ON' if pin_enabled else 'OFF'}</b>\n"
            f"📊 Progress: <b>0 / {total}</b>\n\n"
            "⏳ Please wait..."
        ),
        parse_mode="HTML",
    )
    progress_msg_id = progress_msg.message_id

    reply_markup = _build_broadcast_keyboard(state["buttons"])
    content_html = state["content_html"]

    sent_count = 0
    failed_count = 0
    blocked_count = 0
    skipped_count = 0
    pinned_count = 0
    pin_failed_count = 0
    start_time = time.time()

    update_interval = max(1, total // 20)

    for i, tid in enumerate(audience_ids):
        if tid == ADMIN_CHAT_ID:
            skipped_count += 1
            continue

        try:
            sent_msg = await bot.send_message(
                chat_id=tid,
                text=content_html,
                parse_mode="HTML",
                reply_markup=reply_markup,
            )
            sent_count += 1

            if pin_enabled:
                try:
                    await bot.pin_chat_message(
                        chat_id=tid,
                        message_id=sent_msg.message_id,
                        disable_notification=True,
                    )
                    register_broadcast_pin(tid, sent_msg.message_id)
                    pinned_count += 1
                except Exception:
                    pin_failed_count += 1

        except Exception as e:
            err_str = str(e).lower()
            if "forbidden" in err_str or "blocked" in err_str or "deactivated" in err_str or "chat not found" in err_str:
                blocked_count += 1
            else:
                failed_count += 1
                logger.warning(f"Broadcast send failed for {tid}: {e}")

        processed = i + 1
        if processed % update_interval == 0 or processed == total:
            pct = int(processed / total * 100)
            pin_line = f"\n    📌 {pinned_count} pinned" if pin_enabled else ""
            try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=progress_msg_id,
                    text=(
                        "<b>📤 Broadcasting...</b>\n"
                        "━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
                        f"📊 Progress: <b>{processed} / {total}</b> ({pct}%)\n"
                        f"    ✅ {sent_count} sent  •  🚫 {blocked_count} blocked  •  ❌ {failed_count} failed"
                        f"{pin_line}\n\n"
                        "⏳ Please wait..."
                    ),
                    parse_mode="HTML",
                )
            except Exception:
                pass

        if (sent_count + failed_count + blocked_count) % 25 == 0 and (sent_count + failed_count + blocked_count) > 0:
            await asyncio.sleep(1.0)

    elapsed = time.time() - start_time
    if elapsed < 60:
        elapsed_str = f"{elapsed:.1f} seconds"
    elif elapsed < 3600:
        elapsed_str = f"{elapsed / 60:.1f} minutes"
    else:
        elapsed_str = f"{elapsed / 3600:.1f} hours"

    await safe_delete_message(bot, chat_id, progress_msg_id)

    now_str = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

    pin_report = ""
    if pin_enabled:
        pin_report = (
            f"\n<b>Pinning:</b>\n"
            f"  📌 Pinned successfully: <b>{pinned_count}</b>\n"
            f"  ⚠️ Pin failed: <b>{pin_failed_count}</b>\n"
        )

    report = (
        "<b>✅ Broadcast Complete</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"🎯 Target: <b>{_target_label(state['target'])}</b>\n"
        f"    <i>{_target_description(state['target'])}</i>\n\n"
        "<b>Results:</b>\n"
        f"  👥 Total matched: <b>{total}</b>\n"
        f"  📨 Sent successfully: <b>{sent_count}</b>\n"
        f"  🚫 Blocked / Unreachable: <b>{blocked_count}</b>\n"
        f"  ❌ Failed: <b>{failed_count}</b>\n"
        f"  ⏭ Skipped (admin): <b>{skipped_count}</b>\n"
        f"{pin_report}\n"
        "<b>Details:</b>\n"
        f"  🔘 Inline buttons: <b>{len(state['buttons'])}</b>\n"
        f"  ⏱ Duration: <b>{elapsed_str}</b>\n"
        f"  🕐 Completed: <b>{now_str}</b>"
    )
    await bot.send_message(
        chat_id=chat_id,
        text=report,
        parse_mode="HTML",
    )

    _clear_state(admin_id)
