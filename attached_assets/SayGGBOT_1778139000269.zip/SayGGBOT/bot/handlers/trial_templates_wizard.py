"""
Telegram-first trial template editor.
Admin-only (ADMIN_CHAT_ID). Callback prefix: ttw_

Flow:
  /trialtemplates → list → view → edit_message / edit_buttons / preview / test_send / history
  Covers: trial_start, trial_expire, trial_apk_caption
"""
import json
import re
import time
import logging
from datetime import datetime, timezone, timedelta
from html import escape

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ForceReply, Update
from telegram.ext import ContextTypes

from bot import database as db
from bot.config import ADMIN_CHAT_ID
from bot.cleanup import safe_delete_message

logger = logging.getLogger(__name__)

IST = timezone(timedelta(hours=5, minutes=30))

SESSION_TTL = 600

TRIAL_TEMPLATE_SESSIONS: dict[int, dict] = {}

TRIAL_TEMPLATE_TYPES = ("trial_start", "trial_expire", "trial_apk_caption")

VALID_VARIABLES_START = {
    "campaign_name", "user_name", "bot_name",
    "trial_duration", "trial_devices", "expire_time", "start_time",
    "categories", "TrialCategoryBlocks", "TrialCategoryNames",
    "TrialCategoryCount", "trial_key", "category_name",
}

VALID_VARIABLES_EXPIRE = {
    "campaign_name", "user_name", "bot_name",
    "expire_time", "categories", "TrialCategoryNames", "TrialCategoryCount",
}

VALID_VARIABLES_APK = {
    "category_name", "trial_key", "category_key", "category_file_name",
    "trial_duration", "trial_devices", "expire_time", "start_time",
    "bot_name", "campaign_name", "user_name", "categories", "TrialCategoryCount",
}

SAMPLE_VALUES = {
    "campaign_name": "Weekend Trial Drop",
    "user_name": "John",
    "bot_name": "KeyStore",
    "trial_duration": "5",
    "trial_devices": "1000",
    "expire_time": "29 Mar 2026, 06:20 PM IST",
    "start_time": "29 Mar 2026, 01:20 PM IST",
    "categories": "NovaEsp, SayGG",
    "TrialCategoryNames": "NovaEsp, SayGG",
    "TrialCategoryCount": "2",
    "trial_key": "TRIAL-ABC-123",
    "category_key": "TRIAL-ABC-123",
    "category_name": "NovaEsp",
    "category_file_name": "NovaEsp",
    "TrialCategoryBlocks": "• <b>NovaEsp</b>\n  Key: <code>Vzhshsuajqw</code>\n• <b>SayGG</b>\n  Key: <code>KEYDGHAUWNW</code>",
}

VARIABLES_HELP_START = (
    "<b>Trial Start Variables:</b>\n"
    "<code>{campaign_name}</code>  <code>{user_name}</code>  <code>{bot_name}</code>\n"
    "<code>{trial_duration}</code>  <code>{trial_devices}</code>  <code>{expire_time}</code>  <code>{start_time}</code>\n"
    "<code>{categories}</code>  <code>{TrialCategoryBlocks}</code>  <code>{TrialCategoryNames}</code>\n"
    "<code>{TrialCategoryCount}</code>  <code>{trial_key}</code>  <code>{category_name}</code>"
)

VARIABLES_HELP_EXPIRE = (
    "<b>Trial Expire Variables:</b>\n"
    "<code>{campaign_name}</code>  <code>{user_name}</code>  <code>{bot_name}</code>\n"
    "<code>{expire_time}</code>  <code>{categories}</code>  <code>{TrialCategoryNames}</code>  <code>{TrialCategoryCount}</code>"
)

VARIABLES_HELP_APK = (
    "<b>APK Caption Variables:</b>\n"
    "<code>{category_name}</code>  <code>{trial_key}</code>  <code>{category_key}</code>\n"
    "<code>{category_file_name}</code>  <code>{trial_duration}</code>  <code>{trial_devices}</code>\n"
    "<code>{expire_time}</code>  <code>{start_time}</code>  <code>{bot_name}</code>\n"
    "<code>{campaign_name}</code>  <code>{user_name}</code>  <code>{categories}</code>  <code>{TrialCategoryCount}</code>"
)

BUTTON_COLORS = ["none", "default", "primary", "success", "warning", "danger"]

STEP_BTN_NAME = "btn_name"
STEP_BTN_URL = "btn_url"
STEP_BTN_COLOR = "btn_color"
STEP_BTN_EMOJI_MODE = "btn_emoji_mode"
STEP_BTN_EMOJI_CHAR = "btn_emoji_char"
STEP_BTN_EMOJI_CUSTOM_ID = "btn_emoji_cid"
STEP_BTN_EMOJI_FALLBACK = "btn_emoji_fallback"
STEP_BTN_ROW = "btn_row"
STEP_BTN_CONFIRM = "btn_confirm"


def _is_admin(telegram_id: int) -> bool:
    return ADMIN_CHAT_ID > 0 and telegram_id == ADMIN_CHAT_ID


def _get_session(admin_id: int) -> dict | None:
    s = TRIAL_TEMPLATE_SESSIONS.get(admin_id)
    if not s:
        return None
    if time.time() > s.get("expires_at", 0):
        TRIAL_TEMPLATE_SESSIONS.pop(admin_id, None)
        return None
    return s


def _new_session(admin_id: int) -> dict:
    s = {
        "step": "list",
        "template_id": None,
        "template_data": {},
        "prompt_msg_id": None,
        "list_msg_id": None,
        "info_msg_id": None,
        "preview_msg_id": None,
        "extra_msg_ids": [],
        "current_button_draft": {},
        "button_edit_idx": None,
        "temp_buttons": [],
        "expires_at": time.time() + SESSION_TTL,
    }
    TRIAL_TEMPLATE_SESSIONS[admin_id] = s
    return s


def _bump_session(admin_id: int):
    s = TRIAL_TEMPLATE_SESSIONS.get(admin_id)
    if s:
        s["expires_at"] = time.time() + SESSION_TTL


def _clear_session(admin_id: int):
    TRIAL_TEMPLATE_SESSIONS.pop(admin_id, None)


def is_trial_template_wizard_active(admin_id: int) -> bool:
    return _get_session(admin_id) is not None


def _get_valid_vars(template_type: str) -> set:
    if template_type == "trial_expire":
        return VALID_VARIABLES_EXPIRE
    if template_type == "trial_apk_caption":
        return VALID_VARIABLES_APK
    return VALID_VARIABLES_START


def _get_vars_help(template_type: str) -> str:
    if template_type == "trial_expire":
        return VARIABLES_HELP_EXPIRE
    if template_type == "trial_apk_caption":
        return VARIABLES_HELP_APK
    return VARIABLES_HELP_START


def _render_sample(body_text: str) -> str:
    result = body_text
    for k, v in SAMPLE_VALUES.items():
        result = result.replace("{" + k + "}", v)
    return result


def _validate_variables(body_text: str, template_type: str) -> list[str]:
    valid = _get_valid_vars(template_type)
    found = re.findall(r'\{(\w+)\}', body_text)
    return [v for v in found if v not in valid and not v.startswith("TrialKey")]


def _count_variables(body_text: str, template_type: str) -> int:
    valid = _get_valid_vars(template_type)
    found = re.findall(r'\{(\w+)\}', body_text)
    return len(set(v for v in found if v in valid))


def _capture_html(msg) -> str:
    try:
        html = getattr(msg, "text_html", None) or getattr(msg, "caption_html", None)
        if html is not None:
            return html.strip()
    except Exception as exc:
        logger.warning(f"[trial_template_capture] text_html failed: {exc!r}")
    raw = (msg.text or msg.caption or "").strip()
    return raw


def _entities_to_json(entities) -> str | None:
    if not entities:
        return None
    result = []
    for e in entities:
        d: dict = {"type": e.type, "offset": e.offset, "length": e.length}
        if getattr(e, "url", None):
            d["url"] = e.url
        if getattr(e, "language", None):
            d["language"] = e.language
        if getattr(e, "custom_emoji_id", None):
            d["custom_emoji_id"] = e.custom_emoji_id
        result.append(d)
    return json.dumps(result, ensure_ascii=False)


def _fmt_dt(dt_val) -> str:
    if not dt_val:
        return "—"
    if isinstance(dt_val, datetime):
        aware = dt_val.replace(tzinfo=timezone.utc) if dt_val.tzinfo is None else dt_val
        return aware.astimezone(IST).strftime("%d %b %Y, %I:%M %p")
    return str(dt_val)


def _tpl_type_label(t: str) -> str:
    return {
        "trial_start": "Trial Start",
        "trial_expire": "Trial Expire",
        "trial_apk_caption": "APK Caption",
    }.get(t, t)


def _tpl_type_icon(t: str) -> str:
    return {
        "trial_start": "🚀",
        "trial_expire": "⏰",
        "trial_apk_caption": "📦",
    }.get(t, "📋")


def _btn_summary(b: dict, idx: int) -> str:
    text = (b.get("text") or "Btn")[:22]
    row = b.get("row", 1)
    style = (b.get("style") or "").strip()
    mode = b.get("emoji_mode", "none")
    emoji = ""
    if mode == "plain":
        emoji = (b.get("emoji") or "").strip()
    elif mode == "custom":
        emoji = (b.get("fallback_emoji") or b.get("emoji") or "").strip()
    label = f"{emoji} {text}".strip() if emoji else text
    parts = [f"{idx+1}. {label}", f"row {row}"]
    if style:
        parts.append(style)
    if not b.get("enabled", True):
        parts.append("off")
    return "  ·  ".join(parts)


async def _cleanup_msgs(bot, chat_id: int, session: dict):
    to_delete = []
    for key in ("prompt_msg_id", "preview_msg_id", "info_msg_id"):
        mid = session.get(key)
        if mid:
            to_delete.append(mid)
            session[key] = None
    for mid in session.get("extra_msg_ids", []):
        if mid:
            to_delete.append(mid)
    session["extra_msg_ids"] = []
    for mid in to_delete:
        await safe_delete_message(bot, chat_id, mid)


async def _save_version(template_id: int, changed_by: str, changed_via: str, note: str):
    old = await db.fetch_one(
        "SELECT body_text, inline_buttons_json, body_entities_json FROM campaign_templates WHERE id = $1",
        template_id,
    )
    if not old:
        return
    await db.execute(
        """INSERT INTO template_versions
           (template_id, body_text, inline_buttons_json, body_entities_json, changed_by, changed_via, change_note)
           VALUES ($1, $2, $3, $4, $5, $6, $7)""",
        template_id,
        old["body_text"] or "",
        old.get("inline_buttons_json") or "",
        old.get("body_entities_json") or None,
        changed_by,
        changed_via,
        note,
    )


async def _save_template_body(template_id: int, new_body: str, updated_by: str,
                              entities_json: str | None = None):
    await _save_version(template_id, updated_by, "bot", "message body updated via bot")
    await db.execute(
        """UPDATE campaign_templates
           SET body_text = $1, body_entities_json = $2,
               updated_at = NOW(), updated_by = $3, edited_via = 'bot'
           WHERE id = $4""",
        new_body, entities_json, updated_by, template_id,
    )


async def _save_template_buttons(template_id: int, buttons_list: list, updated_by: str):
    await _save_version(template_id, updated_by, "bot", "buttons updated via bot")
    await db.execute(
        """UPDATE campaign_templates
           SET inline_buttons_json = $1, updated_at = NOW(), updated_by = $2, edited_via = 'bot'
           WHERE id = $3""",
        json.dumps(buttons_list), updated_by, template_id,
    )


async def _show_template_list(bot, chat_id: int, admin_id: int, edit_msg_id: int | None = None) -> int:
    rows_db = await db.fetch_all(
        "SELECT id, name, template_type, category_id FROM campaign_templates "
        "WHERE is_active = true AND template_type IN ('trial_start', 'trial_expire', 'trial_apk_caption') "
        "ORDER BY template_type, name"
    )
    rows_db = [dict(r) for r in (rows_db or [])]

    starts = [t for t in rows_db if t["template_type"] == "trial_start"]
    expires = [t for t in rows_db if t["template_type"] == "trial_expire"]
    apk_captions = [t for t in rows_db if t["template_type"] == "trial_apk_caption"]

    kb = []
    for t in starts:
        kb.append([InlineKeyboardButton(f"🚀 {t['name']}", callback_data=f"ttw_v_{t['id']}")])
    for t in expires:
        kb.append([InlineKeyboardButton(f"⏰ {t['name']}", callback_data=f"ttw_v_{t['id']}")])
    for t in apk_captions:
        kb.append([InlineKeyboardButton(f"📦 {t['name']}", callback_data=f"ttw_v_{t['id']}")])

    if rows_db:
        parts = []
        if starts:
            parts.append(f"🚀 {len(starts)} Trial Start")
        if expires:
            parts.append(f"⏰ {len(expires)} Trial Expire")
        if apk_captions:
            parts.append(f"📦 {len(apk_captions)} APK Caption")
        text = (
            "📋 <b>Trial Templates</b>\n\n"
            + "  ·  ".join(parts)
            + "\n\nTap a template to open its editor."
        )
    else:
        text = (
            "📋 <b>Trial Templates</b>\n\n"
            "No active trial templates found.\n"
            "Create templates from the admin panel or use /trialtemplates again after seeding defaults."
        )

    kb.append([
        InlineKeyboardButton("🔄 Refresh", callback_data="ttw_list"),
        InlineKeyboardButton("❌ Close", callback_data="ttw_close"),
    ])
    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
            )
            return edit_msg_id
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return edit_msg_id

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    return msg.message_id


async def _show_template_view(bot, chat_id: int, admin_id: int, template_id: int, session: dict):
    tpl = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", template_id)
    if not tpl:
        await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
        return
    tpl = dict(tpl)
    session["template_data"] = tpl
    session["template_id"] = template_id

    await _cleanup_msgs(bot, chat_id, session)

    tpl_type = tpl.get("template_type", "trial_start")
    preview_text = _render_sample(tpl.get("body_text") or "")
    if not preview_text.strip():
        preview_text = "<i>(Empty template body)</i>"

    try:
        pm = await bot.send_message(
            chat_id=chat_id, text=preview_text,
            parse_mode="HTML", disable_web_page_preview=True,
        )
        session["preview_msg_id"] = pm.message_id
    except Exception as e:
        pm = await bot.send_message(
            chat_id=chat_id,
            text=f"⚠️ <b>Preview render error</b>\n<code>{escape(str(e)[:200])}</code>",
            parse_mode="HTML",
        )
        session["preview_msg_id"] = pm.message_id

    version_count = await db.fetch_val(
        "SELECT COUNT(*) FROM template_versions WHERE template_id = $1", template_id
    ) or 0

    btns_list: list = []
    raw_btns = tpl.get("inline_buttons_json")
    if raw_btns:
        try:
            btns_list = json.loads(raw_btns) or []
        except Exception:
            pass
    btn_info = (
        f"{len(btns_list)} button{'s' if len(btns_list) != 1 else ''}"
        if btns_list else "No buttons"
    )
    var_count = _count_variables(tpl.get("body_text") or "", tpl_type)

    updated_by = tpl.get("updated_by") or "web"
    edited_via = tpl.get("edited_via") or "web"
    via_icon = "🤖" if edited_via == "bot" else "🌐"

    cat_info = ""
    if tpl_type == "trial_apk_caption" and tpl.get("category_id"):
        cat_row = await db.fetch_one("SELECT name FROM categories WHERE id = $1", tpl["category_id"])
        if cat_row:
            cat_name = re.sub(r'\s*\{\d{5,32}\}\s*', '', cat_row["name"] or '').strip()
            cat_info = f"Category: <b>{escape(cat_name)}</b>\n"

    vars_help = _get_vars_help(tpl_type)

    info_text = (
        f"{_tpl_type_icon(tpl_type)} <b>{escape(tpl['name'])}</b>   <i>{_tpl_type_label(tpl_type)}</i>\n"
        f"{cat_info}"
        f"Buttons: <b>{btn_info}</b>   Variables: <b>{var_count}</b>\n"
        f"Updated: <b>{_fmt_dt(tpl.get('updated_at'))}</b>\n"
        f"By: <code>{escape(str(updated_by))}</code>   Via: {via_icon} <b>{edited_via}</b>   Versions: <b>{version_count}</b>\n\n"
        f"{vars_help}"
    )

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✏️ Edit Message", callback_data=f"ttw_em_{template_id}"),
            InlineKeyboardButton("🔘 Edit Buttons", callback_data=f"ttw_eb_{template_id}"),
        ],
        [
            InlineKeyboardButton("👁️ Preview Sample", callback_data=f"ttw_ps_{template_id}"),
            InlineKeyboardButton("📨 Test Send", callback_data=f"ttw_ts_{template_id}"),
        ],
        [
            InlineKeyboardButton("📜 History", callback_data=f"ttw_his_{template_id}"),
            InlineKeyboardButton("◀️ Back", callback_data="ttw_list"),
        ],
    ])

    im = await bot.send_message(
        chat_id=chat_id, text=info_text,
        parse_mode="HTML", reply_markup=markup,
        disable_web_page_preview=True,
    )
    session["info_msg_id"] = im.message_id
    session["step"] = "view"
    _bump_session(admin_id)


async def _start_edit_message(bot, chat_id: int, admin_id: int, template_id: int, session: dict):
    if session.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        session["prompt_msg_id"] = None

    tpl = session.get("template_data") or {}
    tpl_type = tpl.get("template_type", "trial_start")
    vars_help = _get_vars_help(tpl_type)

    prompt = await bot.send_message(
        chat_id=chat_id,
        text=(
            "✏️ <b>Edit Trial Template Message</b>\n\n"
            "Reply with the new template body using normal Telegram formatting.\n\n"
            "<b>Fully preserved:</b>\n"
            "  • Bold, italic, underline, strikethrough, spoiler\n"
            "  • Code, pre blocks, text links\n"
            "  • Custom emoji (animated sticker emoji)\n"
            "  • Line breaks and spacing\n\n"
            f"{vars_help}\n\n"
            "⏱ Session expires in 10 minutes.\n"
            "Tip: send /ttw_cancel to abort."
        ),
        parse_mode="HTML",
        reply_markup=ForceReply(selective=True, input_field_placeholder="Type new message body here…"),
    )
    session["prompt_msg_id"] = prompt.message_id
    session["step"] = "edit_msg_await"
    session["template_id"] = template_id
    _bump_session(admin_id)


async def _show_button_list(bot, chat_id: int, admin_id: int, template_id: int, session: dict,
                            edit_msg_id: int | None = None) -> int:
    tpl = await db.fetch_one("SELECT id, name, inline_buttons_json FROM campaign_templates WHERE id = $1", template_id)
    if not tpl:
        await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
        return 0
    tpl = dict(tpl)
    session["template_id"] = template_id

    btns = session.get("temp_buttons")
    if btns is None:
        raw = tpl.get("inline_buttons_json") or ""
        try:
            btns = json.loads(raw) if raw else []
        except Exception:
            btns = []
        session["temp_buttons"] = [dict(b) for b in btns]
    btns = session["temp_buttons"]

    if btns:
        lines = "\n".join(_btn_summary(b, i) for i, b in enumerate(btns))
        text = (
            f"🔘 <b>Buttons — {escape(tpl['name'])}</b>\n\n"
            f"<code>{escape(lines)}</code>\n\n"
            "<i>Changes held in session. Tap Save to persist.</i>"
        )
    else:
        text = (
            f"🔘 <b>Buttons — {escape(tpl['name'])}</b>\n\n"
            "No buttons yet. Tap <b>➕ Add Button</b> to create one."
        )

    kb = []
    for i, b in enumerate(btns):
        label = (b.get("text") or "Btn")[:18]
        kb.append([
            InlineKeyboardButton(f"✏️ {i+1}. {label}", callback_data=f"ttw_be_{template_id}_{i}"),
            InlineKeyboardButton("🗑 Del", callback_data=f"ttw_bd_{template_id}_{i}"),
        ])

    kb.append([InlineKeyboardButton("➕ Add Button", callback_data=f"ttw_ba_{template_id}")])
    if btns:
        kb.append([InlineKeyboardButton("💾 Save Buttons", callback_data=f"ttw_bsave_{template_id}")])
    kb.append([
        InlineKeyboardButton("👁️ Preview", callback_data=f"ttw_ps_{template_id}"),
        InlineKeyboardButton("◀️ Back", callback_data=f"ttw_v_{template_id}"),
    ])
    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
            )
            return edit_msg_id
    except Exception as e:
        if "not modified" in str(e).lower():
            return edit_msg_id or 0
    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    return msg.message_id


async def _start_add_button(bot, chat_id: int, admin_id: int, template_id: int, session: dict):
    session["current_button_draft"] = {"text": "", "url": "", "row": 1, "enabled": True, "style": "", "emoji_mode": "none"}
    session["button_edit_idx"] = None
    session["step"] = STEP_BTN_NAME

    if session.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
    prompt = await bot.send_message(
        chat_id=chat_id,
        text="🔘 <b>Step 1/6 — Button Text</b>\n\nReply with the button text (label).",
        parse_mode="HTML",
        reply_markup=ForceReply(selective=True, input_field_placeholder="Button text…"),
    )
    session["prompt_msg_id"] = prompt.message_id
    _bump_session(admin_id)


async def _start_edit_button(bot, chat_id: int, admin_id: int, template_id: int, btn_idx: int, session: dict):
    btns = session.get("temp_buttons") or []
    if btn_idx >= len(btns):
        await bot.send_message(chat_id=chat_id, text="❌ Button not found.")
        return
    session["current_button_draft"] = dict(btns[btn_idx])
    session["button_edit_idx"] = btn_idx
    session["step"] = STEP_BTN_NAME

    if session.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
    old_text = btns[btn_idx].get("text") or ""
    prompt = await bot.send_message(
        chat_id=chat_id,
        text=f"✏️ <b>Step 1/6 — Edit Button #{btn_idx+1}</b>\n\nCurrent: <code>{escape(old_text)}</code>\n\nReply with new button text, or /ttw_skip to keep.",
        parse_mode="HTML",
        reply_markup=ForceReply(selective=True, input_field_placeholder="New button text…"),
    )
    session["prompt_msg_id"] = prompt.message_id
    _bump_session(admin_id)


async def _ask_button_color(bot, chat_id: int, session: dict):
    session["step"] = STEP_BTN_COLOR
    p = await bot.send_message(
        chat_id=chat_id,
        text="<b>Step 3/6 — Button Color</b>\n\nChoose an accent color for this button:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("None", callback_data="ttw_bc_none"),
                InlineKeyboardButton("Default", callback_data="ttw_bc_default"),
                InlineKeyboardButton("Primary", callback_data="ttw_bc_primary"),
            ],
            [
                InlineKeyboardButton("✅ Success", callback_data="ttw_bc_success"),
                InlineKeyboardButton("⚠️ Warning", callback_data="ttw_bc_warning"),
                InlineKeyboardButton("🚨 Danger", callback_data="ttw_bc_danger"),
            ],
            [InlineKeyboardButton("❌ Cancel", callback_data="ttw_list")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


async def _ask_button_emoji_mode(bot, chat_id: int, session: dict):
    session["step"] = STEP_BTN_EMOJI_MODE
    p = await bot.send_message(
        chat_id=chat_id,
        text="<b>Step 4/6 — Emoji Mode</b>\n\nChoose how to display an emoji on this button:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("No Emoji", callback_data="ttw_bem_none"),
                InlineKeyboardButton("Plain Emoji", callback_data="ttw_bem_plain"),
                InlineKeyboardButton("Custom Emoji", callback_data="ttw_bem_custom"),
            ],
            [InlineKeyboardButton("❌ Cancel", callback_data="ttw_list")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


async def _ask_button_row(bot, chat_id: int, session: dict):
    session["step"] = STEP_BTN_ROW
    p = await bot.send_message(
        chat_id=chat_id,
        text="<b>Step 6/6 — Button Row</b>\n\nButtons in the same row appear side by side. Choose row:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("Row 1", callback_data="ttw_brow_1"),
                InlineKeyboardButton("Row 2", callback_data="ttw_brow_2"),
                InlineKeyboardButton("Row 3", callback_data="ttw_brow_3"),
            ],
            [
                InlineKeyboardButton("Row 4", callback_data="ttw_brow_4"),
                InlineKeyboardButton("Row 5", callback_data="ttw_brow_5"),
            ],
            [InlineKeyboardButton("❌ Cancel", callback_data="ttw_list")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


async def _show_button_confirm(bot, chat_id: int, session: dict, template_id: int):
    session["step"] = STEP_BTN_CONFIRM
    b = session["current_button_draft"]

    mode = b.get("emoji_mode", "none")
    if mode == "plain":
        emoji_info = f"Plain: {b.get('emoji', '') or '—'}"
    elif mode == "custom":
        cid = b.get("icon_custom_emoji_id", "") or "—"
        fb = b.get("fallback_emoji", "") or "none"
        emoji_info = f"Custom ID: {cid[:20]}  Fallback: {fb}"
    else:
        emoji_info = "None"

    base = b.get("text", "Button")
    display = f"{b['emoji']} {base}".strip() if mode == "plain" and b.get("emoji") else base

    url = b.get("url", "")
    url_display = url[:60]

    text = (
        "📋 <b>Button Preview</b>\n\n"
        f"<b>Label:</b>   {escape(base)}\n"
        f"<b>URL:</b>    <code>{escape(url_display)}</code>\n"
        f"<b>Color:</b>  {b.get('style', 'none') or 'none'}\n"
        f"<b>Emoji:</b>  {escape(emoji_info)}\n"
        f"<b>Row:</b>    {b.get('row', 1)}\n\n"
        f"<b>Telegram preview:</b>  [ {escape(display)} ]"
    )

    if session.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, session["prompt_msg_id"])

    p = await bot.send_message(
        chat_id=chat_id, text=text, parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Save Button", callback_data=f"ttw_bconfirm_{template_id}"),
                InlineKeyboardButton("🔄 Start Over", callback_data=f"ttw_ba_{template_id}"),
            ],
            [InlineKeyboardButton("◀️ Back to Buttons", callback_data=f"ttw_eb_{template_id}")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


def _build_test_markup(buttons_json: str | None) -> InlineKeyboardMarkup | None:
    if not buttons_json:
        return None
    try:
        raw = json.loads(buttons_json) or []
    except Exception:
        return None
    rows_map: dict = {}
    for b in raw:
        if not b.get("enabled", True):
            continue
        rn = int(b.get("row") or 1)
        rows_map.setdefault(rn, []).append(b)
    tg_rows = []
    for rn in sorted(rows_map.keys()):
        row = []
        for b in rows_map[rn]:
            base = (b.get("text") or "Button").strip()
            mode = b.get("emoji_mode", "none")
            btn_text = f"{b['emoji']} {base}".strip() if mode == "plain" and b.get("emoji") else base
            url = (b.get("url") or "https://t.me").strip()
            if not url.startswith(("http://", "https://", "tg://")):
                url = "https://t.me"
            row.append(InlineKeyboardButton(text=btn_text, url=url))
        if row:
            tg_rows.append(row)
    return InlineKeyboardMarkup(tg_rows) if tg_rows else None


async def _test_send(bot, chat_id: int, template_id: int, session: dict):
    tpl = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", template_id)
    if not tpl:
        await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
        return
    tpl = dict(tpl)
    rendered = _render_sample(tpl.get("body_text") or "")
    if not rendered.strip():
        rendered = "<i>(Empty template body)</i>"
    markup = _build_test_markup(tpl.get("inline_buttons_json"))
    try:
        msg = await bot.send_message(
            chat_id=chat_id, text=rendered,
            parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True,
        )
        session["extra_msg_ids"].append(msg.message_id)
        conf = await bot.send_message(
            chat_id=chat_id,
            text="✅ <b>Test sent!</b> This is how it looks to users.",
            parse_mode="HTML",
        )
        session["extra_msg_ids"].append(conf.message_id)
    except Exception as e:
        err = await bot.send_message(
            chat_id=chat_id,
            text=f"❌ Send failed:\n<code>{escape(str(e)[:300])}</code>",
            parse_mode="HTML",
        )
        session["extra_msg_ids"].append(err.message_id)


async def _handle_button_step_reply(bot, chat_id: int, admin_id: int, text: str, session: dict):
    step = session.get("step")
    draft = session.get("current_button_draft", {})
    template_id = session.get("template_id")

    if step == STEP_BTN_NAME:
        if text != "/ttw_skip":
            draft["text"] = text[:64]
        session["step"] = STEP_BTN_URL
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        old_url = draft.get("url") or ""
        hint = f"\nCurrent: <code>{escape(old_url)}</code>" if old_url else ""
        prompt = await bot.send_message(
            chat_id=chat_id,
            text=f"🔗 <b>Step 2/6 — Button URL</b>{hint}\n\nReply with the button URL (https:// or tg://)\nor /ttw_skip to keep current.",
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="https://..."),
        )
        session["prompt_msg_id"] = prompt.message_id
        _bump_session(admin_id)
        return

    if step == STEP_BTN_URL:
        if text != "/ttw_skip":
            url = text.strip()
            if url and not url.startswith(("http://", "https://", "tg://")):
                prompt = await bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ URL must start with <code>http://</code>, <code>https://</code>, or <code>tg://</code>.\nTry again:",
                    parse_mode="HTML",
                    reply_markup=ForceReply(selective=True, input_field_placeholder="https://..."),
                )
                session["prompt_msg_id"] = prompt.message_id
                return
            draft["url"] = url
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None
        await _ask_button_color(bot, chat_id, session)
        _bump_session(admin_id)
        return

    if step == STEP_BTN_EMOJI_CHAR:
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        draft["emoji"] = text
        draft["emoji_mode"] = "plain"
        await _ask_button_row(bot, chat_id, session)
        _bump_session(admin_id)
        return

    if step == STEP_BTN_EMOJI_CUSTOM_ID:
        draft["icon_custom_emoji_id"] = text
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        session["step"] = STEP_BTN_EMOJI_FALLBACK
        p = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>Step 5b/6 — Fallback Emoji</b>\n\n"
                "Send a plain emoji as fallback for clients that don't support custom emoji.\n"
                "Example: <code>🛒</code>   Or type <code>none</code> to skip."
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="🛒 or none"),
        )
        session["prompt_msg_id"] = p.message_id
        _bump_session(admin_id)
        return

    if step == STEP_BTN_EMOJI_FALLBACK:
        val = "" if text.lower() == "none" else text
        draft["fallback_emoji"] = val
        draft["emoji_mode"] = "custom"
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await _ask_button_row(bot, chat_id, session)
        _bump_session(admin_id)
        return


async def _show_history(bot, chat_id: int, admin_id: int, template_id: int, session: dict):
    versions = await db.fetch_all(
        "SELECT id, body_text, changed_by, changed_via, change_note, created_at "
        "FROM template_versions WHERE template_id = $1 ORDER BY created_at DESC LIMIT 10",
        template_id,
    )
    if not versions:
        await bot.send_message(chat_id=chat_id, text="📜 No version history for this template.", parse_mode="HTML")
        return

    kb = []
    lines = []
    for v in versions:
        v = dict(v)
        via_icon = "🤖" if v.get("changed_via") == "bot" else "🌐"
        snippet = (v.get("body_text") or "")[:40].replace("\n", " ")
        lines.append(f"<b>v{v['id']}</b>  {via_icon}  {_fmt_dt(v.get('created_at'))}\n<code>{escape(snippet)}…</code>")
        kb.append([InlineKeyboardButton(f"↩️ Restore v{v['id']}", callback_data=f"ttw_hrest_{template_id}_{v['id']}")])

    kb.append([InlineKeyboardButton("◀️ Back", callback_data=f"ttw_v_{template_id}")])
    text = "📜 <b>Version History</b>\n\n" + "\n\n".join(lines)

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(kb))
    session["extra_msg_ids"].append(msg.message_id)
    _bump_session(admin_id)


async def _restore_version(bot, chat_id: int, admin_id: int, template_id: int, version_id: int, session: dict):
    ver = await db.fetch_one(
        "SELECT body_text, inline_buttons_json, body_entities_json FROM template_versions WHERE id = $1 AND template_id = $2",
        version_id, template_id,
    )
    if not ver:
        await bot.send_message(chat_id=chat_id, text="❌ Version not found.")
        return

    await _save_version(template_id, str(admin_id), "bot", f"restored version {version_id}")
    await db.execute(
        """UPDATE campaign_templates
           SET body_text = $1, inline_buttons_json = $2, body_entities_json = $3,
               updated_at = NOW(), updated_by = $4, edited_via = 'bot'
           WHERE id = $5""",
        ver["body_text"] or "", ver.get("inline_buttons_json") or None,
        ver.get("body_entities_json") or None, str(admin_id), template_id,
    )
    await bot.send_message(chat_id=chat_id, text=f"✅ Restored version {version_id}.", parse_mode="HTML")
    session["temp_buttons"] = None
    await _show_template_view(bot, chat_id, admin_id, template_id, session)


async def _preview_with_buttons(bot, chat_id: int, template_id: int, session: dict):
    tpl = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", template_id)
    if not tpl:
        return
    tpl = dict(tpl)
    preview_text = _render_sample(tpl.get("body_text") or "")
    if not preview_text.strip():
        preview_text = "<i>(Empty)</i>"

    btns_raw = tpl.get("inline_buttons_json")
    kb = []
    if btns_raw:
        try:
            btns = json.loads(btns_raw) or []
            row_map: dict[int, list] = {}
            for b in btns:
                if b.get("enabled") is False:
                    continue
                r = b.get("row", 1)
                row_map.setdefault(r, [])
                row_map[r].append(InlineKeyboardButton(text=b.get("text", "Button"), url=b.get("url", "https://example.com")))
            for rn in sorted(row_map.keys()):
                kb.append(row_map[rn])
        except Exception:
            pass

    try:
        msg = await bot.send_message(
            chat_id=chat_id, text=preview_text,
            parse_mode="HTML", reply_markup=InlineKeyboardMarkup(kb) if kb else None,
            disable_web_page_preview=True,
        )
        session["extra_msg_ids"].append(msg.message_id)
    except Exception as e:
        msg = await bot.send_message(
            chat_id=chat_id,
            text=f"⚠️ Preview error:\n<code>{escape(str(e)[:200])}</code>",
            parse_mode="HTML",
        )
        session["extra_msg_ids"].append(msg.message_id)


async def handle_trial_templates_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    if not msg or not msg.from_user:
        return
    admin_id = msg.from_user.id
    if not _is_admin(admin_id):
        await msg.reply_text("⛔ Admin only.")
        return

    session = _new_session(admin_id)
    list_msg_id = await _show_template_list(context.bot, msg.chat_id, admin_id)
    session["list_msg_id"] = list_msg_id


async def handle_trial_template_wizard_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    msg = update.effective_message
    if not msg or not msg.from_user:
        return False
    admin_id = msg.from_user.id
    session = _get_session(admin_id)
    if not session:
        return False

    text = (msg.text or "").strip()
    bot = context.bot
    chat_id = msg.chat_id

    if text in ("/ttw_cancel", "/trialtemplates"):
        if text == "/ttw_cancel":
            await _cleanup_msgs(bot, chat_id, session)
            _clear_session(admin_id)
            await bot.send_message(chat_id=chat_id, text="❌ Trial template wizard cancelled.")
            return True
        return False

    step = session.get("step")

    if step == "edit_msg_await":
        template_id = session.get("template_id")
        if not template_id:
            return False

        tpl = session.get("template_data") or {}
        tpl_type = tpl.get("template_type", "trial_start")
        new_body = _capture_html(msg)
        entities_json = _entities_to_json(msg.entities)

        invalid = _validate_variables(new_body, tpl_type)
        if invalid:
            warn = await bot.send_message(
                chat_id=chat_id,
                text=f"⚠️ Unknown variables: <code>{escape(', '.join(invalid))}</code>\n\nSaved anyway — they will not resolve.",
                parse_mode="HTML",
            )
            session["extra_msg_ids"].append(warn.message_id)

        await _save_template_body(template_id, new_body, str(admin_id), entities_json)

        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None

        ok = await bot.send_message(chat_id=chat_id, text="✅ Message body saved.", parse_mode="HTML")
        session["extra_msg_ids"].append(ok.message_id)

        session["temp_buttons"] = None
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        return True

    if step in (STEP_BTN_NAME, STEP_BTN_URL, STEP_BTN_EMOJI_CHAR, STEP_BTN_EMOJI_CUSTOM_ID, STEP_BTN_EMOJI_FALLBACK):
        await _handle_button_step_reply(bot, chat_id, admin_id, text, session)
        return True

    return False


async def handle_trial_template_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query or not query.from_user:
        return
    admin_id = query.from_user.id
    if not _is_admin(admin_id):
        await query.answer("⛔ Admin only.", show_alert=True)
        return

    data = query.data or ""
    bot = context.bot
    chat_id = query.message.chat_id

    await query.answer()

    session = _get_session(admin_id)
    if not session:
        session = _new_session(admin_id)

    if data == "ttw_list":
        await _cleanup_msgs(bot, chat_id, session)
        session["temp_buttons"] = None
        list_msg_id = await _show_template_list(bot, chat_id, admin_id, query.message.message_id)
        session["list_msg_id"] = list_msg_id
        session["step"] = "list"
        return

    if data == "ttw_close":
        await _cleanup_msgs(bot, chat_id, session)
        _clear_session(admin_id)
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=query.message.message_id,
                text="📋 Trial template wizard closed.",
            )
        except Exception:
            pass
        return

    m = re.match(r"ttw_v_(\d+)$", data)
    if m:
        template_id = int(m.group(1))
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        return

    m = re.match(r"ttw_em_(\d+)$", data)
    if m:
        template_id = int(m.group(1))
        await _start_edit_message(bot, chat_id, admin_id, template_id, session)
        return

    m = re.match(r"ttw_eb_(\d+)$", data)
    if m:
        template_id = int(m.group(1))
        session["temp_buttons"] = None
        msg_id = await _show_button_list(bot, chat_id, admin_id, int(m.group(1)), session)
        session["info_msg_id"] = msg_id
        session["step"] = "btn_list"
        return

    m = re.match(r"ttw_ba_(\d+)$", data)
    if m:
        await _start_add_button(bot, chat_id, admin_id, int(m.group(1)), session)
        return

    m = re.match(r"ttw_be_(\d+)_(\d+)$", data)
    if m:
        await _start_edit_button(bot, chat_id, admin_id, int(m.group(1)), int(m.group(2)), session)
        return

    m = re.match(r"ttw_bd_(\d+)_(\d+)$", data)
    if m:
        template_id = int(m.group(1))
        btn_idx = int(m.group(2))
        btns = session.get("temp_buttons") or []
        if btn_idx < len(btns):
            btns.pop(btn_idx)
            session["temp_buttons"] = btns
        await _show_button_list(bot, chat_id, admin_id, template_id, session, query.message.message_id)
        return

    m = re.match(r"ttw_bsave_(\d+)$", data)
    if m:
        template_id = int(m.group(1))
        btns = session.get("temp_buttons") or []
        await _save_template_buttons(template_id, btns, str(admin_id))
        await bot.send_message(chat_id=chat_id, text="✅ Buttons saved.", parse_mode="HTML")
        session["temp_buttons"] = None
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        return

    m = re.match(r"ttw_ps_(\d+)$", data)
    if m:
        await _preview_with_buttons(bot, chat_id, int(m.group(1)), session)
        return

    m = re.match(r"ttw_ts_(\d+)$", data)
    if m:
        await _test_send(bot, chat_id, int(m.group(1)), session)
        return

    if data.startswith("ttw_bc_"):
        color = data[7:]
        if color not in BUTTON_COLORS:
            return
        session["current_button_draft"]["style"] = "" if color == "none" else color
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await _ask_button_emoji_mode(bot, chat_id, session)
        return

    if data.startswith("ttw_bem_"):
        mode = data[8:]
        if mode not in ("none", "plain", "custom"):
            return
        session["current_button_draft"]["emoji_mode"] = mode
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        if mode == "none":
            session["current_button_draft"].update({"emoji": "", "icon_custom_emoji_id": "", "fallback_emoji": ""})
            await _ask_button_row(bot, chat_id, session)
        elif mode == "plain":
            session["step"] = STEP_BTN_EMOJI_CHAR
            p = await bot.send_message(
                chat_id=chat_id,
                text="<b>Step 5/6 — Emoji Character</b>\n\nSend the emoji to show on the button:\nExample: <code>🛒</code>",
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="🛒"),
            )
            session["prompt_msg_id"] = p.message_id
        elif mode == "custom":
            session["step"] = STEP_BTN_EMOJI_CUSTOM_ID
            p = await bot.send_message(
                chat_id=chat_id,
                text=(
                    "<b>Step 5a/6 — Custom Emoji ID</b>\n\n"
                    "Send the Telegram custom emoji ID:\n"
                    "Example: <code>5368324170671202286</code>"
                ),
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="Custom emoji ID…"),
            )
            session["prompt_msg_id"] = p.message_id
        return

    if data.startswith("ttw_brow_"):
        try:
            row = int(data[9:])
        except ValueError:
            return
        session["current_button_draft"]["row"] = row
        session["current_button_draft"].setdefault("enabled", True)
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        template_id_val = session.get("template_id")
        await _show_button_confirm(bot, chat_id, session, template_id_val)
        return

    if data.startswith("ttw_bconfirm_"):
        try:
            template_id_val = int(data[13:])
        except ValueError:
            return
        draft = dict(session.get("current_button_draft", {}))
        edit_idx = session.get("button_edit_idx")
        btns = list(session.get("temp_buttons") or [])
        if edit_idx is not None and 0 <= edit_idx < len(btns):
            btns[edit_idx] = draft
        else:
            btns.append(draft)
        session["temp_buttons"] = btns
        session["current_button_draft"] = {}
        session["button_edit_idx"] = None
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None
        await _show_button_list(bot, chat_id, admin_id, template_id_val, session)
        return

    m = re.match(r"ttw_his_(\d+)$", data)
    if m:
        await _show_history(bot, chat_id, admin_id, int(m.group(1)), session)
        return

    m = re.match(r"ttw_hrest_(\d+)_(\d+)$", data)
    if m:
        await _restore_version(bot, chat_id, admin_id, int(m.group(1)), int(m.group(2)), session)
        return
