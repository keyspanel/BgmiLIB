"""
Private admin-only bot settings editor via Telegram chat.
Callback prefix: bs_

Flow:
  /botsettings → section menu → setting list → view/edit → ForceReply → save → confirm
  Supports: view current, preview with sample values, reset to default, cancel
"""
import time
import logging
import re
from html import escape

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ForceReply, Update
from telegram.ext import ContextTypes

from bot import database as db
from bot.config import ADMIN_CHAT_ID
from bot.cleanup import safe_delete_message
from bot import settings as bot_settings

logger = logging.getLogger(__name__)

SESSION_TTL = 600

SETTINGS_SESSIONS: dict[int, dict] = {}


def _is_admin(telegram_id: int) -> bool:
    return ADMIN_CHAT_ID > 0 and telegram_id == ADMIN_CHAT_ID


SECTIONS = [
    ("welcome", "✨ Welcome & Start"),
    ("store", "🏪 Store & Categories"),
    ("buttons", "🔘 Button Labels"),
    ("payment", "💳 Payment Messages"),
    ("delivery", "📦 Key Delivery"),
    ("errors", "⚠️ Status / Error Messages"),
    ("forcejoin", "🔒 Force Join"),
    ("reseller", "🔑 Reseller Messages"),
    ("broadcast", "📢 Broadcast & Campaigns"),
    ("styles", "🎨 Button Styles & Emoji"),
    ("misc", "⚙️ Miscellaneous"),
    ("catdur", "📂 Category Duration Messages"),
]

CAT_DUR_FIELDS = [
    {"key": "tpl_duration_caption", "label": "Duration Caption Template",
     "desc": "Full layout of the duration selection screen for this category",
     "placeholders": ["{duration_title}", "{category}", "{duration_sub}"], "multiline": True, "html": True},
    {"key": "msg_select_duration_title", "label": "Duration Title",
     "desc": "Title line shown on the duration screen for this category",
     "placeholders": ["{brand}"], "multiline": False, "html": True},
    {"key": "msg_select_duration_sub", "label": "Duration Subtitle",
     "desc": "Subtitle/instruction text on the duration screen for this category",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "duration_link_buttons", "label": "Duration Link Buttons (JSON)",
     "desc": "URL buttons below duration list. JSON array: [{\"text\":\"...\",\"url\":\"https://...\"}]",
     "placeholders": [], "multiline": True, "html": False},
]
CAT_DUR_FIELD_BY_KEY = {f["key"]: f for f in CAT_DUR_FIELDS}

SETTINGS_REGISTRY: list[dict] = [
    {"key": "welcome_greeting", "label": "Welcome Greeting", "section": "welcome",
     "desc": "Greeting line shown at the top of the welcome message",
     "placeholders": ["{name_link}", "{first_name}", "{brand}"], "multiline": False, "html": True},
    {"key": "bot_welcome_msg", "label": "Welcome Title", "section": "welcome",
     "desc": "Main welcome message shown after /start",
     "placeholders": ["{brand}"], "multiline": False, "html": True},
    {"key": "bot_welcome_instruction", "label": "Welcome Instruction", "section": "welcome",
     "desc": "Instruction text below the welcome title",
     "placeholders": ["{brand}"], "multiline": True, "html": True},
    {"key": "tpl_welcome", "label": "Welcome Template", "section": "welcome",
     "desc": "Full welcome message template",
     "placeholders": ["{welcome_greeting}", "{name_link}", "{welcome_title}", "{welcome_body}"], "multiline": True, "html": True},
    {"key": "start_preview_url", "label": "Start Preview URL", "section": "welcome",
     "desc": "URL for link preview image on /start (leave empty to disable)",
     "placeholders": [], "multiline": False, "html": False},

    {"key": "bot_store_title", "label": "Store Title", "section": "store",
     "desc": "Title of the categories menu",
     "placeholders": ["{brand}"], "multiline": False, "html": True},
    {"key": "bot_store_subtitle", "label": "Store Subtitle", "section": "store",
     "desc": "Subtitle below the store title",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "bot_store_empty", "label": "Store Empty Text", "section": "store",
     "desc": "Shown when no categories are active",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "tpl_store_header", "label": "Store Header Template", "section": "store",
     "desc": "Full store header template",
     "placeholders": ["{store_title}", "{store_subtitle}", "{categories_footer}"], "multiline": True, "html": True},
    {"key": "msg_categories_footer", "label": "Categories Footer", "section": "store",
     "desc": "Footer text below category buttons",
     "placeholders": [], "multiline": False, "html": True},

    {"key": "bot_btn_my_keys", "label": "My Keys Button", "section": "buttons",
     "desc": "Reply keyboard button label for My Keys",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "bot_btn_how_to", "label": "How To Button", "section": "buttons",
     "desc": "Reply keyboard button label for How To",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "bot_btn_categories", "label": "Categories Button", "section": "buttons",
     "desc": "Inline button label for Categories Menu",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "bot_btn_verify", "label": "Verify Payment Button", "section": "buttons",
     "desc": "Inline button label for Verify Payment",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "bot_btn_copy_key", "label": "Copy Key Button", "section": "buttons",
     "desc": "Inline button label for Copy Key",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "bot_btn_manage_keys", "label": "Manage Keys Button", "section": "buttons",
     "desc": "Inline button label for Manage Keys",
     "placeholders": [], "multiline": False, "html": False},

    {"key": "tpl_payment_caption", "label": "Payment Invoice Template", "section": "payment",
     "desc": "Payment QR message template",
     "placeholders": ["{category}", "{duration}", "{currency}", "{amount}", "{order_id}",
                      "{txn_ref}", "{created_time}", "{expiry_time}", "{upi_id}", "{verify_btn}"],
     "multiline": True, "html": True},
    {"key": "tpl_reseller_caption", "label": "Reseller Invoice Template", "section": "payment",
     "desc": "Payment QR template for reseller orders",
     "placeholders": ["{category}", "{duration}", "{currency}", "{base_amount}", "{amount}",
                      "{order_id}", "{txn_ref}", "{created_time}", "{expiry_time}", "{upi_id}", "{verify_btn}"],
     "multiline": True, "html": True},
    {"key": "bot_payment_success", "label": "Payment Success Text", "section": "payment",
     "desc": "Short success text shown after payment verification",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_verify_not_received", "label": "Payment Not Received", "section": "payment",
     "desc": "Message when payment verification shows no payment",
     "placeholders": ["{first_name}"], "multiline": True, "html": True},
    {"key": "msg_payment_not_found", "label": "Payment Not Found", "section": "payment",
     "desc": "Message when no payment record exists for order",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "msg_payment_pending", "label": "Payment Pending", "section": "payment",
     "desc": "Message when payment is still being processed",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "msg_payment_failed", "label": "Payment Failed", "section": "payment",
     "desc": "Message when payment was not successful",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "msg_amount_mismatch", "label": "Amount Mismatch", "section": "payment",
     "desc": "Message when payment amount doesn't match order",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "msg_upi_not_configured", "label": "UPI Not Configured", "section": "payment",
     "desc": "Message when UPI ID is not set up",
     "placeholders": [], "multiline": False, "html": True},

    {"key": "tpl_success_body", "label": "Success Body Template", "section": "delivery",
     "desc": "Full delivery/success message template",
     "placeholders": ["{verified_title}", "{category}", "{duration}", "{order_id}",
                      "{key_label}", "{key}", "{apk_notice}", "{footer}"],
     "multiline": True, "html": True},
    {"key": "tpl_delivery_body", "label": "Delivery Body Template", "section": "delivery",
     "desc": "Compact delivery message template",
     "placeholders": ["{category}", "{duration}", "{order_id}", "{key_value}"],
     "multiline": True, "html": True},
    {"key": "msg_payment_verified_title", "label": "Verified Title", "section": "delivery",
     "desc": "Title shown on successful payment verification",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_key_label", "label": "Key Label", "section": "delivery",
     "desc": "Label shown before the key value",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "bot_keys_title", "label": "My Keys Title", "section": "delivery",
     "desc": "Title of the purchased keys viewer",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "bot_keys_reseller_title", "label": "Reseller Keys Title", "section": "delivery",
     "desc": "Title for reseller purchased keys",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "bot_keys_empty", "label": "No Keys Text", "section": "delivery",
     "desc": "Message when user has no purchased keys",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "tpl_keys_item", "label": "Keys Item Template", "section": "delivery",
     "desc": "Template for each key in the viewer",
     "placeholders": ["{index}", "{total}", "{order_id}", "{category}", "{duration}",
                      "{currency}", "{amount}", "{purchased_time}", "{buyer}", "{key}", "{reference_section}"],
     "multiline": True, "html": True},
    {"key": "msg_apk_caption", "label": "APK Caption", "section": "delivery",
     "desc": "Caption when sending APK file",
     "placeholders": ["{category}"], "multiline": True, "html": True},
    {"key": "msg_apk_notice", "label": "APK Notice", "section": "delivery",
     "desc": "Notice text about the APK file",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "msg_no_keys_found_title", "label": "No Keys Found Title", "section": "delivery",
     "desc": "Title when user has no purchased keys",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "delivery_link_buttons", "label": "Delivery Link Buttons (JSON)", "section": "delivery",
     "desc": "JSON array of link buttons on delivery message",
     "placeholders": [], "multiline": True, "html": False},

    {"key": "bot_how_to_text", "label": "How To Purchase Text", "section": "delivery",
     "desc": "Full how-to-purchase guide text",
     "placeholders": [], "multiline": True, "html": True},

    {"key": "msg_banned", "label": "Banned User Message", "section": "errors",
     "desc": "Message shown to banned users",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_store_unavailable_title", "label": "Store Unavailable Title", "section": "errors",
     "desc": "Title when store is unavailable",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_no_keys_available", "label": "No Keys Available", "section": "errors",
     "desc": "When no keys available for selected category/duration",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_key_taken", "label": "Key Taken", "section": "errors",
     "desc": "When a key was just taken by another user",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_invalid_cat_dur", "label": "Invalid Category/Duration", "section": "errors",
     "desc": "When category or duration is invalid",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_inactive_verify_btn", "label": "Inactive Verify Button", "section": "errors",
     "desc": "When user taps an old verify button",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_order_not_found", "label": "Order Not Found", "section": "errors",
     "desc": "When order doesn't exist",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_order_not_yours", "label": "Order Not Yours", "section": "errors",
     "desc": "When order belongs to another user",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_already_paid", "label": "Already Paid", "section": "errors",
     "desc": "When payment was already verified",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_order_expired", "label": "Order Expired", "section": "errors",
     "desc": "When order has expired",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_order_inactive", "label": "Order Inactive", "section": "errors",
     "desc": "When order is no longer active",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_verify_error", "label": "Verify Error", "section": "errors",
     "desc": "Generic verification error",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_verify_failed_title", "label": "Verify Failed Title", "section": "errors",
     "desc": "Title for failed verification",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_payment_not_received_title", "label": "Payment Not Received Title", "section": "errors",
     "desc": "Title when payment not received",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_verify_generic_error", "label": "Generic Verify Error", "section": "errors",
     "desc": "Fallback verification error",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_verification_issue", "label": "Verification Issue", "section": "errors",
     "desc": "Payment could not be verified message",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_gateway_error", "label": "Gateway Error", "section": "errors",
     "desc": "Payment gateway temporarily unavailable",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_keys_load_error", "label": "Keys Load Error", "section": "errors",
     "desc": "Unable to load keys error",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_order_expired_notice", "label": "Order Expired Notice", "section": "errors",
     "desc": "Notice sent when an order expires",
     "placeholders": [], "multiline": True, "html": True},

    {"key": "cb_banned", "label": "CB: Banned", "section": "errors",
     "desc": "Callback answer for banned user",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_category_unavailable", "label": "CB: Category Unavailable", "section": "errors",
     "desc": "Callback answer for unavailable category",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_no_durations", "label": "CB: No Durations", "section": "errors",
     "desc": "Callback answer when no durations available",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_category_error", "label": "CB: Category Error", "section": "errors",
     "desc": "Callback answer for category open error",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_generating_qr", "label": "CB: Generating QR", "section": "errors",
     "desc": "Callback answer while generating payment QR",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_unknown_action", "label": "CB: Unknown Action", "section": "errors",
     "desc": "Callback answer for unknown button action",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_order_not_found", "label": "CB: Order Not Found", "section": "errors",
     "desc": "Callback answer when order not found",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_order_not_yours", "label": "CB: Not Yours", "section": "errors",
     "desc": "Callback answer when order doesn't belong to user",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_already_paid", "label": "CB: Already Paid", "section": "errors",
     "desc": "Callback answer when already paid",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_order_expired", "label": "CB: Order Expired", "section": "errors",
     "desc": "Callback answer when order expired",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_order_inactive", "label": "CB: Order Inactive", "section": "errors",
     "desc": "Callback answer when order inactive",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "cb_verify_error", "label": "CB: Verify Error", "section": "errors",
     "desc": "Callback answer for verification error",
     "placeholders": [], "multiline": False, "html": False},

    {"key": "force_join_enabled", "label": "Force Join Enabled", "section": "forcejoin",
     "desc": "Set to 1 to enable, 0 to disable",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_show_verify_btn", "label": "Show Verify Button", "section": "forcejoin",
     "desc": "Set to 1 to show verify button, 0 to hide",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_title", "label": "Force Join Title", "section": "forcejoin",
     "desc": "Title of the force join prompt",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "force_join_body", "label": "Force Join Body", "section": "forcejoin",
     "desc": "Body text of the force join prompt",
     "placeholders": ["{user_mention}", "{category}", "{duration}"], "multiline": True, "html": True},
    {"key": "force_join_btn_verify", "label": "Force Join Verify Button", "section": "forcejoin",
     "desc": "Button label for join verification",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_missing_msg", "label": "Force Join Missing Message", "section": "forcejoin",
     "desc": "Message when user hasn't joined all channels",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "force_join_expired_msg", "label": "Force Join Expired", "section": "forcejoin",
     "desc": "Message when force join order has expired",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "force_join_join_btn_text", "label": "Join Button Text", "section": "forcejoin",
     "desc": "Join channel button label template",
     "placeholders": ["{channel}"], "multiline": False, "html": False},

    {"key": "msg_reseller_prompt", "label": "Reseller Prompt", "section": "reseller",
     "desc": "Prompt asking user to enter reseller code",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "msg_invalid_code_format", "label": "Invalid Code Format", "section": "reseller",
     "desc": "When code format is wrong",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_invalid_code", "label": "Invalid Reseller Code", "section": "reseller",
     "desc": "When reseller code is not valid",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_code_expired", "label": "Code Expired", "section": "reseller",
     "desc": "When reseller code is expired",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_usage_limit", "label": "Usage Limit Reached", "section": "reseller",
     "desc": "When reseller code reached max users",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_already_active_title", "label": "Already Active Title", "section": "reseller",
     "desc": "Title when reseller is already active",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_activation_failed", "label": "Activation Failed", "section": "reseller",
     "desc": "When activation encounters an error",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_activated_title", "label": "Activated Title", "section": "reseller",
     "desc": "Title for successful activation",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_reseller_activated_footer", "label": "Activated Footer", "section": "reseller",
     "desc": "Footer after successful activation",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "tpl_reseller_activated", "label": "Reseller Activated Template", "section": "reseller",
     "desc": "Full template for reseller activation message",
     "placeholders": ["{reseller_title}", "{code}", "{switched_section}",
                      "{expires}", "{max_users}", "{offer_summary}", "{reseller_footer}"],
     "multiline": True, "html": True},
    {"key": "tpl_reseller_already_active", "label": "Already Active Template", "section": "reseller",
     "desc": "Template for already-active reseller message",
     "placeholders": ["{reseller_title}", "{code}", "{expires}", "{offer_summary}"],
     "multiline": True, "html": True},
    {"key": "msg_reference_label", "label": "Reference Label", "section": "reseller",
     "desc": "Label for reference section in keys",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "msg_reseller_switched_label", "label": "Switched Label", "section": "reseller",
     "desc": "Label when previous reseller code was replaced",
     "placeholders": [], "multiline": False, "html": False},

    {"key": "bot_admin_sale_title", "label": "Admin Sale Title", "section": "broadcast",
     "desc": "Title for admin sale notification",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "tpl_admin_sale", "label": "Admin Sale Template", "section": "broadcast",
     "desc": "Full admin sale notification template",
     "placeholders": ["{admin_sale_title}", "{order_id}", "{buyer_label}",
                      "{category}", "{duration}", "{currency}", "{amount}"],
     "multiline": True, "html": True},
    {"key": "tpl_discount_broadcast_title", "label": "Discount Broadcast Title", "section": "broadcast",
     "desc": "Title for discount broadcast messages",
     "placeholders": ["{plan_name}"], "multiline": False, "html": True},
    {"key": "tpl_discount_broadcast_body", "label": "Discount Broadcast Body", "section": "broadcast",
     "desc": "Body template for discount broadcasts",
     "placeholders": ["{first_name}", "{description}", "{pricing_examples}", "{expiry_time}"],
     "multiline": True, "html": True},
    {"key": "tpl_discount_broadcast_footer", "label": "Discount Broadcast Footer", "section": "broadcast",
     "desc": "Footer text for discount broadcasts",
     "placeholders": [], "multiline": True, "html": True},
    {"key": "discount_broadcast_buttons", "label": "Discount Broadcast Buttons (JSON)", "section": "broadcast",
     "desc": "JSON array of buttons for discount broadcasts",
     "placeholders": [], "multiline": True, "html": False},
    {"key": "discount_broadcast_send_categories", "label": "Send Categories After Broadcast", "section": "broadcast",
     "desc": "Set to 1 to send categories after broadcast, 0 to skip",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "broadcast_pin_message", "label": "Pin Broadcast Message", "section": "broadcast",
     "desc": "Set to 1 to pin broadcast messages, 0 to skip",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "msg_broadcast_progress", "label": "Broadcast Progress", "section": "broadcast",
     "desc": "Progress message during broadcast sending",
     "placeholders": ["{sent}", "{total}"], "multiline": False, "html": True},
    {"key": "msg_broadcast_complete", "label": "Broadcast Complete", "section": "broadcast",
     "desc": "Summary after broadcast finishes",
     "placeholders": ["{sent}", "{failed}", "{skipped}", "{total}"], "multiline": True, "html": True},
    {"key": "msg_broadcast_error", "label": "Broadcast Error", "section": "broadcast",
     "desc": "Error message when broadcast fails",
     "placeholders": ["{error}"], "multiline": True, "html": True},
    {"key": "discount_offer_ended_title", "label": "Offer Ended Title", "section": "broadcast",
     "desc": "Title when discount offer has ended",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "discount_offer_ended_body", "label": "Offer Ended Body", "section": "broadcast",
     "desc": "Body when discount offer has ended",
     "placeholders": [], "multiline": True, "html": True},

    {"key": "msg_select_duration_title", "label": "Duration Title", "section": "store",
     "desc": "Title for duration selection menu",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "msg_select_duration_sub", "label": "Duration Subtitle", "section": "store",
     "desc": "Subtitle for duration selection",
     "placeholders": [], "multiline": False, "html": True},
    {"key": "tpl_duration_caption", "label": "Duration Caption Template", "section": "store",
     "desc": "Template for duration menu caption",
     "placeholders": ["{duration_title}", "{category}", "{duration_sub}"], "multiline": True, "html": True},

    {"key": "reply_mykeys_style", "label": "My Keys Button Style", "section": "styles",
     "desc": "Style code for My Keys reply button (1-5 or empty)",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "reply_howto_style", "label": "How To Button Style", "section": "styles",
     "desc": "Style code for How To reply button (1-5 or empty)",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "reply_mykeys_emoji_id", "label": "My Keys Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for My Keys button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "reply_howto_emoji_id", "label": "How To Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for How To button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "categories_btn_style", "label": "Categories Button Style", "section": "styles",
     "desc": "Style for categories inline buttons",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "categories_btn_emoji_id", "label": "Categories Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for categories buttons",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "verify_btn_style", "label": "Verify Button Style", "section": "styles",
     "desc": "Style for verify payment button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "verify_btn_emoji_id", "label": "Verify Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for verify button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "copy_key_btn_style", "label": "Copy Key Button Style", "section": "styles",
     "desc": "Style for copy key button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "copy_key_btn_emoji_id", "label": "Copy Key Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for copy key button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "manage_keys_btn_style", "label": "Manage Keys Button Style", "section": "styles",
     "desc": "Style for manage keys button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "manage_keys_btn_emoji_id", "label": "Manage Keys Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for manage keys button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_join_btn_style", "label": "Join Button Style", "section": "styles",
     "desc": "Style for force join channel button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_join_btn_emoji_id", "label": "Join Button Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for join channel button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_verify_btn_style", "label": "FJ Verify Button Style", "section": "styles",
     "desc": "Style for force join verify button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "force_join_verify_btn_emoji_id", "label": "FJ Verify Emoji ID", "section": "styles",
     "desc": "Custom emoji ID for force join verify button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "help_btn_style", "label": "Help Button Style", "section": "styles",
     "desc": "Style code for help button",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "owner_btn_style", "label": "Owner Button Style", "section": "styles",
     "desc": "Style code for owner button",
     "placeholders": [], "multiline": False, "html": False},

    {"key": "order_timeout_minutes", "label": "Order Timeout (minutes)", "section": "misc",
     "desc": "Minutes before an unpaid order expires",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "currency_symbol", "label": "Currency Symbol", "section": "misc",
     "desc": "Currency symbol used in prices (e.g. ₹, $, €)",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "payment_label_name", "label": "Payment Label Name", "section": "misc",
     "desc": "Brand name shown on payment labels",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "btn_prev_page", "label": "Previous Page Button", "section": "misc",
     "desc": "Label for previous page button in paginated views",
     "placeholders": [], "multiline": False, "html": False},
    {"key": "btn_next_page", "label": "Next Page Button", "section": "misc",
     "desc": "Label for next page button in paginated views",
     "placeholders": [], "multiline": False, "html": False},
]

_REGISTRY_BY_KEY: dict[str, dict] = {s["key"]: s for s in SETTINGS_REGISTRY}
_REGISTRY_BY_SECTION: dict[str, list[dict]] = {}
for _s in SETTINGS_REGISTRY:
    _REGISTRY_BY_SECTION.setdefault(_s["section"], []).append(_s)

SAMPLE_CONTEXT = {
    "brand": "SayGG",
    "first_name": "Alex",
    "full_name": "Alex Smith",
    "username": "alexsmith",
    "user_id": "123456789",
    "name_link": '<a href="tg://user?id=123456789">Alex</a>',
    "welcome_greeting": '\u2728 <b>Hey <a href="tg://user?id=123456789">Alex</a>!</b>',
    "welcome_title": "Welcome to SayGG.",
    "welcome_body": "Use the menu below to browse categories and purchase keys.",
    "store_title": "SayGG — Digital Key Store",
    "store_subtitle": "Choose a category below to browse available products.",
    "categories_footer": "👇 <b>Select a category to continue</b>",
    "category": "NovaEsp Loader",
    "duration": "1 Month",
    "currency": "₹",
    "amount": "299",
    "base_amount": "399",
    "order_id": "10042",
    "txn_ref": "TXN-ABC123",
    "created_time": "01 Apr 2026, 10:00 PM",
    "expiry_time": "01 Apr 2026, 10:15 PM",
    "upi_id": "merchant@paytm",
    "verify_btn": "✅ Verify Payment",
    "verified_title": "✅ <b>Payment Verified Successfully</b>",
    "key_label": "🔑 <b>Your Key:</b>",
    "key": "ABCD-EFGH-1234-5678",
    "key_value": "ABCD-EFGH-1234-5678",
    "apk_notice": "📲 The application file has been sent above.",
    "footer": "Thank you for your purchase.",
    "admin_sale_title": "🔔 <b>New Sale</b>",
    "buyer_label": "@alexsmith",
    "index": "1",
    "total": "3",
    "purchased_time": "01 Apr 2026, 10:05 PM",
    "buyer": "@alexsmith",
    "reference_section": "",
    "duration_title": "⏱️ <b>Select Duration</b>",
    "duration_sub": "Select a duration below:",
    "user_mention": '<a href="tg://user?id=123456789">Alex</a>',
    "channel": "@SayGGChannel",
    "reseller_title": "🎉 <b>Reseller Access Activated Successfully</b>",
    "code": "123456",
    "switched_section": "",
    "expires": "30 Apr 2026",
    "max_users": "50",
    "offer_summary": "• NovaEsp Loader · Month: ₹249",
    "reseller_footer": "✅ You will now see your reseller prices.",
    "plan_name": "Night Sale",
    "description": "Special discount on all products!",
    "pricing_examples": "• NovaEsp · Day: ₹8 (was ₹10)",
    "sent": "150",
    "failed": "3",
    "skipped": "10",
    "error": "Network timeout",
}


def _get_session(admin_id: int) -> dict | None:
    s = SETTINGS_SESSIONS.get(admin_id)
    if not s:
        return None
    if time.time() > s.get("expires_at", 0):
        SETTINGS_SESSIONS.pop(admin_id, None)
        return None
    return s


def _new_session(admin_id: int) -> dict:
    s = {
        "step": "sections",
        "editing_key": None,
        "prompt_msg_id": None,
        "menu_msg_id": None,
        "extra_msg_ids": [],
        "expires_at": time.time() + SESSION_TTL,
    }
    SETTINGS_SESSIONS[admin_id] = s
    return s


def _bump(admin_id: int):
    s = SETTINGS_SESSIONS.get(admin_id)
    if s:
        s["expires_at"] = time.time() + SESSION_TTL


def _clear_session(admin_id: int):
    SETTINGS_SESSIONS.pop(admin_id, None)


def is_botsettings_wizard_active(admin_id: int) -> bool:
    return _get_session(admin_id) is not None


async def _cleanup_msgs(bot, chat_id: int, session: dict):
    for key in ("prompt_msg_id",):
        mid = session.get(key)
        if mid:
            await safe_delete_message(bot, chat_id, mid)
            session[key] = None
    for mid in session.get("extra_msg_ids", []):
        if mid:
            await safe_delete_message(bot, chat_id, mid)
    session["extra_msg_ids"] = []


def _capture_html(msg) -> str:
    try:
        html = getattr(msg, "text_html", None) or getattr(msg, "caption_html", None)
        if html is not None:
            return html.strip()
    except Exception as exc:
        logger.warning(f"[botsettings] text_html conversion failed: {exc!r}")
    raw = (msg.text or msg.caption or "").strip()
    return raw


def _truncate(text: str, max_len: int = 300) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len] + "…"


def _preview_value(key: str, value: str) -> str:
    if not value.strip():
        return "<i>(empty)</i>"
    if len(value) > 600:
        return f"<code>{escape(_truncate(value, 500))}</code>"
    return f"<code>{escape(value)}</code>"


def _render_preview(value: str) -> str:
    result = value
    for k, v in SAMPLE_CONTEXT.items():
        result = result.replace("{" + k + "}", v)
    return result


async def _save_setting(key: str, value: str):
    existing = await db.fetch_one(
        "SELECT key FROM bot_settings WHERE key = $1", key
    )
    if existing:
        await db.execute(
            "UPDATE bot_settings SET value = $1 WHERE key = $2",
            value, key
        )
    else:
        await db.execute(
            "INSERT INTO bot_settings (key, value) VALUES ($1, $2)",
            key, value
        )
    await bot_settings.force_reload_settings()


async def _delete_setting(key: str):
    await db.execute("DELETE FROM bot_settings WHERE key = $1", key)
    await bot_settings.force_reload_settings()


async def _show_sections(bot, chat_id: int, admin_id: int, edit_msg_id: int | None = None):
    session = _get_session(admin_id) or _new_session(admin_id)
    session["step"] = "sections"
    session["editing_key"] = None

    await _cleanup_msgs(bot, chat_id, session)

    kb = []
    for sec_id, sec_label in SECTIONS:
        if sec_id == "catdur":
            kb.append([InlineKeyboardButton(f"{sec_label}", callback_data=f"bs_sec_{sec_id}")])
        else:
            count = len(_REGISTRY_BY_SECTION.get(sec_id, []))
            kb.append([InlineKeyboardButton(f"{sec_label} ({count})", callback_data=f"bs_sec_{sec_id}")])

    kb.append([InlineKeyboardButton("❌ Close", callback_data="bs_close")])

    text = (
        "⚙️ <b>Bot Settings Editor</b>\n\n"
        "Choose a section to browse and edit bot messages, templates, button labels, and more.\n\n"
        f"<i>Total editable settings: {len(SETTINGS_REGISTRY)}</i>"
    )

    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
            )
            session["menu_msg_id"] = edit_msg_id
            _bump(admin_id)
            return edit_msg_id
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return edit_msg_id

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    session["menu_msg_id"] = msg.message_id
    _bump(admin_id)
    return msg.message_id


async def _show_catdur_categories(bot, chat_id: int, admin_id: int, edit_msg_id: int | None = None):
    session = _get_session(admin_id) or _new_session(admin_id)
    session["step"] = "catdur_cats"
    session["editing_key"] = None
    session.pop("catdur_cat_id", None)

    cats = await db.fetch_all(
        "SELECT id, name FROM categories WHERE is_hidden = 0 ORDER BY sort_order ASC, id ASC"
    )
    if not cats:
        text = "📂 <b>Category Duration Messages</b>\n\nNo active categories found."
        kb = [[InlineKeyboardButton("◀️ Back", callback_data="bs_sections")]]
        try:
            if edit_msg_id:
                await bot.edit_message_text(chat_id=chat_id, message_id=edit_msg_id,
                                            text=text, parse_mode="HTML",
                                            reply_markup=InlineKeyboardMarkup(kb))
                session["menu_msg_id"] = edit_msg_id
                _bump(admin_id)
                return
        except Exception:
            pass
        msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML",
                                     reply_markup=InlineKeyboardMarkup(kb))
        session["menu_msg_id"] = msg.message_id
        _bump(admin_id)
        return

    kb = []
    for c in cats:
        from bot.services.categories import extract_custom_emoji_and_clean_name
        parsed = extract_custom_emoji_and_clean_name(c["name"])
        label = parsed["name"] or f"Category #{c['id']}"
        has_custom = bool(bot_settings.get_category_duration_all(c["id"]))
        marker = " ✏️" if has_custom else ""
        kb.append([InlineKeyboardButton(f"{label}{marker}", callback_data=f"bs_cd_cat_{c['id']}")])

    kb.append([InlineKeyboardButton("◀️ Back", callback_data="bs_sections")])
    kb.append([InlineKeyboardButton("❌ Close", callback_data="bs_close")])

    text = (
        "📂 <b>Category Duration Messages</b>\n\n"
        "Select a category to edit its duration screen messages.\n"
        "Categories marked with ✏️ have custom settings."
    )
    markup = InlineKeyboardMarkup(kb)
    try:
        if edit_msg_id:
            await bot.edit_message_text(chat_id=chat_id, message_id=edit_msg_id,
                                        text=text, parse_mode="HTML", reply_markup=markup)
            session["menu_msg_id"] = edit_msg_id
            _bump(admin_id)
            return
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    session["menu_msg_id"] = msg.message_id
    _bump(admin_id)


async def _show_catdur_fields(bot, chat_id: int, admin_id: int, cat_id: int, edit_msg_id: int | None = None):
    session = _get_session(admin_id) or _new_session(admin_id)
    session["step"] = "catdur_fields"
    session["catdur_cat_id"] = cat_id
    session["editing_key"] = None

    cat = await db.fetch_one("SELECT name FROM categories WHERE id = $1", cat_id)
    if not cat:
        await _show_catdur_categories(bot, chat_id, admin_id, edit_msg_id)
        return

    from bot.services.categories import extract_custom_emoji_and_clean_name
    cat_name = extract_custom_emoji_and_clean_name(cat["name"])["name"] or f"Category #{cat_id}"

    overrides = bot_settings.get_category_duration_all(cat_id)

    kb = []
    for f in CAT_DUR_FIELDS:
        is_custom = f["key"] in overrides
        marker = " ✏️" if is_custom else " 📝"
        kb.append([InlineKeyboardButton(f"{f['label']}{marker}", callback_data=f"bs_cd_v_{cat_id}_{f['key']}")])

    if overrides:
        kb.append([InlineKeyboardButton("🔄 Reset All to Global", callback_data=f"bs_cd_resetall_{cat_id}")])

    kb.append([InlineKeyboardButton("◀️ Back to Categories", callback_data="bs_sec_catdur")])
    kb.append([InlineKeyboardButton("❌ Close", callback_data="bs_close")])

    custom_count = len(overrides)
    text = (
        f"📂 <b>Duration Settings — {escape(cat_name)}</b>\n\n"
        f"Edit duration screen messages for this category.\n"
        f"Items marked ✏️ have custom values, 📝 use global defaults.\n\n"
        f"<i>Custom overrides: {custom_count}/{len(CAT_DUR_FIELDS)}</i>"
    )
    markup = InlineKeyboardMarkup(kb)
    try:
        if edit_msg_id:
            await bot.edit_message_text(chat_id=chat_id, message_id=edit_msg_id,
                                        text=text, parse_mode="HTML", reply_markup=markup)
            session["menu_msg_id"] = edit_msg_id
            _bump(admin_id)
            return
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    session["menu_msg_id"] = msg.message_id
    _bump(admin_id)


async def _show_catdur_field_view(bot, chat_id: int, admin_id: int, cat_id: int,
                                   field_key: str, edit_msg_id: int | None = None):
    session = _get_session(admin_id) or _new_session(admin_id)
    session["step"] = "catdur_view"
    session["catdur_cat_id"] = cat_id
    session["editing_key"] = field_key

    await _cleanup_msgs(bot, chat_id, session)

    meta = CAT_DUR_FIELD_BY_KEY.get(field_key)
    if not meta:
        await bot.send_message(chat_id=chat_id, text="❌ Unknown field.", parse_mode="HTML")
        return

    cat = await db.fetch_one("SELECT name FROM categories WHERE id = $1", cat_id)
    from bot.services.categories import extract_custom_emoji_and_clean_name
    cat_name = extract_custom_emoji_and_clean_name((cat or {}).get("name", ""))["name"] or f"#{cat_id}"

    overrides = bot_settings.get_category_duration_all(cat_id)
    is_custom = field_key in overrides
    current_val = overrides.get(field_key, bot_settings.get(field_key))
    default_val = bot_settings.SETTING_DEFAULTS.get(field_key, "")

    status = "✏️ <b>Custom value</b>" if is_custom else "📝 <b>Using global default</b>"
    ph_text = ""
    if meta["placeholders"]:
        ph_list = "  ".join(f"<code>{p}</code>" for p in meta["placeholders"])
        ph_text = f"\n\n<b>Placeholders:</b>\n{ph_list}"

    fmt_note = "\n<i>Supports Telegram HTML + custom emoji</i>" if meta["html"] else ""
    value_preview = _preview_value(field_key, current_val)

    text = (
        f"📂 <b>{escape(meta['label'])}</b>\n"
        f"Category: <b>{escape(cat_name)}</b>\n"
        f"{status}{fmt_note}\n\n"
        f"<b>Description:</b> {escape(meta['desc'])}\n\n"
        f"<b>Current Value:</b>\n{value_preview}"
        f"{ph_text}"
    )

    kb = [
        [
            InlineKeyboardButton("✏️ Edit", callback_data=f"bs_cd_edit_{cat_id}_{field_key}"),
            InlineKeyboardButton("👁️ Preview", callback_data=f"bs_cd_prev_{cat_id}_{field_key}"),
        ],
        [
            InlineKeyboardButton("📋 View Global Default", callback_data=f"bs_cd_def_{cat_id}_{field_key}"),
        ],
    ]
    if is_custom:
        kb.append([InlineKeyboardButton("🔄 Reset to Global", callback_data=f"bs_cd_reset_{cat_id}_{field_key}")])
    kb.append([
        InlineKeyboardButton("◀️ Back", callback_data=f"bs_cd_cat_{cat_id}"),
        InlineKeyboardButton("❌ Close", callback_data="bs_close"),
    ])

    markup = InlineKeyboardMarkup(kb)
    try:
        if edit_msg_id:
            await bot.edit_message_text(chat_id=chat_id, message_id=edit_msg_id,
                                        text=text, parse_mode="HTML", reply_markup=markup,
                                        disable_web_page_preview=True)
            session["menu_msg_id"] = edit_msg_id
            _bump(admin_id)
            return
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML",
                                 reply_markup=markup, disable_web_page_preview=True)
    session["menu_msg_id"] = msg.message_id
    _bump(admin_id)


async def _start_catdur_edit(bot, chat_id: int, admin_id: int, cat_id: int, field_key: str):
    session = _get_session(admin_id) or _new_session(admin_id)
    await _cleanup_msgs(bot, chat_id, session)

    meta = CAT_DUR_FIELD_BY_KEY.get(field_key)
    if not meta:
        await bot.send_message(chat_id=chat_id, text="❌ Unknown field.", parse_mode="HTML")
        return

    cat = await db.fetch_one("SELECT name FROM categories WHERE id = $1", cat_id)
    from bot.services.categories import extract_custom_emoji_and_clean_name
    cat_name = extract_custom_emoji_and_clean_name((cat or {}).get("name", ""))["name"] or f"#{cat_id}"

    overrides = bot_settings.get_category_duration_all(cat_id)
    current_val = overrides.get(field_key, bot_settings.get(field_key))

    ph_text = ""
    if meta["placeholders"]:
        ph_list = "  ".join(f"<code>{p}</code>" for p in meta["placeholders"])
        ph_text = f"\n\n<b>Supported placeholders:</b>\n{ph_list}"

    fmt_note = ""
    if meta["html"]:
        fmt_note = (
            "\n\n<b>Formatting:</b>\n"
            "  • Bold, italic, underline, strikethrough, spoiler\n"
            "  • Code, pre blocks, text links\n"
            "  • Custom emoji (animated sticker emoji)\n"
            "  • Line breaks and spacing"
        )

    prompt_text = (
        f"✏️ <b>Editing: {escape(meta['label'])}</b>\n"
        f"Category: <b>{escape(cat_name)}</b>\n\n"
        f"<b>Current value:</b>\n{_preview_value(field_key, current_val)}"
        f"{ph_text}"
        f"{fmt_note}\n\n"
        "Reply to this message with the new value.\n"
        "Send /cancel to abort."
    )

    prompt = await bot.send_message(
        chat_id=chat_id,
        text=prompt_text,
        parse_mode="HTML",
        reply_markup=ForceReply(selective=True, input_field_placeholder=f"New value for {meta['label']}…"),
        disable_web_page_preview=True,
    )
    session["prompt_msg_id"] = prompt.message_id
    session["step"] = "catdur_edit_await"
    session["catdur_cat_id"] = cat_id
    session["editing_key"] = field_key
    _bump(admin_id)


async def _handle_catdur_save(bot, chat_id: int, admin_id: int, cat_id: int,
                               field_key: str, new_value: str, msg):
    session = _get_session(admin_id)
    if not session:
        return

    meta = CAT_DUR_FIELD_BY_KEY.get(field_key)
    if not meta:
        await bot.send_message(chat_id=chat_id, text="❌ Unknown field.", parse_mode="HTML")
        return

    if meta["html"]:
        captured = _capture_html(msg)
    else:
        captured = (msg.text or "").strip()

    await bot_settings.set_category_duration(cat_id, field_key, captured)

    await _cleanup_msgs(bot, chat_id, session)

    cat = await db.fetch_one("SELECT name FROM categories WHERE id = $1", cat_id)
    from bot.services.categories import extract_custom_emoji_and_clean_name
    cat_name = extract_custom_emoji_and_clean_name((cat or {}).get("name", ""))["name"] or f"#{cat_id}"

    kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👁️ Preview", callback_data=f"bs_cd_prev_{cat_id}_{field_key}"),
            InlineKeyboardButton("✏️ Edit Again", callback_data=f"bs_cd_edit_{cat_id}_{field_key}"),
        ],
        [
            InlineKeyboardButton("◀️ Back to Field", callback_data=f"bs_cd_v_{cat_id}_{field_key}"),
            InlineKeyboardButton("📂 Back to Category", callback_data=f"bs_cd_cat_{cat_id}"),
        ],
        [InlineKeyboardButton("❌ Close", callback_data="bs_close")],
    ])

    saved_preview = _preview_value(field_key, captured)
    text = (
        f"✅ <b>Saved: {escape(meta['label'])}</b>\n"
        f"Category: <b>{escape(cat_name)}</b>\n\n"
        f"<b>New value:</b>\n{saved_preview}"
    )

    save_msg = await bot.send_message(
        chat_id=chat_id, text=text, parse_mode="HTML",
        reply_markup=kb, disable_web_page_preview=True,
    )
    session["menu_msg_id"] = save_msg.message_id
    session["step"] = "catdur_saved"
    session["editing_key"] = field_key
    _bump(admin_id)


async def _show_section_settings(bot, chat_id: int, admin_id: int, section_id: str,
                                  page: int = 0, edit_msg_id: int | None = None):
    if section_id == "catdur":
        await _show_catdur_categories(bot, chat_id, admin_id, edit_msg_id)
        return

    session = _get_session(admin_id) or _new_session(admin_id)
    session["step"] = "setting_list"
    session["editing_key"] = None

    items = _REGISTRY_BY_SECTION.get(section_id, [])
    if not items:
        try:
            if edit_msg_id:
                await bot.edit_message_text(
                    chat_id=chat_id, message_id=edit_msg_id,
                    text="No settings found in this section.",
                    parse_mode="HTML",
                )
        except Exception:
            pass
        return

    page_size = 8
    total_pages = max(1, (len(items) + page_size - 1) // page_size)
    page = max(0, min(page, total_pages - 1))
    page_items = items[page * page_size:(page + 1) * page_size]

    sec_label = dict(SECTIONS).get(section_id, section_id)

    kb = []
    for item in page_items:
        has_custom = bool(bot_settings._cache.get(item["key"]))
        marker = "✏️" if has_custom else "📝"
        kb.append([InlineKeyboardButton(
            f"{marker} {item['label']}",
            callback_data=f"bs_v_{item['key']}"
        )])

    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"bs_sp_{section_id}_{page - 1}"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("Next ➡️", callback_data=f"bs_sp_{section_id}_{page + 1}"))
    if nav_row:
        kb.append(nav_row)

    kb.append([
        InlineKeyboardButton("◀️ Back", callback_data="bs_sections"),
        InlineKeyboardButton("❌ Close", callback_data="bs_close"),
    ])

    page_info = f"Page {page + 1}/{total_pages}" if total_pages > 1 else ""
    text = (
        f"{sec_label}\n\n"
        f"<i>{len(items)} settings in this section</i>"
        + (f"  ·  {page_info}" if page_info else "")
        + "\n\n✏️ = customized  ·  📝 = using default"
    )

    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
            )
            session["menu_msg_id"] = edit_msg_id
            _bump(admin_id)
            return
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    session["menu_msg_id"] = msg.message_id
    _bump(admin_id)


async def _show_setting_view(bot, chat_id: int, admin_id: int, setting_key: str,
                              edit_msg_id: int | None = None):
    session = _get_session(admin_id) or _new_session(admin_id)
    session["step"] = "setting_view"
    session["editing_key"] = setting_key

    await _cleanup_msgs(bot, chat_id, session)

    meta = _REGISTRY_BY_KEY.get(setting_key)
    if not meta:
        await bot.send_message(chat_id=chat_id, text="❌ Unknown setting.", parse_mode="HTML")
        return

    current_val = bot_settings.get(setting_key)
    default_val = bot_settings.SETTING_DEFAULTS.get(setting_key, "")
    is_custom = bool(bot_settings._cache.get(setting_key))

    status = "✏️ <b>Custom value</b>" if is_custom else "📝 <b>Using default</b>"
    placeholders_text = ""
    if meta["placeholders"]:
        ph_list = "  ".join(f"<code>{p}</code>" for p in meta["placeholders"])
        placeholders_text = f"\n\n<b>Placeholders:</b>\n{ph_list}"

    format_note = ""
    if meta["html"]:
        format_note = "\n<i>Supports Telegram HTML + custom emoji</i>"

    value_preview = _preview_value(setting_key, current_val)

    text = (
        f"⚙️ <b>{escape(meta['label'])}</b>\n"
        f"Key: <code>{setting_key}</code>\n"
        f"{status}{format_note}\n\n"
        f"<b>Description:</b> {escape(meta['desc'])}\n\n"
        f"<b>Current Value:</b>\n{value_preview}"
        f"{placeholders_text}"
    )

    section_id = meta["section"]
    kb = [
        [
            InlineKeyboardButton("✏️ Edit", callback_data=f"bs_edit_{setting_key}"),
            InlineKeyboardButton("👁️ Preview", callback_data=f"bs_prev_{setting_key}"),
        ],
        [
            InlineKeyboardButton("📋 View Default", callback_data=f"bs_def_{setting_key}"),
        ],
    ]
    if is_custom:
        kb.append([InlineKeyboardButton("🔄 Reset to Default", callback_data=f"bs_reset_{setting_key}")])
    kb.append([
        InlineKeyboardButton("◀️ Back", callback_data=f"bs_sec_{section_id}"),
        InlineKeyboardButton("❌ Close", callback_data="bs_close"),
    ])

    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
                disable_web_page_preview=True,
            )
            session["menu_msg_id"] = edit_msg_id
            _bump(admin_id)
            return
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return

    msg = await bot.send_message(
        chat_id=chat_id, text=text, parse_mode="HTML",
        reply_markup=markup, disable_web_page_preview=True,
    )
    session["menu_msg_id"] = msg.message_id
    _bump(admin_id)


async def _start_edit(bot, chat_id: int, admin_id: int, setting_key: str):
    session = _get_session(admin_id) or _new_session(admin_id)

    await _cleanup_msgs(bot, chat_id, session)

    meta = _REGISTRY_BY_KEY.get(setting_key)
    if not meta:
        await bot.send_message(chat_id=chat_id, text="❌ Unknown setting.", parse_mode="HTML")
        return

    current_val = bot_settings.get(setting_key)

    placeholders_text = ""
    if meta["placeholders"]:
        ph_list = "  ".join(f"<code>{p}</code>" for p in meta["placeholders"])
        placeholders_text = f"\n\n<b>Supported placeholders:</b>\n{ph_list}"

    format_note = ""
    if meta["html"]:
        format_note = (
            "\n\n<b>Formatting:</b>\n"
            "  • Bold, italic, underline, strikethrough, spoiler\n"
            "  • Code, pre blocks, text links\n"
            "  • Custom emoji (animated sticker emoji)\n"
            "  • Line breaks and spacing"
        )

    prompt_text = (
        f"✏️ <b>Editing: {escape(meta['label'])}</b>\n"
        f"Key: <code>{setting_key}</code>\n\n"
        f"<b>Current value:</b>\n{_preview_value(setting_key, current_val)}"
        f"{placeholders_text}"
        f"{format_note}\n\n"
        "Reply to this message with the new value.\n"
        "Send /cancel to abort."
    )

    prompt = await bot.send_message(
        chat_id=chat_id,
        text=prompt_text,
        parse_mode="HTML",
        reply_markup=ForceReply(selective=True, input_field_placeholder=f"New value for {meta['label']}…"),
        disable_web_page_preview=True,
    )
    session["prompt_msg_id"] = prompt.message_id
    session["step"] = "edit_await"
    session["editing_key"] = setting_key
    _bump(admin_id)


async def _show_preview(bot, chat_id: int, admin_id: int, setting_key: str):
    session = _get_session(admin_id) or _new_session(admin_id)

    meta = _REGISTRY_BY_KEY.get(setting_key)
    if not meta:
        return

    current_val = bot_settings.get(setting_key)
    rendered = _render_preview(current_val)

    if not rendered.strip():
        rendered = "<i>(empty)</i>"

    try:
        pm = await bot.send_message(
            chat_id=chat_id,
            text=f"👁️ <b>Preview: {escape(meta['label'])}</b>\n\n{rendered}",
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
    except Exception as e:
        pm = await bot.send_message(
            chat_id=chat_id,
            text=f"⚠️ <b>Preview render error</b>\n<code>{escape(str(e)[:300])}</code>",
            parse_mode="HTML",
        )
    session["extra_msg_ids"].append(pm.message_id)
    _bump(admin_id)


async def _show_default(bot, chat_id: int, admin_id: int, setting_key: str):
    session = _get_session(admin_id) or _new_session(admin_id)

    meta = _REGISTRY_BY_KEY.get(setting_key)
    if not meta:
        return

    default_val = bot_settings.SETTING_DEFAULTS.get(setting_key, "")
    is_custom = bool(bot_settings._cache.get(setting_key))

    text = (
        f"📋 <b>Default: {escape(meta['label'])}</b>\n\n"
        f"{_preview_value(setting_key, default_val)}\n\n"
    )
    if is_custom:
        text += "<i>Your current value is customized (different from default).</i>"
    else:
        text += "<i>Currently using this default value.</i>"

    pm = await bot.send_message(
        chat_id=chat_id, text=text, parse_mode="HTML",
        disable_web_page_preview=True,
    )
    session["extra_msg_ids"].append(pm.message_id)
    _bump(admin_id)


async def _handle_reset(bot, chat_id: int, admin_id: int, setting_key: str,
                         edit_msg_id: int | None = None):
    meta = _REGISTRY_BY_KEY.get(setting_key)
    if not meta:
        return

    await _delete_setting(setting_key)

    await _show_setting_view(bot, chat_id, admin_id, setting_key, edit_msg_id=edit_msg_id)

    confirm = await bot.send_message(
        chat_id=chat_id,
        text=f"🔄 <b>{escape(meta['label'])}</b> has been reset to its default value.",
        parse_mode="HTML",
    )
    session = _get_session(admin_id)
    if session:
        session["extra_msg_ids"].append(confirm.message_id)


async def _handle_save(bot, chat_id: int, admin_id: int, setting_key: str,
                        new_value: str, msg):
    session = _get_session(admin_id)
    if not session:
        return

    meta = _REGISTRY_BY_KEY.get(setting_key)
    if not meta:
        await bot.send_message(chat_id=chat_id, text="❌ Unknown setting.", parse_mode="HTML")
        return

    if meta["html"]:
        captured = _capture_html(msg)
    else:
        captured = (msg.text or "").strip()

    await _save_setting(setting_key, captured)

    await _cleanup_msgs(bot, chat_id, session)

    section_id = meta["section"]
    kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👁️ Preview", callback_data=f"bs_prev_{setting_key}"),
            InlineKeyboardButton("✏️ Edit Again", callback_data=f"bs_edit_{setting_key}"),
        ],
        [
            InlineKeyboardButton("◀️ Back to Setting", callback_data=f"bs_v_{setting_key}"),
            InlineKeyboardButton("📂 Back to Section", callback_data=f"bs_sec_{section_id}"),
        ],
        [
            InlineKeyboardButton("❌ Close", callback_data="bs_close"),
        ],
    ])

    saved_preview = _preview_value(setting_key, captured)
    text = (
        f"✅ <b>Saved: {escape(meta['label'])}</b>\n\n"
        f"<b>New value:</b>\n{saved_preview}"
    )

    save_msg = await bot.send_message(
        chat_id=chat_id, text=text, parse_mode="HTML",
        reply_markup=kb, disable_web_page_preview=True,
    )
    session["menu_msg_id"] = save_msg.message_id
    session["step"] = "saved"
    session["editing_key"] = setting_key
    _bump(admin_id)


async def handle_botsettings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.from_user:
        return

    admin_id = msg.from_user.id
    chat_id = msg.chat_id

    if not _is_admin(admin_id):
        await msg.reply_text("⛔ This command is available to the bot admin only.")
        return

    if msg.chat.type != "private":
        await msg.reply_text("⚙️ This command only works in private chat with the bot.")
        return

    _clear_session(admin_id)
    await _show_sections(context.bot, chat_id, admin_id)


async def handle_botsettings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query or not query.from_user:
        return

    admin_id = query.from_user.id
    chat_id = query.message.chat_id
    data = query.data or ""
    bot = context.bot
    msg_id = query.message.message_id

    if not _is_admin(admin_id):
        await query.answer("Not authorized.", show_alert=True)
        return

    await query.answer()

    if data == "bs_close":
        _clear_session(admin_id)
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=msg_id,
                text="⚙️ <b>Bot Settings Editor</b> — closed.",
                parse_mode="HTML",
            )
        except Exception:
            pass
        return

    if data == "bs_sections":
        await _show_sections(bot, chat_id, admin_id, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_sec_(\w+)$', data)
    if m:
        section_id = m.group(1)
        await _show_section_settings(bot, chat_id, admin_id, section_id, page=0, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_sp_(\w+)_(\d+)$', data)
    if m:
        section_id = m.group(1)
        page = int(m.group(2))
        await _show_section_settings(bot, chat_id, admin_id, section_id, page=page, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_v_(.+)$', data)
    if m:
        setting_key = m.group(1)
        await _show_setting_view(bot, chat_id, admin_id, setting_key, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_edit_(.+)$', data)
    if m:
        setting_key = m.group(1)
        await _start_edit(bot, chat_id, admin_id, setting_key)
        return

    m = re.match(r'^bs_prev_(.+)$', data)
    if m:
        setting_key = m.group(1)
        await _show_preview(bot, chat_id, admin_id, setting_key)
        return

    m = re.match(r'^bs_def_(.+)$', data)
    if m:
        setting_key = m.group(1)
        await _show_default(bot, chat_id, admin_id, setting_key)
        return

    m = re.match(r'^bs_reset_(.+)$', data)
    if m:
        setting_key = m.group(1)
        await _handle_reset(bot, chat_id, admin_id, setting_key, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_cd_cat_(\d+)$', data)
    if m:
        cat_id = int(m.group(1))
        await _show_catdur_fields(bot, chat_id, admin_id, cat_id, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_cd_v_(\d+)_(.+)$', data)
    if m:
        cat_id = int(m.group(1))
        field_key = m.group(2)
        await _show_catdur_field_view(bot, chat_id, admin_id, cat_id, field_key, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_cd_edit_(\d+)_(.+)$', data)
    if m:
        cat_id = int(m.group(1))
        field_key = m.group(2)
        await _start_catdur_edit(bot, chat_id, admin_id, cat_id, field_key)
        return

    m = re.match(r'^bs_cd_prev_(\d+)_(.+)$', data)
    if m:
        cat_id = int(m.group(1))
        field_key = m.group(2)
        meta = CAT_DUR_FIELD_BY_KEY.get(field_key)
        if meta:
            overrides = bot_settings.get_category_duration_all(cat_id)
            val = overrides.get(field_key, bot_settings.get(field_key))
            rendered = _render_preview(val)
            session = _get_session(admin_id)
            await _cleanup_msgs(bot, chat_id, session)
            confirm = await bot.send_message(
                chat_id=chat_id,
                text=f"👁️ <b>Preview: {escape(meta['label'])}</b>\n\n{rendered}",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            if session:
                session["extra_msg_ids"].append(confirm.message_id)
        return

    m = re.match(r'^bs_cd_def_(\d+)_(.+)$', data)
    if m:
        cat_id = int(m.group(1))
        field_key = m.group(2)
        meta = CAT_DUR_FIELD_BY_KEY.get(field_key)
        if meta:
            default_val = bot_settings.get(field_key)
            session = _get_session(admin_id)
            await _cleanup_msgs(bot, chat_id, session)
            confirm = await bot.send_message(
                chat_id=chat_id,
                text=f"📋 <b>Global Default: {escape(meta['label'])}</b>\n\n{_preview_value(field_key, default_val)}",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            if session:
                session["extra_msg_ids"].append(confirm.message_id)
        return

    m = re.match(r'^bs_cd_reset_(\d+)_(.+)$', data)
    if m:
        cat_id = int(m.group(1))
        field_key = m.group(2)
        await bot_settings.delete_category_duration(cat_id, field_key)
        await _show_catdur_field_view(bot, chat_id, admin_id, cat_id, field_key, edit_msg_id=msg_id)
        return

    m = re.match(r'^bs_cd_resetall_(\d+)$', data)
    if m:
        cat_id = int(m.group(1))
        for fk in CAT_DUR_FIELDS:
            await bot_settings.delete_category_duration(cat_id, fk["key"])
        await _show_catdur_fields(bot, chat_id, admin_id, cat_id, edit_msg_id=msg_id)
        return


async def handle_botsettings_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    msg = update.message
    if not msg or not msg.from_user:
        return False

    admin_id = msg.from_user.id
    session = _get_session(admin_id)
    if not session:
        return False

    text = (msg.text or "").strip()
    chat_id = msg.chat_id
    bot = context.bot

    if text.lower() in ("/cancel", "/botsettings"):
        await _cleanup_msgs(bot, chat_id, session)
        if text.lower() == "/cancel":
            _clear_session(admin_id)
            await bot.send_message(chat_id=chat_id, text="❌ Bot settings editing cancelled.", parse_mode="HTML")
            return True
        else:
            _clear_session(admin_id)
            await _show_sections(bot, chat_id, admin_id)
            return True

    if session["step"] == "edit_await":
        setting_key = session.get("editing_key")
        if not setting_key:
            _clear_session(admin_id)
            return False

        reply_to = msg.reply_to_message
        if reply_to and reply_to.message_id == session.get("prompt_msg_id"):
            await _handle_save(bot, chat_id, admin_id, setting_key, text, msg)
            return True

        if session.get("prompt_msg_id"):
            await _handle_save(bot, chat_id, admin_id, setting_key, text, msg)
            return True

    if session["step"] == "catdur_edit_await":
        field_key = session.get("editing_key")
        cat_id = session.get("catdur_cat_id")
        if not field_key or not cat_id:
            _clear_session(admin_id)
            return False

        reply_to = msg.reply_to_message
        if reply_to and reply_to.message_id == session.get("prompt_msg_id"):
            await _handle_catdur_save(bot, chat_id, admin_id, cat_id, field_key, text, msg)
            return True

        if session.get("prompt_msg_id"):
            await _handle_catdur_save(bot, chat_id, admin_id, cat_id, field_key, text, msg)
            return True

    return False
