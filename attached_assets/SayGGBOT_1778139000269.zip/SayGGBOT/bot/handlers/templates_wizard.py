"""
Telegram-first campaign template editor.
Admin-only (ADMIN_CHAT_ID). Callback prefix: tw_

Flow:
  /templates → list → view → edit_message / edit_buttons / preview / test_send / history
  edit_message: ForceReply for new body text, variable validation, version save
  edit_buttons: step-by-step button wizard with ForceReply for text/url/emoji
  history: last-10 versions, one-tap restore
"""
import json
import re
import time
import logging
from datetime import datetime, timezone, timedelta
from html import escape

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ForceReply, Update
from telegram.ext import ContextTypes

from bot import database as db
from bot.config import ADMIN_CHAT_ID
from bot.cleanup import safe_delete_message

logger = logging.getLogger(__name__)

IST = timezone(timedelta(hours=5, minutes=30))

SESSION_TTL = 600

TEMPLATE_SESSIONS: dict[int, dict] = {}

VALID_VARIABLES = {
    "campaign_name", "user_name", "starts_at", "expires_at", "deep_link",
    "discount_percent", "original_price", "discounted_price", "current_price",
    "category_name", "duration_name", "product_discount_lines", "product_expiry_lines",
}

SAMPLE_VALUES = {
    "campaign_name": "Night Sale Live",
    "user_name": "SayGG Admin",
    "discount_percent": "20",
    "starts_at": "28 Mar 2026, 10:00 PM IST",
    "expires_at": "28 Mar 2026, 11:00 PM IST",
    "deep_link": "https://t.me/ExampleBot?start=promo_demo",
    "category_name": "NovaEsp",
    "duration_name": "Month",
    "original_price": "₹20.00",
    "discounted_price": "₹16.00",
    "current_price": "₹16.00",
    "product_discount_lines": (
        "• <b>NovaEsp · Day</b>\n"
        "   <s>Original: ₹10.00</s>\n"
        "   <b>Now: ₹8.00</b>   (You save ₹2.00)\n\n"
        "• <b>NovaEsp · Week</b>\n"
        "   <s>Original: ₹15.00</s>\n"
        "   <b>Now: ₹12.00</b>   (You save ₹3.00)"
    ),
    "product_expiry_lines": (
        "• <b>NovaEsp · Day</b>\n"
        "   <s>Discounted: ₹8.00</s>\n"
        "   <b>Current: ₹10.00</b>\n\n"
        "• <b>NovaEsp · Week</b>\n"
        "   <s>Discounted: ₹12.00</s>\n"
        "   <b>Current: ₹15.00</b>"
    ),
}

VARIABLES_HELP = (
    "<b>Supported Variables:</b>\n"
    "<code>{campaign_name}</code>  <code>{user_name}</code>  <code>{starts_at}</code>  <code>{expires_at}</code>\n"
    "<code>{deep_link}</code>  <code>{discount_percent}</code>  <code>{original_price}</code>\n"
    "<code>{discounted_price}</code>  <code>{current_price}</code>  <code>{category_name}</code>\n"
    "<code>{duration_name}</code>  <code>{product_discount_lines}</code>  <code>{product_expiry_lines}</code>"
)

BUTTON_COLORS = ["none", "default", "primary", "success", "warning", "danger"]

STEP_BTN_NAME = "btn_name"
STEP_BTN_URL = "btn_url"
STEP_BTN_EMOJI_CHAR = "btn_emoji_char"
STEP_BTN_EMOJI_CUSTOM_ID = "btn_emoji_cid"
STEP_BTN_EMOJI_FALLBACK = "btn_emoji_fallback"


def _is_admin(telegram_id: int) -> bool:
    return ADMIN_CHAT_ID > 0 and telegram_id == ADMIN_CHAT_ID


def _get_session(admin_id: int) -> dict | None:
    s = TEMPLATE_SESSIONS.get(admin_id)
    if not s:
        return None
    if time.time() > s.get("expires_at", 0):
        TEMPLATE_SESSIONS.pop(admin_id, None)
        return None
    return s


def _new_session(admin_id: int) -> dict:
    s = {
        "step": "list",
        "template_id": None,
        "template_data": {},
        "prompt_msg_id": None,
        "list_msg_id": None,
        "info_msg_id": None,
        "preview_msg_id": None,
        "extra_msg_ids": [],
        "current_button_draft": {},
        "button_edit_idx": None,
        "temp_buttons": [],
        "expires_at": time.time() + SESSION_TTL,
    }
    TEMPLATE_SESSIONS[admin_id] = s
    return s


def _bump_session(admin_id: int):
    s = TEMPLATE_SESSIONS.get(admin_id)
    if s:
        s["expires_at"] = time.time() + SESSION_TTL


def _clear_session(admin_id: int):
    TEMPLATE_SESSIONS.pop(admin_id, None)


def is_template_wizard_active(admin_id: int) -> bool:
    return _get_session(admin_id) is not None


def _render_sample(body_text: str) -> str:
    result = body_text
    for k, v in SAMPLE_VALUES.items():
        result = result.replace("{" + k + "}", v)
    return result


def _validate_variables(body_text: str) -> list[str]:
    found = re.findall(r'\{(\w+)\}', body_text)
    return [v for v in found if v not in VALID_VARIABLES]


def _count_variables(body_text: str) -> int:
    found = re.findall(r'\{(\w+)\}', body_text)
    return len(set(v for v in found if v in VALID_VARIABLES))


def _capture_html(msg) -> str:
    """
    Return the HTML-formatted text of a Telegram message, preserving ALL entity
    types: bold, italic, underline, strikethrough, spoiler, code, pre, text_link,
    custom_emoji (as <tg-emoji emoji-id="...">char</tg-emoji>), blockquote, etc.

    Falls back to the raw text if PTB cannot convert entities (e.g. unsupported type).
    """
    try:
        html = getattr(msg, "text_html", None) or getattr(msg, "caption_html", None)
        if html is not None:
            return html.strip()
    except Exception as exc:
        logger.warning(f"[template_capture] text_html conversion failed: {exc!r} — falling back to raw text")
    raw = (msg.text or msg.caption or "").strip()
    return raw


def _entities_to_json(entities) -> str | None:
    """
    Serialise a list of PTB MessageEntity objects to a JSON string for storage.
    Preserves all fields including custom_emoji_id, url, language.
    Returns None if there are no entities.
    """
    if not entities:
        return None
    result = []
    for e in entities:
        d: dict = {
            "type": e.type,
            "offset": e.offset,
            "length": e.length,
        }
        if getattr(e, "url", None):
            d["url"] = e.url
        if getattr(e, "language", None):
            d["language"] = e.language
        if getattr(e, "custom_emoji_id", None):
            d["custom_emoji_id"] = e.custom_emoji_id
        result.append(d)
    return json.dumps(result, ensure_ascii=False)


def _fmt_dt(dt_val) -> str:
    if not dt_val:
        return "—"
    if isinstance(dt_val, datetime):
        aware = dt_val.replace(tzinfo=timezone.utc) if dt_val.tzinfo is None else dt_val
        return aware.astimezone(IST).strftime("%d %b %Y, %I:%M %p")
    return str(dt_val)


def _tpl_type_label(t: str) -> str:
    return {"promo_start": "Promo Start", "promo_expiry": "Promo Expire"}.get(t, t)


def _btn_summary(b: dict, idx: int) -> str:
    text = (b.get("text") or "Btn")[:22]
    row = b.get("row", 1)
    style = (b.get("style") or "").strip()
    mode = b.get("emoji_mode", "none")
    emoji = ""
    if mode == "plain":
        emoji = (b.get("emoji") or "").strip()
    elif mode == "custom":
        emoji = (b.get("fallback_emoji") or b.get("emoji") or "").strip()
    label = f"{emoji} {text}".strip() if emoji else text
    parts = [f"{idx+1}. {label}", f"row {row}"]
    if style:
        parts.append(style)
    if not b.get("enabled", True):
        parts.append("off")
    return "  ·  ".join(parts)


async def _cleanup_msgs(bot, chat_id: int, session: dict):
    to_delete = []
    for key in ("prompt_msg_id", "preview_msg_id", "info_msg_id"):
        mid = session.get(key)
        if mid:
            to_delete.append(mid)
            session[key] = None
    for mid in session.get("extra_msg_ids", []):
        if mid:
            to_delete.append(mid)
    session["extra_msg_ids"] = []
    for mid in to_delete:
        await safe_delete_message(bot, chat_id, mid)


async def _save_version(template_id: int, changed_by: str, changed_via: str, note: str):
    old = await db.fetch_one(
        "SELECT body_text, inline_buttons_json, body_entities_json FROM campaign_templates WHERE id = $1",
        template_id,
    )
    if not old:
        return
    await db.execute(
        """INSERT INTO template_versions
           (template_id, body_text, inline_buttons_json, body_entities_json, changed_by, changed_via, change_note)
           VALUES ($1, $2, $3, $4, $5, $6, $7)""",
        template_id,
        old["body_text"] or "",
        old.get("inline_buttons_json") or "",
        old.get("body_entities_json") or None,
        changed_by,
        changed_via,
        note,
    )


async def _save_template_body(template_id: int, new_body: str, updated_by: str,
                              entities_json: str | None = None):
    await _save_version(template_id, updated_by, "bot", "message body updated via bot")
    await db.execute(
        """UPDATE campaign_templates
           SET body_text = $1, body_entities_json = $2,
               updated_at = NOW(), updated_by = $3, edited_via = 'bot'
           WHERE id = $4""",
        new_body, entities_json, updated_by, template_id,
    )


async def _save_template_buttons(template_id: int, buttons_list: list, updated_by: str):
    await _save_version(template_id, updated_by, "bot", "buttons updated via bot")
    await db.execute(
        """UPDATE campaign_templates
           SET inline_buttons_json = $1, updated_at = NOW(), updated_by = $2, edited_via = 'bot'
           WHERE id = $3""",
        json.dumps(buttons_list), updated_by, template_id,
    )


async def _show_template_list(bot, chat_id: int, admin_id: int, edit_msg_id: int | None = None) -> int:
    rows_db = await db.fetch_all(
        "SELECT id, name, template_type FROM campaign_templates WHERE is_active = true ORDER BY template_type, name"
    )
    rows_db = [dict(r) for r in (rows_db or [])]

    starts = [t for t in rows_db if t["template_type"] == "promo_start"]
    expiries = [t for t in rows_db if t["template_type"] in ("promo_expiry", "promo_expire")]

    kb = []
    for t in starts:
        kb.append([InlineKeyboardButton(f"🎉 {t['name']}", callback_data=f"tw_v_{t['id']}")])
    for t in expiries:
        kb.append([InlineKeyboardButton(f"⏰ {t['name']}", callback_data=f"tw_v_{t['id']}")])

    if rows_db:
        parts = []
        if starts:
            parts.append(f"🎉 {len(starts)} Promo Start")
        if expiries:
            parts.append(f"⏰ {len(expiries)} Promo Expire")
        text = (
            "📋 <b>Campaign Templates</b>\n\n"
            + "  ·  ".join(parts)
            + "\n\nTap a template to open its editor."
        )
    else:
        text = (
            "📋 <b>Campaign Templates</b>\n\n"
            "No active templates found.\n"
            "Create templates from the admin panel first."
        )

    kb.append([
        InlineKeyboardButton("🔄 Refresh", callback_data="tw_list"),
        InlineKeyboardButton("❌ Close", callback_data="tw_close"),
    ])
    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
            )
            return edit_msg_id
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return edit_msg_id

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    return msg.message_id


async def _show_template_view(bot, chat_id: int, admin_id: int, template_id: int, session: dict):
    tpl = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", template_id)
    if not tpl:
        await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
        return
    tpl = dict(tpl)
    session["template_data"] = tpl
    session["template_id"] = template_id

    await _cleanup_msgs(bot, chat_id, session)

    preview_text = _render_sample(tpl.get("body_text") or "")
    if not preview_text.strip():
        preview_text = "<i>(Empty template body)</i>"

    try:
        pm = await bot.send_message(
            chat_id=chat_id, text=preview_text,
            parse_mode="HTML", disable_web_page_preview=True,
        )
        session["preview_msg_id"] = pm.message_id
    except Exception as e:
        pm = await bot.send_message(
            chat_id=chat_id,
            text=f"⚠️ <b>Preview render error</b>\n<code>{escape(str(e)[:200])}</code>",
            parse_mode="HTML",
        )
        session["preview_msg_id"] = pm.message_id

    version_count = await db.fetch_val(
        "SELECT COUNT(*) FROM template_versions WHERE template_id = $1", template_id
    ) or 0

    btns_list: list = []
    raw_btns = tpl.get("inline_buttons_json")
    if raw_btns:
        try:
            btns_list = json.loads(raw_btns) or []
        except Exception:
            pass
    btn_info = (
        f"{len(btns_list)} button{'s' if len(btns_list) != 1 else ''}"
        if btns_list else "No buttons"
    )
    var_count = _count_variables(tpl.get("body_text") or "")

    updated_by = tpl.get("updated_by") or "web"
    edited_via = tpl.get("edited_via") or "web"
    via_icon = "🤖" if edited_via == "bot" else "🌐"

    info_text = (
        f"📋 <b>{escape(tpl['name'])}</b>   <i>{_tpl_type_label(tpl.get('template_type', ''))}</i>\n"
        f"Buttons: <b>{btn_info}</b>   Variables: <b>{var_count}</b>\n"
        f"Updated: <b>{_fmt_dt(tpl.get('updated_at'))}</b>\n"
        f"By: <code>{escape(str(updated_by))}</code>   Via: {via_icon} <b>{edited_via}</b>   Versions: <b>{version_count}</b>\n\n"
        f"{VARIABLES_HELP}"
    )

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✏️ Edit Message", callback_data=f"tw_em_{template_id}"),
            InlineKeyboardButton("🔘 Edit Buttons", callback_data=f"tw_eb_{template_id}"),
        ],
        [
            InlineKeyboardButton("👁️ Preview Sample", callback_data=f"tw_ps_{template_id}"),
            InlineKeyboardButton("📨 Test Send", callback_data=f"tw_ts_{template_id}"),
        ],
        [
            InlineKeyboardButton("📜 History", callback_data=f"tw_his_{template_id}"),
            InlineKeyboardButton("◀️ Back", callback_data="tw_list"),
        ],
    ])

    im = await bot.send_message(
        chat_id=chat_id, text=info_text,
        parse_mode="HTML", reply_markup=markup,
        disable_web_page_preview=True,
    )
    session["info_msg_id"] = im.message_id
    session["step"] = "view"
    _bump_session(admin_id)


async def _start_edit_message(bot, chat_id: int, admin_id: int, template_id: int, session: dict):
    if session.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        session["prompt_msg_id"] = None

    prompt = await bot.send_message(
        chat_id=chat_id,
        text=(
            "✏️ <b>Edit Template Message</b>\n\n"
            "Reply with the new template body using normal Telegram formatting.\n\n"
            "<b>Fully preserved:</b>\n"
            "  • Bold, italic, underline, strikethrough, spoiler\n"
            "  • Code, pre blocks, text links\n"
            "  • Custom emoji (animated sticker emoji)\n"
            "  • Line breaks and spacing\n\n"
            f"{VARIABLES_HELP}\n\n"
            "⏱ Session expires in 10 minutes.\n"
            "Tip: send /tw_cancel to abort."
        ),
        parse_mode="HTML",
        reply_markup=ForceReply(selective=True, input_field_placeholder="Type new message body here…"),
    )
    session["prompt_msg_id"] = prompt.message_id
    session["step"] = "edit_msg_await"
    session["template_id"] = template_id
    _bump_session(admin_id)


async def _show_button_list(bot, chat_id: int, admin_id: int, template_id: int, session: dict,
                            edit_msg_id: int | None = None) -> int:
    tpl = await db.fetch_one("SELECT id, name, inline_buttons_json FROM campaign_templates WHERE id = $1", template_id)
    if not tpl:
        await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
        return 0
    tpl = dict(tpl)
    session["template_id"] = template_id

    btns = session.get("temp_buttons")
    if btns is None:
        raw = tpl.get("inline_buttons_json") or ""
        try:
            btns = json.loads(raw) if raw else []
        except Exception:
            btns = []
        session["temp_buttons"] = [dict(b) for b in btns]
    btns = session["temp_buttons"]

    if btns:
        lines = "\n".join(_btn_summary(b, i) for i, b in enumerate(btns))
        text = (
            f"🔘 <b>Buttons — {escape(tpl['name'])}</b>\n\n"
            f"<code>{escape(lines)}</code>\n\n"
            "<i>Changes held in session. Tap Save to persist.</i>"
        )
    else:
        text = (
            f"🔘 <b>Buttons — {escape(tpl['name'])}</b>\n\n"
            "No buttons yet. Tap <b>➕ Add Button</b> to create one."
        )

    kb = []
    for i, b in enumerate(btns):
        label = (b.get("text") or "Btn")[:18]
        kb.append([
            InlineKeyboardButton(f"✏️ {i+1}. {label}", callback_data=f"tw_be_{template_id}_{i}"),
            InlineKeyboardButton("🗑 Del", callback_data=f"tw_bd_{template_id}_{i}"),
        ])

    kb.append([InlineKeyboardButton("➕ Add Button", callback_data=f"tw_ba_{template_id}")])
    if btns:
        kb.append([InlineKeyboardButton("💾 Save Buttons", callback_data=f"tw_bsave_{template_id}")])
    kb.append([
        InlineKeyboardButton("👁️ Preview", callback_data=f"tw_ps_{template_id}"),
        InlineKeyboardButton("◀️ Back", callback_data=f"tw_v_{template_id}"),
    ])
    markup = InlineKeyboardMarkup(kb)

    try:
        if edit_msg_id:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=edit_msg_id,
                text=text, parse_mode="HTML", reply_markup=markup,
            )
            session["info_msg_id"] = edit_msg_id
            session["step"] = "btn_list"
            return edit_msg_id
    except Exception as e:
        if "not modified" in str(e).lower() and edit_msg_id:
            return edit_msg_id

    msg = await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup)
    session["info_msg_id"] = msg.message_id
    session["step"] = "btn_list"
    return msg.message_id


async def _ask_button_color(bot, chat_id: int, session: dict):
    session["step"] = "btn_color"
    p = await bot.send_message(
        chat_id=chat_id,
        text="<b>Step 3/6 — Button Color</b>\n\nChoose an accent color for this button:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("None", callback_data="tw_bc_none"),
                InlineKeyboardButton("Default", callback_data="tw_bc_default"),
                InlineKeyboardButton("Primary", callback_data="tw_bc_primary"),
            ],
            [
                InlineKeyboardButton("✅ Success", callback_data="tw_bc_success"),
                InlineKeyboardButton("⚠️ Warning", callback_data="tw_bc_warning"),
                InlineKeyboardButton("🚨 Danger", callback_data="tw_bc_danger"),
            ],
            [InlineKeyboardButton("❌ Cancel", callback_data="tw_cancel")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


async def _ask_button_emoji_mode(bot, chat_id: int, session: dict):
    session["step"] = "btn_emoji_mode"
    p = await bot.send_message(
        chat_id=chat_id,
        text="<b>Step 4/6 — Emoji Mode</b>\n\nChoose how to display an emoji on this button:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("No Emoji", callback_data="tw_bem_none"),
                InlineKeyboardButton("Plain Emoji", callback_data="tw_bem_plain"),
                InlineKeyboardButton("Custom Emoji", callback_data="tw_bem_custom"),
            ],
            [InlineKeyboardButton("❌ Cancel", callback_data="tw_cancel")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


async def _ask_button_row(bot, chat_id: int, session: dict):
    session["step"] = "btn_row"
    p = await bot.send_message(
        chat_id=chat_id,
        text="<b>Step 6/6 — Button Row</b>\n\nButtons in the same row appear side by side. Choose row:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("Row 1", callback_data="tw_brow_1"),
                InlineKeyboardButton("Row 2", callback_data="tw_brow_2"),
                InlineKeyboardButton("Row 3", callback_data="tw_brow_3"),
            ],
            [
                InlineKeyboardButton("Row 4", callback_data="tw_brow_4"),
                InlineKeyboardButton("Row 5", callback_data="tw_brow_5"),
            ],
            [InlineKeyboardButton("❌ Cancel", callback_data="tw_cancel")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


async def _show_button_confirm(bot, chat_id: int, session: dict, template_id: int):
    session["step"] = "btn_confirm"
    b = session["current_button_draft"]

    mode = b.get("emoji_mode", "none")
    if mode == "plain":
        emoji_info = f"Plain: {b.get('emoji', '') or '—'}"
    elif mode == "custom":
        cid = b.get("icon_custom_emoji_id", "") or "—"
        fb = b.get("fallback_emoji", "") or "none"
        emoji_info = f"Custom ID: {cid[:20]}  Fallback: {fb}"
    else:
        emoji_info = "None"

    base = b.get("text", "Button")
    display = f"{b['emoji']} {base}".strip() if mode == "plain" and b.get("emoji") else base

    url = b.get("url", "")
    url_display = "{deep_link} (resolved at send)" if url == "{deep_link}" else url[:60]

    text = (
        "📋 <b>Button Preview</b>\n\n"
        f"<b>Label:</b>   {escape(base)}\n"
        f"<b>URL:</b>    <code>{escape(url_display)}</code>\n"
        f"<b>Color:</b>  {b.get('style', 'none') or 'none'}\n"
        f"<b>Emoji:</b>  {escape(emoji_info)}\n"
        f"<b>Row:</b>    {b.get('row', 1)}\n\n"
        f"<b>Telegram preview:</b>  [ {escape(display)} ]"
    )

    if session.get("prompt_msg_id"):
        await safe_delete_message(bot, chat_id, session["prompt_msg_id"])

    p = await bot.send_message(
        chat_id=chat_id, text=text, parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Save Button", callback_data=f"tw_bconfirm_{template_id}"),
                InlineKeyboardButton("🔄 Start Over", callback_data=f"tw_ba_{template_id}"),
            ],
            [InlineKeyboardButton("◀️ Back to Buttons", callback_data=f"tw_eb_{template_id}")],
        ]),
    )
    session["prompt_msg_id"] = p.message_id


def _build_test_markup(buttons_json: str | None) -> InlineKeyboardMarkup | None:
    if not buttons_json:
        return None
    try:
        raw = json.loads(buttons_json) or []
    except Exception:
        return None
    rows_map: dict = {}
    for b in raw:
        if not b.get("enabled", True):
            continue
        rn = int(b.get("row") or 1)
        rows_map.setdefault(rn, []).append(b)
    tg_rows = []
    for rn in sorted(rows_map.keys()):
        row = []
        for b in rows_map[rn]:
            base = (b.get("text") or "Button").strip()
            mode = b.get("emoji_mode", "none")
            btn_text = f"{b['emoji']} {base}".strip() if mode == "plain" and b.get("emoji") else base
            url = (b.get("url") or "https://t.me").strip()
            if url == "{deep_link}":
                url = SAMPLE_VALUES["deep_link"]
            if not url.startswith(("http://", "https://", "tg://")):
                url = "https://t.me"
            row.append(InlineKeyboardButton(text=btn_text, url=url))
        if row:
            tg_rows.append(row)
    return InlineKeyboardMarkup(tg_rows) if tg_rows else None


async def handle_templates_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg:
        return
    admin_id = msg.from_user.id
    if not _is_admin(admin_id):
        return
    session = _new_session(admin_id)
    list_msg_id = await _show_template_list(context.bot, msg.chat_id, admin_id)
    session["list_msg_id"] = list_msg_id
    session["step"] = "list"


async def handle_template_wizard_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    msg = update.message
    admin_id = msg.from_user.id
    chat_id = msg.chat_id
    bot = context.bot

    session = _get_session(admin_id)
    if not session:
        return False

    step = session.get("step", "")
    # Plain raw text used by all button wizard steps and as fallback
    text = (msg.text or msg.caption or "").strip()

    if step == "edit_msg_await":
        # For edit_msg_await: validate on raw text, store as HTML
        raw_text = text
        unknown = _validate_variables(raw_text)
        if unknown:
            if session.get("prompt_msg_id"):
                await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            await safe_delete_message(bot, chat_id, msg.message_id)
            p = await bot.send_message(
                chat_id=chat_id,
                text=(
                    "❌ <b>Unknown variable(s):</b>\n"
                    + "  ".join(f"<code>{{{v}}}</code>" for v in unknown)
                    + "\n\nFix and resend:\n\n"
                    + VARIABLES_HELP
                ),
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="Fix and resend…"),
            )
            session["prompt_msg_id"] = p.message_id
            return True

        # Capture full Telegram formatting as HTML, including custom emoji
        html_body = _capture_html(msg)

        # Serialise entities for forward-compatible storage
        raw_entities = msg.entities or msg.caption_entities or []
        entities_json = _entities_to_json(raw_entities)

        # Count entity types for logging and user feedback
        total_entities = len(raw_entities)
        custom_emoji_count = sum(1 for e in raw_entities if e.type == "custom_emoji")
        formatting_types = sorted({e.type for e in raw_entities} - {"custom_emoji"})

        logger.info(
            f"[template_capture] tpl_id={session.get('template_id')} "
            f"total_entities={total_entities} custom_emoji={custom_emoji_count} "
            f"formatting={formatting_types} "
            f"html_len={len(html_body)} raw_len={len(raw_text)}"
        )

        template_id = session["template_id"]
        admin_name = str(admin_id)
        await _save_template_body(template_id, html_body, admin_name, entities_json)

        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None
        await safe_delete_message(bot, chat_id, msg.message_id)

        # Build a save-confirmation line that shows what was preserved
        if total_entities:
            parts = []
            if custom_emoji_count:
                parts.append(f"{custom_emoji_count} custom emoji")
            if formatting_types:
                parts.append(", ".join(formatting_types))
            detail = " · ".join(parts)
            saved_note = f"<i>Preserved: {detail}</i>"
        else:
            saved_note = "<i>Saved as plain text — no formatting detected.</i>"

        ok = await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Template saved!</b>\n{saved_note}",
            parse_mode="HTML",
        )
        session["extra_msg_ids"].append(ok.message_id)
        session["step"] = "view"
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        await safe_delete_message(bot, chat_id, ok.message_id)
        session["extra_msg_ids"] = [m for m in session["extra_msg_ids"] if m != ok.message_id]
        return True

    elif step == STEP_BTN_NAME:
        if not text:
            return True
        session["current_button_draft"]["text"] = text
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await safe_delete_message(bot, chat_id, msg.message_id)

        session["step"] = STEP_BTN_URL
        url_prompt = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>Step 2/6 — Button URL</b>\n\n"
                "Send the full URL, or tap <b>Use Deep Link</b> below.\n"
                "Example: <code>https://t.me/YourBot?start=promo</code>"
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="https://…"),
        )
        opt_msg = await bot.send_message(
            chat_id=chat_id,
            text="Or choose:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔗 Use Deep Link", callback_data="tw_bdl"),
                InlineKeyboardButton("❌ Cancel", callback_data="tw_cancel"),
            ]]),
        )
        session["prompt_msg_id"] = url_prompt.message_id
        session["extra_msg_ids"].append(opt_msg.message_id)
        return True

    elif step == STEP_BTN_URL:
        url = text
        if not url.startswith(("http://", "https://", "tg://")):
            if session.get("prompt_msg_id"):
                await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            await safe_delete_message(bot, chat_id, msg.message_id)
            p = await bot.send_message(
                chat_id=chat_id,
                text="❌ URL must start with <code>http://</code>, <code>https://</code>, or <code>tg://</code>\n\nTry again:",
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="https://…"),
            )
            session["prompt_msg_id"] = p.message_id
            return True

        session["current_button_draft"]["url"] = url
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        for mid in session.get("extra_msg_ids", []):
            await safe_delete_message(bot, chat_id, mid)
        session["extra_msg_ids"] = []
        await safe_delete_message(bot, chat_id, msg.message_id)
        await _ask_button_color(bot, chat_id, session)
        return True

    elif step == STEP_BTN_EMOJI_CHAR:
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await safe_delete_message(bot, chat_id, msg.message_id)
        session["current_button_draft"]["emoji"] = text
        session["current_button_draft"]["emoji_mode"] = "plain"
        await _ask_button_row(bot, chat_id, session)
        return True

    elif step == STEP_BTN_EMOJI_CUSTOM_ID:
        session["current_button_draft"]["icon_custom_emoji_id"] = text
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await safe_delete_message(bot, chat_id, msg.message_id)
        session["step"] = STEP_BTN_EMOJI_FALLBACK
        p = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>Step 5b/6 — Fallback Emoji</b>\n\n"
                "Send a plain emoji as fallback for clients that don't support custom emoji.\n"
                "Example: <code>🛒</code>   Or type <code>none</code> to skip."
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="🛒 or none"),
        )
        session["prompt_msg_id"] = p.message_id
        return True

    elif step == STEP_BTN_EMOJI_FALLBACK:
        val = "" if text.lower() == "none" else text
        session["current_button_draft"]["fallback_emoji"] = val
        session["current_button_draft"]["emoji_mode"] = "custom"
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await safe_delete_message(bot, chat_id, msg.message_id)
        await _ask_button_row(bot, chat_id, session)
        return True

    return False


async def handle_template_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data or ""
    chat_id = query.message.chat_id
    admin_id = query.from_user.id
    bot = context.bot

    if not _is_admin(admin_id):
        await query.answer("Not authorized.", show_alert=True)
        return

    await query.answer()

    session = _get_session(admin_id)
    if not session:
        session = _new_session(admin_id)
    _bump_session(admin_id)

    if data == "tw_close":
        try:
            await bot.delete_message(chat_id=chat_id, message_id=query.message.message_id)
        except Exception:
            pass
        await _cleanup_msgs(bot, chat_id, session)
        _clear_session(admin_id)
        return

    if data == "tw_list":
        await _cleanup_msgs(bot, chat_id, session)
        session["temp_buttons"] = None
        list_id = await _show_template_list(bot, chat_id, admin_id, edit_msg_id=query.message.message_id)
        session["list_msg_id"] = list_id
        session["step"] = "list"
        return

    if data.startswith("tw_v_"):
        try:
            template_id = int(data[5:])
        except ValueError:
            return
        await _cleanup_msgs(bot, chat_id, session)
        session["temp_buttons"] = None
        try:
            await bot.delete_message(chat_id=chat_id, message_id=query.message.message_id)
        except Exception:
            pass
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        return

    if data.startswith("tw_em_"):
        try:
            template_id = int(data[6:])
        except ValueError:
            return
        await _start_edit_message(bot, chat_id, admin_id, template_id, session)
        return

    if data.startswith("tw_eb_"):
        try:
            template_id = int(data[6:])
        except ValueError:
            return
        session["temp_buttons"] = None
        await _cleanup_msgs(bot, chat_id, session)
        try:
            await bot.delete_message(chat_id=chat_id, message_id=query.message.message_id)
        except Exception:
            pass
        await _show_button_list(bot, chat_id, admin_id, template_id, session)
        return

    if data.startswith("tw_ps_"):
        try:
            template_id = int(data[6:])
        except ValueError:
            return
        tpl = await db.fetch_one("SELECT body_text, name FROM campaign_templates WHERE id = $1", template_id)
        if not tpl:
            await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
            return
        rendered = _render_sample(dict(tpl).get("body_text") or "")
        if not rendered.strip():
            rendered = "<i>(Empty template body)</i>"
        try:
            await bot.send_message(
                chat_id=chat_id, text=rendered,
                parse_mode="HTML", disable_web_page_preview=True,
            )
        except Exception as e:
            await bot.send_message(
                chat_id=chat_id,
                text=f"⚠️ Preview failed:\n<code>{escape(str(e)[:200])}</code>",
                parse_mode="HTML",
            )
        return

    if data.startswith("tw_ts_"):
        try:
            template_id = int(data[6:])
        except ValueError:
            return
        tpl = await db.fetch_one("SELECT * FROM campaign_templates WHERE id = $1", template_id)
        if not tpl:
            await bot.send_message(chat_id=chat_id, text="❌ Template not found.")
            return
        tpl = dict(tpl)
        rendered = _render_sample(tpl.get("body_text") or "")
        if not rendered.strip():
            rendered = "<i>(Empty template body)</i>"
        markup = _build_test_markup(tpl.get("inline_buttons_json"))
        try:
            await bot.send_message(
                chat_id=chat_id, text=rendered,
                parse_mode="HTML", reply_markup=markup, disable_web_page_preview=True,
            )
            await bot.send_message(
                chat_id=chat_id,
                text="✅ <b>Test sent!</b> This is how it looks to users.",
                parse_mode="HTML",
            )
        except Exception as e:
            await bot.send_message(
                chat_id=chat_id,
                text=f"❌ Send failed:\n<code>{escape(str(e)[:300])}</code>",
                parse_mode="HTML",
            )
        return

    if data.startswith("tw_his_"):
        try:
            template_id = int(data[7:])
        except ValueError:
            return
        versions = await db.fetch_all(
            """SELECT id, changed_by, changed_via, change_note, created_at
               FROM template_versions WHERE template_id = $1
               ORDER BY created_at DESC LIMIT 10""",
            template_id,
        )
        versions = [dict(v) for v in (versions or [])]
        if not versions:
            await bot.send_message(chat_id=chat_id, text="📜 No version history yet for this template.", parse_mode="HTML")
            return

        kb = []
        lines = ["📜 <b>Version History</b> (last 10)\n"]
        for i, v in enumerate(versions):
            dt = _fmt_dt(v["created_at"])
            by = escape(str(v.get("changed_by") or "?"))
            via = v.get("changed_via") or "?"
            note = escape((v.get("change_note") or "")[:50])
            lines.append(f"{i+1}.  {dt}\n    By: <code>{by}</code>  ·  Via: {via}\n    {note}")
            kb.append([InlineKeyboardButton(f"↩️ Restore #{i+1}", callback_data=f"tw_rst_{template_id}_{v['id']}")])

        kb.append([InlineKeyboardButton("◀️ Back", callback_data=f"tw_v_{template_id}")])
        await bot.send_message(
            chat_id=chat_id,
            text="\n".join(lines),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(kb),
        )
        return

    if data.startswith("tw_rst_"):
        parts = data[7:].split("_", 1)
        if len(parts) != 2:
            return
        try:
            template_id, version_id = int(parts[0]), int(parts[1])
        except ValueError:
            return
        version = await db.fetch_one(
            "SELECT * FROM template_versions WHERE id = $1 AND template_id = $2",
            version_id, template_id,
        )
        if not version:
            await bot.send_message(chat_id=chat_id, text="❌ Version not found.")
            return
        version = dict(version)
        updated_by = f"{admin_id}(restore)"
        await _save_template_body(template_id, version["body_text"], updated_by)
        if version.get("inline_buttons_json"):
            try:
                btns = json.loads(version["inline_buttons_json"])
                await _save_template_buttons(template_id, btns, updated_by)
            except Exception:
                pass
        session["temp_buttons"] = None
        ok = await bot.send_message(chat_id=chat_id, text="✅ <b>Version restored!</b>", parse_mode="HTML")
        session["extra_msg_ids"].append(ok.message_id)
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        return

    if data == "tw_cancel":
        template_id = session.get("template_id")
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None
        for mid in session.get("extra_msg_ids", []):
            await safe_delete_message(bot, chat_id, mid)
        session["extra_msg_ids"] = []
        session["current_button_draft"] = {}
        session["button_edit_idx"] = None
        if template_id:
            session["step"] = "view"
            await _show_template_view(bot, chat_id, admin_id, template_id, session)
        else:
            list_id = await _show_template_list(bot, chat_id, admin_id)
            session["list_msg_id"] = list_id
            session["step"] = "list"
        return

    if data.startswith("tw_ba_"):
        try:
            template_id = int(data[6:])
        except ValueError:
            return
        session["current_button_draft"] = {}
        session["button_edit_idx"] = None
        session["template_id"] = template_id
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        session["step"] = STEP_BTN_NAME
        p = await bot.send_message(
            chat_id=chat_id,
            text=(
                "<b>Step 1/6 — Button Label</b>\n\n"
                "Enter the button text that users will see:\n"
                "Example: <code>Buy Now</code>"
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="Button label…"),
        )
        session["prompt_msg_id"] = p.message_id
        return

    if data == "tw_bdl":
        session["current_button_draft"]["url"] = "{deep_link}"
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        for mid in session.get("extra_msg_ids", []):
            await safe_delete_message(bot, chat_id, mid)
        session["extra_msg_ids"] = []
        session["prompt_msg_id"] = None
        await _ask_button_color(bot, chat_id, session)
        return

    if data.startswith("tw_bc_"):
        color = data[6:]
        if color not in BUTTON_COLORS:
            return
        session["current_button_draft"]["style"] = "" if color == "none" else color
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        await _ask_button_emoji_mode(bot, chat_id, session)
        return

    if data.startswith("tw_bem_"):
        mode = data[7:]
        if mode not in ("none", "plain", "custom"):
            return
        session["current_button_draft"]["emoji_mode"] = mode
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        if mode == "none":
            session["current_button_draft"].update({"emoji": "", "icon_custom_emoji_id": "", "fallback_emoji": ""})
            await _ask_button_row(bot, chat_id, session)
        elif mode == "plain":
            session["step"] = STEP_BTN_EMOJI_CHAR
            p = await bot.send_message(
                chat_id=chat_id,
                text="<b>Step 5/6 — Emoji Character</b>\n\nSend the emoji to show on the button:\nExample: <code>🛒</code>",
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="🛒"),
            )
            session["prompt_msg_id"] = p.message_id
        elif mode == "custom":
            session["step"] = STEP_BTN_EMOJI_CUSTOM_ID
            p = await bot.send_message(
                chat_id=chat_id,
                text=(
                    "<b>Step 5a/6 — Custom Emoji ID</b>\n\n"
                    "Send the Telegram custom emoji ID:\n"
                    "Example: <code>5368324170671202286</code>"
                ),
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="Custom emoji ID…"),
            )
            session["prompt_msg_id"] = p.message_id
        return

    if data.startswith("tw_brow_"):
        try:
            row = int(data[8:])
        except ValueError:
            return
        session["current_button_draft"]["row"] = row
        session["current_button_draft"].setdefault("enabled", True)
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        template_id = session.get("template_id")
        await _show_button_confirm(bot, chat_id, session, template_id)
        return

    if data.startswith("tw_bconfirm_"):
        try:
            template_id = int(data[12:])
        except ValueError:
            return
        draft = dict(session.get("current_button_draft", {}))
        edit_idx = session.get("button_edit_idx")
        btns = list(session.get("temp_buttons") or [])
        if edit_idx is not None and 0 <= edit_idx < len(btns):
            btns[edit_idx] = draft
        else:
            btns.append(draft)
        session["temp_buttons"] = btns
        session["current_button_draft"] = {}
        session["button_edit_idx"] = None
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None
        await _show_button_list(bot, chat_id, admin_id, template_id, session)
        return

    if data.startswith("tw_be_"):
        rest = data[6:]
        parts = rest.rsplit("_", 1)
        if len(parts) != 2:
            return
        try:
            template_id, idx = int(parts[0]), int(parts[1])
        except ValueError:
            return
        btns = session.get("temp_buttons") or []
        if idx < 0 or idx >= len(btns):
            return
        session["current_button_draft"] = dict(btns[idx])
        session["button_edit_idx"] = idx
        session["template_id"] = template_id
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
        session["step"] = STEP_BTN_NAME
        p = await bot.send_message(
            chat_id=chat_id,
            text=(
                f"<b>Edit Button #{idx+1} — Label</b>\n\n"
                f"Current: <code>{escape(btns[idx].get('text', ''))}</code>\n\n"
                "Send the new button label:"
            ),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="Button label…"),
        )
        session["prompt_msg_id"] = p.message_id
        return

    if data.startswith("tw_bd_"):
        rest = data[6:]
        parts = rest.rsplit("_", 1)
        if len(parts) != 2:
            return
        try:
            template_id, idx = int(parts[0]), int(parts[1])
        except ValueError:
            return
        btns = list(session.get("temp_buttons") or [])
        removed_name = ""
        if 0 <= idx < len(btns):
            removed_name = btns[idx].get("text", "")
            btns.pop(idx)
        session["temp_buttons"] = btns
        await _show_button_list(bot, chat_id, admin_id, template_id, session,
                                edit_msg_id=query.message.message_id)
        return

    if data.startswith("tw_bsave_"):
        try:
            template_id = int(data[9:])
        except ValueError:
            return
        btns = list(session.get("temp_buttons") or [])
        await _save_template_buttons(template_id, btns, str(admin_id))
        session["temp_buttons"] = None
        if session.get("prompt_msg_id"):
            await safe_delete_message(bot, chat_id, session["prompt_msg_id"])
            session["prompt_msg_id"] = None
        count = len(btns)
        ok = await bot.send_message(
            chat_id=chat_id,
            text=f"✅ <b>Buttons saved!</b>  ({count} button{'s' if count != 1 else ''})",
            parse_mode="HTML",
        )
        session["extra_msg_ids"].append(ok.message_id)
        await _show_template_view(bot, chat_id, admin_id, template_id, session)
        return
