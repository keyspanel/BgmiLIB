import re
import logging
import secrets
from datetime import datetime, timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))
from html import escape
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, LinkPreviewOptions, ForceReply
from telegram.ext import ContextTypes
from bot import database as db
from bot.config import ADMIN_CHAT_ID
from bot import settings
from bot.services.categories import extract_custom_emoji_and_clean_name, get_telegram_style
from bot.services.profile_sync import sync_profile_photo
from bot.cleanup import (
    cleanup_all_user_browsing_state,
    safe_delete_message,
    cleanup_old_start_thread,
    save_start_thread,
    cleanup_user_howto_messages,
    save_user_howto_message_ids,
    save_user_mykeys_user_message_id,
    save_user_mykeys_pin_notice_message_id,
    cleanup_reseller_temp_thread,
    save_reseller_temp_thread,
    cleanup_reseller_wrong_attempt,
    save_reseller_wrong_attempt,
    save_reseller_success_result_msg_id,
    save_last_key_delivery_message_id,
)
from bot.services.categories import send_categories
from bot.services.keys_viewer import send_purchased_keys_viewer
from bot.services.reseller import assign_reseller_code
from bot.handlers.broadcast_wizard import handle_broadcast_wizard_message, is_broadcast_wizard_active, is_broadcast_pinned_message
from bot.handlers.templates_wizard import handle_template_wizard_message, is_template_wizard_active
from bot.handlers.trial_templates_wizard import handle_trial_template_wizard_message, is_trial_template_wizard_active
from bot.handlers.botsettings_wizard import handle_botsettings_message, is_botsettings_wizard_active

logger = logging.getLogger(__name__)


async def handle_pin_service_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg:
        return

    pinned = msg.pinned_message
    if pinned and msg.chat.type == "private":
        user = await get_user(msg.chat_id)
        if user:
            viewer_mid = int(user.get("active_keys_viewer_message_id") or 0)
            if viewer_mid > 0 and pinned.message_id == viewer_mid:
                await save_user_mykeys_pin_notice_message_id(user["id"], msg.message_id)
                return

            reseller_success_mid = int(user.get("reseller_success_result_msg_id") or 0)
            if reseller_success_mid > 0 and pinned.message_id == reseller_success_mid:
                return

            key_delivery_mid = int(user.get("last_key_delivery_message_id") or 0)
            if key_delivery_mid > 0 and pinned.message_id == key_delivery_mid:
                return

        bc_row = await db.fetch_one(
            "SELECT id FROM discount_broadcast_messages WHERE telegram_id = $1 AND broadcast_message_id = $2",
            msg.chat_id, pinned.message_id
        )
        if bc_row:
            try:
                await db.execute(
                    "UPDATE discount_broadcast_messages SET pin_service_message_id = $1 WHERE id = $2",
                    msg.message_id, bc_row["id"]
                )
            except Exception as e:
                logger.debug(f"Failed to store pin service message id: {e}")
            return

        if is_broadcast_pinned_message(msg.chat_id, pinned.message_id):
            return

    try:
        await context.bot.delete_message(chat_id=msg.chat_id, message_id=msg.message_id)
    except Exception:
        pass


async def get_user(telegram_id: int) -> dict | None:
    row = await db.fetch_one(
        "SELECT * FROM users WHERE telegram_id = $1 LIMIT 1",
        telegram_id
    )
    return dict(row) if row else None


async def create_user_if_not_exists(tg_user) -> dict:
    telegram_id = tg_user.id
    username = tg_user.username
    first_name = tg_user.first_name
    last_name = tg_user.last_name

    user = await get_user(telegram_id)

    if user:
        if (user.get("username") != username or
            user.get("first_name") != first_name or
            user.get("last_name") != last_name):
            await db.execute(
                "UPDATE users SET username = $1, first_name = $2, last_name = $3 WHERE id = $4",
                username, first_name, last_name, user["id"]
            )
            user["username"] = username
            user["first_name"] = first_name
            user["last_name"] = last_name
        return user

    token = secrets.token_hex(16)

    row = await db.fetch_one(
        """INSERT INTO users (telegram_id, username, first_name, last_name, token)
           VALUES ($1, $2, $3, $4, $5)
           RETURNING *""",
        telegram_id, username, first_name, last_name, token
    )
    return dict(row)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.from_user:
        return
    try:
        await _handle_message_inner(update, context)
    except Exception:
        logger.exception("Unhandled error in handle_message")
        try:
            await update.message.reply_text("Something went wrong. Please try again.")
        except Exception:
            pass


async def _handle_message_inner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await settings.reload_settings()

    msg = update.message
    chat_id = msg.chat_id
    from_user = msg.from_user
    bot = context.bot

    user = await create_user_if_not_exists(from_user)

    if user.get("is_banned"):
        await bot.send_message(chat_id=chat_id, text=settings.get("msg_banned"), parse_mode="HTML")
        return

    text = (msg.text or "").strip()
    telegram_id = from_user.id

    if telegram_id == ADMIN_CHAT_ID:
        if is_broadcast_wizard_active(telegram_id):
            handled = await handle_broadcast_wizard_message(update, context)
            if handled:
                return
        if is_template_wizard_active(telegram_id):
            handled = await handle_template_wizard_message(update, context)
            if handled:
                return
        if is_trial_template_wizard_active(telegram_id):
            handled = await handle_trial_template_wizard_message(update, context)
            if handled:
                return
        if is_botsettings_wizard_active(telegram_id):
            handled = await handle_botsettings_message(update, context)
            if handled:
                return

        m = re.match(r'^/setapk\s+(\d+)$', text, re.IGNORECASE)
        if m:
            await _handle_setapk(bot, msg, user, int(m.group(1)))
            return

        m = re.match(r'^/removeapk\s+(\d+)$', text, re.IGNORECASE)
        if m:
            await _handle_removeapk(bot, chat_id, int(m.group(1)))
            return

    btn_my_keys_raw = settings.get("bot_btn_my_keys")
    btn_how_to_raw = settings.get("bot_btn_how_to")
    _mykeys_clean = extract_custom_emoji_and_clean_name(btn_my_keys_raw)["name"] or btn_my_keys_raw
    _howto_clean = extract_custom_emoji_and_clean_name(btn_how_to_raw)["name"] or btn_how_to_raw

    if text == _mykeys_clean:
        await send_purchased_keys_viewer(bot, chat_id, user, page=1)
        await save_user_mykeys_user_message_id(user["id"], msg.message_id)
        return

    if text == _howto_clean:
        await cleanup_user_howto_messages(bot, user, chat_id)
        how_to_text = settings.get("bot_how_to_text")
        bot_msg = await bot.send_message(
            chat_id=chat_id,
            text=how_to_text,
            parse_mode="HTML"
        )
        await save_user_howto_message_ids(user["id"], msg.message_id, bot_msg.message_id)
        return

    if text == "/start" or text.startswith("/start "):
        deep_link_arg = text[7:].strip() if text.startswith("/start ") else ""
        import asyncio
        asyncio.create_task(sync_profile_photo(bot, from_user.id, user["id"], force=True))
        await _handle_start(bot, msg, user, from_user, deep_link_arg=deep_link_arg)
        return

    if text == "/level":
        await cleanup_reseller_temp_thread(bot, user["id"], chat_id)
        await db.execute("UPDATE users SET awaiting_code = 1 WHERE id = $1", user["id"])
        prompt_msg = await bot.send_message(
            chat_id=chat_id,
            text=settings.get("msg_reseller_prompt"),
            parse_mode="HTML",
            reply_markup=ForceReply(selective=True, input_field_placeholder="Enter 6-digit code"),
        )
        await save_reseller_temp_thread(user["id"], msg.message_id, prompt_msg.message_id)
        return

    if user.get("awaiting_code"):
        if text.lower() == "/cancel":
            await cleanup_reseller_temp_thread(bot, user["id"], chat_id)
            await db.execute("UPDATE users SET awaiting_code = 0 WHERE id = $1", user["id"])
            await bot.send_message(
                chat_id=chat_id,
                text=settings.get("msg_reseller_cancelled"),
                parse_mode="HTML",
            )
            return

        code = re.sub(r'\D', '', text)
        if len(code) == 6:
            result = await assign_reseller_code(user, code)
            msg_text = result.get("text", "")
            result_type = result.get("result", "")

            if result_type in ("activated", "already_active"):
                await cleanup_reseller_wrong_attempt(bot, user["id"], chat_id)
                fresh = await db.fetch_one(
                    "SELECT reseller_prompt_msg_id FROM users WHERE id = $1 LIMIT 1",
                    user["id"]
                )
                prompt_mid = int((fresh.get("reseller_prompt_msg_id") if fresh else None) or 0)
                if prompt_mid > 0:
                    await safe_delete_message(bot, chat_id, prompt_mid)
                await db.execute(
                    "UPDATE users SET reseller_level_trigger_msg_id = NULL, reseller_prompt_msg_id = NULL, reseller_wrong_code_msg_id = NULL, reseller_wrong_result_msg_id = NULL, awaiting_code = 0 WHERE id = $1",
                    user["id"]
                )
                resp = await bot.send_message(chat_id=chat_id, text=msg_text, parse_mode="HTML")
                await save_reseller_success_result_msg_id(user["id"], resp.message_id)
                try:
                    await bot.pin_chat_message(chat_id=chat_id, message_id=resp.message_id, disable_notification=True)
                except Exception:
                    pass
            elif result_type == "error":
                await cleanup_reseller_wrong_attempt(bot, user["id"], chat_id)
                await db.execute("UPDATE users SET awaiting_code = 0 WHERE id = $1", user["id"])
                resp = await bot.send_message(chat_id=chat_id, text=msg_text, parse_mode="HTML")
                await save_reseller_wrong_attempt(user["id"], msg.message_id, resp.message_id)
            else:
                await cleanup_reseller_wrong_attempt(bot, user["id"], chat_id)
                resp = await bot.send_message(
                    chat_id=chat_id,
                    text=msg_text,
                    parse_mode="HTML",
                    reply_markup=ForceReply(selective=True, input_field_placeholder="Enter 6-digit code"),
                )
                await save_reseller_wrong_attempt(user["id"], msg.message_id, resp.message_id)
        else:
            await cleanup_reseller_wrong_attempt(bot, user["id"], chat_id)
            resp = await bot.send_message(
                chat_id=chat_id,
                text=settings.get("msg_invalid_code_format"),
                parse_mode="HTML",
                reply_markup=ForceReply(selective=True, input_field_placeholder="Enter 6-digit code"),
            )
            await save_reseller_wrong_attempt(user["id"], msg.message_id, resp.message_id)
        return


async def _handle_start(bot, msg, user, from_user, deep_link_arg=""):
    chat_id = msg.chat_id
    user_start_msg_id = msg.message_id

    if deep_link_arg and deep_link_arg.startswith("promo_"):
        try:
            from bot.services.campaigns import resolve_deep_link, record_deep_link_event, upsert_campaign_attribution
            link_data = await resolve_deep_link(deep_link_arg)
            if link_data:
                campaign_id      = link_data["campaign_id"]
                deep_link_id     = link_data.get("id")
                campaign_run_id  = link_data.get("campaign_run_id")
                attribution_end  = link_data.get("attribution_end_at")
                # Record the open event with per-run context
                await record_deep_link_event(
                    campaign_id, deep_link_arg,
                    from_user.id, from_user.username or "", "open",
                    campaign_run_id=campaign_run_id,
                    deep_link_id=deep_link_id,
                )
                # Store code on user for payment-time attribution lookup
                await db.execute(
                    "UPDATE users SET campaign_deep_link_code = $1 WHERE id = $2",
                    deep_link_arg, user["id"]
                )
                # Persist attribution — expiry is tied to campaign run's attribution_end_at
                await upsert_campaign_attribution(
                    user["id"], from_user.id, campaign_id, deep_link_arg,
                    campaign_run_id=campaign_run_id,
                    deep_link_id=deep_link_id,
                    attribution_end_at=attribution_end,
                )
                logger.info(
                    f"Deep link: user_id={user['id']} (tg={from_user.id}) opened "
                    f"campaign #{campaign_id} run #{campaign_run_id} via {deep_link_arg} "
                    f"(attribution_end={attribution_end})"
                )
            else:
                logger.info(f"Deep link {deep_link_arg!r} resolved to no active campaign (inactive or missing)")
        except Exception as e:
            logger.warning(f"Deep link tracking error: {e}", exc_info=True)

    now_ist = datetime.now(IST)
    today_str = now_ist.strftime("%Y-%m-%d")

    await cleanup_old_start_thread(bot, user, chat_id, today_str)

    from bot.services.force_join import cleanup_force_join_for_start
    await cleanup_force_join_for_start(bot, chat_id, from_user.id)

    await cleanup_all_user_browsing_state(bot, user, chat_id)

    first_name = (user.get("first_name") or from_user.first_name or "").strip()
    username = (user.get("username") or from_user.username or "").strip()
    display_name = first_name or username or "there"
    display_name_esc = escape(display_name)

    tg_user_id = from_user.id
    preview_url = settings.get("start_preview_url").strip()
    name_link = f'<a href="tg://user?id={tg_user_id}">{display_name_esc}</a>'

    greeting_tpl = settings.get("welcome_greeting")
    brand_name = settings.get_brand_name()
    welcome_greeting = (greeting_tpl
        .replace("{name_link}", name_link)
        .replace("{first_name}", display_name_esc)
        .replace("{brand}", brand_name))

    welcome_values = {
        "welcome_greeting_raw": welcome_greeting,
        "name_link_raw": name_link,
        "first_name": display_name,
        "brand_raw": brand_name,
        "welcome_title_raw": settings.get_resolved("bot_welcome_msg"),
        "welcome_body_raw": settings.get_resolved("bot_welcome_instruction"),
    }

    welcome_text = settings.fmt("tpl_welcome", welcome_values)
    if preview_url:
        welcome_text = f'<a href="{escape(preview_url)}">\u200b</a>{welcome_text}'

    btn_my_keys_raw = settings.get("bot_btn_my_keys")
    btn_how_to_raw = settings.get("bot_btn_how_to")
    mykeys_parsed = extract_custom_emoji_and_clean_name(btn_my_keys_raw)
    howto_parsed = extract_custom_emoji_and_clean_name(btn_how_to_raw)

    mykeys_kwargs = {}
    mykeys_style_val = settings.get("reply_mykeys_style")
    mykeys_style = get_telegram_style(mykeys_style_val)
    if mykeys_style:
        mykeys_kwargs["style"] = mykeys_style
    mykeys_emoji = settings.get("reply_mykeys_emoji_id").strip()
    if mykeys_emoji:
        mykeys_kwargs["icon_custom_emoji_id"] = mykeys_emoji
    elif mykeys_parsed["emoji_id"]:
        mykeys_kwargs["icon_custom_emoji_id"] = mykeys_parsed["emoji_id"]

    howto_kwargs = {}
    howto_style_val = settings.get("reply_howto_style")
    howto_style = get_telegram_style(howto_style_val)
    if howto_style:
        howto_kwargs["style"] = howto_style
    howto_emoji = settings.get("reply_howto_emoji_id").strip()
    if howto_emoji:
        howto_kwargs["icon_custom_emoji_id"] = howto_emoji
    elif howto_parsed["emoji_id"]:
        howto_kwargs["icon_custom_emoji_id"] = howto_parsed["emoji_id"]

    mykeys_text = mykeys_parsed["name"] or btn_my_keys_raw
    howto_text = howto_parsed["name"] or btn_how_to_raw

    kb_rows = [
        [KeyboardButton(mykeys_text, api_kwargs=mykeys_kwargs if mykeys_kwargs else None)],
        [KeyboardButton(howto_text, api_kwargs=howto_kwargs if howto_kwargs else None)],
    ]

    reply_kb = ReplyKeyboardMarkup(
        kb_rows,
        resize_keyboard=True,
        one_time_keyboard=False,
        is_persistent=False,
        selective=False,
    )

    if preview_url:
        welcome_msg = await bot.send_message(
            chat_id=chat_id,
            text=welcome_text,
            reply_markup=reply_kb,
            parse_mode="HTML",
            link_preview_options=LinkPreviewOptions(
                is_disabled=False,
                show_above_text=True,
                url=preview_url,
                prefer_large_media=True,
            )
        )
    else:
        welcome_msg = await bot.send_message(
            chat_id=chat_id,
            text=welcome_text,
            reply_markup=reply_kb,
            parse_mode="HTML"
        )

    cat_resp = await send_categories(bot, chat_id)
    cat_msg_id = cat_resp.get("message_id") if cat_resp else None

    await save_start_thread(user["id"], user_start_msg_id, welcome_msg.message_id, cat_msg_id, today_str)


async def _handle_setapk(bot, msg, user, category_id: int):
    chat_id = msg.chat_id

    cat = await db.fetch_one("SELECT * FROM categories WHERE id = $1 LIMIT 1", category_id)
    if not cat:
        await bot.send_message(chat_id=chat_id, text=f"\u274c Category ID <code>{category_id}</code> not found.", parse_mode="HTML")
        return

    if not msg.reply_to_message:
        await bot.send_message(chat_id=chat_id, text=f"\u274c Reply to the APK file message with:\n<code>/setapk {category_id}</code>", parse_mode="HTML")
        return

    reply_msg = msg.reply_to_message
    if not reply_msg.document:
        await bot.send_message(
            chat_id=chat_id,
            text=f"\u274c The replied message does not contain a document.\n\nReply to the APK file message with:\n<code>/setapk {category_id}</code>",
            parse_mode="HTML"
        )
        return

    doc = reply_msg.document
    file_id = doc.file_id or ""
    file_name = doc.file_name or ""
    mime_type = doc.mime_type or ""

    if not file_id:
        await bot.send_message(chat_id=chat_id, text="\u274c Failed to read Telegram file_id from the replied APK.", parse_mode="HTML")
        return

    if not file_name or not file_name.lower().endswith(".apk"):
        await bot.send_message(
            chat_id=chat_id,
            text=f"\u274c Only <b>.apk</b> files are allowed.\n\nCurrent file: <code>{escape(file_name)}</code>",
            parse_mode="HTML"
        )
        return

    await db.execute("UPDATE categories SET file_id = $1 WHERE id = $2", file_id, category_id)

    await bot.send_message(
        chat_id=chat_id,
        text=(
            "\u2705 <b>APK updated successfully</b>\n\n"
            f"<b>Category:</b> {escape(cat['name'])}\n"
            f"<b>Category ID:</b> <code>{category_id}</code>\n"
            f"<b>File Name:</b> <code>{escape(file_name)}</code>\n"
            f"<b>MIME:</b> <code>{escape(mime_type)}</code>\n\n"
            "Now users who tap this category will get the updated APK."
        ),
        parse_mode="HTML"
    )


async def _handle_removeapk(bot, chat_id: int, category_id: int):
    cat = await db.fetch_one("SELECT * FROM categories WHERE id = $1 LIMIT 1", category_id)
    if not cat:
        await bot.send_message(chat_id=chat_id, text=f"\u274c Category ID <code>{category_id}</code> not found.", parse_mode="HTML")
        return

    await db.execute("UPDATE categories SET file_id = NULL WHERE id = $1", category_id)

    await bot.send_message(
        chat_id=chat_id,
        text=f"\u2705 APK removed from category:\n<b>{escape(cat['name'])}</b>",
        parse_mode="HTML"
    )
