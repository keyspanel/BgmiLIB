import re
import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes
from bot.handlers.messages import create_user_if_not_exists
from bot.cleanup import (
    save_user_category_message_id,
    safe_delete_message,
    cleanup_user_durations_message,
)
from bot.services.categories import send_categories, send_durations
from bot.services.keys_viewer import edit_purchased_keys_viewer
from bot.payment import handle_buy, handle_verify
from bot import settings
from bot.handlers.broadcast_wizard import handle_broadcast_callback
from bot.handlers.templates_wizard import handle_template_callback
from bot.handlers.trial_templates_wizard import handle_trial_template_callback
from bot.handlers.botsettings_wizard import handle_botsettings_callback
from bot.services.force_join import (
    get_active_channels,
    check_membership,
    send_force_join_prompt,
    handle_verify_callback as fj_handle_verify,
    cleanup_force_join_prompt,
    clear_pending,
    cancel_auto_check,
)

logger = logging.getLogger(__name__)


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not query or not query.from_user:
        return
    try:
        await _handle_callback_inner(update, context)
    except Exception:
        logger.exception("Unhandled error in handle_callback")
        try:
            await update.callback_query.answer(text="Something went wrong.", show_alert=True)
        except Exception:
            pass


async def _handle_callback_inner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data or ""
    chat_id = query.message.chat_id
    from_user = query.from_user
    bot = context.bot

    await settings.reload_settings()

    if data.startswith("bw_"):
        await handle_broadcast_callback(update, context)
        return

    if data.startswith("tw_"):
        await handle_template_callback(update, context)
        return

    if data.startswith("ttw_"):
        await handle_trial_template_callback(update, context)
        return

    if data.startswith("bs_"):
        await handle_botsettings_callback(update, context)
        return

    user = await create_user_if_not_exists(from_user)

    if user.get("is_banned"):
        await query.answer(text=settings.get("cb_banned"), show_alert=True)
        return

    if data == "fj_verify":
        result = await fj_handle_verify(bot, user, chat_id, query)
        if result:
            cat_id = result["cat_id"]
            dur_id = result["dur_id"]
            discount_plan_id = result.get("discount_plan_id", 0)

            if cat_id == 0 and dur_id == 0:
                cat_resp = await send_categories(bot, chat_id)
                return

            is_reseller = bool(user.get("reseller_id"))
            if not is_reseller and discount_plan_id > 0:
                from bot.services.user_discount import get_active_discount_plan, invalidate_cache
                invalidate_cache()
                active_plan = await get_active_discount_plan()
                active_plan_id = active_plan["id"] if active_plan else 0
                if active_plan_id != discount_plan_id:
                    title = settings.get("discount_offer_ended_title")
                    body = settings.get("discount_offer_ended_body")
                    await bot.send_message(
                        chat_id=chat_id,
                        text=f"{title}\n\n{body}",
                        parse_mode="HTML"
                    )
                    return

            await handle_buy(bot, user, chat_id, cat_id, dur_id)
        return

    m = re.match(r'^cat_(\d+)', data)
    if m:
        cat_id = int(m.group(1))
        message_id = query.message.message_id

        await query.answer()

        res = await send_durations(bot, chat_id, message_id, cat_id, user)

        if not res.get("ok"):
            reason = res.get("reason", "")
            if reason == "invalid_category":
                popup = settings.get("cb_category_unavailable")
            elif reason == "no_durations":
                popup = settings.get("cb_no_durations")
            else:
                popup = settings.get("cb_category_error")
            try:
                await bot.send_message(chat_id=chat_id, text=popup, parse_mode="HTML")
            except Exception:
                pass
        return

    if data == "categories_menu":
        message_id = query.message.message_id
        await query.answer()

        await safe_delete_message(bot, chat_id, message_id)
        from bot.cleanup import clear_user_durations_message_id
        await clear_user_durations_message_id(user["id"])

        cat_resp = await send_categories(bot, chat_id)
        cat_msg_id = cat_resp.get("message_id") if cat_resp else None
        await save_user_category_message_id(user["id"], cat_msg_id)
        return

    m = re.match(r'^buy_(\d+)_(\d+)(?:_(\d+))?', data)
    if m:
        cat_id = int(m.group(1))
        dur_id = int(m.group(2))
        btn_discount_plan_id = int(m.group(3)) if m.group(3) else 0

        is_reseller = bool(user.get("reseller_id"))
        if not is_reseller and btn_discount_plan_id > 0:
            from bot.services.user_discount import get_active_discount_plan, invalidate_cache
            invalidate_cache()
            active_plan = await get_active_discount_plan()
            active_plan_id = active_plan["id"] if active_plan else 0
            if active_plan_id != btn_discount_plan_id:
                await query.answer()
                title = settings.get("discount_offer_ended_title")
                body = settings.get("discount_offer_ended_body")
                dur_msg_id = query.message.message_id
                await safe_delete_message(bot, chat_id, dur_msg_id)
                from bot.cleanup import clear_user_durations_message_id
                await clear_user_durations_message_id(user["id"])
                await bot.send_message(
                    chat_id=chat_id,
                    text=f"{title}\n\n{body}",
                    parse_mode="HTML"
                )
                return

        channels = await get_active_channels()
        if channels:
            all_joined, missing = await check_membership(bot, from_user.id, channels)
            if not all_joined:
                await query.answer()
                dur_msg_id = query.message.message_id
                await safe_delete_message(bot, chat_id, dur_msg_id)
                from bot.cleanup import clear_user_durations_message_id
                await clear_user_durations_message_id(user["id"])
                from bot import database as _db
                cat_row = await _db.fetch_one("SELECT name FROM categories WHERE id = $1 LIMIT 1", cat_id)
                dur_row = await _db.fetch_one("SELECT name FROM durations WHERE id = $1 LIMIT 1", dur_id)
                _cat_name = cat_row["name"] if cat_row else ""
                _dur_name = dur_row["name"] if dur_row else ""
                await send_force_join_prompt(
                    bot, chat_id, from_user.id, channels, missing,
                    cat_id, dur_id, btn_discount_plan_id,
                    cat_name=_cat_name, dur_name=_dur_name,
                    first_name=from_user.first_name or "",
                    username=from_user.username or "",
                )
                return

        await query.answer(text=settings.get("cb_generating_qr"), show_alert=False)

        dur_msg_id = query.message.message_id
        await safe_delete_message(bot, chat_id, dur_msg_id)
        from bot.cleanup import clear_user_durations_message_id
        await clear_user_durations_message_id(user["id"])

        await handle_buy(bot, user, chat_id, cat_id, dur_id)
        return

    m = re.match(r'^pkeys_(\d+)$', data)
    if m:
        page = int(m.group(1))
        await query.answer()
        await edit_purchased_keys_viewer(bot, chat_id, query.message.message_id, user, page)
        return

    m = re.match(r'^verify_(\d+)', data)
    if m:
        order_id = int(m.group(1))
        await handle_verify(bot, user, chat_id, order_id, query.id)
        return

    await query.answer(text=settings.get("cb_unknown_action"), show_alert=True)
