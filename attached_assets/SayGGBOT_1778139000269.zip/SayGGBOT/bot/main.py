import asyncio
import logging
import os
from telegram.ext import ApplicationBuilder, MessageHandler, CallbackQueryHandler, CommandHandler, filters
from bot.config import BOT_TOKEN, validate_config, WEBHOOK_MODE, WEBHOOK_URL, WEBHOOK_PATH, WEBHOOK_PORT
from bot.database import init_pool, close_pool
from bot.migrations import run_migrations
from bot.settings import reload_settings
from bot.handlers.messages import handle_message, handle_pin_service_message
from bot.handlers.callbacks import handle_callback
from bot.handlers.broadcast_wizard import handle_broadcast_command
from bot.handlers.templates_wizard import handle_templates_command
from bot.handlers.trial_templates_wizard import handle_trial_templates_command
from bot.handlers.botsettings_wizard import handle_botsettings_command
from bot.tasks import run_expire_loop, run_broadcast_poller
from bot.services.campaigns import run_campaign_scheduler
from bot.services.trial_campaigns import run_trial_campaign_scheduler

logging.basicConfig(
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.INFO)

logger = logging.getLogger("bot")

_background_tasks: dict[str, asyncio.Task] = {}
_shutdown_event = asyncio.Event()


async def _cancellable(coro, name: str):
    try:
        await coro
    except asyncio.CancelledError:
        logger.info("Background task stopped: %s", name)


async def post_init(application):
    _shutdown_event.clear()

    await init_pool()
    logger.info("Database pool initialized")

    await run_migrations()
    logger.info("Database migrations verified")

    await reload_settings()
    logger.info("Bot settings loaded")

    bot = application.bot

    _background_tasks["expire_loop"] = asyncio.create_task(
        _cancellable(run_expire_loop(bot), "expire_loop")
    )
    logger.info("Order expiry background task started")

    _background_tasks["broadcast_poller"] = asyncio.create_task(
        _cancellable(run_broadcast_poller(bot), "broadcast_poller")
    )
    logger.info("Broadcast poller started")

    _background_tasks["campaign_scheduler"] = asyncio.create_task(
        _cancellable(run_campaign_scheduler(bot), "campaign_scheduler")
    )
    logger.info("Campaign scheduler started")

    _background_tasks["trial_campaign_scheduler"] = asyncio.create_task(
        _cancellable(run_trial_campaign_scheduler(bot), "trial_campaign_scheduler")
    )
    logger.info("Trial campaign scheduler started")

    if not WEBHOOK_MODE:
        await bot.delete_webhook(drop_pending_updates=True)
        logger.info("Webhook deleted (cleared any conflicting instance)")
    else:
        logger.info("Webhook mode enabled, skipping webhook delete")

    me = await bot.get_me()
    logger.info(f"Bot connected: @{me.username} ({me.id})")


async def _cancel_background_tasks():
    if not _background_tasks:
        return
    for name, task in _background_tasks.items():
        if not task.done():
            task.cancel()
    results = await asyncio.gather(*_background_tasks.values(), return_exceptions=True)
    for name, result in zip(_background_tasks.keys(), results):
        if isinstance(result, Exception) and not isinstance(result, asyncio.CancelledError):
            logger.warning("Background task %s ended with error: %s", name, result)
    _background_tasks.clear()
    logger.info("All background tasks stopped")


async def post_stop(application):
    await _cancel_background_tasks()


async def post_shutdown(application):
    await _cancel_background_tasks()
    await close_pool()
    logger.info("Database pool closed")


def main():
    if not WEBHOOK_MODE and os.environ.get("BOT_POLLING_DEV", "").lower() != "true":
        logger.warning(
            "Bot startup skipped in dev (polling mode would delete the production webhook). "
            "Set BOT_WEBHOOK_MODE=webhook for production or BOT_POLLING_DEV=true to allow local polling."
        )
        return

    validate_config()

    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .post_stop(post_stop)
        .post_shutdown(post_shutdown)
        .build()
    )

    app.add_handler(MessageHandler(filters.StatusUpdate.PINNED_MESSAGE, handle_pin_service_message))
    app.add_handler(CommandHandler("broadcast", handle_broadcast_command))
    app.add_handler(CommandHandler("templates", handle_templates_command))
    app.add_handler(CommandHandler("trialtemplates", handle_trial_templates_command))
    app.add_handler(CommandHandler("botsettings", handle_botsettings_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(MessageHandler(filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(handle_callback))

    if WEBHOOK_MODE:
        if not WEBHOOK_URL:
            logger.error("BOT_WEBHOOK_URL must be set for webhook mode (full HTTPS URL)")
            return
        full_webhook_url = WEBHOOK_URL.rstrip("/") + WEBHOOK_PATH
        logger.info(f"Starting bot in webhook mode on port {WEBHOOK_PORT}, URL: {full_webhook_url}")
        app.run_webhook(
            listen="0.0.0.0",
            port=WEBHOOK_PORT,
            url_path=WEBHOOK_PATH,
            webhook_url=full_webhook_url,
        )
    else:
        logger.info("Starting bot in polling mode")
        app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.getLogger("bot").critical(f"Bot failed to start: {e}")
        logging.getLogger("bot").critical("Bot process exiting. The admin panel will continue to work.")
