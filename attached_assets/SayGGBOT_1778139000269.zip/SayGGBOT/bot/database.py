import asyncpg
import logging
from bot.config import DATABASE_URL

logger = logging.getLogger(__name__)

pool: asyncpg.Pool | None = None


async def init_pool():
    global pool
    if pool is not None:
        return pool
    pool = await asyncpg.create_pool(
        DATABASE_URL,
        min_size=5,
        max_size=10,
        command_timeout=30,
    )
    logger.info("Database pool created")
    return pool


async def close_pool():
    global pool
    if pool:
        await pool.close()
        pool = None
        logger.info("Database pool closed")


async def fetch_one(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.fetchrow(query, *args)


async def fetch_all(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.fetch(query, *args)


async def execute(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.execute(query, *args)


async def fetch_val(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.fetchval(query, *args)
