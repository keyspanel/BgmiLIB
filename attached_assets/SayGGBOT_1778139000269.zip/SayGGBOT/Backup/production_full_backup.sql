-- ==========================================================
-- PRODUCTION FULL DATABASE BACKUP (SCHEMA + DATA)
-- SayGGKeysBOT - PostgreSQL 16
-- Exported: 2026-04-20T11:05:50.095209Z
-- Source: Development Database (verified match of production)
-- ==========================================================

-- Disable FK checks during restore
SET session_replication_role = replica;

-- ==========================================================
-- PRODUCTION DATABASE SCHEMA BACKUP
-- SayGGKeysBOT - PostgreSQL 16
-- Exported: 2026-04-06T07:38:14.838Z
-- Source: Published Replit App (Production Database)
-- ==========================================================

-- ==========================================================
-- SEQUENCES
-- ==========================================================

CREATE SEQUENCE IF NOT EXISTS api_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS broadcast_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_attributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_daily_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_deep_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_delivery_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_discount_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_expiry_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_link_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS discount_broadcast_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS discount_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS discount_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS durations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS force_join_channels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS fulfillment_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS product_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS purchased_keys_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS reseller_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS reseller_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS resellers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS scheduled_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS source_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS source_fulfillment_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS source_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS template_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaign_delivery_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaign_run_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaign_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

-- ==========================================================
-- TABLES
-- ==========================================================

-- Table: api_providers
CREATE TABLE IF NOT EXISTS api_providers (
    id integer DEFAULT nextval('api_providers_id_seq'::regclass) NOT NULL,
    name character varying(255),
    base_url text,
    token text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT api_providers_pkey PRIMARY KEY (id)
);

-- Table: bot_settings
CREATE TABLE IF NOT EXISTS bot_settings (
    key character varying(100) NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    CONSTRAINT bot_settings_pkey PRIMARY KEY (key)
);

-- Table: broadcast_queue
CREATE TABLE IF NOT EXISTS broadcast_queue (
    id integer DEFAULT nextval('broadcast_queue_id_seq'::regclass) NOT NULL,
    plan_id integer,
    template_override text DEFAULT ''::text,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    result jsonb,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    queue_type character varying(30) DEFAULT 'broadcast'::character varying,
    delete_target_queue_id integer,
    CONSTRAINT broadcast_queue_pkey PRIMARY KEY (id)
);

-- Table: campaign_attributions
CREATE TABLE IF NOT EXISTS campaign_attributions (
    id integer DEFAULT nextval('campaign_attributions_id_seq'::regclass) NOT NULL,
    user_id integer,
    telegram_id bigint,
    campaign_id integer,
    deep_link_code character varying(64),
    first_opened_at timestamp without time zone DEFAULT now() NOT NULL,
    last_opened_at timestamp without time zone DEFAULT now() NOT NULL,
    total_opens integer DEFAULT 1 NOT NULL,
    attributed_orders integer DEFAULT 0 NOT NULL,
    attributed_revenue numeric DEFAULT 0 NOT NULL,
    attribution_expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    campaign_run_id integer,
    deep_link_id integer,
    attribution_end_at timestamp without time zone,
    CONSTRAINT campaign_attributions_pkey PRIMARY KEY (id)
);

-- Table: campaign_daily_stats
CREATE TABLE IF NOT EXISTS campaign_daily_stats (
    id integer DEFAULT nextval('campaign_daily_stats_id_seq'::regclass) NOT NULL,
    stat_date date,
    campaign_id integer,
    total_opens integer DEFAULT 0 NOT NULL,
    unique_opens integer DEFAULT 0 NOT NULL,
    total_purchases integer DEFAULT 0 NOT NULL,
    total_revenue numeric DEFAULT 0 NOT NULL,
    promo_start_sent integer DEFAULT 0 NOT NULL,
    promo_expiry_sent integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_daily_stats_pkey PRIMARY KEY (id)
);

-- Table: campaign_deep_links
CREATE TABLE IF NOT EXISTS campaign_deep_links (
    id integer DEFAULT nextval('campaign_deep_links_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    code character varying(64),
    deep_link_url text DEFAULT ''::text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    campaign_run_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    activated_at timestamp without time zone,
    expired_at timestamp without time zone,
    attribution_start_at timestamp without time zone,
    attribution_end_at timestamp without time zone,
    opens_count integer DEFAULT 0 NOT NULL,
    unique_opens_count integer DEFAULT 0 NOT NULL,
    starts_count integer DEFAULT 0 NOT NULL,
    purchases_count integer DEFAULT 0 NOT NULL,
    revenue_total numeric DEFAULT 0 NOT NULL,
    late_purchases_count integer DEFAULT 0 NOT NULL,
    late_revenue_total numeric DEFAULT 0 NOT NULL,
    CONSTRAINT campaign_deep_links_pkey PRIMARY KEY (id)
);

-- Table: campaign_delivery_logs
CREATE TABLE IF NOT EXISTS campaign_delivery_logs (
    id bigint DEFAULT nextval('campaign_delivery_logs_id_seq'::regclass) NOT NULL,
    campaign_run_id integer,
    campaign_id integer,
    target_type character varying(20) DEFAULT 'user'::character varying NOT NULL,
    telegram_id bigint,
    username character varying(255),
    message_kind character varying(20) DEFAULT 'promo_start'::character varying NOT NULL,
    delivery_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    telegram_message_id bigint,
    error_text text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    delivery_method character varying(30) DEFAULT 'direct'::character varying,
    source_message_id bigint
);

-- Table: campaign_discount_rules
CREATE TABLE IF NOT EXISTS campaign_discount_rules (
    id integer DEFAULT nextval('campaign_discount_rules_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    discount_mode character varying(30) DEFAULT 'fixed_percent'::character varying NOT NULL,
    fixed_value numeric,
    min_value numeric,
    max_value numeric,
    applies_to_category_id integer,
    applies_to_duration_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_discount_rules_pkey PRIMARY KEY (id)
);

-- Table: campaign_expiry_logs
CREATE TABLE IF NOT EXISTS campaign_expiry_logs (
    id integer DEFAULT nextval('campaign_expiry_logs_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    campaign_run_id integer,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    discount_deactivated boolean DEFAULT false NOT NULL,
    recipients_resolved integer DEFAULT 0 NOT NULL,
    sent integer DEFAULT 0 NOT NULL,
    failed integer DEFAULT 0 NOT NULL,
    error_text text,
    metadata text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_expiry_logs_pkey PRIMARY KEY (id)
);

-- Table: campaign_link_events
CREATE TABLE IF NOT EXISTS campaign_link_events (
    id bigint DEFAULT nextval('campaign_link_events_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    deep_link_code character varying(64),
    telegram_user_id bigint,
    username character varying(255),
    event_type character varying(20) DEFAULT 'open'::character varying NOT NULL,
    order_id integer,
    revenue_amount numeric,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    attributed boolean DEFAULT false,
    campaign_run_id integer,
    deep_link_id integer,
    is_late_conversion boolean DEFAULT false NOT NULL
);

-- Table: campaign_runs
CREATE TABLE IF NOT EXISTS campaign_runs (
    id integer DEFAULT nextval('campaign_runs_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    run_type character varying(30) DEFAULT 'promo_start'::character varying NOT NULL,
    executed_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    generated_discount_value numeric,
    generated_discount_type character varying(30),
    generated_final_price_json text,
    total_targets integer DEFAULT 0 NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    total_failed integer DEFAULT 0 NOT NULL,
    revenue_generated numeric,
    metadata text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    error_text text,
    admin_notified boolean DEFAULT false,
    source_chat_id bigint,
    source_message_id bigint,
    channel_delivery_method character varying(30) DEFAULT 'forward_message'::character varying,
    channels_targeted integer DEFAULT 0,
    channels_copied integer DEFAULT 0,
    channels_failed integer DEFAULT 0,
    CONSTRAINT campaign_runs_pkey PRIMARY KEY (id)
);

-- Table: campaign_targets
CREATE TABLE IF NOT EXISTS campaign_targets (
    id integer DEFAULT nextval('campaign_targets_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    target_type character varying(30) DEFAULT 'all_users'::character varying NOT NULL,
    target_value text,
    message_kind character varying(20) DEFAULT 'promo_start'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_targets_pkey PRIMARY KEY (id)
);

-- Table: campaign_templates
CREATE TABLE IF NOT EXISTS campaign_templates (
    id integer DEFAULT nextval('campaign_templates_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled'::character varying NOT NULL,
    template_type character varying(30) DEFAULT 'promo_start'::character varying NOT NULL,
    body_text text DEFAULT ''::text NOT NULL,
    parse_mode character varying(20) DEFAULT 'HTML'::character varying NOT NULL,
    custom_emoji_json text,
    inline_buttons_json text,
    button_style_json text,
    media_type character varying(30),
    media_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by character varying(255) DEFAULT 'web'::character varying,
    edited_via character varying(10) DEFAULT 'web'::character varying,
    body_entities_json text,
    apk_captions_json text,
    start_delivery_config_json text,
    category_id integer,
    category_name_snapshot character varying(255),
    CONSTRAINT campaign_templates_pkey PRIMARY KEY (id)
);

-- Table: categories
CREATE TABLE IF NOT EXISTS categories (
    id integer DEFAULT nextval('categories_id_seq'::regclass) NOT NULL,
    name character varying(100),
    sort_order integer DEFAULT 0 NOT NULL,
    is_hidden smallint DEFAULT 0 NOT NULL,
    button_style smallint DEFAULT 4 NOT NULL,
    file_id character varying(255) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT categories_pkey PRIMARY KEY (id)
);

-- Table: category_duration_settings
CREATE TABLE IF NOT EXISTS category_duration_settings (
    category_id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    CONSTRAINT category_duration_settings_pkey PRIMARY KEY (category_id, setting_key)
);

-- Table: channel_audit_log
CREATE TABLE IF NOT EXISTS channel_audit_log (
    id integer,
    action text,
    actor text DEFAULT 'admin'::text NOT NULL,
    channel_id integer,
    channel_label text,
    normalized_input text,
    resolved_chat_id bigint,
    result text,
    error_reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: configured_channels
CREATE TABLE IF NOT EXISTS configured_channels (
    id integer,
    label text DEFAULT ''::text NOT NULL,
    original_input text,
    normalized_input text,
    resolved_chat_id bigint,
    resolved_username text,
    resolved_title text,
    chat_type text,
    is_validated boolean DEFAULT false NOT NULL,
    bot_is_member boolean DEFAULT false NOT NULL,
    bot_is_admin boolean DEFAULT false NOT NULL,
    can_post_messages boolean DEFAULT false NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    last_validated_at timestamp without time zone,
    last_validation_status text DEFAULT 'pending'::text NOT NULL,
    last_validation_error text,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: discount_broadcast_messages
CREATE TABLE IF NOT EXISTS discount_broadcast_messages (
    id integer DEFAULT nextval('discount_broadcast_messages_id_seq'::regclass) NOT NULL,
    queue_id integer,
    plan_id integer,
    user_id integer,
    telegram_id bigint,
    broadcast_message_id integer,
    created_at timestamp without time zone DEFAULT now(),
    pin_service_message_id bigint,
    CONSTRAINT discount_broadcast_messages_pkey PRIMARY KEY (id)
);

-- Table: discount_plans
CREATE TABLE IF NOT EXISTS discount_plans (
    id integer DEFAULT nextval('discount_plans_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled Offer'::character varying NOT NULL,
    description text DEFAULT ''::text,
    is_active boolean DEFAULT false NOT NULL,
    apply_scope character varying(50) DEFAULT 'all_categories'::character varying NOT NULL,
    starts_at timestamp without time zone,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    broadcast_template text DEFAULT ''::text,
    is_campaign_generated boolean DEFAULT false,
    CONSTRAINT discount_plans_pkey PRIMARY KEY (id)
);

-- Table: discount_rules
CREATE TABLE IF NOT EXISTS discount_rules (
    id integer DEFAULT nextval('discount_rules_id_seq'::regclass) NOT NULL,
    plan_id integer,
    category_id integer,
    duration_id integer,
    discount_type character varying(30),
    discount_value numeric,
    override_price numeric,
    CONSTRAINT discount_rules_pkey PRIMARY KEY (id)
);

-- Table: durations
CREATE TABLE IF NOT EXISTS durations (
    id integer DEFAULT nextval('durations_id_seq'::regclass) NOT NULL,
    category_id integer,
    name character varying(100),
    sort_order integer DEFAULT 0 NOT NULL,
    button_style smallint DEFAULT 4 NOT NULL,
    price numeric DEFAULT 0 NOT NULL,
    is_hidden smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT durations_pkey PRIMARY KEY (id)
);

-- Table: force_join_channels
CREATE TABLE IF NOT EXISTS force_join_channels (
    id integer DEFAULT nextval('force_join_channels_id_seq'::regclass),
    channel_identifier text,
    channel_title character varying(255) DEFAULT ''::character varying NOT NULL,
    invite_link text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    channel_username text,
    status text DEFAULT 'pending'::text NOT NULL,
    status_detail text DEFAULT ''::text NOT NULL,
    channel_id bigint
);

-- Table: fulfillment_issues
CREATE TABLE IF NOT EXISTS fulfillment_issues (
    id integer DEFAULT nextval('fulfillment_issues_id_seq'::regclass) NOT NULL,
    order_id integer,
    user_id integer,
    category_id integer,
    duration_id integer,
    source_rule_id integer,
    provider_id integer,
    source_type character varying(30) DEFAULT NULL::character varying,
    failure_reason text,
    failure_code character varying(100) DEFAULT NULL::character varying,
    payload_snapshot jsonb,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    recovery_key text,
    recovery_note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone,
    resolved_by character varying(255) DEFAULT NULL::character varying,
    send_attempts integer DEFAULT 0 NOT NULL,
    last_send_error text,
    CONSTRAINT fulfillment_issues_pkey PRIMARY KEY (id)
);

-- Table: orders
CREATE TABLE IF NOT EXISTS orders (
    id integer DEFAULT nextval('orders_id_seq'::regclass) NOT NULL,
    user_id integer,
    key_id integer,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    qr_message_id bigint,
    last_error_message_id bigint,
    txn_ref character varying(64) DEFAULT NULL::character varying,
    verified_at timestamp without time zone,
    purchased_category_name character varying(150) DEFAULT NULL::character varying,
    purchased_duration_name character varying(150) DEFAULT NULL::character varying,
    purchased_key_value text,
    purchased_amount numeric,
    purchaser_role character varying(50) DEFAULT 'customer'::character varying NOT NULL,
    purchaser_label character varying(255) DEFAULT NULL::character varying,
    paid_utr character varying(255) DEFAULT NULL::character varying,
    delivered_at timestamp without time zone,
    gateway_txn_id character varying(255) DEFAULT NULL::character varying,
    gateway_bank_txn_id character varying(255) DEFAULT NULL::character varying,
    paid_amount numeric,
    pricing_source character varying(50),
    base_amount numeric,
    applied_discount_plan_id integer,
    applied_discount_plan_name character varying(255),
    fulfillment_status character varying(30) DEFAULT 'pending'::character varying,
    fulfillment_attempted_at timestamp without time zone,
    fulfilled_at timestamp without time zone,
    fulfillment_error text,
    provider_response_meta text,
    fallback_used boolean DEFAULT false,
    delivered_source character varying(30),
    owner_alert_sent_at timestamp without time zone,
    source_rule_snapshot text,
    campaign_id integer,
    campaign_deep_link_code character varying(64),
    campaign_run_id integer,
    campaign_deep_link_id integer,
    is_campaign_late_conversion boolean DEFAULT false NOT NULL,
    CONSTRAINT orders_pkey PRIMARY KEY (id)
);

-- Table: product_keys
CREATE TABLE IF NOT EXISTS product_keys (
    id integer DEFAULT nextval('product_keys_id_seq'::regclass) NOT NULL,
    category_id integer,
    duration_id integer,
    key_value character varying(255),
    price numeric DEFAULT 0 NOT NULL,
    is_sold smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT product_keys_pkey PRIMARY KEY (id)
);

-- Table: purchased_keys_history
CREATE TABLE IF NOT EXISTS purchased_keys_history (
    id bigint DEFAULT nextval('purchased_keys_history_id_seq'::regclass) NOT NULL,
    user_id integer,
    order_id integer,
    telegram_id bigint,
    username character varying(255) DEFAULT NULL::character varying,
    first_name character varying(255) DEFAULT NULL::character varying,
    last_name character varying(255) DEFAULT NULL::character varying,
    is_reseller_purchase smallint DEFAULT 0 NOT NULL,
    category_name character varying(150),
    duration_name character varying(150),
    key_value character varying(255),
    amount numeric DEFAULT 0 NOT NULL,
    txn_ref character varying(64) DEFAULT NULL::character varying,
    gateway_txn_id character varying(128) DEFAULT NULL::character varying,
    gateway_bank_txn_id character varying(128) DEFAULT NULL::character varying,
    verified_at timestamp without time zone,
    purchased_at timestamp without time zone DEFAULT now() NOT NULL,
    pricing_source character varying(50),
    base_amount numeric,
    applied_discount_plan_id integer,
    applied_discount_plan_name character varying(255)
);

-- Table: reseller_prices
CREATE TABLE IF NOT EXISTS reseller_prices (
    id integer DEFAULT nextval('reseller_prices_id_seq'::regclass) NOT NULL,
    reseller_id integer,
    category_id integer,
    duration_id integer,
    price numeric,
    discount_type character varying(10) DEFAULT NULL::character varying,
    discount_value numeric,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT reseller_prices_pkey PRIMARY KEY (id)
);

-- Table: reseller_users
CREATE TABLE IF NOT EXISTS reseller_users (
    id integer DEFAULT nextval('reseller_users_id_seq'::regclass) NOT NULL,
    reseller_id integer,
    user_id integer,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT reseller_users_pkey PRIMARY KEY (id)
);

-- Table: resellers
CREATE TABLE IF NOT EXISTS resellers (
    id integer DEFAULT nextval('resellers_id_seq'::regclass) NOT NULL,
    code character varying(6),
    expires_at timestamp without time zone,
    max_users integer,
    total_price numeric,
    discount_type character varying(10) DEFAULT 'percent'::character varying NOT NULL,
    discount_value numeric DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT resellers_pkey PRIMARY KEY (id)
);

-- Table: scheduled_campaigns
CREATE TABLE IF NOT EXISTS scheduled_campaigns (
    id integer DEFAULT nextval('scheduled_campaigns_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled Campaign'::character varying NOT NULL,
    description text DEFAULT ''::text,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    campaign_mode character varying(30) DEFAULT 'fixed_plan'::character varying NOT NULL,
    linked_discount_plan_id integer,
    category_scope_json text DEFAULT '[]'::text,
    duration_scope_json text DEFAULT '[]'::text,
    repeat_mode character varying(20) DEFAULT 'once'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'Asia/Kolkata'::character varying NOT NULL,
    start_at timestamp without time zone DEFAULT now() NOT NULL,
    expire_at timestamp without time zone DEFAULT now() NOT NULL,
    next_run_at timestamp without time zone,
    next_expire_at timestamp without time zone,
    is_enabled boolean DEFAULT false NOT NULL,
    promo_template_id integer,
    expiry_template_id integer,
    send_to_users boolean DEFAULT true NOT NULL,
    send_to_channels boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_run_at timestamp without time zone,
    last_expired_at timestamp without time zone,
    auto_discount_plan_id integer,
    channel_targets_json text DEFAULT '[]'::text,
    CONSTRAINT scheduled_campaigns_pkey PRIMARY KEY (id)
);

-- Table: source_audit_logs
CREATE TABLE IF NOT EXISTS source_audit_logs (
    id bigint DEFAULT nextval('source_audit_logs_id_seq'::regclass) NOT NULL,
    action_type character varying(50),
    target_type character varying(50),
    target_id integer,
    target_name character varying(255) DEFAULT NULL::character varying,
    actor character varying(255) DEFAULT 'admin'::character varying,
    changes jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: source_fulfillment_logs
CREATE TABLE IF NOT EXISTS source_fulfillment_logs (
    id bigint DEFAULT nextval('source_fulfillment_logs_id_seq'::regclass) NOT NULL,
    order_id integer,
    category_id integer,
    duration_id integer,
    category_name character varying(255) DEFAULT NULL::character varying,
    duration_name character varying(255) DEFAULT NULL::character varying,
    source_type character varying(20) DEFAULT NULL::character varying,
    provider_id integer,
    provider_name character varying(255) DEFAULT NULL::character varying,
    resolution_success boolean DEFAULT false NOT NULL,
    delivery_success boolean DEFAULT false NOT NULL,
    key_value text,
    api_request_url text,
    api_raw_response text,
    failure_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_telegram_id bigint,
    user_display_name character varying(255) DEFAULT NULL::character varying,
    delivered_source character varying(30) DEFAULT NULL::character varying,
    fallback_used boolean DEFAULT false,
    response_time_ms integer,
    http_status integer
);

-- Table: source_rules
CREATE TABLE IF NOT EXISTS source_rules (
    id integer DEFAULT nextval('source_rules_id_seq'::regclass) NOT NULL,
    category_id integer,
    duration_id integer,
    source_type character varying(20),
    api_provider_id integer,
    api_game_value character varying(255) DEFAULT NULL::character varying,
    api_duration_value character varying(255) DEFAULT NULL::character varying,
    api_device_value character varying(255) DEFAULT NULL::character varying,
    api_currency_value character varying(255) DEFAULT NULL::character varying,
    is_active boolean DEFAULT true NOT NULL,
    last_test_result text,
    last_test_success boolean,
    last_test_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT source_rules_pkey PRIMARY KEY (id)
);

-- Table: template_versions
CREATE TABLE IF NOT EXISTS template_versions (
    id integer DEFAULT nextval('template_versions_id_seq'::regclass) NOT NULL,
    template_id integer,
    body_text text DEFAULT ''::text NOT NULL,
    inline_buttons_json text,
    changed_by character varying(255) DEFAULT 'web'::character varying,
    changed_via character varying(10) DEFAULT 'web'::character varying,
    change_note text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    body_entities_json text,
    CONSTRAINT template_versions_pkey PRIMARY KEY (id)
);

-- Table: trial_campaign_delivery_logs
CREATE TABLE IF NOT EXISTS trial_campaign_delivery_logs (
    id bigint DEFAULT nextval('trial_campaign_delivery_logs_id_seq'::regclass) NOT NULL,
    run_id integer,
    campaign_id integer,
    target_type character varying(20) DEFAULT 'user'::character varying NOT NULL,
    telegram_id bigint,
    message_kind character varying(30) DEFAULT 'trial_start'::character varying NOT NULL,
    delivery_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    telegram_message_id bigint,
    error_text text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: trial_campaign_run_keys
CREATE TABLE IF NOT EXISTS trial_campaign_run_keys (
    id integer DEFAULT nextval('trial_campaign_run_keys_id_seq'::regclass) NOT NULL,
    run_id integer,
    campaign_id integer,
    category_id integer,
    category_name_snapshot character varying(255),
    trial_key_id integer,
    key_value_snapshot character varying(500),
    duration_hours integer,
    max_devices integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT trial_campaign_run_keys_pkey PRIMARY KEY (id)
);

-- Table: trial_campaign_runs
CREATE TABLE IF NOT EXISTS trial_campaign_runs (
    id integer DEFAULT nextval('trial_campaign_runs_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    run_type character varying(30) DEFAULT 'trial_start'::character varying NOT NULL,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    total_targets integer DEFAULT 0 NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    total_failed integer DEFAULT 0 NOT NULL,
    channels_targeted integer DEFAULT 0 NOT NULL,
    channels_sent integer DEFAULT 0 NOT NULL,
    channels_failed integer DEFAULT 0 NOT NULL,
    error_text text,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT trial_campaign_runs_pkey PRIMARY KEY (id)
);

-- Table: trial_campaigns
CREATE TABLE IF NOT EXISTS trial_campaigns (
    id integer DEFAULT nextval('trial_campaigns_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled Trial'::character varying NOT NULL,
    description text DEFAULT ''::text,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    category_ids_json text DEFAULT '[]'::text NOT NULL,
    trial_duration_hours integer DEFAULT 1 NOT NULL,
    max_devices integer,
    repeat_mode character varying(20) DEFAULT 'once'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'Asia/Kolkata'::character varying NOT NULL,
    start_at timestamp without time zone DEFAULT now() NOT NULL,
    expire_at timestamp without time zone DEFAULT now() NOT NULL,
    next_run_at timestamp without time zone,
    next_expire_at timestamp without time zone,
    is_enabled boolean DEFAULT false NOT NULL,
    start_template_id integer,
    expire_template_id integer,
    send_to_users boolean DEFAULT true NOT NULL,
    send_to_channels boolean DEFAULT false NOT NULL,
    channel_targets_json text DEFAULT '[]'::text,
    reveal_keys_in_channels boolean DEFAULT false NOT NULL,
    linked_promo_campaign_id integer,
    target_audience character varying(30) DEFAULT 'all_users'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_run_at timestamp without time zone,
    last_expired_at timestamp without time zone,
    apk_delivery_config_json text,
    delivery_mode character varying(30) DEFAULT 'mode_1_separate'::character varying NOT NULL,
    category_names_snapshot_json text,
    CONSTRAINT trial_campaigns_pkey PRIMARY KEY (id)
);

-- Table: trial_keys
CREATE TABLE IF NOT EXISTS trial_keys (
    id integer DEFAULT nextval('trial_keys_id_seq'::regclass) NOT NULL,
    category_id integer,
    category_name_snapshot character varying(255),
    duration_hours integer DEFAULT 1 NOT NULL,
    max_devices integer DEFAULT 1 NOT NULL,
    key_value character varying(500),
    status character varying(20) DEFAULT 'available'::character varying NOT NULL,
    used_in_trial_campaign_run_id integer,
    used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT trial_keys_pkey PRIMARY KEY (id)
);

-- Table: users
CREATE TABLE IF NOT EXISTS users (
    id integer DEFAULT nextval('users_id_seq'::regclass) NOT NULL,
    telegram_id bigint,
    username character varying(255) DEFAULT NULL::character varying,
    first_name character varying(255) DEFAULT NULL::character varying,
    last_name character varying(255) DEFAULT NULL::character varying,
    token character varying(64) DEFAULT NULL::character varying,
    is_banned smallint DEFAULT 0 NOT NULL,
    reseller_id integer,
    awaiting_code smallint DEFAULT 0 NOT NULL,
    start_categories_message_id bigint,
    active_payment_order_id bigint,
    active_keys_viewer_message_id bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    active_durations_message_id bigint,
    active_payment_error_message_id bigint,
    active_expiry_notice_message_id bigint,
    last_user_start_message_id bigint,
    last_bot_welcome_message_id bigint,
    last_start_date date,
    broadcast_categories_message_id bigint,
    last_mykeys_user_message_id bigint,
    last_mykeys_pin_notice_message_id bigint,
    last_howto_user_message_id bigint,
    last_howto_bot_message_id bigint,
    reseller_level_trigger_msg_id bigint,
    reseller_prompt_msg_id bigint,
    reseller_success_result_msg_id bigint,
    reseller_wrong_code_msg_id bigint,
    reseller_wrong_result_msg_id bigint,
    last_key_delivery_message_id bigint,
    profile_photo_url text,
    profile_photo_file_id character varying(255),
    profile_photo_updated_at timestamp without time zone,
    campaign_deep_link_code character varying(64),
    CONSTRAINT users_pkey PRIMARY KEY (id)
);

-- ==========================================================
-- FOREIGN KEY CONSTRAINTS
-- ==========================================================

ALTER TABLE campaign_deep_links ADD CONSTRAINT campaign_deep_links_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_delivery_logs ADD CONSTRAINT campaign_delivery_logs_campaign_run_id_fkey FOREIGN KEY (campaign_run_id) REFERENCES campaign_runs(id) ON DELETE CASCADE;
ALTER TABLE campaign_discount_rules ADD CONSTRAINT campaign_discount_rules_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_link_events ADD CONSTRAINT campaign_link_events_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_runs ADD CONSTRAINT campaign_runs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_targets ADD CONSTRAINT campaign_targets_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE category_duration_settings ADD CONSTRAINT category_duration_settings_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE discount_rules ADD CONSTRAINT discount_rules_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES discount_plans(id) ON DELETE CASCADE;
ALTER TABLE durations ADD CONSTRAINT durations_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE orders ADD CONSTRAINT orders_key_id_fkey FOREIGN KEY (key_id) REFERENCES product_keys(id) ON DELETE SET NULL;
ALTER TABLE orders ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE product_keys ADD CONSTRAINT product_keys_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE product_keys ADD CONSTRAINT product_keys_duration_id_fkey FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE CASCADE;
ALTER TABLE reseller_prices ADD CONSTRAINT reseller_prices_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE reseller_prices ADD CONSTRAINT reseller_prices_duration_id_fkey FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE CASCADE;
ALTER TABLE reseller_prices ADD CONSTRAINT reseller_prices_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES resellers(id) ON DELETE CASCADE;
ALTER TABLE reseller_users ADD CONSTRAINT reseller_users_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES resellers(id) ON DELETE CASCADE;
ALTER TABLE reseller_users ADD CONSTRAINT reseller_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE scheduled_campaigns ADD CONSTRAINT scheduled_campaigns_expiry_template_id_fkey FOREIGN KEY (expiry_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE scheduled_campaigns ADD CONSTRAINT scheduled_campaigns_promo_template_id_fkey FOREIGN KEY (promo_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE source_rules ADD CONSTRAINT source_rules_api_provider_id_fkey FOREIGN KEY (api_provider_id) REFERENCES api_providers(id) ON DELETE SET NULL;
ALTER TABLE source_rules ADD CONSTRAINT source_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE source_rules ADD CONSTRAINT source_rules_duration_id_fkey FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE CASCADE;
ALTER TABLE trial_campaign_delivery_logs ADD CONSTRAINT trial_campaign_delivery_logs_run_id_fkey FOREIGN KEY (run_id) REFERENCES trial_campaign_runs(id) ON DELETE CASCADE;
ALTER TABLE trial_campaign_run_keys ADD CONSTRAINT trial_campaign_run_keys_run_id_fkey FOREIGN KEY (run_id) REFERENCES trial_campaign_runs(id) ON DELETE CASCADE;
ALTER TABLE trial_campaign_run_keys ADD CONSTRAINT trial_campaign_run_keys_trial_key_id_fkey FOREIGN KEY (trial_key_id) REFERENCES trial_keys(id) ON DELETE SET NULL;
ALTER TABLE trial_campaign_runs ADD CONSTRAINT trial_campaign_runs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES trial_campaigns(id) ON DELETE CASCADE;
ALTER TABLE trial_campaigns ADD CONSTRAINT trial_campaigns_expire_template_id_fkey FOREIGN KEY (expire_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE trial_campaigns ADD CONSTRAINT trial_campaigns_start_template_id_fkey FOREIGN KEY (start_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE trial_keys ADD CONSTRAINT trial_keys_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL;
ALTER TABLE users ADD CONSTRAINT users_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES resellers(id) ON DELETE SET NULL;

-- ==========================================================
-- INDEXES
-- ==========================================================

CREATE INDEX idx_ca_campaign ON public.campaign_attributions USING btree (campaign_id);
CREATE INDEX idx_ca_expires ON public.campaign_attributions USING btree (attribution_expires_at);
CREATE INDEX idx_ca_telegram ON public.campaign_attributions USING btree (telegram_id);
CREATE UNIQUE INDEX uq_ca_user_campaign ON public.campaign_attributions USING btree (user_id, campaign_id);
CREATE INDEX idx_cds_campaign ON public.campaign_daily_stats USING btree (campaign_id);
CREATE INDEX idx_cds_date ON public.campaign_daily_stats USING btree (stat_date);
CREATE UNIQUE INDEX uq_cds_date_camp ON public.campaign_daily_stats USING btree (stat_date, campaign_id);
CREATE INDEX idx_cdl_campaign ON public.campaign_deep_links USING btree (campaign_id);
CREATE INDEX idx_cdl_run_id ON public.campaign_deep_links USING btree (campaign_run_id);
CREATE INDEX idx_cdl_status ON public.campaign_deep_links USING btree (status);
CREATE UNIQUE INDEX uq_cdl_code ON public.campaign_deep_links USING btree (code);
CREATE INDEX idx_cdl_camp ON public.campaign_delivery_logs USING btree (campaign_id);
CREATE INDEX idx_cdl_delivery_status ON public.campaign_delivery_logs USING btree (delivery_status);
CREATE INDEX idx_cdl_run ON public.campaign_delivery_logs USING btree (campaign_run_id);
CREATE INDEX idx_cdr_campaign ON public.campaign_discount_rules USING btree (campaign_id);
CREATE INDEX idx_cel_campaign ON public.campaign_expiry_logs USING btree (campaign_id);
CREATE INDEX idx_cel_started ON public.campaign_expiry_logs USING btree (started_at);
CREATE INDEX idx_cle_campaign ON public.campaign_link_events USING btree (campaign_id);
CREATE INDEX idx_cle_code ON public.campaign_link_events USING btree (deep_link_code);
CREATE INDEX idx_cle_created ON public.campaign_link_events USING btree (created_at);
CREATE INDEX idx_cle_dlid ON public.campaign_link_events USING btree (deep_link_id);
CREATE INDEX idx_cle_event_type ON public.campaign_link_events USING btree (event_type);
CREATE INDEX idx_cle_late ON public.campaign_link_events USING btree (is_late_conversion);
CREATE INDEX idx_cle_order ON public.campaign_link_events USING btree (order_id);
CREATE INDEX idx_cle_user ON public.campaign_link_events USING btree (telegram_user_id);
CREATE INDEX idx_cr_campaign ON public.campaign_runs USING btree (campaign_id);
CREATE INDEX idx_cr_executed ON public.campaign_runs USING btree (executed_at);
CREATE INDEX idx_ct_campaign ON public.campaign_targets USING btree (campaign_id);
CREATE INDEX idx_ct_apk_caption_lookup ON public.campaign_templates USING btree (template_type, category_id, is_active) WHERE ((template_type)::text = 'trial_apk_caption'::text);
CREATE INDEX idx_categories_visible_sort ON public.categories USING btree (is_hidden, sort_order, id);
CREATE INDEX idx_catdur_category ON public.category_duration_settings USING btree (category_id);
CREATE INDEX idx_dbm_plan ON public.discount_broadcast_messages USING btree (plan_id);
CREATE INDEX idx_dbm_queue ON public.discount_broadcast_messages USING btree (queue_id);
CREATE INDEX idx_discount_plans_active ON public.discount_plans USING btree (is_active) WHERE (is_active = true);
CREATE INDEX idx_discount_rules_plan ON public.discount_rules USING btree (plan_id);
CREATE INDEX idx_durations_cat_sort ON public.durations USING btree (category_id, sort_order, id);
CREATE INDEX idx_fi_created ON public.fulfillment_issues USING btree (created_at);
CREATE INDEX idx_fi_order ON public.fulfillment_issues USING btree (order_id);
CREATE INDEX idx_fi_status ON public.fulfillment_issues USING btree (status);
CREATE INDEX idx_orders_campaign_id ON public.orders USING btree (campaign_id);
CREATE INDEX idx_orders_delivered_at ON public.orders USING btree (delivered_at);
CREATE INDEX idx_orders_purchaser_role ON public.orders USING btree (purchaser_role, id);
CREATE INDEX idx_orders_status_created ON public.orders USING btree (status, created_at);
CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);
CREATE INDEX idx_orders_user_status_id ON public.orders USING btree (user_id, status, id);
CREATE UNIQUE INDEX uq_orders_txn_ref ON public.orders USING btree (txn_ref) WHERE (txn_ref IS NOT NULL);
CREATE INDEX idx_product_keys_is_sold ON public.product_keys USING btree (is_sold, id);
CREATE INDEX idx_product_keys_stock_lookup ON public.product_keys USING btree (category_id, duration_id, is_sold, id);
CREATE UNIQUE INDEX uq_product_keys_key_value ON public.product_keys USING btree (key_value);
CREATE INDEX idx_pkh_key_value ON public.purchased_keys_history USING btree (key_value);
CREATE UNIQUE INDEX idx_pkh_order_id ON public.purchased_keys_history USING btree (order_id);
CREATE INDEX idx_pkh_tg_time ON public.purchased_keys_history USING btree (telegram_id, purchased_at, id);
CREATE INDEX idx_pkh_user_time ON public.purchased_keys_history USING btree (user_id, purchased_at, id);
CREATE INDEX idx_reseller_prices_reseller ON public.reseller_prices USING btree (reseller_id);
CREATE UNIQUE INDEX uq_reseller_users_pair ON public.reseller_users USING btree (reseller_id, user_id);
CREATE UNIQUE INDEX uq_resellers_code ON public.resellers USING btree (code);
CREATE INDEX idx_sc_next_expire ON public.scheduled_campaigns USING btree (next_expire_at) WHERE (is_enabled = true);
CREATE INDEX idx_sc_next_run ON public.scheduled_campaigns USING btree (next_run_at) WHERE (is_enabled = true);
CREATE INDEX idx_sc_status ON public.scheduled_campaigns USING btree (status);
CREATE INDEX idx_sfl_cat ON public.source_fulfillment_logs USING btree (category_id);
CREATE INDEX idx_sfl_created ON public.source_fulfillment_logs USING btree (created_at);
CREATE INDEX idx_sfl_order ON public.source_fulfillment_logs USING btree (order_id);
CREATE UNIQUE INDEX source_rules_category_id_duration_id_key ON public.source_rules USING btree (category_id, duration_id);
CREATE UNIQUE INDEX uq_source_rules_cat_dur ON public.source_rules USING btree (category_id, duration_id);
CREATE INDEX idx_tv_created ON public.template_versions USING btree (created_at);
CREATE INDEX idx_tv_template ON public.template_versions USING btree (template_id);
CREATE INDEX idx_tcdl_campaign ON public.trial_campaign_delivery_logs USING btree (campaign_id);
CREATE INDEX idx_tcdl_delivery_status ON public.trial_campaign_delivery_logs USING btree (delivery_status);
CREATE INDEX idx_tcdl_run ON public.trial_campaign_delivery_logs USING btree (run_id);
CREATE INDEX idx_tcdl_target_type ON public.trial_campaign_delivery_logs USING btree (target_type);
CREATE INDEX idx_tcrk_run ON public.trial_campaign_run_keys USING btree (run_id);
CREATE UNIQUE INDEX uq_tcrk_run_cat ON public.trial_campaign_run_keys USING btree (run_id, category_id);
CREATE INDEX idx_tcr_campaign ON public.trial_campaign_runs USING btree (campaign_id);
CREATE INDEX idx_tcr_started ON public.trial_campaign_runs USING btree (started_at);
CREATE INDEX idx_tc_next_expire ON public.trial_campaigns USING btree (next_expire_at) WHERE (is_enabled = true);
CREATE INDEX idx_tc_next_run ON public.trial_campaigns USING btree (next_run_at) WHERE (is_enabled = true);
CREATE INDEX idx_tc_status ON public.trial_campaigns USING btree (status);
CREATE INDEX idx_trial_keys_cat_dur ON public.trial_keys USING btree (category_id, duration_hours, status);
CREATE INDEX idx_trial_keys_status ON public.trial_keys USING btree (status);
CREATE UNIQUE INDEX uq_trial_keys_value ON public.trial_keys USING btree (key_value);
CREATE INDEX idx_users_awaiting_code ON public.users USING btree (awaiting_code);
CREATE INDEX idx_users_banned ON public.users USING btree (is_banned);
CREATE INDEX idx_users_reseller_id ON public.users USING btree (reseller_id);
CREATE UNIQUE INDEX uq_users_telegram_id ON public.users USING btree (telegram_id);

-- ==========================================================
-- SEQUENCE VALUES (restore current auto-increment positions)
-- ==========================================================

SELECT setval('api_providers_id_seq', 2, true);
SELECT setval('broadcast_queue_id_seq', 2, true);
SELECT setval('campaign_attributions_id_seq', 1, true);
SELECT setval('campaign_daily_stats_id_seq', 2, true);
SELECT setval('campaign_deep_links_id_seq', 2, true);
SELECT setval('campaign_delivery_logs_id_seq', 7, true);
SELECT setval('campaign_discount_rules_id_seq', 1, true);
SELECT setval('campaign_expiry_logs_id_seq', 2, true);
SELECT setval('campaign_link_events_id_seq', 1, true);
SELECT setval('campaign_runs_id_seq', 3, true);
SELECT setval('campaign_targets_id_seq', 1, true);
SELECT setval('campaign_templates_id_seq', 9, true);
SELECT setval('categories_id_seq', 3, true);
SELECT setval('discount_broadcast_messages_id_seq', 4, true);
SELECT setval('discount_plans_id_seq', 2, true);
SELECT setval('discount_rules_id_seq', 2, true);
SELECT setval('durations_id_seq', 11, true);
SELECT setval('force_join_channels_id_seq', 1, true);
SELECT setval('fulfillment_issues_id_seq', 1, true);
SELECT setval('orders_id_seq', 17, true);
SELECT setval('product_keys_id_seq', 7, true);
SELECT setval('purchased_keys_history_id_seq', 7, true);
SELECT setval('reseller_prices_id_seq', 1, true);
SELECT setval('reseller_users_id_seq', 1, true);
SELECT setval('resellers_id_seq', 1, true);
SELECT setval('scheduled_campaigns_id_seq', 1, true);
SELECT setval('source_audit_logs_id_seq', 17, true);
SELECT setval('source_fulfillment_logs_id_seq', 8, true);
SELECT setval('source_rules_id_seq', 11, true);
SELECT setval('template_versions_id_seq', 1, true);
SELECT setval('trial_campaign_delivery_logs_id_seq', 1, true);
SELECT setval('trial_campaign_run_keys_id_seq', 1, true);
SELECT setval('trial_campaign_runs_id_seq', 1, true);
SELECT setval('trial_campaigns_id_seq', 1, true);
SELECT setval('trial_keys_id_seq', 1, true);
SELECT setval('users_id_seq', 4, true);

-- ==========================================================
-- DATA
-- ==========================================================

-- ==========================================================
-- PRODUCTION DATABASE DATA BACKUP
-- SayGGKeysBOT - PostgreSQL 16
-- Exported: 2026-04-20T11:05:05.348323Z
-- Source: Development Database (verified match of production)
-- ==========================================================

-- Table: api_providers (2 rows)
INSERT INTO api_providers (id, name, base_url, token, is_active, created_at) VALUES (1, 'NovaEsp Server', 'http://Nova-esp-server.xyz/novaetnurerhbrhbj.php', NULL, true, '2026-03-31 18:44:28.802070');
INSERT INTO api_providers (id, name, base_url, token, is_active, created_at) VALUES (2, 'SayGG Skin Server', 'https://saygg.shop/g/aa02b82e1c/6d0b71827e/7c9eed35d2/3d38958183/b05aef9fc2', '5u3k0q614h5c6u375v4p4a546o1v0p3e0s421w412g403659', true, '2026-03-31 18:45:53.336393');

-- Table: categories (3 rows)
INSERT INTO categories (id, name, sort_order, is_hidden, button_style, file_id, created_at) VALUES (1, 'NovaEsp Loader', 2, 0, 3, 'BQACAgUAAxkBAAIB-mnNFb3R0Yp9PSZvvUOtw_UB_4hkAAJsHAACKU5pVtQ_cICj4hluOgQ', '2026-03-31 18:37:53.958635');
INSERT INTO categories (id, name, sort_order, is_hidden, button_style, file_id, created_at) VALUES (2, 'SayGG Skin MOD x64', 1, 0, 3, 'BQACAgUAAxkBAAIBsmnNAoy2HizF7anWyZbWqBBhsV6YAALnHQACFz0xVkp5-swSMDjwOgQ', '2026-03-31 18:38:24.584510');
INSERT INTO categories (id, name, sort_order, is_hidden, button_style, file_id, created_at) VALUES (3, 'NovaEsp MoD x64', 3, 0, 3, 'BQACAgUAAxkBAAICHGnNGQPWVkUV1VXQKpM_jl5AYdmjAAJwHAACKU5pVlJ1NFajnl6bOgQ', '2026-03-31 18:39:16.198673');

-- Table: durations (11 rows)
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (1, 2, 'Day', 1, 2, '100.00', 0, '2026-03-31 18:39:51.421816');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (2, 2, 'Week', 2, 2, '350.00', 0, '2026-03-31 18:40:15.253799');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (3, 1, 'Day', 1, 2, '100.00', 0, '2026-03-31 18:40:31.230515');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (4, 1, 'Week', 2, 2, '500.00', 0, '2026-03-31 18:41:30.197843');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (5, 1, 'Month', 3, 2, '1000.00', 0, '2026-03-31 18:41:44.540789');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (6, 1, 'Season', 4, 2, '1500.00', 0, '2026-03-31 18:42:02.231392');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (7, 3, 'Day', 1, 2, '100.00', 0, '2026-03-31 18:42:34.074435');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (8, 3, 'Week', 2, 2, '500.00', 0, '2026-03-31 18:42:45.246931');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (9, 3, 'Month', 3, 2, '1000.00', 0, '2026-03-31 18:43:10.102341');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (10, 3, 'Season', 4, 2, '1500.00', 0, '2026-03-31 18:43:31.452608');
INSERT INTO durations (id, category_id, name, sort_order, button_style, price, is_hidden, created_at) VALUES (11, 2, 'Test', 3, 2, '1', 0, '2026-04-01 19:54:29.288552');

-- Table: users (4 rows)
INSERT INTO users (id, telegram_id, username, first_name, last_name, token, is_banned, reseller_id, awaiting_code, start_categories_message_id, active_payment_order_id, active_keys_viewer_message_id, created_at, active_durations_message_id, active_payment_error_message_id, active_expiry_notice_message_id, last_user_start_message_id, last_bot_welcome_message_id, last_start_date, broadcast_categories_message_id, last_mykeys_user_message_id, last_mykeys_pin_notice_message_id, last_howto_user_message_id, last_howto_bot_message_id, reseller_level_trigger_msg_id, reseller_prompt_msg_id, reseller_success_result_msg_id, reseller_wrong_code_msg_id, reseller_wrong_result_msg_id, last_key_delivery_message_id, profile_photo_url, profile_photo_file_id, profile_photo_updated_at, campaign_deep_link_code) VALUES (1, 6092672929, 'Ceo_DarkFury', '⌬ Ｉｍ ➛ 𝗗𝗮𝗿𝗸𝗙𝘂𝗿𝘆', '〝 ᴺᵒᵛᵃᴱˢᵖ 〞', 'd06906b8f70f3bb99a777b9733a72201', 0, NULL, 0, NULL, NULL, 1390, '2026-03-31 16:51:20.511498', 1381, NULL, NULL, 1378, 1379, '2026-04-20', NULL, 1389, 1391, 1385, 1386, NULL, NULL, NULL, NULL, NULL, 1375, 'https://api.telegram.org/file/bot8714587404:AAHujo4UqWUETK8qjKa0Ofp_cXl5D2Klw30/photos/file_6.jpg', 'AgACAgUAAxUAAWnmBTTEtWIimQbfr7fFOGqlv2spAAJpC2sbmhRAVK4jD_MG9jziAQADAgADYwADOwQ', '2026-04-20 10:52:39.310754', NULL);
INSERT INTO users (id, telegram_id, username, first_name, last_name, token, is_banned, reseller_id, awaiting_code, start_categories_message_id, active_payment_order_id, active_keys_viewer_message_id, created_at, active_durations_message_id, active_payment_error_message_id, active_expiry_notice_message_id, last_user_start_message_id, last_bot_welcome_message_id, last_start_date, broadcast_categories_message_id, last_mykeys_user_message_id, last_mykeys_pin_notice_message_id, last_howto_user_message_id, last_howto_bot_message_id, reseller_level_trigger_msg_id, reseller_prompt_msg_id, reseller_success_result_msg_id, reseller_wrong_code_msg_id, reseller_wrong_result_msg_id, last_key_delivery_message_id, profile_photo_url, profile_photo_file_id, profile_photo_updated_at, campaign_deep_link_code) VALUES (2, 7532582412, 'SayGGAdmin', '𝗦𝗮𝘆𝗚𝗚 ➛ Aᴅᴍɪɴ 🏃🏻', NULL, '48858f5ee08e13086de75101ccdb6b55', 0, NULL, 0, NULL, NULL, 1147, '2026-04-01 03:52:30.792311', NULL, NULL, 1230, 1184, 1185, '2026-04-05', NULL, 1146, 1148, 1149, 1150, NULL, NULL, NULL, NULL, NULL, 1135, 'https://api.telegram.org/file/bot8714587404:AAHujo4UqWUETK8qjKa0Ofp_cXl5D2Klw30/photos/file_3.jpg', 'AgACAgUAAxUAAWnRJrLpbmTUN82e-1ckT0qbV9C9AAKHDWsbuDURVrC7bXNnqjreAQADAgADYwADOwQ', '2026-04-05 17:54:38.038113', NULL);
INSERT INTO users (id, telegram_id, username, first_name, last_name, token, is_banned, reseller_id, awaiting_code, start_categories_message_id, active_payment_order_id, active_keys_viewer_message_id, created_at, active_durations_message_id, active_payment_error_message_id, active_expiry_notice_message_id, last_user_start_message_id, last_bot_welcome_message_id, last_start_date, broadcast_categories_message_id, last_mykeys_user_message_id, last_mykeys_pin_notice_message_id, last_howto_user_message_id, last_howto_bot_message_id, reseller_level_trigger_msg_id, reseller_prompt_msg_id, reseller_success_result_msg_id, reseller_wrong_code_msg_id, reseller_wrong_result_msg_id, last_key_delivery_message_id, profile_photo_url, profile_photo_file_id, profile_photo_updated_at, campaign_deep_link_code) VALUES (3, 6842239034, 'CodeBrecker', '< 𝗖𝗼𝗗𝗘 - 𝗕𝗥𝗘𝗖𝗞𝗘𝗥 \\>𝗧𝗔𝗠𝗜𝗟', NULL, 'fe3f31d3ca7697ebae508f5698a154b3', 0, NULL, 0, 1049, NULL, 1051, '2026-04-01 13:23:40.114221', NULL, NULL, NULL, 1047, 1048, '2026-04-02', NULL, 1050, NULL, 955, 956, NULL, NULL, NULL, NULL, NULL, NULL, 'https://api.telegram.org/file/bot8714587404:AAHujo4UqWUETK8qjKa0Ofp_cXl5D2Klw30/photos/file_2.jpg', 'AgACAgUAAxUAAWnNHFyTE7Jl7E2BE58Q5crwPK2GAAL6DGsbAzdwVgNQRiYYeZovAQADAgADYwADOgQ', '2026-04-02 12:58:00.923066', NULL);
INSERT INTO users (id, telegram_id, username, first_name, last_name, token, is_banned, reseller_id, awaiting_code, start_categories_message_id, active_payment_order_id, active_keys_viewer_message_id, created_at, active_durations_message_id, active_payment_error_message_id, active_expiry_notice_message_id, last_user_start_message_id, last_bot_welcome_message_id, last_start_date, broadcast_categories_message_id, last_mykeys_user_message_id, last_mykeys_pin_notice_message_id, last_howto_user_message_id, last_howto_bot_message_id, reseller_level_trigger_msg_id, reseller_prompt_msg_id, reseller_success_result_msg_id, reseller_wrong_code_msg_id, reseller_wrong_result_msg_id, last_key_delivery_message_id, profile_photo_url, profile_photo_file_id, profile_photo_updated_at, campaign_deep_link_code) VALUES (4, 6334386009, 'Tamil_Hacks', '<ᅳ𝙏𝘾ᅳSPIKE>', NULL, '48841672f95e37ae0a99e4e8db8970e0', 0, NULL, 0, 1182, NULL, NULL, '2026-04-04 18:17:30.742020', NULL, NULL, NULL, 1180, 1181, '2026-04-05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://api.telegram.org/file/bot8714587404:AAHujo4UqWUETK8qjKa0Ofp_cXl5D2Klw30/photos/file_5.jpg', 'AgACAgUAAxUAAWnRVbst34Uw0bGwgl6Ch4YY_Dz2AALIC2sbB3RgVv9E8bqeWcjkAQADAgADYwADOwQ', '2026-04-04 19:37:23.128698', NULL);

-- Table: product_keys (7 rows)
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (2, 2, 11, 'Testz', '0', 1, '2026-04-01 19:54:43.222102');
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (3, 2, 11, 'Jsuwjwnsw', '0', 1, '2026-04-02 09:12:06.174869');
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (4, 2, 11, 'Nsiwiwjw', '0', 1, '2026-04-02 19:04:24.433632');
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (5, 2, 11, 'SayGG_Trial_LMCF8', '0', 1, '2026-04-02 19:14:23.946259');
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (6, 2, 11, 'SayGG_Trial_YQJR6', '0', 1, '2026-04-02 19:29:04.928470');
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (7, 2, 11, 'SayGG_Trial_99ZE8', '0', 1, '2026-04-03 12:43:54.147495');
INSERT INTO product_keys (id, category_id, duration_id, key_value, price, is_sold, created_at) VALUES (8, 2, 11, 'SayGG_Trial_ZK10Q', '0', 1, '2026-04-20 10:52:05.920875');

-- Table: source_rules (11 rows)
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (1, 2, 1, 'api', 2, 'PUBG', '1d', '1', NULL, true, 'API test passed. Key: SayGG_Day_ZICTL', true, '2026-03-31 18:46:27.059984', '2026-03-31 18:46:23.818333', '2026-03-31 18:46:23.818333');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (2, 2, 2, 'api', 2, 'PUBG', '7d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:46:53.759560', '2026-03-31 18:46:53.759560');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (3, 1, 3, 'api', 1, 'PUBG', '1d', '1', NULL, true, 'API test passed. Key: novaesp6TK6LKNVQK', true, '2026-03-31 18:52:47.093608', '2026-03-31 18:49:29.798270', '2026-03-31 18:49:29.798270');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (4, 1, 4, 'api', 1, 'PUBG', '7d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:49:50.477370', '2026-03-31 18:49:50.477370');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (5, 1, 5, 'api', 1, 'PUBG', '30d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:50:09.020713', '2026-03-31 18:50:09.020713');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (6, 1, 6, 'api', 1, 'PUBG', '60d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:50:30.057147', '2026-03-31 18:50:30.057147');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (7, 3, 7, 'api', 1, 'PUBG', '1d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:51:06.390092', '2026-03-31 18:51:06.390092');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (8, 3, 8, 'api', 1, 'PUBG', '7d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:51:23.720579', '2026-03-31 18:51:23.720579');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (9, 3, 9, 'api', 1, 'PUBG', '30d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:51:56.318014', '2026-03-31 18:51:56.318014');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (10, 3, 10, 'api', 1, 'PUBG', '60d', '1', NULL, true, NULL, NULL, NULL, '2026-03-31 18:52:40.280215', '2026-03-31 18:52:40.280215');
INSERT INTO source_rules (id, category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active, last_test_result, last_test_success, last_test_at, created_at, updated_at) VALUES (11, 2, 11, 'api', 2, 'PUBG', '1h', '1', NULL, true, 'API test passed. Key: SayGG_Trial_CALJV', true, '2026-04-02 19:12:47.413455', '2026-04-01 19:55:28.775313', '2026-04-02 19:12:41.260086');

-- Table: discount_plans (2 rows)
INSERT INTO discount_plans (id, name, description, is_active, apply_scope, starts_at, expires_at, created_at, updated_at, broadcast_template, is_campaign_generated) VALUES (1, 'Sunday Discount ', NULL, true, 'all_categories', NULL, '2026-04-01 09:30:00', '2026-04-01 03:55:04.717474', '2026-04-01 03:56:21.101225', NULL, false);
INSERT INTO discount_plans (id, name, description, is_active, apply_scope, starts_at, expires_at, created_at, updated_at, broadcast_template, is_campaign_generated) VALUES (2, '[Campaign] Night Flash Sale', 'Auto-generated by campaign #1', false, 'all_categories', NULL, NULL, '2026-04-01 18:29:23.162085', '2026-04-01 18:29:23.162085', NULL, true);

-- Table: discount_rules (2 rows)
INSERT INTO discount_rules (id, plan_id, category_id, duration_id, discount_type, discount_value, override_price) VALUES (1, 1, NULL, NULL, 'percent', '10.00', NULL);
INSERT INTO discount_rules (id, plan_id, category_id, duration_id, discount_type, discount_value, override_price) VALUES (2, 2, NULL, NULL, 'percent', '13.9000000000000003552713678800500929355621337890625', NULL);

-- Table: orders (18 rows)
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (1, 1, NULL, 'cancelled', '100.00', '2026-04-01 03:12:34.664341', '2026-04-01 03:12:34.664341', 80, NULL, 'KS2026040103123510DB20E4A', NULL, 'NovaEsp MoD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100.00', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 7, category_id: 3, duration_id: 7}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (2, 2, NULL, 'cancelled', '90.00', '2026-04-01 08:13:00.505827', '2026-04-01 08:13:00.505827', 178, NULL, 'KS202604010813002396BBDBE', NULL, 'SayGG Skin MOD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'user_discount', '100.00', 1, 'Sunday Discount', 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 1, category_id: 2, duration_id: 1, api_provider_id: 2}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (3, 3, NULL, 'cancelled', '100', '2026-04-01 18:37:01.803727', '2026-04-01 18:37:01.803727', 794, NULL, 'KS2026040118370239AC68957', NULL, 'SayGG Skin MOD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 1, category_id: 2, duration_id: 1}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (4, 3, NULL, 'cancelled', '100', '2026-04-01 18:38:08.299133', '2026-04-01 18:38:08.299133', 799, NULL, 'KS202604011838084789D5C2F', NULL, 'SayGG Skin MOD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 1, category_id: 2, duration_id: 1}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (5, 3, NULL, 'cancelled', '100', '2026-04-01 18:41:02.725014', '2026-04-01 18:41:02.725014', 815, NULL, 'KS2026040118410256D781635', NULL, 'SayGG Skin MOD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 1, category_id: 2, duration_id: 1}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (6, 2, 2, 'paid', '1', '2026-04-01 19:55:50.166669', '2026-04-01 19:55:50.166669', 862, NULL, 'KS2026040119555065F36BC26', '2026-04-01 19:56:23.292454', 'SayGG Skin MOD x64', 'Test', 'Testz', NULL, 'customer', '@SayGGAdmin', '645802928325', '2026-04-01 19:56:23.862293', '20260402110920000246273593718281133', '645802928325', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-01 19:56:23.495856', '2026-04-01 19:56:23.556826', NULL, NULL, false, 'manual', NULL, '{source_type: manual, rule_id: 11, category_id: 2, duration_id: 11}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (7, 2, NULL, 'cancelled', '100', '2026-04-01 20:02:00.390083', '2026-04-01 20:02:00.390083', 870, NULL, 'KS2026040120020077DA0B71A', NULL, 'SayGG Skin MOD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 1, category_id: 2, duration_id: 1}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (8, 2, NULL, 'cancelled', '100', '2026-04-01 20:29:40.072270', '2026-04-01 20:29:40.072270', 894, NULL, 'KS2026040120294085C590BAA', NULL, 'SayGG Skin MOD x64', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 1, category_id: 2, duration_id: 1}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (9, 2, NULL, 'cancelled', '100', '2026-04-02 05:05:05.056605', '2026-04-02 05:05:05.056605', 901, NULL, 'KS202604020505059EDD80B7B', NULL, 'NovaEsp Loader', 'Day', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '100', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 3, category_id: 1, duration_id: 3}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (10, 2, 3, 'paid', '1', '2026-04-02 09:12:30.475794', '2026-04-02 09:12:30.475794', 1029, NULL, 'KS2026040209123010F5E9D3C8', '2026-04-02 09:15:17.189505', 'SayGG Skin MOD x64', 'Test', 'Jsuwjwnsw', NULL, 'customer', '@SayGGAdmin', '645877050069', '2026-04-02 09:15:17.787224', '20260402110920000246474639417854637', '645877050069', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-02 09:15:17.403314', '2026-04-02 09:15:17.468109', NULL, NULL, false, 'manual', NULL, '{source_type: manual, rule_id: 11, category_id: 2, duration_id: 11}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (11, 1, 4, 'paid', '1', '2026-04-02 19:05:39.362614', '2026-04-02 19:05:39.362614', 1061, NULL, 'KS202604021905391191CDABDC', '2026-04-02 19:06:17.189467', 'SayGG Skin MOD x64', 'Test', 'Nsiwiwjw', NULL, 'customer', '@Ceo_DarkFury', '609365613837', '2026-04-02 19:06:17.758991', '20260403111050000246623372306781598', '609365613837', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-02 19:06:17.391847', '2026-04-02 19:06:17.452792', NULL, NULL, false, 'manual', NULL, '{source_type: manual, rule_id: 11, category_id: 2, duration_id: 11}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (12, 1, 5, 'paid', '1', '2026-04-02 19:14:00.784587', '2026-04-02 19:14:00.784587', 1080, NULL, 'KS2026040219140112447EB50D', '2026-04-02 19:14:23.394853', 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_LMCF8', NULL, 'customer', '@Ceo_DarkFury', '645923798719', '2026-04-02 19:14:24.215059', '20260403110940000246625414097930840', '645923798719', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-02 19:14:23.600244', '2026-04-02 19:14:23.946259', NULL, NULL, false, 'api', NULL, '{source_type: api, rule_id: 11, category_id: 2, duration_id: 11, api_provider_id: 2}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (13, 1, 6, 'paid', '1', '2026-04-02 19:28:06.546661', '2026-04-02 19:28:06.546661', 1093, NULL, 'KS20260402192806135AD277CF', '2026-04-02 19:29:02.628357', 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_YQJR6', NULL, 'customer', '@Ceo_DarkFury', '609346005743', '2026-04-02 19:29:05.188816', '20260403110880000246628972981824041', '609346005743', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-02 19:29:02.829769', '2026-04-02 19:29:04.928470', NULL, NULL, false, 'api', NULL, '{source_type: api, rule_id: 11, category_id: 2, duration_id: 11, api_provider_id: 2}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (14, 2, 7, 'paid', '1', '2026-04-03 12:43:11.762547', '2026-04-03 12:43:11.762547', 1132, NULL, 'KS2026040312431114D5CF4F4D', '2026-04-03 12:43:52.096766', 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_99ZE8', NULL, 'customer', '@SayGGAdmin', '609370440684', '2026-04-03 12:43:54.423774', '20260403110970000246889435602983568', '609370440684', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-03 12:43:52.308738', '2026-04-03 12:43:54.147495', NULL, NULL, false, 'api', NULL, '{source_type: api, rule_id: 11, category_id: 2, duration_id: 11, api_provider_id: 2}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (15, 2, NULL, 'cancelled', '1', '2026-04-04 14:56:59.527371', '2026-04-04 14:56:59.527371', 1142, NULL, 'KS20260404145659155CC2FDEE', NULL, 'SayGG Skin MOD x64', 'Test', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '1', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 11, category_id: 2, duration_id: 11}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (16, 4, NULL, 'cancelled', '1', '2026-04-04 18:18:50.368984', '2026-04-04 18:18:50.368984', 1170, NULL, 'KS2026040418185016F1419ADD', NULL, 'SayGG Skin MOD x64', 'Test', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '1', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 11, category_id: 2, duration_id: 11}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (17, 2, NULL, 'cancelled', '1', '2026-04-05 17:54:55.677496', '2026-04-05 17:54:55.677496', 1188, NULL, 'KS202604051754551775D1C016', NULL, 'SayGG Skin MOD x64', 'Test', NULL, NULL, 'customer', NULL, NULL, NULL, NULL, NULL, NULL, 'base', '1', NULL, NULL, 'pending', NULL, NULL, NULL, NULL, false, NULL, NULL, '{source_type: api, rule_id: 11, category_id: 2, duration_id: 11}', NULL, NULL, NULL, NULL, false);
INSERT INTO orders (id, user_id, key_id, status, amount, created_at, updated_at, qr_message_id, last_error_message_id, txn_ref, verified_at, purchased_category_name, purchased_duration_name, purchased_key_value, purchased_amount, purchaser_role, purchaser_label, paid_utr, delivered_at, gateway_txn_id, gateway_bank_txn_id, paid_amount, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name, fulfillment_status, fulfillment_attempted_at, fulfilled_at, fulfillment_error, provider_response_meta, fallback_used, delivered_source, owner_alert_sent_at, source_rule_snapshot, campaign_id, campaign_deep_link_code, campaign_run_id, campaign_deep_link_id, is_campaign_late_conversion) VALUES (18, 1, 8, 'paid', '1', '2026-04-20 10:51:38.456308', '2026-04-20 10:51:38.456308', 1373, NULL, 'KS2026042010513818ACFBABE5', '2026-04-20 10:52:02.916159', 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_ZK10Q', NULL, 'customer', '@Ceo_DarkFury', '647608727502', '2026-04-20 10:52:05.929533', '20260420110870000253021969948106712', '647608727502', '1', 'base', '1', NULL, NULL, 'fulfilled', '2026-04-20 10:52:02.968781', '2026-04-20 10:52:05.920875', NULL, '{"success":true,"currency":"","quantity":1,"keys":[{"game":"PUBG","user_key":"SayGG_Trial_ZK10Q","duration":1,"max_devices":1,"status":1,"registrator":"SayGG","created_at":"2026-04-20 10:52:05"}]}', false, 'api', NULL, '{"source_type": "api", "rule_id": 11, "category_id": 2, "duration_id": 11, "api_provider_id": 2, "provider_name": "SayGG Skin Server", "provider_base_url": "https://saygg.shop/g/aa02b82e1c/6d0b71827e/7c9eed35d2/3d38958183/b05aef9fc2", "provider_token": "5u3k0q614h5c6u375v4p4a546o1v0p3e0s421w412g403659", "provider_is_active": true, "api_game_value": "PUBG", "api_duration_value": "1h", "api_device_value": "1", "api_currency_value": null}', NULL, NULL, NULL, NULL, false);

-- Table: purchased_keys_history (7 rows)
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (2, 2, 6, 7532582412, 'SayGGAdmin', '𝗦𝗮𝘆𝗚𝗚 ➛ Aᴅᴍɪɴ 🏃🏻', NULL, 0, 'SayGG Skin MOD x64', 'Test', 'Testz', '1', 'KS2026040119555065F36BC26', '20260402110920000246273593718281133', '645802928325', '2026-04-01 19:56:23.292454', '2026-04-01 19:56:23.962906', NULL, NULL, NULL, NULL);
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (3, 2, 10, 7532582412, 'SayGGAdmin', '𝗦𝗮𝘆𝗚𝗚 ➛ Aᴅᴍɪɴ 🏃🏻', NULL, 0, 'SayGG Skin MOD x64', 'Test', 'Jsuwjwnsw', '1', 'KS2026040209123010F5E9D3C8', '20260402110920000246474639417854637', '645877050069', '2026-04-02 09:15:17.189505', '2026-04-02 09:15:17.895065', NULL, NULL, NULL, NULL);
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (4, 1, 11, 6092672929, 'Ceo_DarkFury', '⌬ Ｉｍ ➛ 𝗗𝗮𝗿𝗸𝗙𝘂𝗿𝘆', '〝 ᴺᵒᵛᵃᴱˢᵖ 〞', 0, 'SayGG Skin MOD x64', 'Test', 'Nsiwiwjw', '1', 'KS202604021905391191CDABDC', '20260403111050000246623372306781598', '609365613837', '2026-04-02 19:06:17.189467', '2026-04-02 19:06:17.866374', NULL, NULL, NULL, NULL);
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (5, 1, 12, 6092672929, 'Ceo_DarkFury', '⌬ Ｉｍ ➛ 𝗗𝗮𝗿𝗸𝗙𝘂𝗿𝘆', '〝 ᴺᵒᵛᵃᴱˢᵖ 〞', 0, 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_LMCF8', '1', 'KS2026040219140112447EB50D', '20260403110940000246625414097930840', '645923798719', '2026-04-02 19:14:23.394853', '2026-04-02 19:14:24.317447', NULL, NULL, NULL, NULL);
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (6, 1, 13, 6092672929, 'Ceo_DarkFury', '⌬ Ｉｍ ➛ 𝗗𝗮𝗿𝗸𝗙𝘂𝗿𝘆', '〝 ᴺᵒᵛᵃᴱˢᵖ 〞', 0, 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_YQJR6', '1', 'KS20260402192806135AD277CF', '20260403110880000246628972981824041', '609346005743', '2026-04-02 19:29:02.628357', '2026-04-02 19:29:05.290437', NULL, NULL, NULL, NULL);
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (7, 2, 14, 7532582412, 'SayGGAdmin', '𝗦𝗮𝘆𝗚𝗚 ➛ Aᴅᴍɪɴ 🏃🏻', NULL, 0, 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_99ZE8', '1', 'KS2026040312431114D5CF4F4D', '20260403110970000246889435602983568', '609370440684', '2026-04-03 12:43:52.096766', '2026-04-03 12:43:54.530225', NULL, NULL, NULL, NULL);
INSERT INTO purchased_keys_history (id, user_id, order_id, telegram_id, username, first_name, last_name, is_reseller_purchase, category_name, duration_name, key_value, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at, pricing_source, base_amount, applied_discount_plan_id, applied_discount_plan_name) VALUES (8, 1, 18, 6092672929, 'Ceo_DarkFury', '⌬ Ｉｍ ➛ 𝗗𝗮𝗿𝗸𝗙𝘂𝗿𝘆', '〝 ᴺᵒᵛᵃᴱˢᵖ 〞', 0, 'SayGG Skin MOD x64', 'Test', 'SayGG_Trial_ZK10Q', '1', 'KS2026042010513818ACFBABE5', '20260420110870000253021969948106712', '647608727502', '2026-04-20 10:52:02.916159', '2026-04-20 10:52:05.946319', NULL, NULL, NULL, NULL);

-- Table: discount_broadcast_messages (4 rows)
INSERT INTO discount_broadcast_messages (id, queue_id, plan_id, user_id, telegram_id, broadcast_message_id, created_at, pin_service_message_id) VALUES (1, 1, 1, 1, 6092672929, 91, '2026-04-01 03:55:25.236903', NULL);
INSERT INTO discount_broadcast_messages (id, queue_id, plan_id, user_id, telegram_id, broadcast_message_id, created_at, pin_service_message_id) VALUES (2, 1, 1, 2, 7532582412, 92, '2026-04-01 03:55:25.628037', NULL);
INSERT INTO discount_broadcast_messages (id, queue_id, plan_id, user_id, telegram_id, broadcast_message_id, created_at, pin_service_message_id) VALUES (3, 2, 1, 2, 7532582412, 102, '2026-04-01 03:57:52.865745', NULL);
INSERT INTO discount_broadcast_messages (id, queue_id, plan_id, user_id, telegram_id, broadcast_message_id, created_at, pin_service_message_id) VALUES (4, 2, 1, 1, 6092672929, 104, '2026-04-01 03:57:53.803611', NULL);

-- Table: force_join_channels (2 rows)
INSERT INTO force_join_channels (id, channel_identifier, channel_title, invite_link, is_active, created_at, sort_order, channel_username, status, status_detail, channel_id) VALUES (1, '-1003762030313', 'Vip', 'https://t.me/+Q2r7ZXDG-OJjMjRl', true, '2026-04-01 18:37:40.701613', 0, NULL, 'valid', 'Bot is administrator — can verify membership · Fresh invite link generated', -1003762030313);
INSERT INTO force_join_channels (id, channel_identifier, channel_title, invite_link, is_active, created_at, sort_order, channel_username, status, status_detail, channel_id) VALUES (1, '-1003762030313', 'Vip', 'https://t.me/+Q2r7ZXDG-OJjMjRl', true, '2026-04-01 18:37:40.701613', 0, NULL, 'valid', 'Bot is administrator — can verify membership · Fresh invite link generated', -1003762030313);

-- Table: campaign_templates (9 rows)
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (1, 'Night Offer Start', 'promo_start', '🔥 <b>{campaign_name}</b> is now live!

🎯 Category: <b>{category_name}</b>
⏳ Duration: <b>{duration_name}</b>

💸 Original Price: <b>{original_price}</b>
🎁 Discount: <b>{discount_percent}% OFF</b>
✅ Offer Price: <b>{discounted_price}</b>

⚠️ Hurry! Offer expires at <b>{expires_at}</b>

Tap below to open the promo offer.', 'HTML', NULL, '[{text:🛒 Buy Now, url:{deep_link}}]', NULL, NULL, NULL, true, '2026-04-01 03:13:53.562726', '2026-04-01 03:13:53.562726', 'web', 'web', NULL, NULL, NULL, NULL, NULL);
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (2, 'Night Offer Expired', 'promo_expiry', '⌛ <b>{campaign_name}</b> has expired.

📦 Category: <b>{category_name}</b>
⏳ Duration: <b>{duration_name}</b>

💰 Current Price: <b>{current_price}</b>

The promo price is no longer active.
Check the bot for the latest available offers.', 'HTML', NULL, '[{text:📲 Open Bot, url:{deep_link}}]', NULL, NULL, NULL, true, '2026-04-01 03:13:53.562726', '2026-04-01 03:13:53.562726', 'web', 'web', NULL, NULL, NULL, NULL, NULL);
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (3, 'Default Promo Start', 'promo_start', '📢 <b>{campaign_name}</b> — Limited Offer

Hi <b>{user_name}</b> 👋

💰 <b>{discount_percent}% Discounted Prices</b>
──────────────
{product_discount_lines}
──────────────

⏰ <b>Offer ends:</b> {expires_at}

Tap below to open the store and claim your deal ↓', 'HTML', '[]', '[{text:🛒 Buy Now, url:{deep_link}, style:primary, emoji_id:}]', NULL, NULL, NULL, true, '2026-04-01 03:13:54.371953', '2026-04-01 03:13:54.371953', 'web', 'web', NULL, NULL, NULL, NULL, NULL);
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (4, 'Default Promo Expiry', 'promo_expiry', '⏰ <b>{campaign_name} Expired</b>

Hi <b>{user_name}</b> 👋

The promotional prices have ended. Current prices are now:

──────────────
{product_expiry_lines}
──────────────

Check the store for active offers and new discounts.', 'HTML', '[]', '[{text:📦 Open Store, url:{deep_link}, style:secondary, emoji_id:}]', NULL, NULL, NULL, true, '2026-04-01 03:13:54.371953', '2026-04-01 03:13:54.371953', 'web', 'web', NULL, NULL, NULL, NULL, NULL);
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (5, 'Default Trial Start', 'trial_start', '🎉 <b>Free Trial Activated!</b>

Hey {user_name}, your trial has been activated!

{TrialCategoryBlocks}

⏱ Duration: <b>{trial_duration} hours</b>
📱 Devices: <b>{trial_devices}</b>
⏰ Expires: <b>{expire_time}</b>

Enjoy your trial from <b>{bot_name}</b>!', 'HTML', NULL, NULL, NULL, NULL, NULL, true, '2026-04-01 03:52:52.483122', '2026-04-01 03:52:52.483122', 'web', 'web', NULL, NULL, NULL, NULL, NULL);
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (6, 'Default Trial Expire', 'trial_expire', '⏰ <b>Trial Expired</b>

Hey {user_name}, your trial for <b>{campaign_name}</b> has expired.

Want to continue? Purchase a full key from <b>{bot_name}</b>!', 'HTML', NULL, NULL, NULL, NULL, NULL, true, '2026-04-01 03:52:52.531936', '2026-04-01 03:52:52.531936', 'web', 'web', NULL, NULL, NULL, NULL, NULL);
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (7, 'APK Caption — NovaEsp Loader', 'trial_apk_caption', '📦 <b>{category_name}</b>
🔑 Key: <code>{trial_key}</code>

⏱ Duration: <b>{trial_duration}h</b>
⏰ Expires: <b>{expire_time}</b>', 'HTML', NULL, NULL, NULL, NULL, NULL, true, '2026-04-01 03:52:52.597157', '2026-04-01 03:52:52.597157', 'system', 'system', NULL, NULL, NULL, 1, 'NovaEsp Loader');
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (8, 'APK Caption — SayGG Skin MOD x64', 'trial_apk_caption', '📦 <b>{category_name}</b>
🔑 Key: <code>{trial_key}</code>

⏱ Duration: <b>{trial_duration}h</b>
⏰ Expires: <b>{expire_time}</b>', 'HTML', NULL, NULL, NULL, NULL, NULL, true, '2026-04-01 03:52:52.640318', '2026-04-01 03:52:52.640318', 'system', 'system', NULL, NULL, NULL, 2, 'SayGG Skin MOD x64');
INSERT INTO campaign_templates (id, name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, created_at, updated_at, updated_by, edited_via, body_entities_json, apk_captions_json, start_delivery_config_json, category_id, category_name_snapshot) VALUES (9, 'APK Caption — NovaEsp MoD x64', 'trial_apk_caption', '📦 <b>{category_name}</b>
🔑 Key: <code>{trial_key}</code>

⏱ Duration: <b>{trial_duration}h</b>
⏰ Expires: <b>{expire_time}</b>', 'HTML', NULL, NULL, NULL, NULL, NULL, true, '2026-04-01 03:52:52.682186', '2026-04-01 03:52:52.682186', 'system', 'system', NULL, NULL, NULL, 3, 'NovaEsp MoD x64');

-- Table: scheduled_campaigns (1 rows)
INSERT INTO scheduled_campaigns (id, name, description, status, campaign_mode, linked_discount_plan_id, category_scope_json, duration_scope_json, repeat_mode, timezone, start_at, expire_at, next_run_at, next_expire_at, is_enabled, promo_template_id, expiry_template_id, send_to_users, send_to_channels, created_at, updated_at, last_run_at, last_expired_at, auto_discount_plan_id, channel_targets_json) VALUES (1, 'Night Flash Sale', 'Auto-created demo promo campaign', 'expired', 'random_discount', NULL, '[1]', '[1]', 'once', 'Asia/Kolkata', '2026-04-01 16:30:00', '2026-04-01 17:30:00', '2026-04-01 16:30:00', '2026-04-01 17:30:00', true, 1, 2, true, false, '2026-04-01 03:13:53.562726', '2026-04-01 18:29:30.426802', '2026-04-01 18:29:23.033250', '2026-04-01 18:29:30.426802', 2, '[]');

-- Table: campaign_targets (1 rows)
INSERT INTO campaign_targets (id, campaign_id, target_type, target_value, message_kind, created_at) VALUES (1, 1, 'all_users', NULL, 'promo_start', '2026-04-01 03:13:53.562726');

-- Table: campaign_discount_rules (1 rows)
INSERT INTO campaign_discount_rules (id, campaign_id, discount_mode, fixed_value, min_value, max_value, applies_to_category_id, applies_to_duration_id, created_at, updated_at) VALUES (1, 1, 'random_percent', NULL, '5.00', '25.00', NULL, NULL, '2026-04-01 03:13:53.562726', '2026-04-01 03:13:53.562726');

-- Table: campaign_deep_links (2 rows)
INSERT INTO campaign_deep_links (id, campaign_id, code, deep_link_url, is_active, created_at, campaign_run_id, status, activated_at, expired_at, attribution_start_at, attribution_end_at, opens_count, unique_opens_count, starts_count, purchases_count, revenue_total, late_purchases_count, late_revenue_total) VALUES (1, 1, 'promo_3ae62e6f', NULL, true, '2026-04-01 03:13:53.562726', NULL, 'active', NULL, NULL, NULL, NULL, 0, 0, 0, 0, '0.00', 0, '0.00');
INSERT INTO campaign_deep_links (id, campaign_id, code, deep_link_url, is_active, created_at, campaign_run_id, status, activated_at, expired_at, attribution_start_at, attribution_end_at, opens_count, unique_opens_count, starts_count, purchases_count, revenue_total, late_purchases_count, late_revenue_total) VALUES (2, 1, 'promo_qh0fhot1', 'https://t.me/Bgmi_KeysBot?start=promo_qh0fhot1', false, '2026-04-01 18:29:24.196388', 2, 'expired', '2026-04-01 18:29:24.196388', '2026-04-01 18:29:29.951758', '2026-04-01 18:29:24.196388', '2026-04-01 17:30:00', 0, 0, 0, 0, '0', 0, '0');

-- Table: campaign_runs (2 rows)
INSERT INTO campaign_runs (id, campaign_id, run_type, executed_at, status, generated_discount_value, generated_discount_type, generated_final_price_json, total_targets, total_sent, total_failed, revenue_generated, metadata, created_at, error_text, admin_notified, source_chat_id, source_message_id, channel_delivery_method, channels_targeted, channels_copied, channels_failed) VALUES (2, 1, 'promo_start', '2026-04-01 18:29:24.276207', 'completed', '13.9', 'percent', '{NovaEsp Loader_Day: {original: 100.0, final: 86.1, category: NovaEsp Loader, duration: Day}, NovaEsp Loader_Week: {original: 500.0, final: 430.5, category: NovaEsp Loader, duration: Week}, NovaEsp Loader_Month: {original: 1000.0, final: 861.0, category: NovaEsp Loader, duration: Month}, NovaEsp Loader_Season: {original: 1500.0, final: 1291.5, category: NovaEsp Loader, duration: Season}}', 3, 3, 0, NULL, NULL, '2026-04-01 18:29:24.276207', NULL, false, NULL, NULL, 'direct_channel', 0, 0, 0);
INSERT INTO campaign_runs (id, campaign_id, run_type, executed_at, status, generated_discount_value, generated_discount_type, generated_final_price_json, total_targets, total_sent, total_failed, revenue_generated, metadata, created_at, error_text, admin_notified, source_chat_id, source_message_id, channel_delivery_method, channels_targeted, channels_copied, channels_failed) VALUES (3, 1, 'promo_expiry', '2026-04-01 18:29:27.509187', 'completed', '16.6', 'percent', '{NovaEsp Loader_Day: {original: 100.0, final: 83.4, category: NovaEsp Loader, duration: Day}, NovaEsp Loader_Week: {original: 500.0, final: 417.0, category: NovaEsp Loader, duration: Week}, NovaEsp Loader_Month: {original: 1000.0, final: 834.0, category: NovaEsp Loader, duration: Month}, NovaEsp Loader_Season: {original: 1500.0, final: 1251.0, category: NovaEsp Loader, duration: Season}}', 3, 3, 0, NULL, NULL, '2026-04-01 18:29:27.509187', NULL, false, NULL, NULL, 'direct_channel', 0, 0, 0);

-- Table: campaign_daily_stats (1 rows)
INSERT INTO campaign_daily_stats (id, stat_date, campaign_id, total_opens, unique_opens, total_purchases, total_revenue, promo_start_sent, promo_expiry_sent, created_at, updated_at) VALUES (2, '2026-04-01', 1, 0, 0, 0, '0', 0, 3, '2026-04-01 18:29:30.354276', '2026-04-01 18:29:30.354276');

-- Table: campaign_delivery_logs (12 rows)
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (2, 2, 1, 'user', 6092672929, NULL, 'promo_start', 'sent', 766, NULL, '2026-04-01 18:29:25.714422', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (2, 2, 1, 'user', 6092672929, NULL, 'promo_start', 'sent', 766, NULL, '2026-04-01 18:29:25.714422', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (3, 2, 1, 'user', 6842239034, NULL, 'promo_start', 'sent', 767, NULL, '2026-04-01 18:29:26.381724', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (3, 2, 1, 'user', 6842239034, NULL, 'promo_start', 'sent', 767, NULL, '2026-04-01 18:29:26.381724', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (4, 2, 1, 'user', 7532582412, NULL, 'promo_start', 'sent', 768, NULL, '2026-04-01 18:29:27.006613', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (4, 2, 1, 'user', 7532582412, NULL, 'promo_start', 'sent', 768, NULL, '2026-04-01 18:29:27.006613', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (5, 3, 1, 'user', 6092672929, NULL, 'promo_expiry', 'sent', 769, NULL, '2026-04-01 18:29:28.747059', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (5, 3, 1, 'user', 6092672929, NULL, 'promo_expiry', 'sent', 769, NULL, '2026-04-01 18:29:28.747059', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (6, 3, 1, 'user', 6842239034, NULL, 'promo_expiry', 'sent', 770, NULL, '2026-04-01 18:29:29.373532', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (6, 3, 1, 'user', 6842239034, NULL, 'promo_expiry', 'sent', 770, NULL, '2026-04-01 18:29:29.373532', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (7, 3, 1, 'user', 7532582412, NULL, 'promo_expiry', 'sent', 771, NULL, '2026-04-01 18:29:30.012212', 'direct', NULL);
INSERT INTO campaign_delivery_logs (id, campaign_run_id, campaign_id, target_type, telegram_id, username, message_kind, delivery_status, telegram_message_id, error_text, created_at, delivery_method, source_message_id) VALUES (7, 3, 1, 'user', 7532582412, NULL, 'promo_expiry', 'sent', 771, NULL, '2026-04-01 18:29:30.012212', 'direct', NULL);

-- Table: campaign_expiry_logs (1 rows)
INSERT INTO campaign_expiry_logs (id, campaign_id, campaign_run_id, started_at, completed_at, status, discount_deactivated, recipients_resolved, sent, failed, error_text, metadata, created_at) VALUES (2, 1, NULL, '2026-04-01 18:29:27.243337', '2026-04-01 18:29:30.290439', 'completed', true, 3, 3, 0, NULL, NULL, '2026-04-01 18:29:27.243337');

-- Table: source_fulfillment_logs (9 rows)
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (2, NULL, 2, 11, 'SayGG Skin MOD x64', 'Test', NULL, NULL, NULL, false, false, NULL, NULL, NULL, 'no_source_rule', '2026-04-01 19:55:04.653404', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (2, NULL, 2, 11, 'SayGG Skin MOD x64', 'Test', NULL, NULL, NULL, false, false, NULL, NULL, NULL, 'no_source_rule', '2026-04-01 19:55:04.653404', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (3, 6, 2, 11, 'SayGG Skin MOD x64', 'Test', 'manual', NULL, NULL, true, true, 'Testz', NULL, NULL, NULL, '2026-04-01 19:56:23.738044', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (3, 6, 2, 11, 'SayGG Skin MOD x64', 'Test', 'manual', NULL, NULL, true, true, 'Testz', NULL, NULL, NULL, '2026-04-01 19:56:23.738044', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (4, 10, 2, 11, 'SayGG Skin MOD x64', 'Test', 'manual', NULL, NULL, true, true, 'Jsuwjwnsw', NULL, NULL, NULL, '2026-04-02 09:15:17.658965', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (4, 10, 2, 11, 'SayGG Skin MOD x64', 'Test', 'manual', NULL, NULL, true, true, 'Jsuwjwnsw', NULL, NULL, NULL, '2026-04-02 09:15:17.658965', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (5, 11, 2, 11, 'SayGG Skin MOD x64', 'Test', 'manual', NULL, NULL, true, true, 'Nsiwiwjw', NULL, NULL, NULL, '2026-04-02 19:06:17.634567', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (5, 11, 2, 11, 'SayGG Skin MOD x64', 'Test', 'manual', NULL, NULL, true, true, 'Nsiwiwjw', NULL, NULL, NULL, '2026-04-02 19:06:17.634567', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO source_fulfillment_logs (id, order_id, category_id, duration_id, category_name, duration_name, source_type, provider_id, provider_name, resolution_success, delivery_success, key_value, api_request_url, api_raw_response, failure_reason, created_at, user_telegram_id, user_display_name, delivered_source, fallback_used, response_time_ms, http_status) VALUES (9, 18, 2, 11, 'SayGG Skin MOD x64', 'Test', 'api', 2, 'SayGG Skin Server', true, true, 'SayGG_Trial_ZK10Q', 'https://saygg.shop/g/aa02b82e1c/6d0b71827e/7c9eed35d2/3d38958183/b05aef9fc2?game=PUBG&duration=1h&max_devices=1&token=5u3k0q614h5c6u375v4p4a546o1v0p3e0s421w412g403659', '{"success":true,"currency":"","quantity":1,"keys":[{"game":"PUBG","user_key":"SayGG_Trial_ZK10Q","duration":1,"max_devices":1,"status":1,"registrator":"SayGG","created_at":"2026-04-20 10:52:05"}]}', NULL, '2026-04-20 10:52:05.925549', NULL, NULL, NULL, false, NULL, NULL);

-- Table: category_duration_settings (6 rows)
INSERT INTO category_duration_settings (category_id, setting_key, value) VALUES (1, 'msg_select_duration_title', '<blockquote><tg-emoji emoji-id=5071254429701768247>🔠</tg-emoji><tg-emoji emoji-id=5071441338088555640>🔠</tg-emoji><tg-emoji emoji-id=5069043436372362922>🔠</tg-emoji><tg-emoji emoji-id=5069230001161766304>🔠</tg-emoji><tg-emoji emoji-id=6026367225466720832>🌩</tg-emoji> <tg-emoji emoji-id=5069292149338538858>🔠</tg-emoji><tg-emoji emoji-id=5071510590141236002>🔠</tg-emoji><tg-emoji emoji-id=5071300518995821842>🔠</tg-emoji></blockquote>');
INSERT INTO category_duration_settings (category_id, setting_key, value) VALUES (1, 'msg_select_duration_sub', '<blockquote><b><u>Features</u> :)</b></blockquote><b>
• </b><b><u>Lᴏɢɪɴ</u> -
</b><blockquote><b><tg-emoji emoji-id=6143010548586910207>🕊</tg-emoji></b><b>Tᴡɪᴛᴛᴇʀ | </b><b><tg-emoji emoji-id=5454340696183943190>😎</tg-emoji></b><b>Fᴀᴄᴇʙᴏᴏᴋ</b></blockquote>
<b>
• </b><b><u>Esᴘ</u> ( Nᴀᴍᴇ, Hᴇᴀʟᴛʜ , Dɪsᴛᴀɴᴄᴇ )
• </b><b><u>HɪᴅᴇEsᴘ</u> ( YᴏᴜTᴜʙᴇ Sᴛʀᴇᴀᴍ)
• </b><b><u>Aɪᴍʙᴏᴛ</u> ( Tᴀʀɢᴇᴛ - Hᴇᴀᴅ | Hᴀʀᴅ )
• </b><b><u>Bᴜʟʟᴇᴛ Tʀᴀᴄᴋ</u> ( Tᴀʀɢᴇᴛ - Hᴇᴀᴅ | Hᴀʀᴅ )

</b><blockquote><b>𝗦𝗲𝗹𝗲𝗰𝘁 𝗮 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 𝗕𝗲𝗹𝗼𝘄 :</b></blockquote>');
INSERT INTO category_duration_settings (category_id, setting_key, value) VALUES (2, 'msg_select_duration_title', '<blockquote><tg-emoji emoji-id=6296394276087533485>🔠</tg-emoji><tg-emoji emoji-id=6293891774737813501>🔠</tg-emoji><tg-emoji emoji-id=6296309626577096516>🔠</tg-emoji><tg-emoji emoji-id=6296279196733805867>🔠</tg-emoji><tg-emoji emoji-id=6296279196733805867>🔠</tg-emoji><tg-emoji emoji-id=6294120331422470681>➖</tg-emoji><tg-emoji emoji-id=6296394276087533485>🔠</tg-emoji><tg-emoji emoji-id=6294165982629859436>🔠</tg-emoji><tg-emoji emoji-id=6294105543850070579>🔠</tg-emoji><tg-emoji emoji-id=6296133769141161433>🔠</tg-emoji></blockquote>');
INSERT INTO category_duration_settings (category_id, setting_key, value) VALUES (2, 'msg_select_duration_sub', '<blockquote>Fᴇᴀᴛᴜʀᴇs :)</blockquote>
<b>• </b><b><u>Lᴏɢɪɴ</u> -
</b><blockquote><b><tg-emoji emoji-id=6143010548586910207>🕊</tg-emoji></b><b>Tᴡɪᴛᴛᴇʀ | </b><b><tg-emoji emoji-id=5454340696183943190>😎</tg-emoji></b><b>Fᴀᴄᴇʙᴏᴏᴋ</b></blockquote>

<b>• </b><b><u>Esᴘ</u> ( Nᴀᴍᴇ, Hᴇᴀʟᴛʜ , Dɪsᴛᴀɴᴄᴇ )
• </b><b><u>Sᴋɪɴ</u> (Gᴜɴ Mᴀx, X-Sʜᴜᴛ, Cᴀʀ Mᴀx )
• </b><b><u>Aɪᴍʙᴏᴛ</u> ( Tᴀʀɢᴇᴛ - Hᴇᴀᴅ | Hᴀʀᴅ ) 

</b><blockquote><b>𝗦𝗲𝗹𝗲𝗰𝘁 𝗮 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 𝗕𝗲𝗹𝗼𝘄 :</b></blockquote>');
INSERT INTO category_duration_settings (category_id, setting_key, value) VALUES (3, 'msg_select_duration_title', '<blockquote><tg-emoji emoji-id=5071254429701768247>🔠</tg-emoji><tg-emoji emoji-id=5071441338088555640>🔠</tg-emoji><tg-emoji emoji-id=5069043436372362922>🔠</tg-emoji><tg-emoji emoji-id=5069230001161766304>🔠</tg-emoji> <tg-emoji emoji-id=6298529729532136003>💰</tg-emoji>  <tg-emoji emoji-id=5071076798444339841>🔠</tg-emoji><tg-emoji emoji-id=5071441338088555640>🔠</tg-emoji><tg-emoji emoji-id=5071445774789772365>🔠</tg-emoji></blockquote>');
INSERT INTO category_duration_settings (category_id, setting_key, value) VALUES (3, 'msg_select_duration_sub', '<blockquote><b><u>Features</u> :)</b></blockquote><b>
• </b><b><u>Lᴏɢɪɴ</u> -
</b><blockquote><b><tg-emoji emoji-id=6143010548586910207>🕊</tg-emoji></b><b>Tᴡɪᴛᴛᴇʀ | </b><b><tg-emoji emoji-id=5454340696183943190>😎</tg-emoji></b><b>Fᴀᴄᴇʙᴏᴏᴋ</b></blockquote><b>

• </b><b><u>Esᴘ</u> ( Nᴀᴍᴇ, Hᴇᴀʟᴛʜ , Dɪsᴛᴀɴᴄᴇ )
• </b><b><u>Aɪᴍʙᴏᴛ</u> ( Tᴀʀɢᴇᴛ - Hᴇᴀᴅ | Hᴀʀᴅ )</b>
<b>• 80% </b><b><u>Fʟᴀɢ Fɪxᴇᴅ</u> Vᴇʀɪsᴏɴs.

</b><blockquote><b>𝗦𝗲𝗹𝗲𝗰𝘁 𝗮 𝗗𝘂𝗿𝗮𝘁𝗶𝗼𝗻 𝗕𝗲𝗹𝗼𝘄 :</b></blockquote>');

-- Table: bot_settings (94 rows)
INSERT INTO bot_settings (key, value) VALUES ('_discount_cache_version', '1775015861188');
INSERT INTO bot_settings (key, value) VALUES ('bot_btn_categories', 'Categories Menu');
INSERT INTO bot_settings (key, value) VALUES ('bot_btn_copy_key', 'Copy Key');
INSERT INTO bot_settings (key, value) VALUES ('bot_btn_how_to', 'How to Purchase');
INSERT INTO bot_settings (key, value) VALUES ('bot_btn_manage_keys', 'Manage Keys');
INSERT INTO bot_settings (key, value) VALUES ('bot_btn_my_keys', 'My Keys');
INSERT INTO bot_settings (key, value) VALUES ('bot_btn_verify', '𝗩𝗘𝗥𝗜𝗙𝗬 𝗠𝗬 𝗣𝗔𝗬𝗠𝗘𝗡𝗧');
INSERT INTO bot_settings (key, value) VALUES ('bot_keys_empty', '<tg-emoji emoji-id=5404327206476326350>👎</tg-emoji> <b>You </b><b><u>Don''t Have</u> Any </b><b><u>Delivered Keys Yet</u>, You Can </b><b><u>Purchase &amp; Countinue Our Services</u>.</b>');
INSERT INTO bot_settings (key, value) VALUES ('bot_keys_reseller_title', '<blockquote><b><tg-emoji emoji-id=5800835941543186089>#⃣</tg-emoji></b><b>Reseller Purchased Keys.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('bot_keys_title', '<u><tg-emoji emoji-id=5287580662407129147>🔤</tg-emoji></u><u><tg-emoji emoji-id=5287418995543140678>🔤</tg-emoji></u><u><tg-emoji emoji-id=5287307803134813043>🔤</tg-emoji></u><tg-emoji emoji-id=5240003746301224139>⭐️</tg-emoji><u><tg-emoji emoji-id=5287301575432236322>🔤</tg-emoji></u><u><tg-emoji emoji-id=5287301575432236322>🔤</tg-emoji></u>
<blockquote><tg-emoji emoji-id=5289823756322101387>🔤</tg-emoji><tg-emoji emoji-id=5290031877552363770>🔤</tg-emoji><tg-emoji emoji-id=5287307803134813043>🔤</tg-emoji><tg-emoji emoji-id=5287456220024691195>➖</tg-emoji><tg-emoji emoji-id=5287580662407129147>🔤</tg-emoji><tg-emoji emoji-id=5289923811880229027>🔤</tg-emoji><tg-emoji emoji-id=5287479820869984284>🔤</tg-emoji><tg-emoji emoji-id=5289925070305646492>🔤</tg-emoji><tg-emoji emoji-id=5290031877552363770>🔤</tg-emoji></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('bot_payment_success', '<blockquote><b>Tʜᴀɴᴋ Yᴏᴜ Fᴏʀ Yᴏᴜʀ Pᴜʀᴄʜᴀsᴇ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('bot_store_empty', '<blockquote><tg-emoji emoji-id=5258509201306557640>📍</tg-emoji><b>Bot Currently </b><b><u>Maintanence</u></b>.</blockquote>

<b>If You are want anything, Just dm Admin -</b>
<tg-emoji emoji-id=5893149782465057649>🕞</tg-emoji> | <b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('bot_store_subtitle', '<tg-emoji emoji-id=5814327284223448001>🖌</tg-emoji> <b><u>𝖡𝗋𝗈𝗐𝗌𝖾 𝖮𝗎𝗋 𝖠𝗏𝖺𝗂𝗅𝖺𝖻𝗅𝖾 𝖯𝗋𝗈𝖽𝗎𝖼𝗍𝗌</u></b> 𝖡𝗒 <b><u>𝖢𝖺𝗍𝖾𝗀𝗈𝗋𝗒</u></b> 𝖺𝗇𝖽 𝖥𝗂𝗇𝖽 𝖤𝗑𝖺𝖼𝗍𝗅𝗒 <b><u>𝖶𝗁𝖺𝗍 𝗒𝗈𝗎 𝖭𝖾𝖾𝖽</u></b> 𝖶𝗂𝗍𝗁 <b><u>𝖤𝖺𝗌𝖾</u>.</b>');
INSERT INTO bot_settings (key, value) VALUES ('bot_store_title', '<blockquote><tg-emoji emoji-id=5963312935148195483>💎</tg-emoji> <b>{brand} — Digital Key Store</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('bot_welcome_instruction', '<blockquote><b>Gᴇᴛ Kᴇʏs Iɴsᴛᴀɴᴛʟʏ !
Oᴘᴇɴ Bᴏᴛ ➛ Pɪᴄᴋ Pʀᴏᴅᴜᴄᴛ ➛ Pᴀʏ ᴠɪᴀ UPI ➛ Kᴇʏ Dᴇʟɪᴠᴇʀᴇᴅ ɪɴ Sᴇᴄᴏɴᴅs.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('bot_welcome_msg', '<b>Welcome to {brand}</b>');
INSERT INTO bot_settings (key, value) VALUES ('broadcast_pin_message', '0');
INSERT INTO bot_settings (key, value) VALUES ('categories_btn_emoji_id', '5210956306952758910');
INSERT INTO bot_settings (key, value) VALUES ('categories_btn_style', '4');
INSERT INTO bot_settings (key, value) VALUES ('cb_generating_qr', 'Generating Payment QR...');
INSERT INTO bot_settings (key, value) VALUES ('cb_order_not_found', 'Order Not Found.');
INSERT INTO bot_settings (key, value) VALUES ('copy_key_btn_emoji_id', '6280750562086492198');
INSERT INTO bot_settings (key, value) VALUES ('copy_key_btn_style', '4');
INSERT INTO bot_settings (key, value) VALUES ('discount_broadcast_buttons', '[]');
INSERT INTO bot_settings (key, value) VALUES ('discount_broadcast_send_categories', '1');
INSERT INTO bot_settings (key, value) VALUES ('discount_offer_ended_body', 'Sorry, this discount offer is no longer active.

Tap /start to see current prices — new deals drop regularly.');
INSERT INTO bot_settings (key, value) VALUES ('discount_offer_ended_title', '⏳ <b>This Offer Has Ended</b>');
INSERT INTO bot_settings (key, value) VALUES ('force_join_body', 'Hey {user_mention},

You selected <b>{category}</b> — <b>{duration}</b>.

Before we create your order, please join our required channel(s) below.

💡 <i>Your order has not been created yet — no need to start over.</i>
As soon as you join, I''ll automatically detect your membership and continue your order flow seamlessly.');
INSERT INTO bot_settings (key, value) VALUES ('force_join_btn_verify', '✅ I Joined — Verify');
INSERT INTO bot_settings (key, value) VALUES ('force_join_enabled', '1');
INSERT INTO bot_settings (key, value) VALUES ('force_join_expired_msg', '⚠️ <b>Your pending order has expired.</b>

Please go back to the store and select a product again.');
INSERT INTO bot_settings (key, value) VALUES ('force_join_join_btn_emoji_id', '');
INSERT INTO bot_settings (key, value) VALUES ('force_join_join_btn_style', '');
INSERT INTO bot_settings (key, value) VALUES ('force_join_join_btn_text', '📢 Join {channel}');
INSERT INTO bot_settings (key, value) VALUES ('force_join_missing_msg', '⚠️ <b>You haven''t joined all required channels yet.</b>

Please join the channels below and try again:');
INSERT INTO bot_settings (key, value) VALUES ('force_join_show_verify_btn', '1');
INSERT INTO bot_settings (key, value) VALUES ('force_join_title', '🔒 <b>Channel Membership Required</b>');
INSERT INTO bot_settings (key, value) VALUES ('force_join_verify_btn_emoji_id', '');
INSERT INTO bot_settings (key, value) VALUES ('force_join_verify_btn_style', '');
INSERT INTO bot_settings (key, value) VALUES ('manage_keys_btn_emoji_id', '6255620884531255071');
INSERT INTO bot_settings (key, value) VALUES ('manage_keys_btn_style', '4');
INSERT INTO bot_settings (key, value) VALUES ('msg_already_paid', '<blockquote><tg-emoji emoji-id=6228978025573126806>📢</tg-emoji><b> Pᴀʏᴍᴇɴᴛ Aʟʀᴇᴀᴅʏ Vᴇʀɪғɪᴇᴅ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_amount_mismatch', '<b><u>Payment Amount</u> </b><b><u>Does Not Match The Order</u>.</b>
<b>Please Contact Support.
~ </b><b>T.me/Ceo_DarkFury</b><b>
~ </b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_apk_caption', '<b><tg-emoji emoji-id=5899757765743615694>⬇️</tg-emoji></b><b> Application for {category}</b>

<blockquote><b>SETUP CHANNEL -</b> 
<tg-emoji emoji-id=6233324953383476967>😱</tg-emoji> <b>T.ME/SAFESETUPS</b></blockquote>

<blockquote><b><u>English :)</u></b></blockquote>
<b>If You Have any Questions, Doubts, or Installation Issues, Feel Free to Contact Us Anytime — 24/7.

Telegram:
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> </b><b>T.me/Ceo_DarkFury</b><b>
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> </b><b>T.me/SayGGAdmin</b>

<blockquote><b>Hindi :)</b></blockquote>
<b>Agar aapko koi question, doubt, ya installation issue ho, toh aap hume kabhi bhi contact kar sakte ho — 24/7.

Telegram:
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> </b><b>T.me/Ceo_DarkFury</b><b>
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> </b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_apk_notice', '<tg-emoji emoji-id=5819062970998590994>📱</tg-emoji> <b>The {category} file has Been Sent above. Install it and Use Your Key to Activate.</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_banned', '🚫 You are banned from using this service.');
INSERT INTO bot_settings (key, value) VALUES ('msg_broadcast_complete', '✅ <b>Broadcast Complete</b>

• Delivered: <b>{sent}</b>
• Failed: <b>{failed}</b>
• Skipped: <b>{skipped}</b>
• Total: <b>{total}</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_broadcast_error', '❌ <b>Broadcast Failed</b>
{error}');
INSERT INTO bot_settings (key, value) VALUES ('msg_broadcast_progress', '⏳ Broadcasting… {sent}/{total} sent');
INSERT INTO bot_settings (key, value) VALUES ('msg_categories_footer', '<tg-emoji emoji-id=6251317640833275754>👇</tg-emoji> <b>Which You Want ? Just </b><b><u>Tap Below</u></b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_gateway_error', '<blockquote><tg-emoji emoji-id=5987718983728503684>🏷</tg-emoji> <b>Pᴀʏᴍᴇɴᴛ Vᴇʀɪғɪᴄᴀᴛɪᴏɴ ɪs Tᴇᴍᴘᴏʀᴀʀɪʟʏ Uɴᴀᴠᴀɪʟᴀʙʟᴇ. Pʟᴇᴀsᴇ ᴛʀʏ ᴀɢᴀɪɴ Sʜᴏʀᴛʟʏ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_inactive_verify_btn', '<blockquote><b>Tʜɪs 𝗩𝗘𝗥𝗜𝗙𝗬 𝗠𝗬 𝗣𝗔𝗬𝗠𝗘𝗡𝗧 Bᴜᴛᴛᴏɴ ɪs Nᴏ Lᴏɴɢᴇʀ Aᴄᴛɪᴠᴇ. Pʟᴇᴀsᴇ Usᴇ Tʜᴇ Lᴀᴛᴇsᴛ Pᴀʏᴍᴇɴᴛ QR Oɴʟʏ.</b></blockquote>
<tg-emoji emoji-id=5987718983728503684>🏷</tg-emoji> <b>Oʀᴅᴇʀ Aᴠᴀɪʟᴀʙʟᴇ Tɪᴍᴇ 15ᴍɪɴ</b>

<u>If you have any issue kindly dm</u> -
<b>T.me/Ceo_DarkFury</b><b>
</b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_invalid_cat_dur', '<b><tg-emoji emoji-id=5778527486270770928>😀</tg-emoji></b><b>INVALID CATEGORY OR DURATION.</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_key_label', '<tg-emoji emoji-id=6163730523089801410>➡️</tg-emoji> <b>Key :
</b><b><tg-emoji emoji-id=6163730523089801410>➡️</tg-emoji></b><b> Key :</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_key_taken', '<blockquote><tg-emoji emoji-id=5924681813149618024>🛜</tg-emoji> <b>Tʜɪs Kᴇʏ Wᴀs Jᴜsᴛ Sᴏᴍᴇᴏɴᴇ Tᴀᴋᴇɴ. Pʟᴇᴀsᴇ Tʀʏ Nᴇᴡ Oʀᴅᴇʀs ᴀɢᴀɪɴ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_keys_load_error', '<blockquote><tg-emoji emoji-id=5796440171364749940>📌</tg-emoji><b>Uɴᴀʙʟᴇ ᴛᴏ Lᴏᴀᴅ Yᴏᴜʀ Kᴇʏs Rɪɢʜᴛ Nᴏᴡ. Pʟᴇᴀsᴇ ᴛʀʏ ᴀɢᴀɪɴ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_no_keys_available', '<b><tg-emoji emoji-id=5771511103141975115>📢</tg-emoji></b><b> Sorry, no keys available for this category and duration.</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_no_keys_found_title', '<blockquote><b><tg-emoji emoji-id=5924720918826848520>😀</tg-emoji></b><b> No Keys Found.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_order_expired', '<blockquote><tg-emoji emoji-id=5258419835922030550>🕔</tg-emoji>Tʜɪs Oʀᴅᴇʀ ʜᴀs Exᴘɪʀᴇᴅ.</blockquote>
<b>𝖯𝗅𝖾𝖺𝗌𝖾 𝖢𝗋𝖾𝖺𝗍𝖾 𝖺 𝖭𝖾𝗐 𝖮𝗋𝖽𝖾𝗋.</b>

<u>If you have any issue kindly dm</u> -
<b>T.me/Ceo_DarkFury</b><b>
</b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_order_expired_notice', '<b>Order ID :</b> <code>{order_id}</code>
<b>Ref ID :</b> <code>{txn_ref}</code>

<blockquote><b><tg-emoji emoji-id=5258419835922030550>🕔</tg-emoji></b><b> Oʀᴅᴇʀ Exᴘɪʀᴇᴅ.</b></blockquote><b>
</b>

<b>Your Previous Order Has Expired as Payment Was Not Completed in Time.

𝖳𝗈 𝖢𝗈𝗇𝗍𝗂𝗇𝗎𝖾, 𝖡𝗋𝗈𝗐𝗌𝖾 𝖮𝗎𝗋 𝖢𝖺𝗍𝖾𝗀𝗈𝗋𝗂𝖾𝗌 𝖺𝗇𝖽 𝖯𝗅𝖺𝖼𝖾 𝖺 𝖭𝖾𝗐 𝖮𝗋𝖽𝖾𝗋 𝖶𝗁𝖾𝗇𝖾𝗏𝖾𝗋 𝖸𝗈𝗎''𝗋𝖾 𝖱𝖾𝖺𝖽𝗒.</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_order_inactive', '<blockquote><b><tg-emoji emoji-id=5240241223632954241>🚫</tg-emoji></b><b>Tʜɪs Oʀᴅᴇʀ Is Nᴏᴛ Aᴄᴛɪᴠᴇ Aɴʏᴍᴏʀᴇ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_order_not_found', '<tg-emoji emoji-id=5987718983728503684>🏷</tg-emoji> <b>Oʀᴅᴇʀ Nᴏᴛ Fᴏᴜɴᴅ.
𝖯𝗅𝖾𝖺𝗌𝖾 𝖢𝗋𝖾𝖺𝗍𝖾 𝖺 𝖭𝖾𝗐 𝖮𝗋𝖽𝖾𝗋.

Oʀᴅᴇʀ Aᴠᴀɪʟᴀʙʟᴇ Tɪᴍᴇ Oɴʟʏ 15ᴍɪɴ.
</b>
<u>If you have any issue kindly dm</u> -
<b>T.me/Ceo_DarkFury</b><b>
</b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_order_not_yours', '<blockquote><b><tg-emoji emoji-id=5904238507555033712>⛔️</tg-emoji></b><b>Tʜɪs Oʀᴅᴇʀ Dᴏᴇs Nᴏᴛ Bᴇʟᴏɴɢ ᴛᴏ Yᴏᴜ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_payment_failed', '<b>Order ID :</b> <code>{order_id}</code>
<b>Ref ID :</b> <code>{txn_ref}</code>

<tg-emoji emoji-id=5444856076954520455>🧾</tg-emoji> <b>Payment Was Not Received Yet.</b>
<b>
Please Complete The Payment and Then Tap {verify_btn} to Verify Your Order.
</b>
<blockquote><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Fᴀsᴛ Vᴇʀɪғɪᴄᴀᴛɪᴏɴ
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Iɴsᴛᴀɴᴛ Kᴇʏ Dᴇʟɪᴠᴇʀʏ
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Eᴀsʏ Pʀᴏᴄᴇss</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_payment_not_found', '<b>Payment Was Not found for this Order. Please Complete The Payment First, Then Tap Verify.</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_payment_not_received_title', '<b>Hey {name_link}</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_payment_pending', 'Your Payment is Still Being Processed. Please Wait a Moment and Try Again.

If you Have any issue ?
• T.me/SayGGAdmin');
INSERT INTO bot_settings (key, value) VALUES ('msg_payment_verified_title', '<blockquote><b><tg-emoji emoji-id=6255587091728568580>💰</tg-emoji></b><b> {currency}{amount} Pᴀʏᴍᴇɴᴛ Vᴇʀɪғɪᴇᴅ Sᴜᴄᴄᴇssғᴜʟʟʏ</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_select_duration_sub', 'Select a duration below:');
INSERT INTO bot_settings (key, value) VALUES ('msg_select_duration_title', '<tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji> <b>Yup » {first_name}</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_store_unavailable_title', '🛒 <b>Store Currently Unavailable</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_upi_not_configured', '⚠️ <b><u>UPI ID is Not Configured</u>. </b><b><u>Please Contact</u> the </b><b><u>Administrator</u>.</b> 

<b><u>Please Contact</u> Support.
~ </b><b>T.me/Ceo_DarkFury</b><b>
~ </b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_verification_issue', '<blockquote><tg-emoji emoji-id=5987718983728503684>🏷</tg-emoji><b>Pᴀʏᴍᴇɴᴛ Cᴏᴜʟᴅ Nᴏᴛ Bᴇ Vᴇʀɪғɪᴇᴅ ᴀᴛ Tʜɪs Tɪᴍᴇ. Pʟᴇᴀsᴇ Tʀʏ Aɢᴀɪɴ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_verify_error', '<blockquote expandable><tg-emoji emoji-id=5877260593903177342>⚙</tg-emoji><b> Pᴀʏᴍᴇɴᴛ Vᴇʀɪғɪᴄᴀᴛɪᴏɴ Eɴᴄᴏᴜɴᴛᴇʀᴇᴅ ᴀɴ Eʀʀᴏʀ.</b></blockquote><b>
𝖯𝗅𝖾𝖺𝗌𝖾 𝗍𝗋𝗒 𝖠𝗀𝖺𝗂𝗇 𝗂𝗇 𝖺 𝖬𝗈𝗆𝖾𝗇𝗍.</b>

<u>If you have any issue kindly dm</u> -
<b>T.me/Ceo_DarkFury</b><b>
</b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_verify_failed_title', '<blockquote><b><tg-emoji emoji-id=5987718983728503684>🏷</tg-emoji></b><b>Pᴀʏᴍᴇɴᴛ Vᴇʀɪғɪᴄᴀᴛɪᴏɴ Fᴀɪʟᴇᴅ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('msg_verify_generic_error', '<blockquote><b><tg-emoji emoji-id=5987718983728503684>🏷</tg-emoji></b><b>Sᴏᴍᴇᴛʜɪɴɢ Wᴇɴᴛ Wʀᴏɴɢ Dᴜʀɪɴɢ Vᴇʀɪғɪᴄᴀᴛɪᴏɴ.</b></blockquote><b>
𝖯𝗅𝖾𝖺𝗌𝖾 𝗍𝗋𝗒 𝖠𝗀𝖺𝗂𝗇 𝖫𝖺𝗍𝖾𝗋.</b>

<u>If you have any issue kindly dm</u> -
<b>T.me/Ceo_DarkFury</b><b>
</b><b>T.me/SayGGAdmin</b>');
INSERT INTO bot_settings (key, value) VALUES ('msg_verify_not_received', 'Hey {first_name}, Payment Not Received Yet. Please Pay the QR, Then Tap Verify Payment to Continue.');
INSERT INTO bot_settings (key, value) VALUES ('reply_howto_emoji_id', '5314504236132747481');
INSERT INTO bot_settings (key, value) VALUES ('reply_howto_style', '3');
INSERT INTO bot_settings (key, value) VALUES ('reply_mykeys_emoji_id', '6136508728309974931');
INSERT INTO bot_settings (key, value) VALUES ('reply_mykeys_style', '3');
INSERT INTO bot_settings (key, value) VALUES ('start_preview_url', 'https://i.ibb.co/N6P3Czn5/file-000000003be471fa8d728bd4063a2464.png');
INSERT INTO bot_settings (key, value) VALUES ('tpl_discount_broadcast_body', 'Hi <b>{first_name}</b> 👋

{description}

💰 <b>Discounted Prices</b>
──────────────
{pricing_examples}
──────────────

⏰ <b>Offer ends:</b> {expiry_time}');
INSERT INTO bot_settings (key, value) VALUES ('tpl_discount_broadcast_footer', 'Open the store now and claim your deal ↓');
INSERT INTO bot_settings (key, value) VALUES ('tpl_discount_broadcast_title', '📢 <b>{plan_name} — Limited Offer</b>');
INSERT INTO bot_settings (key, value) VALUES ('tpl_duration_caption', '{duration_title}
Category: <b>{category}</b>
{duration_sub}');
INSERT INTO bot_settings (key, value) VALUES ('tpl_keys_item', '<b>My Keys - {index} of {total}</b>
<b>
</b><b><u>Order ID</u> : </b><code>{order_id}</code><b>
</b><b><u>Category</u> : {category}
</b><b><u>Validity</u> : {duration}
</b><b><u>Amount Paid</u></b> <b>: {currency}{amount}
</b><b><u>Purchased On</u> :</b> {purchased_time}<b>

</b><b><tg-emoji emoji-id=6163730523089801410>➡️</tg-emoji></b><b>Key : </b><code>{key}</code> <b>{reference_section}

Please Keep This Key Safe. You May Need it Later for Use, Support, or Order Reference.</b>');
INSERT INTO bot_settings (key, value) VALUES ('tpl_payment_caption', '<blockquote><b><tg-emoji emoji-id=5444856076954520455>🧾</tg-emoji></b><b> </b><b><u>Payment Invoice</u></b></blockquote><b>

</b><b><u>Category</u> : {category}
</b><b><u>Duration</u> : {duration}
</b><b><u>Amount</u> : {currency}{amount}
</b><b><u>Order ID</u> : </b><code>{order_id}</code><b>
</b><b><u>Ref ID</u> : </b><code>{txn_ref}</code><b>

</b><b><tg-emoji emoji-id=5884343982816759327>↗️</tg-emoji></b><b> </b><b><u>Created : {created_time}</u>
</b><b><tg-emoji emoji-id=5877597667231534929>🗒</tg-emoji></b><b> </b><b><u>Expires : {expiry_time}</u>

Your Order is Ready. </b><b><u>Please Complete</u> the Payment Below to </b><b><u>Confirm your Order</u>.

After Payment, Tap </b><b><u>{verify_btn}</u> to </b><b><u>Verify Your Payment</u>.

</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Eᴀsʏ Pᴀʏᴍᴇɴᴛ Pʀᴏᴄᴇss
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Qᴜɪᴄᴋ Cᴏɴғɪʀᴍᴀᴛɪᴏɴ
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Iɴsᴛᴀɴᴛ Kᴇʏ Dᴇʟɪᴠᴇʀʏ Aғᴛᴇʀ Pᴀʏᴍᴇɴᴛ

</b><blockquote><b>Pʟᴇᴀsᴇ Cᴏᴍᴘʟᴇᴛᴇ ᴛʜᴇ Pᴀʏᴍᴇɴᴛ Bᴇғᴏʀᴇ Exᴘɪʀʏ ᴛᴏ Aᴠᴏɪᴅ Oʀᴅᴇʀ Cᴀɴᴄᴇʟʟᴀᴛɪᴏɴ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('tpl_reseller_caption', '<blockquote><b><tg-emoji emoji-id=5444856076954520455>🧾</tg-emoji></b><b> </b><b><u>Payment Invoice</u> - For Resellers</b></blockquote><b>

</b><b><u>Category</u> : {category}
</b><b><u>Duration</u> : {duration}

</b><b><u>Base Price</u> : {currency}{base_amount}
</b><b><u>Your Price</u> : {currency}{amount}

</b><b><u>Order ID</u> : </b><code>{order_id}</code><b>
</b><b><u>Ref ID</u> : </b><code>{txn_ref}</code><b>

</b><b><tg-emoji emoji-id=5884343982816759327>↗️</tg-emoji></b><b> </b><b><u>Created : {created_time}</u>
</b><b><tg-emoji emoji-id=5877597667231534929>🗒</tg-emoji></b><b> </b><b><u>Expires : {expiry_time}</u>

Your Order is Ready. </b><b><u>Please Complete</u> the Payment Below to </b><b><u>Confirm your Order</u>.

After Payment, Tap </b><b><u>{verify_btn}</u> to </b><b><u>Verify Your Payment</u>.

</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Eᴀsʏ Pᴀʏᴍᴇɴᴛ Pʀᴏᴄᴇss
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Qᴜɪᴄᴋ Cᴏɴғɪʀᴍᴀᴛɪᴏɴ
</b><b><tg-emoji emoji-id=5823396554345549784>✔️</tg-emoji></b><b> Iɴsᴛᴀɴᴛ Kᴇʏ Dᴇʟɪᴠᴇʀʏ Aғᴛᴇʀ Pᴀʏᴍᴇɴᴛ

</b><blockquote><b>Pʟᴇᴀsᴇ Cᴏᴍᴘʟᴇᴛᴇ ᴛʜᴇ Pᴀʏᴍᴇɴᴛ Bᴇғᴏʀᴇ Exᴘɪʀʏ ᴛᴏ Aᴠᴏɪᴅ Oʀᴅᴇʀ Cᴀɴᴄᴇʟʟᴀᴛɪᴏɴ.</b></blockquote>');
INSERT INTO bot_settings (key, value) VALUES ('tpl_store_header', '{store_title}

{store_subtitle}

{categories_footer}');
INSERT INTO bot_settings (key, value) VALUES ('tpl_welcome', '{welcome_greeting}

<b>{welcome_title}</b>
{welcome_body}');
INSERT INTO bot_settings (key, value) VALUES ('verify_btn_emoji_id', '6231018663319704664');
INSERT INTO bot_settings (key, value) VALUES ('verify_btn_style', '4');
INSERT INTO bot_settings (key, value) VALUES ('welcome_greeting', '<b><tg-emoji emoji-id=5922612721244704425>🎙</tg-emoji></b><b> Hey {name_link}</b>');

-- ==========================================================
-- SEQUENCE VALUES (restore current auto-increment positions)
-- ==========================================================

SELECT setval('api_providers_id_seq', 2, true);
SELECT setval('broadcast_queue_id_seq', 2, true);
SELECT setval('campaign_attributions_id_seq', 1, true);
SELECT setval('campaign_daily_stats_id_seq', 2, true);
SELECT setval('campaign_deep_links_id_seq', 2, true);
SELECT setval('campaign_delivery_logs_id_seq', 7, true);
SELECT setval('campaign_discount_rules_id_seq', 1, true);
SELECT setval('campaign_expiry_logs_id_seq', 2, true);
SELECT setval('campaign_link_events_id_seq', 1, true);
SELECT setval('campaign_runs_id_seq', 3, true);
SELECT setval('campaign_targets_id_seq', 1, true);
SELECT setval('campaign_templates_id_seq', 9, true);
SELECT setval('categories_id_seq', 3, true);
SELECT setval('discount_broadcast_messages_id_seq', 4, true);
SELECT setval('discount_plans_id_seq', 2, true);
SELECT setval('discount_rules_id_seq', 2, true);
SELECT setval('durations_id_seq', 11, true);
SELECT setval('force_join_channels_id_seq', 1, true);
SELECT setval('fulfillment_issues_id_seq', 1, true);
SELECT setval('orders_id_seq', 18, true);
SELECT setval('product_keys_id_seq', 8, true);
SELECT setval('purchased_keys_history_id_seq', 8, true);
SELECT setval('reseller_prices_id_seq', 1, true);
SELECT setval('reseller_users_id_seq', 1, true);
SELECT setval('resellers_id_seq', 1, true);
SELECT setval('scheduled_campaigns_id_seq', 1, true);
SELECT setval('source_audit_logs_id_seq', 17, true);
SELECT setval('source_fulfillment_logs_id_seq', 9, true);
SELECT setval('source_rules_id_seq', 11, true);
SELECT setval('template_versions_id_seq', 1, true);
SELECT setval('trial_campaign_delivery_logs_id_seq', 1, true);
SELECT setval('trial_campaign_run_keys_id_seq', 1, true);
SELECT setval('trial_campaign_runs_id_seq', 1, true);
SELECT setval('trial_campaigns_id_seq', 1, true);
SELECT setval('trial_keys_id_seq', 1, true);
SELECT setval('users_id_seq', 4, true);


-- Re-enable FK checks
SET session_replication_role = DEFAULT;
