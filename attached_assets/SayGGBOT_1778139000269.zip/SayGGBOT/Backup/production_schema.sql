-- ==========================================================
-- PRODUCTION DATABASE SCHEMA BACKUP
-- SayGGKeysBOT - PostgreSQL 16
-- Exported: 2026-04-06T07:38:14.838Z
-- Source: Published Replit App (Production Database)
-- ==========================================================

-- ==========================================================
-- SEQUENCES
-- ==========================================================

CREATE SEQUENCE IF NOT EXISTS api_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS broadcast_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_attributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_daily_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_deep_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_delivery_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_discount_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_expiry_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_link_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS campaign_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS discount_broadcast_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS discount_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS discount_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS durations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS force_join_channels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS fulfillment_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS product_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS purchased_keys_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS reseller_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS reseller_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS resellers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS scheduled_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS source_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS source_fulfillment_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS source_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS template_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaign_delivery_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaign_run_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaign_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS trial_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

-- ==========================================================
-- TABLES
-- ==========================================================

-- Table: api_providers
CREATE TABLE IF NOT EXISTS api_providers (
    id integer DEFAULT nextval('api_providers_id_seq'::regclass) NOT NULL,
    name character varying(255),
    base_url text,
    token text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT api_providers_pkey PRIMARY KEY (id)
);

-- Table: bot_settings
CREATE TABLE IF NOT EXISTS bot_settings (
    key character varying(100) NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    CONSTRAINT bot_settings_pkey PRIMARY KEY (key)
);

-- Table: broadcast_queue
CREATE TABLE IF NOT EXISTS broadcast_queue (
    id integer DEFAULT nextval('broadcast_queue_id_seq'::regclass) NOT NULL,
    plan_id integer,
    template_override text DEFAULT ''::text,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    result jsonb,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    queue_type character varying(30) DEFAULT 'broadcast'::character varying,
    delete_target_queue_id integer,
    CONSTRAINT broadcast_queue_pkey PRIMARY KEY (id)
);

-- Table: campaign_attributions
CREATE TABLE IF NOT EXISTS campaign_attributions (
    id integer DEFAULT nextval('campaign_attributions_id_seq'::regclass) NOT NULL,
    user_id integer,
    telegram_id bigint,
    campaign_id integer,
    deep_link_code character varying(64),
    first_opened_at timestamp without time zone DEFAULT now() NOT NULL,
    last_opened_at timestamp without time zone DEFAULT now() NOT NULL,
    total_opens integer DEFAULT 1 NOT NULL,
    attributed_orders integer DEFAULT 0 NOT NULL,
    attributed_revenue numeric DEFAULT 0 NOT NULL,
    attribution_expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    campaign_run_id integer,
    deep_link_id integer,
    attribution_end_at timestamp without time zone,
    CONSTRAINT campaign_attributions_pkey PRIMARY KEY (id)
);

-- Table: campaign_daily_stats
CREATE TABLE IF NOT EXISTS campaign_daily_stats (
    id integer DEFAULT nextval('campaign_daily_stats_id_seq'::regclass) NOT NULL,
    stat_date date,
    campaign_id integer,
    total_opens integer DEFAULT 0 NOT NULL,
    unique_opens integer DEFAULT 0 NOT NULL,
    total_purchases integer DEFAULT 0 NOT NULL,
    total_revenue numeric DEFAULT 0 NOT NULL,
    promo_start_sent integer DEFAULT 0 NOT NULL,
    promo_expiry_sent integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_daily_stats_pkey PRIMARY KEY (id)
);

-- Table: campaign_deep_links
CREATE TABLE IF NOT EXISTS campaign_deep_links (
    id integer DEFAULT nextval('campaign_deep_links_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    code character varying(64),
    deep_link_url text DEFAULT ''::text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    campaign_run_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    activated_at timestamp without time zone,
    expired_at timestamp without time zone,
    attribution_start_at timestamp without time zone,
    attribution_end_at timestamp without time zone,
    opens_count integer DEFAULT 0 NOT NULL,
    unique_opens_count integer DEFAULT 0 NOT NULL,
    starts_count integer DEFAULT 0 NOT NULL,
    purchases_count integer DEFAULT 0 NOT NULL,
    revenue_total numeric DEFAULT 0 NOT NULL,
    late_purchases_count integer DEFAULT 0 NOT NULL,
    late_revenue_total numeric DEFAULT 0 NOT NULL,
    CONSTRAINT campaign_deep_links_pkey PRIMARY KEY (id)
);

-- Table: campaign_delivery_logs
CREATE TABLE IF NOT EXISTS campaign_delivery_logs (
    id bigint DEFAULT nextval('campaign_delivery_logs_id_seq'::regclass) NOT NULL,
    campaign_run_id integer,
    campaign_id integer,
    target_type character varying(20) DEFAULT 'user'::character varying NOT NULL,
    telegram_id bigint,
    username character varying(255),
    message_kind character varying(20) DEFAULT 'promo_start'::character varying NOT NULL,
    delivery_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    telegram_message_id bigint,
    error_text text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    delivery_method character varying(30) DEFAULT 'direct'::character varying,
    source_message_id bigint
);

-- Table: campaign_discount_rules
CREATE TABLE IF NOT EXISTS campaign_discount_rules (
    id integer DEFAULT nextval('campaign_discount_rules_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    discount_mode character varying(30) DEFAULT 'fixed_percent'::character varying NOT NULL,
    fixed_value numeric,
    min_value numeric,
    max_value numeric,
    applies_to_category_id integer,
    applies_to_duration_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_discount_rules_pkey PRIMARY KEY (id)
);

-- Table: campaign_expiry_logs
CREATE TABLE IF NOT EXISTS campaign_expiry_logs (
    id integer DEFAULT nextval('campaign_expiry_logs_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    campaign_run_id integer,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    discount_deactivated boolean DEFAULT false NOT NULL,
    recipients_resolved integer DEFAULT 0 NOT NULL,
    sent integer DEFAULT 0 NOT NULL,
    failed integer DEFAULT 0 NOT NULL,
    error_text text,
    metadata text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_expiry_logs_pkey PRIMARY KEY (id)
);

-- Table: campaign_link_events
CREATE TABLE IF NOT EXISTS campaign_link_events (
    id bigint DEFAULT nextval('campaign_link_events_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    deep_link_code character varying(64),
    telegram_user_id bigint,
    username character varying(255),
    event_type character varying(20) DEFAULT 'open'::character varying NOT NULL,
    order_id integer,
    revenue_amount numeric,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    attributed boolean DEFAULT false,
    campaign_run_id integer,
    deep_link_id integer,
    is_late_conversion boolean DEFAULT false NOT NULL
);

-- Table: campaign_runs
CREATE TABLE IF NOT EXISTS campaign_runs (
    id integer DEFAULT nextval('campaign_runs_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    run_type character varying(30) DEFAULT 'promo_start'::character varying NOT NULL,
    executed_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    generated_discount_value numeric,
    generated_discount_type character varying(30),
    generated_final_price_json text,
    total_targets integer DEFAULT 0 NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    total_failed integer DEFAULT 0 NOT NULL,
    revenue_generated numeric,
    metadata text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    error_text text,
    admin_notified boolean DEFAULT false,
    source_chat_id bigint,
    source_message_id bigint,
    channel_delivery_method character varying(30) DEFAULT 'forward_message'::character varying,
    channels_targeted integer DEFAULT 0,
    channels_copied integer DEFAULT 0,
    channels_failed integer DEFAULT 0,
    CONSTRAINT campaign_runs_pkey PRIMARY KEY (id)
);

-- Table: campaign_targets
CREATE TABLE IF NOT EXISTS campaign_targets (
    id integer DEFAULT nextval('campaign_targets_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    target_type character varying(30) DEFAULT 'all_users'::character varying NOT NULL,
    target_value text,
    message_kind character varying(20) DEFAULT 'promo_start'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT campaign_targets_pkey PRIMARY KEY (id)
);

-- Table: campaign_templates
CREATE TABLE IF NOT EXISTS campaign_templates (
    id integer DEFAULT nextval('campaign_templates_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled'::character varying NOT NULL,
    template_type character varying(30) DEFAULT 'promo_start'::character varying NOT NULL,
    body_text text DEFAULT ''::text NOT NULL,
    parse_mode character varying(20) DEFAULT 'HTML'::character varying NOT NULL,
    custom_emoji_json text,
    inline_buttons_json text,
    button_style_json text,
    media_type character varying(30),
    media_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by character varying(255) DEFAULT 'web'::character varying,
    edited_via character varying(10) DEFAULT 'web'::character varying,
    body_entities_json text,
    apk_captions_json text,
    start_delivery_config_json text,
    category_id integer,
    category_name_snapshot character varying(255),
    CONSTRAINT campaign_templates_pkey PRIMARY KEY (id)
);

-- Table: categories
CREATE TABLE IF NOT EXISTS categories (
    id integer DEFAULT nextval('categories_id_seq'::regclass) NOT NULL,
    name character varying(100),
    sort_order integer DEFAULT 0 NOT NULL,
    is_hidden smallint DEFAULT 0 NOT NULL,
    button_style smallint DEFAULT 4 NOT NULL,
    file_id character varying(255) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT categories_pkey PRIMARY KEY (id)
);

-- Table: category_duration_settings
CREATE TABLE IF NOT EXISTS category_duration_settings (
    category_id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    CONSTRAINT category_duration_settings_pkey PRIMARY KEY (category_id, setting_key)
);

-- Table: channel_audit_log
CREATE TABLE IF NOT EXISTS channel_audit_log (
    id integer,
    action text,
    actor text DEFAULT 'admin'::text NOT NULL,
    channel_id integer,
    channel_label text,
    normalized_input text,
    resolved_chat_id bigint,
    result text,
    error_reason text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: configured_channels
CREATE TABLE IF NOT EXISTS configured_channels (
    id integer,
    label text DEFAULT ''::text NOT NULL,
    original_input text,
    normalized_input text,
    resolved_chat_id bigint,
    resolved_username text,
    resolved_title text,
    chat_type text,
    is_validated boolean DEFAULT false NOT NULL,
    bot_is_member boolean DEFAULT false NOT NULL,
    bot_is_admin boolean DEFAULT false NOT NULL,
    can_post_messages boolean DEFAULT false NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    last_validated_at timestamp without time zone,
    last_validation_status text DEFAULT 'pending'::text NOT NULL,
    last_validation_error text,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: discount_broadcast_messages
CREATE TABLE IF NOT EXISTS discount_broadcast_messages (
    id integer DEFAULT nextval('discount_broadcast_messages_id_seq'::regclass) NOT NULL,
    queue_id integer,
    plan_id integer,
    user_id integer,
    telegram_id bigint,
    broadcast_message_id integer,
    created_at timestamp without time zone DEFAULT now(),
    pin_service_message_id bigint,
    CONSTRAINT discount_broadcast_messages_pkey PRIMARY KEY (id)
);

-- Table: discount_plans
CREATE TABLE IF NOT EXISTS discount_plans (
    id integer DEFAULT nextval('discount_plans_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled Offer'::character varying NOT NULL,
    description text DEFAULT ''::text,
    is_active boolean DEFAULT false NOT NULL,
    apply_scope character varying(50) DEFAULT 'all_categories'::character varying NOT NULL,
    starts_at timestamp without time zone,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    broadcast_template text DEFAULT ''::text,
    is_campaign_generated boolean DEFAULT false,
    CONSTRAINT discount_plans_pkey PRIMARY KEY (id)
);

-- Table: discount_rules
CREATE TABLE IF NOT EXISTS discount_rules (
    id integer DEFAULT nextval('discount_rules_id_seq'::regclass) NOT NULL,
    plan_id integer,
    category_id integer,
    duration_id integer,
    discount_type character varying(30),
    discount_value numeric,
    override_price numeric,
    CONSTRAINT discount_rules_pkey PRIMARY KEY (id)
);

-- Table: durations
CREATE TABLE IF NOT EXISTS durations (
    id integer DEFAULT nextval('durations_id_seq'::regclass) NOT NULL,
    category_id integer,
    name character varying(100),
    sort_order integer DEFAULT 0 NOT NULL,
    button_style smallint DEFAULT 4 NOT NULL,
    price numeric DEFAULT 0 NOT NULL,
    is_hidden smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT durations_pkey PRIMARY KEY (id)
);

-- Table: force_join_channels
CREATE TABLE IF NOT EXISTS force_join_channels (
    id integer DEFAULT nextval('force_join_channels_id_seq'::regclass),
    channel_identifier text,
    channel_title character varying(255) DEFAULT ''::character varying NOT NULL,
    invite_link text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    channel_username text,
    status text DEFAULT 'pending'::text NOT NULL,
    status_detail text DEFAULT ''::text NOT NULL,
    channel_id bigint
);

-- Table: fulfillment_issues
CREATE TABLE IF NOT EXISTS fulfillment_issues (
    id integer DEFAULT nextval('fulfillment_issues_id_seq'::regclass) NOT NULL,
    order_id integer,
    user_id integer,
    category_id integer,
    duration_id integer,
    source_rule_id integer,
    provider_id integer,
    source_type character varying(30) DEFAULT NULL::character varying,
    failure_reason text,
    failure_code character varying(100) DEFAULT NULL::character varying,
    payload_snapshot jsonb,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    recovery_key text,
    recovery_note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone,
    resolved_by character varying(255) DEFAULT NULL::character varying,
    send_attempts integer DEFAULT 0 NOT NULL,
    last_send_error text,
    CONSTRAINT fulfillment_issues_pkey PRIMARY KEY (id)
);

-- Table: orders
CREATE TABLE IF NOT EXISTS orders (
    id integer DEFAULT nextval('orders_id_seq'::regclass) NOT NULL,
    user_id integer,
    key_id integer,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    qr_message_id bigint,
    last_error_message_id bigint,
    txn_ref character varying(64) DEFAULT NULL::character varying,
    verified_at timestamp without time zone,
    purchased_category_name character varying(150) DEFAULT NULL::character varying,
    purchased_duration_name character varying(150) DEFAULT NULL::character varying,
    purchased_key_value text,
    purchased_amount numeric,
    purchaser_role character varying(50) DEFAULT 'customer'::character varying NOT NULL,
    purchaser_label character varying(255) DEFAULT NULL::character varying,
    paid_utr character varying(255) DEFAULT NULL::character varying,
    delivered_at timestamp without time zone,
    gateway_txn_id character varying(255) DEFAULT NULL::character varying,
    gateway_bank_txn_id character varying(255) DEFAULT NULL::character varying,
    paid_amount numeric,
    pricing_source character varying(50),
    base_amount numeric,
    applied_discount_plan_id integer,
    applied_discount_plan_name character varying(255),
    fulfillment_status character varying(30) DEFAULT 'pending'::character varying,
    fulfillment_attempted_at timestamp without time zone,
    fulfilled_at timestamp without time zone,
    fulfillment_error text,
    provider_response_meta text,
    fallback_used boolean DEFAULT false,
    delivered_source character varying(30),
    owner_alert_sent_at timestamp without time zone,
    source_rule_snapshot text,
    campaign_id integer,
    campaign_deep_link_code character varying(64),
    campaign_run_id integer,
    campaign_deep_link_id integer,
    is_campaign_late_conversion boolean DEFAULT false NOT NULL,
    CONSTRAINT orders_pkey PRIMARY KEY (id)
);

-- Table: product_keys
CREATE TABLE IF NOT EXISTS product_keys (
    id integer DEFAULT nextval('product_keys_id_seq'::regclass) NOT NULL,
    category_id integer,
    duration_id integer,
    key_value character varying(255),
    price numeric DEFAULT 0 NOT NULL,
    is_sold smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT product_keys_pkey PRIMARY KEY (id)
);

-- Table: purchased_keys_history
CREATE TABLE IF NOT EXISTS purchased_keys_history (
    id bigint DEFAULT nextval('purchased_keys_history_id_seq'::regclass) NOT NULL,
    user_id integer,
    order_id integer,
    telegram_id bigint,
    username character varying(255) DEFAULT NULL::character varying,
    first_name character varying(255) DEFAULT NULL::character varying,
    last_name character varying(255) DEFAULT NULL::character varying,
    is_reseller_purchase smallint DEFAULT 0 NOT NULL,
    category_name character varying(150),
    duration_name character varying(150),
    key_value character varying(255),
    amount numeric DEFAULT 0 NOT NULL,
    txn_ref character varying(64) DEFAULT NULL::character varying,
    gateway_txn_id character varying(128) DEFAULT NULL::character varying,
    gateway_bank_txn_id character varying(128) DEFAULT NULL::character varying,
    verified_at timestamp without time zone,
    purchased_at timestamp without time zone DEFAULT now() NOT NULL,
    pricing_source character varying(50),
    base_amount numeric,
    applied_discount_plan_id integer,
    applied_discount_plan_name character varying(255)
);

-- Table: reseller_prices
CREATE TABLE IF NOT EXISTS reseller_prices (
    id integer DEFAULT nextval('reseller_prices_id_seq'::regclass) NOT NULL,
    reseller_id integer,
    category_id integer,
    duration_id integer,
    price numeric,
    discount_type character varying(10) DEFAULT NULL::character varying,
    discount_value numeric,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT reseller_prices_pkey PRIMARY KEY (id)
);

-- Table: reseller_users
CREATE TABLE IF NOT EXISTS reseller_users (
    id integer DEFAULT nextval('reseller_users_id_seq'::regclass) NOT NULL,
    reseller_id integer,
    user_id integer,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT reseller_users_pkey PRIMARY KEY (id)
);

-- Table: resellers
CREATE TABLE IF NOT EXISTS resellers (
    id integer DEFAULT nextval('resellers_id_seq'::regclass) NOT NULL,
    code character varying(6),
    expires_at timestamp without time zone,
    max_users integer,
    total_price numeric,
    discount_type character varying(10) DEFAULT 'percent'::character varying NOT NULL,
    discount_value numeric DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT resellers_pkey PRIMARY KEY (id)
);

-- Table: scheduled_campaigns
CREATE TABLE IF NOT EXISTS scheduled_campaigns (
    id integer DEFAULT nextval('scheduled_campaigns_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled Campaign'::character varying NOT NULL,
    description text DEFAULT ''::text,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    campaign_mode character varying(30) DEFAULT 'fixed_plan'::character varying NOT NULL,
    linked_discount_plan_id integer,
    category_scope_json text DEFAULT '[]'::text,
    duration_scope_json text DEFAULT '[]'::text,
    repeat_mode character varying(20) DEFAULT 'once'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'Asia/Kolkata'::character varying NOT NULL,
    start_at timestamp without time zone DEFAULT now() NOT NULL,
    expire_at timestamp without time zone DEFAULT now() NOT NULL,
    next_run_at timestamp without time zone,
    next_expire_at timestamp without time zone,
    is_enabled boolean DEFAULT false NOT NULL,
    promo_template_id integer,
    expiry_template_id integer,
    send_to_users boolean DEFAULT true NOT NULL,
    send_to_channels boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_run_at timestamp without time zone,
    last_expired_at timestamp without time zone,
    auto_discount_plan_id integer,
    channel_targets_json text DEFAULT '[]'::text,
    CONSTRAINT scheduled_campaigns_pkey PRIMARY KEY (id)
);

-- Table: source_audit_logs
CREATE TABLE IF NOT EXISTS source_audit_logs (
    id bigint DEFAULT nextval('source_audit_logs_id_seq'::regclass) NOT NULL,
    action_type character varying(50),
    target_type character varying(50),
    target_id integer,
    target_name character varying(255) DEFAULT NULL::character varying,
    actor character varying(255) DEFAULT 'admin'::character varying,
    changes jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: source_fulfillment_logs
CREATE TABLE IF NOT EXISTS source_fulfillment_logs (
    id bigint DEFAULT nextval('source_fulfillment_logs_id_seq'::regclass) NOT NULL,
    order_id integer,
    category_id integer,
    duration_id integer,
    category_name character varying(255) DEFAULT NULL::character varying,
    duration_name character varying(255) DEFAULT NULL::character varying,
    source_type character varying(20) DEFAULT NULL::character varying,
    provider_id integer,
    provider_name character varying(255) DEFAULT NULL::character varying,
    resolution_success boolean DEFAULT false NOT NULL,
    delivery_success boolean DEFAULT false NOT NULL,
    key_value text,
    api_request_url text,
    api_raw_response text,
    failure_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_telegram_id bigint,
    user_display_name character varying(255) DEFAULT NULL::character varying,
    delivered_source character varying(30) DEFAULT NULL::character varying,
    fallback_used boolean DEFAULT false,
    response_time_ms integer,
    http_status integer
);

-- Table: source_rules
CREATE TABLE IF NOT EXISTS source_rules (
    id integer DEFAULT nextval('source_rules_id_seq'::regclass) NOT NULL,
    category_id integer,
    duration_id integer,
    source_type character varying(20),
    api_provider_id integer,
    api_game_value character varying(255) DEFAULT NULL::character varying,
    api_duration_value character varying(255) DEFAULT NULL::character varying,
    api_device_value character varying(255) DEFAULT NULL::character varying,
    api_currency_value character varying(255) DEFAULT NULL::character varying,
    is_active boolean DEFAULT true NOT NULL,
    last_test_result text,
    last_test_success boolean,
    last_test_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT source_rules_pkey PRIMARY KEY (id)
);

-- Table: template_versions
CREATE TABLE IF NOT EXISTS template_versions (
    id integer DEFAULT nextval('template_versions_id_seq'::regclass) NOT NULL,
    template_id integer,
    body_text text DEFAULT ''::text NOT NULL,
    inline_buttons_json text,
    changed_by character varying(255) DEFAULT 'web'::character varying,
    changed_via character varying(10) DEFAULT 'web'::character varying,
    change_note text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    body_entities_json text,
    CONSTRAINT template_versions_pkey PRIMARY KEY (id)
);

-- Table: trial_campaign_delivery_logs
CREATE TABLE IF NOT EXISTS trial_campaign_delivery_logs (
    id bigint DEFAULT nextval('trial_campaign_delivery_logs_id_seq'::regclass) NOT NULL,
    run_id integer,
    campaign_id integer,
    target_type character varying(20) DEFAULT 'user'::character varying NOT NULL,
    telegram_id bigint,
    message_kind character varying(30) DEFAULT 'trial_start'::character varying NOT NULL,
    delivery_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    telegram_message_id bigint,
    error_text text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

-- Table: trial_campaign_run_keys
CREATE TABLE IF NOT EXISTS trial_campaign_run_keys (
    id integer DEFAULT nextval('trial_campaign_run_keys_id_seq'::regclass) NOT NULL,
    run_id integer,
    campaign_id integer,
    category_id integer,
    category_name_snapshot character varying(255),
    trial_key_id integer,
    key_value_snapshot character varying(500),
    duration_hours integer,
    max_devices integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT trial_campaign_run_keys_pkey PRIMARY KEY (id)
);

-- Table: trial_campaign_runs
CREATE TABLE IF NOT EXISTS trial_campaign_runs (
    id integer DEFAULT nextval('trial_campaign_runs_id_seq'::regclass) NOT NULL,
    campaign_id integer,
    run_type character varying(30) DEFAULT 'trial_start'::character varying NOT NULL,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    total_targets integer DEFAULT 0 NOT NULL,
    total_sent integer DEFAULT 0 NOT NULL,
    total_failed integer DEFAULT 0 NOT NULL,
    channels_targeted integer DEFAULT 0 NOT NULL,
    channels_sent integer DEFAULT 0 NOT NULL,
    channels_failed integer DEFAULT 0 NOT NULL,
    error_text text,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT trial_campaign_runs_pkey PRIMARY KEY (id)
);

-- Table: trial_campaigns
CREATE TABLE IF NOT EXISTS trial_campaigns (
    id integer DEFAULT nextval('trial_campaigns_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT 'Untitled Trial'::character varying NOT NULL,
    description text DEFAULT ''::text,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    category_ids_json text DEFAULT '[]'::text NOT NULL,
    trial_duration_hours integer DEFAULT 1 NOT NULL,
    max_devices integer,
    repeat_mode character varying(20) DEFAULT 'once'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'Asia/Kolkata'::character varying NOT NULL,
    start_at timestamp without time zone DEFAULT now() NOT NULL,
    expire_at timestamp without time zone DEFAULT now() NOT NULL,
    next_run_at timestamp without time zone,
    next_expire_at timestamp without time zone,
    is_enabled boolean DEFAULT false NOT NULL,
    start_template_id integer,
    expire_template_id integer,
    send_to_users boolean DEFAULT true NOT NULL,
    send_to_channels boolean DEFAULT false NOT NULL,
    channel_targets_json text DEFAULT '[]'::text,
    reveal_keys_in_channels boolean DEFAULT false NOT NULL,
    linked_promo_campaign_id integer,
    target_audience character varying(30) DEFAULT 'all_users'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_run_at timestamp without time zone,
    last_expired_at timestamp without time zone,
    apk_delivery_config_json text,
    delivery_mode character varying(30) DEFAULT 'mode_1_separate'::character varying NOT NULL,
    category_names_snapshot_json text,
    CONSTRAINT trial_campaigns_pkey PRIMARY KEY (id)
);

-- Table: trial_keys
CREATE TABLE IF NOT EXISTS trial_keys (
    id integer DEFAULT nextval('trial_keys_id_seq'::regclass) NOT NULL,
    category_id integer,
    category_name_snapshot character varying(255),
    duration_hours integer DEFAULT 1 NOT NULL,
    max_devices integer DEFAULT 1 NOT NULL,
    key_value character varying(500),
    status character varying(20) DEFAULT 'available'::character varying NOT NULL,
    used_in_trial_campaign_run_id integer,
    used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT trial_keys_pkey PRIMARY KEY (id)
);

-- Table: users
CREATE TABLE IF NOT EXISTS users (
    id integer DEFAULT nextval('users_id_seq'::regclass) NOT NULL,
    telegram_id bigint,
    username character varying(255) DEFAULT NULL::character varying,
    first_name character varying(255) DEFAULT NULL::character varying,
    last_name character varying(255) DEFAULT NULL::character varying,
    token character varying(64) DEFAULT NULL::character varying,
    is_banned smallint DEFAULT 0 NOT NULL,
    reseller_id integer,
    awaiting_code smallint DEFAULT 0 NOT NULL,
    start_categories_message_id bigint,
    active_payment_order_id bigint,
    active_keys_viewer_message_id bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    active_durations_message_id bigint,
    active_payment_error_message_id bigint,
    active_expiry_notice_message_id bigint,
    last_user_start_message_id bigint,
    last_bot_welcome_message_id bigint,
    last_start_date date,
    broadcast_categories_message_id bigint,
    last_mykeys_user_message_id bigint,
    last_mykeys_pin_notice_message_id bigint,
    last_howto_user_message_id bigint,
    last_howto_bot_message_id bigint,
    reseller_level_trigger_msg_id bigint,
    reseller_prompt_msg_id bigint,
    reseller_success_result_msg_id bigint,
    reseller_wrong_code_msg_id bigint,
    reseller_wrong_result_msg_id bigint,
    last_key_delivery_message_id bigint,
    profile_photo_url text,
    profile_photo_file_id character varying(255),
    profile_photo_updated_at timestamp without time zone,
    campaign_deep_link_code character varying(64),
    CONSTRAINT users_pkey PRIMARY KEY (id)
);

-- ==========================================================
-- FOREIGN KEY CONSTRAINTS
-- ==========================================================

ALTER TABLE campaign_deep_links ADD CONSTRAINT campaign_deep_links_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_delivery_logs ADD CONSTRAINT campaign_delivery_logs_campaign_run_id_fkey FOREIGN KEY (campaign_run_id) REFERENCES campaign_runs(id) ON DELETE CASCADE;
ALTER TABLE campaign_discount_rules ADD CONSTRAINT campaign_discount_rules_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_link_events ADD CONSTRAINT campaign_link_events_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_runs ADD CONSTRAINT campaign_runs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE campaign_targets ADD CONSTRAINT campaign_targets_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES scheduled_campaigns(id) ON DELETE CASCADE;
ALTER TABLE category_duration_settings ADD CONSTRAINT category_duration_settings_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE discount_rules ADD CONSTRAINT discount_rules_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES discount_plans(id) ON DELETE CASCADE;
ALTER TABLE durations ADD CONSTRAINT durations_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE orders ADD CONSTRAINT orders_key_id_fkey FOREIGN KEY (key_id) REFERENCES product_keys(id) ON DELETE SET NULL;
ALTER TABLE orders ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE product_keys ADD CONSTRAINT product_keys_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE product_keys ADD CONSTRAINT product_keys_duration_id_fkey FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE CASCADE;
ALTER TABLE reseller_prices ADD CONSTRAINT reseller_prices_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE reseller_prices ADD CONSTRAINT reseller_prices_duration_id_fkey FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE CASCADE;
ALTER TABLE reseller_prices ADD CONSTRAINT reseller_prices_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES resellers(id) ON DELETE CASCADE;
ALTER TABLE reseller_users ADD CONSTRAINT reseller_users_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES resellers(id) ON DELETE CASCADE;
ALTER TABLE reseller_users ADD CONSTRAINT reseller_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE scheduled_campaigns ADD CONSTRAINT scheduled_campaigns_expiry_template_id_fkey FOREIGN KEY (expiry_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE scheduled_campaigns ADD CONSTRAINT scheduled_campaigns_promo_template_id_fkey FOREIGN KEY (promo_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE source_rules ADD CONSTRAINT source_rules_api_provider_id_fkey FOREIGN KEY (api_provider_id) REFERENCES api_providers(id) ON DELETE SET NULL;
ALTER TABLE source_rules ADD CONSTRAINT source_rules_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE;
ALTER TABLE source_rules ADD CONSTRAINT source_rules_duration_id_fkey FOREIGN KEY (duration_id) REFERENCES durations(id) ON DELETE CASCADE;
ALTER TABLE trial_campaign_delivery_logs ADD CONSTRAINT trial_campaign_delivery_logs_run_id_fkey FOREIGN KEY (run_id) REFERENCES trial_campaign_runs(id) ON DELETE CASCADE;
ALTER TABLE trial_campaign_run_keys ADD CONSTRAINT trial_campaign_run_keys_run_id_fkey FOREIGN KEY (run_id) REFERENCES trial_campaign_runs(id) ON DELETE CASCADE;
ALTER TABLE trial_campaign_run_keys ADD CONSTRAINT trial_campaign_run_keys_trial_key_id_fkey FOREIGN KEY (trial_key_id) REFERENCES trial_keys(id) ON DELETE SET NULL;
ALTER TABLE trial_campaign_runs ADD CONSTRAINT trial_campaign_runs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES trial_campaigns(id) ON DELETE CASCADE;
ALTER TABLE trial_campaigns ADD CONSTRAINT trial_campaigns_expire_template_id_fkey FOREIGN KEY (expire_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE trial_campaigns ADD CONSTRAINT trial_campaigns_start_template_id_fkey FOREIGN KEY (start_template_id) REFERENCES campaign_templates(id) ON DELETE SET NULL;
ALTER TABLE trial_keys ADD CONSTRAINT trial_keys_category_id_fkey FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL;
ALTER TABLE users ADD CONSTRAINT users_reseller_id_fkey FOREIGN KEY (reseller_id) REFERENCES resellers(id) ON DELETE SET NULL;

-- ==========================================================
-- INDEXES
-- ==========================================================

CREATE INDEX idx_ca_campaign ON public.campaign_attributions USING btree (campaign_id);
CREATE INDEX idx_ca_expires ON public.campaign_attributions USING btree (attribution_expires_at);
CREATE INDEX idx_ca_telegram ON public.campaign_attributions USING btree (telegram_id);
CREATE UNIQUE INDEX uq_ca_user_campaign ON public.campaign_attributions USING btree (user_id, campaign_id);
CREATE INDEX idx_cds_campaign ON public.campaign_daily_stats USING btree (campaign_id);
CREATE INDEX idx_cds_date ON public.campaign_daily_stats USING btree (stat_date);
CREATE UNIQUE INDEX uq_cds_date_camp ON public.campaign_daily_stats USING btree (stat_date, campaign_id);
CREATE INDEX idx_cdl_campaign ON public.campaign_deep_links USING btree (campaign_id);
CREATE INDEX idx_cdl_run_id ON public.campaign_deep_links USING btree (campaign_run_id);
CREATE INDEX idx_cdl_status ON public.campaign_deep_links USING btree (status);
CREATE UNIQUE INDEX uq_cdl_code ON public.campaign_deep_links USING btree (code);
CREATE INDEX idx_cdl_camp ON public.campaign_delivery_logs USING btree (campaign_id);
CREATE INDEX idx_cdl_delivery_status ON public.campaign_delivery_logs USING btree (delivery_status);
CREATE INDEX idx_cdl_run ON public.campaign_delivery_logs USING btree (campaign_run_id);
CREATE INDEX idx_cdr_campaign ON public.campaign_discount_rules USING btree (campaign_id);
CREATE INDEX idx_cel_campaign ON public.campaign_expiry_logs USING btree (campaign_id);
CREATE INDEX idx_cel_started ON public.campaign_expiry_logs USING btree (started_at);
CREATE INDEX idx_cle_campaign ON public.campaign_link_events USING btree (campaign_id);
CREATE INDEX idx_cle_code ON public.campaign_link_events USING btree (deep_link_code);
CREATE INDEX idx_cle_created ON public.campaign_link_events USING btree (created_at);
CREATE INDEX idx_cle_dlid ON public.campaign_link_events USING btree (deep_link_id);
CREATE INDEX idx_cle_event_type ON public.campaign_link_events USING btree (event_type);
CREATE INDEX idx_cle_late ON public.campaign_link_events USING btree (is_late_conversion);
CREATE INDEX idx_cle_order ON public.campaign_link_events USING btree (order_id);
CREATE INDEX idx_cle_user ON public.campaign_link_events USING btree (telegram_user_id);
CREATE INDEX idx_cr_campaign ON public.campaign_runs USING btree (campaign_id);
CREATE INDEX idx_cr_executed ON public.campaign_runs USING btree (executed_at);
CREATE INDEX idx_ct_campaign ON public.campaign_targets USING btree (campaign_id);
CREATE INDEX idx_ct_apk_caption_lookup ON public.campaign_templates USING btree (template_type, category_id, is_active) WHERE ((template_type)::text = 'trial_apk_caption'::text);
CREATE INDEX idx_categories_visible_sort ON public.categories USING btree (is_hidden, sort_order, id);
CREATE INDEX idx_catdur_category ON public.category_duration_settings USING btree (category_id);
CREATE INDEX idx_dbm_plan ON public.discount_broadcast_messages USING btree (plan_id);
CREATE INDEX idx_dbm_queue ON public.discount_broadcast_messages USING btree (queue_id);
CREATE INDEX idx_discount_plans_active ON public.discount_plans USING btree (is_active) WHERE (is_active = true);
CREATE INDEX idx_discount_rules_plan ON public.discount_rules USING btree (plan_id);
CREATE INDEX idx_durations_cat_sort ON public.durations USING btree (category_id, sort_order, id);
CREATE INDEX idx_fi_created ON public.fulfillment_issues USING btree (created_at);
CREATE INDEX idx_fi_order ON public.fulfillment_issues USING btree (order_id);
CREATE INDEX idx_fi_status ON public.fulfillment_issues USING btree (status);
CREATE INDEX idx_orders_campaign_id ON public.orders USING btree (campaign_id);
CREATE INDEX idx_orders_delivered_at ON public.orders USING btree (delivered_at);
CREATE INDEX idx_orders_purchaser_role ON public.orders USING btree (purchaser_role, id);
CREATE INDEX idx_orders_status_created ON public.orders USING btree (status, created_at);
CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);
CREATE INDEX idx_orders_user_status_id ON public.orders USING btree (user_id, status, id);
CREATE UNIQUE INDEX uq_orders_txn_ref ON public.orders USING btree (txn_ref) WHERE (txn_ref IS NOT NULL);
CREATE INDEX idx_product_keys_is_sold ON public.product_keys USING btree (is_sold, id);
CREATE INDEX idx_product_keys_stock_lookup ON public.product_keys USING btree (category_id, duration_id, is_sold, id);
CREATE UNIQUE INDEX uq_product_keys_key_value ON public.product_keys USING btree (key_value);
CREATE INDEX idx_pkh_key_value ON public.purchased_keys_history USING btree (key_value);
CREATE UNIQUE INDEX idx_pkh_order_id ON public.purchased_keys_history USING btree (order_id);
CREATE INDEX idx_pkh_tg_time ON public.purchased_keys_history USING btree (telegram_id, purchased_at, id);
CREATE INDEX idx_pkh_user_time ON public.purchased_keys_history USING btree (user_id, purchased_at, id);
CREATE INDEX idx_reseller_prices_reseller ON public.reseller_prices USING btree (reseller_id);
CREATE UNIQUE INDEX uq_reseller_users_pair ON public.reseller_users USING btree (reseller_id, user_id);
CREATE UNIQUE INDEX uq_resellers_code ON public.resellers USING btree (code);
CREATE INDEX idx_sc_next_expire ON public.scheduled_campaigns USING btree (next_expire_at) WHERE (is_enabled = true);
CREATE INDEX idx_sc_next_run ON public.scheduled_campaigns USING btree (next_run_at) WHERE (is_enabled = true);
CREATE INDEX idx_sc_status ON public.scheduled_campaigns USING btree (status);
CREATE INDEX idx_sfl_cat ON public.source_fulfillment_logs USING btree (category_id);
CREATE INDEX idx_sfl_created ON public.source_fulfillment_logs USING btree (created_at);
CREATE INDEX idx_sfl_order ON public.source_fulfillment_logs USING btree (order_id);
CREATE UNIQUE INDEX source_rules_category_id_duration_id_key ON public.source_rules USING btree (category_id, duration_id);
CREATE UNIQUE INDEX uq_source_rules_cat_dur ON public.source_rules USING btree (category_id, duration_id);
CREATE INDEX idx_tv_created ON public.template_versions USING btree (created_at);
CREATE INDEX idx_tv_template ON public.template_versions USING btree (template_id);
CREATE INDEX idx_tcdl_campaign ON public.trial_campaign_delivery_logs USING btree (campaign_id);
CREATE INDEX idx_tcdl_delivery_status ON public.trial_campaign_delivery_logs USING btree (delivery_status);
CREATE INDEX idx_tcdl_run ON public.trial_campaign_delivery_logs USING btree (run_id);
CREATE INDEX idx_tcdl_target_type ON public.trial_campaign_delivery_logs USING btree (target_type);
CREATE INDEX idx_tcrk_run ON public.trial_campaign_run_keys USING btree (run_id);
CREATE UNIQUE INDEX uq_tcrk_run_cat ON public.trial_campaign_run_keys USING btree (run_id, category_id);
CREATE INDEX idx_tcr_campaign ON public.trial_campaign_runs USING btree (campaign_id);
CREATE INDEX idx_tcr_started ON public.trial_campaign_runs USING btree (started_at);
CREATE INDEX idx_tc_next_expire ON public.trial_campaigns USING btree (next_expire_at) WHERE (is_enabled = true);
CREATE INDEX idx_tc_next_run ON public.trial_campaigns USING btree (next_run_at) WHERE (is_enabled = true);
CREATE INDEX idx_tc_status ON public.trial_campaigns USING btree (status);
CREATE INDEX idx_trial_keys_cat_dur ON public.trial_keys USING btree (category_id, duration_hours, status);
CREATE INDEX idx_trial_keys_status ON public.trial_keys USING btree (status);
CREATE UNIQUE INDEX uq_trial_keys_value ON public.trial_keys USING btree (key_value);
CREATE INDEX idx_users_awaiting_code ON public.users USING btree (awaiting_code);
CREATE INDEX idx_users_banned ON public.users USING btree (is_banned);
CREATE INDEX idx_users_reseller_id ON public.users USING btree (reseller_id);
CREATE UNIQUE INDEX uq_users_telegram_id ON public.users USING btree (telegram_id);

-- ==========================================================
-- SEQUENCE VALUES (restore current auto-increment positions)
-- ==========================================================

SELECT setval('api_providers_id_seq', 2, true);
SELECT setval('broadcast_queue_id_seq', 2, true);
SELECT setval('campaign_attributions_id_seq', 1, true);
SELECT setval('campaign_daily_stats_id_seq', 2, true);
SELECT setval('campaign_deep_links_id_seq', 2, true);
SELECT setval('campaign_delivery_logs_id_seq', 7, true);
SELECT setval('campaign_discount_rules_id_seq', 1, true);
SELECT setval('campaign_expiry_logs_id_seq', 2, true);
SELECT setval('campaign_link_events_id_seq', 1, true);
SELECT setval('campaign_runs_id_seq', 3, true);
SELECT setval('campaign_targets_id_seq', 1, true);
SELECT setval('campaign_templates_id_seq', 9, true);
SELECT setval('categories_id_seq', 3, true);
SELECT setval('discount_broadcast_messages_id_seq', 4, true);
SELECT setval('discount_plans_id_seq', 2, true);
SELECT setval('discount_rules_id_seq', 2, true);
SELECT setval('durations_id_seq', 11, true);
SELECT setval('force_join_channels_id_seq', 1, true);
SELECT setval('fulfillment_issues_id_seq', 1, true);
SELECT setval('orders_id_seq', 17, true);
SELECT setval('product_keys_id_seq', 7, true);
SELECT setval('purchased_keys_history_id_seq', 7, true);
SELECT setval('reseller_prices_id_seq', 1, true);
SELECT setval('reseller_users_id_seq', 1, true);
SELECT setval('resellers_id_seq', 1, true);
SELECT setval('scheduled_campaigns_id_seq', 1, true);
SELECT setval('source_audit_logs_id_seq', 17, true);
SELECT setval('source_fulfillment_logs_id_seq', 8, true);
SELECT setval('source_rules_id_seq', 11, true);
SELECT setval('template_versions_id_seq', 1, true);
SELECT setval('trial_campaign_delivery_logs_id_seq', 1, true);
SELECT setval('trial_campaign_run_keys_id_seq', 1, true);
SELECT setval('trial_campaign_runs_id_seq', 1, true);
SELECT setval('trial_campaigns_id_seq', 1, true);
SELECT setval('trial_keys_id_seq', 1, true);
SELECT setval('users_id_seq', 4, true);