import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import config from './config';

import authRouter from './routes/auth';
import dashboardRouter from './routes/dashboard';
import categoriesRouter from './routes/categories';
import durationsRouter from './routes/durations';
import keysRouter from './routes/keys';
import ordersRouter from './routes/orders';
import usersRouter from './routes/users';
import paidUsersRouter from './routes/paid-users';
import resellersRouter from './routes/resellers';
import discountPlansRouter from './routes/discount-plans';
import userKeysRouter from './routes/user-keys';
import botSettingsRouter from './routes/bot-settings';
import forceJoinRouter from './routes/force-join';
import sourceRulesRouter from './routes/source-rules';
import campaignsRouter from './routes/campaigns';
import channelsRouter from './routes/channels';
import trialKeysRouter from './routes/trial-keys';
import trialCampaignsRouter from './routes/trial-campaigns';

const app = express();
const PORT = config.app.port;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

const BOT_TOKEN = process.env.BOT_TOKEN || '';
app.get('/api/users/photo', async (req, res) => {
  try {
    const raw = (req.query.p as string) || '';
    if (!BOT_TOKEN || !raw || raw.includes('..')) return res.status(404).end();
    const tgUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${raw}`;
    const upstream = await fetch(tgUrl);
    if (!upstream.ok) return res.status(404).end();
    const ct = upstream.headers.get('content-type');
    if (ct) res.setHeader('Content-Type', ct);
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.end(buf);
  } catch {
    res.status(502).end();
  }
});

app.use('/api/auth', authRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/categories', categoriesRouter);
app.use('/api/durations', durationsRouter);
app.use('/api/keys', keysRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/users', usersRouter);
app.use('/api/paid-users', paidUsersRouter);
app.use('/api/resellers', resellersRouter);
app.use('/api/discount-plans', discountPlansRouter);
app.use('/api/user-keys', userKeysRouter);
app.use('/api/bot-settings', botSettingsRouter);
app.use('/api/force-join', forceJoinRouter);
app.use('/api/source-rules', sourceRulesRouter);
app.use('/api/campaigns', campaignsRouter);
app.use('/api/channels', channelsRouter);
app.use('/api/trial-keys', trialKeysRouter);
app.use('/api/trial-campaigns', trialCampaignsRouter);

const BOT_WEBHOOK_PORT = parseInt(process.env.BOT_WEBHOOK_PORT || '8443', 10);
app.post('/bot/webhook', async (req, res) => {
  try {
    const upstream = await fetch(`http://127.0.0.1:${BOT_WEBHOOK_PORT}/bot/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body),
    });
    res.status(upstream.status).send(await upstream.text());
  } catch {
    res.status(502).json({ error: 'Bot process unavailable' });
  }
});

const clientDist = path.join(__dirname, '..', 'client', 'dist');
app.use(express.static(clientDist));

app.get('/healthz', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

app.get('/{*splat}', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  res.sendFile(path.join(clientDist, 'index.html'));
});

const LISTEN_PORT = 5000;
app.listen(LISTEN_PORT, '0.0.0.0', () => {
  console.log(`${config.branding.name} Admin server running on port ${LISTEN_PORT}`);
});
