import { Request } from 'express';

export interface AdminPayload {
  role: string;
  username: string;
  iat?: number;
  exp?: number;
}

export interface AuthenticatedRequest extends Request {
  admin?: AdminPayload;
}

export interface UserRow {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  is_banned: number;
  reseller_id: number | null;
  token: string | null;
}

export interface UserKeyRequest extends Request {
  userRow?: UserRow;
}

export interface AppConfig {
  app: {
    port: number;
    nodeEnv: string;
  };
  database: {
    url: string;
  };
  auth: {
    jwtSecret: string;
    adminUsername: string;
    adminPassword: string;
    tokenExpiry: string;
  };
  branding: {
    name: string;
    shortName: string;
    tagline: string;
    currency: string;
    locale: string;
  };
}
