import { Pool } from 'pg';
import config from './config';

const pool = new Pool({
  connectionString: config.database.url,
});

pool.query('SELECT 1')
  .then(() => console.log('Database connected'))
  .catch((err: Error) => console.error('Database connection error:', err.message));

export default pool;
