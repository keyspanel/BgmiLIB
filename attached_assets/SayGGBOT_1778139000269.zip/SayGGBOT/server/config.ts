import { AppConfig } from './types';

const env = (key: string, fallback?: string): string | undefined => {
  const val = process.env[key];
  if (val !== undefined && val !== '') return val;
  if (fallback !== undefined) return fallback;
  return undefined;
};

const requireEnv = (key: string): string => {
  const val = process.env[key];
  if (!val) {
    console.error(`FATAL: Required environment variable ${key} is not set`);
    process.exit(1);
  }
  return val;
};

const config: AppConfig = {
  app: {
    port: parseInt(env('PORT', '5000')!, 10),
    nodeEnv: env('NODE_ENV', 'development')!,
  },

  database: {
    url: requireEnv('DATABASE_URL'),
  },

  auth: {
    jwtSecret: requireEnv('JWT_SECRET'),
    adminUsername: requireEnv('ADMIN_USERNAME'),
    adminPassword: requireEnv('ADMIN_PASSWORD'),
    tokenExpiry: env('JWT_TOKEN_EXPIRY', '24h')!,
  },

  branding: {
    name: env('BRAND_NAME', 'KeyStore')!,
    shortName: env('BRAND_SHORT_NAME', 'KS')!,
    tagline: env('BRAND_TAGLINE', 'Secure management console')!,
    currency: env('CURRENCY_SYMBOL', '\u20B9')!,
    locale: env('LOCALE', 'en-IN')!,
  },
};

export default config;
