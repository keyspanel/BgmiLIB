import express, { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import config from '../config';
import { JWT_SECRET } from '../middleware/auth';

const router = express.Router();

router.post('/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  const adminUser = config.auth.adminUsername;
  const adminPass = config.auth.adminPassword;

  if (!adminUser || !adminPass) {
    return res.status(500).json({ error: 'Server misconfigured: admin credentials not set' });
  }

  if (username === adminUser && password === adminPass) {
    const token = jwt.sign({ role: 'admin', username }, JWT_SECRET, { expiresIn: config.auth.tokenExpiry });
    return res.json({ token, username });
  }
  return res.status(401).json({ error: 'Invalid username or password' });
});

router.get('/verify', (req: Request, res: Response) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ valid: false });
  }
  try {
    const decoded = jwt.verify(header.slice(7), JWT_SECRET) as { username: string };
    return res.json({ valid: true, username: decoded.username });
  } catch {
    return res.status(401).json({ valid: false });
  }
});

export default router;
