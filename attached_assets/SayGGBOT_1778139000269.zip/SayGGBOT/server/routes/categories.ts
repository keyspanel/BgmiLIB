import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): { name: string; emojiId: string | null } {
  raw = (raw || '').trim();
  let emojiId: string | null = null;
  const m = raw.match(/\{(\d{5,32})\}/);
  if (m) {
    emojiId = m[1];
    raw = raw.replace(/\{\d{5,32}\}/, '');
  }
  return { name: raw.trim().replace(/\s+/g, ' '), emojiId };
}

router.get('/', async (req: Request, res: Response) => {
  try {
    const search = ((req.query.search as string) || '').trim();
    let sql = `
      SELECT c.*,
        (SELECT COUNT(*) FROM durations d WHERE d.category_id = c.id) AS total_durations,
        (SELECT COUNT(*) FROM durations d WHERE d.category_id = c.id AND d.is_hidden = 0) AS visible_durations,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.category_id = c.id) AS total_keys,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.category_id = c.id AND pk.is_sold = 0) AS available_keys,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.category_id = c.id AND pk.is_sold = 2) AS reserved_keys,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.category_id = c.id AND pk.is_sold = 1) AS sold_keys,
        (SELECT COUNT(*) FROM source_rules sr
         JOIN api_providers ap ON ap.id = sr.api_provider_id
         JOIN durations d2 ON d2.id = sr.duration_id AND d2.category_id = c.id AND d2.is_hidden = 0
         WHERE sr.category_id = c.id
           AND sr.source_type = 'api'
           AND sr.is_active = true
           AND ap.is_active = true
        ) AS api_backed_durations
      FROM categories c
    `;
    const params: any[] = [];
    if (search) {
      sql += ' WHERE c.name ILIKE $1 ';
      params.push(`%${search}%`);
    }
    sql += ' ORDER BY c.sort_order ASC, c.id ASC';
    const result = await pool.query(sql, params);
    const rows = result.rows.map((r: any) => {
      const parsed = cleanEmojiName(r.name);
      return { ...r, displayName: parsed.name, customEmojiId: parsed.emojiId };
    });
    res.json(rows);
  } catch (err) {
    console.error('Categories list error:', err);
    res.status(500).json({ error: 'Failed to load categories' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  try {
    const { name, sort_order = 0, is_hidden = 0, button_style = 4, file_id = null } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    const style = Math.min(4, Math.max(1, parseInt(button_style) || 4));
    const result = await pool.query(
      'INSERT INTO categories (name, sort_order, is_hidden, button_style, file_id) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [name.trim(), parseInt(sort_order) || 0, is_hidden ? 1 : 0, style, file_id || null]
    );
    res.json({ id: result.rows[0].id, message: 'Category created successfully' });
  } catch (err) {
    console.error('Category create error:', err);
    res.status(500).json({ error: 'Failed to create category' });
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, sort_order = 0, is_hidden = 0, button_style = 4, file_id = null } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    const style = Math.min(4, Math.max(1, parseInt(button_style) || 4));
    await pool.query(
      'UPDATE categories SET name = $1, sort_order = $2, is_hidden = $3, button_style = $4, file_id = $5 WHERE id = $6',
      [name.trim(), parseInt(sort_order) || 0, is_hidden ? 1 : 0, style, file_id || null, id]
    );
    res.json({ message: 'Category updated successfully' });
  } catch (err) {
    console.error('Category update error:', err);
    res.status(500).json({ error: 'Failed to update category' });
  }
});

router.put('/:id/visibility', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { is_hidden } = req.body;
    await pool.query('UPDATE categories SET is_hidden = $1 WHERE id = $2', [is_hidden ? 1 : 0, id]);
    res.json({ message: is_hidden ? 'Category hidden' : 'Category visible' });
  } catch (err) {
    console.error('Category visibility error:', err);
    res.status(500).json({ error: 'Failed to update visibility' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM categories WHERE id = $1', [id]);
    res.json({ message: 'Category deleted successfully' });
  } catch (err) {
    console.error('Category delete error:', err);
    res.status(500).json({ error: 'Failed to delete category' });
  }
});

export default router;
