import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { tgPhotoProxyUrl } from './users';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT
        COUNT(*) AS total_orders,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_orders,
        SUM(CASE WHEN status = 'awaiting_payment' THEN 1 ELSE 0 END) AS awaiting_orders,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid_orders,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders,
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) AS total_paid_amount
      FROM orders
    `);
    const s = result.rows[0];
    res.json({
      total_orders: parseInt(s.total_orders||0),
      pending_orders: parseInt(s.pending_orders||0),
      awaiting_orders: parseInt(s.awaiting_orders||0),
      paid_orders: parseInt(s.paid_orders||0),
      cancelled_orders: parseInt(s.cancelled_orders||0),
      total_paid_amount: parseFloat(s.total_paid_amount||0),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load stats' });
  }
});

router.get('/', async (req: Request, res: Response) => {
  try {
    const { search, status, category_id, duration_id, date_from, date_to, page = '1', limit = '50' } = req.query as Record<string, string>;
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;

    if (status && ['pending', 'awaiting_payment', 'paid', 'cancelled'].includes(status)) {
      where.push(`o.status = $${idx++}`); params.push(status);
    }
    if (parseInt(category_id) > 0) { where.push(`c.id = $${idx++}`); params.push(parseInt(category_id)); }
    if (parseInt(duration_id) > 0) { where.push(`d.id = $${idx++}`); params.push(parseInt(duration_id)); }
    if (date_from) { where.push(`o.created_at::date >= $${idx++}`); params.push(date_from); }
    if (date_to) { where.push(`o.created_at::date <= $${idx++}`); params.push(date_to); }
    if (search) {
      const like = `%${search}%`;
      where.push(`(
        CAST(o.id AS TEXT) ILIKE $${idx} OR CAST(u.telegram_id AS TEXT) ILIKE $${idx} OR
        u.username ILIKE $${idx} OR u.first_name ILIKE $${idx} OR u.last_name ILIKE $${idx} OR
        k.key_value ILIKE $${idx} OR c.name ILIKE $${idx} OR d.name ILIKE $${idx} OR
        o.txn_ref ILIKE $${idx} OR o.purchased_category_name ILIKE $${idx} OR o.purchased_duration_name ILIKE $${idx}
      )`);
      params.push(like);
      idx++;
    }

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);

    const countResult = await pool.query(`
      SELECT COUNT(*) AS total FROM orders o
      JOIN users u ON o.user_id = u.id
      LEFT JOIN product_keys k ON o.key_id = k.id
      LEFT JOIN durations d ON k.duration_id = d.id
      LEFT JOIN categories c ON k.category_id = c.id
      ${whereClause}
    `, params);

    const rows = await pool.query(`
      SELECT o.*, o.purchased_category_name, o.purchased_duration_name,
        u.telegram_id, u.username, u.first_name, u.last_name, u.profile_photo_url,
        k.key_value, d.name AS duration_name, c.name AS category_name
      FROM orders o
      JOIN users u ON o.user_id = u.id
      LEFT JOIN product_keys k ON o.key_id = k.id
      LEFT JOIN durations d ON k.duration_id = d.id
      LEFT JOIN categories c ON k.category_id = c.id
      ${whereClause}
      ORDER BY o.id DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `, [...params, parseInt(limit), offset]);

    const result = rows.rows.map((r: any) => ({
      ...r,
      profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url),
      displayCategory: cleanEmojiName(r.purchased_category_name || r.category_name) || '-',
      displayDuration: cleanEmojiName(r.purchased_duration_name || r.duration_name) || '-',
      displayUser: ((r.first_name || '') + ' ' + (r.last_name || '')).trim() || (r.username ? '@' + r.username : '-'),
    }));

    res.json({ orders: result, total: parseInt(countResult.rows[0].total), page: parseInt(page), totalPages: Math.ceil(parseInt(countResult.rows[0].total) / parseInt(limit)) });
  } catch (err) {
    console.error('Orders list error:', err);
    res.status(500).json({ error: 'Failed to load orders' });
  }
});

router.put('/:id/status', async (req: Request, res: Response) => {
  try {
    const { status } = req.body;
    const allowed = ['pending', 'awaiting_payment', 'paid', 'cancelled'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });

    if (status === 'paid') {
      await pool.query('UPDATE orders SET status = $1, verified_at = NOW() WHERE id = $2', [status, req.params.id]);
    } else {
      await pool.query('UPDATE orders SET status = $1 WHERE id = $2', [status, req.params.id]);
    }
    res.json({ message: 'Order status updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

router.put('/:id/txn', async (req: Request, res: Response) => {
  try {
    const { txn_ref } = req.body;
    await pool.query('UPDATE orders SET txn_ref = $1 WHERE id = $2', [txn_ref || null, req.params.id]);
    res.json({ message: 'Transaction reference updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update transaction reference' });
  }
});

export default router;
