import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

async function ensureTables(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS configured_channels (
      id SERIAL PRIMARY KEY,
      label TEXT NOT NULL DEFAULT '',
      original_input TEXT NOT NULL,
      normalized_input TEXT NOT NULL,
      resolved_chat_id BIGINT,
      resolved_username TEXT,
      resolved_title TEXT,
      chat_type TEXT,
      is_validated BOOLEAN NOT NULL DEFAULT false,
      bot_is_member BOOLEAN NOT NULL DEFAULT false,
      bot_is_admin BOOLEAN NOT NULL DEFAULT false,
      can_post_messages BOOLEAN NOT NULL DEFAULT false,
      is_enabled BOOLEAN NOT NULL DEFAULT true,
      last_validated_at TIMESTAMP,
      last_validation_status TEXT NOT NULL DEFAULT 'pending',
      last_validation_error TEXT,
      notes TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS channel_audit_log (
      id SERIAL PRIMARY KEY,
      action TEXT NOT NULL,
      actor TEXT NOT NULL DEFAULT 'admin',
      channel_id INT,
      channel_label TEXT,
      normalized_input TEXT,
      resolved_chat_id BIGINT,
      result TEXT,
      error_reason TEXT,
      metadata JSONB,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  const migrations = [
    `ALTER TABLE configured_channels ADD COLUMN IF NOT EXISTS notes TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE configured_channels ADD COLUMN IF NOT EXISTS chat_type TEXT`,
  ];
  for (const sql of migrations) {
    try { await pool.query(sql); } catch (_) {}
  }
}

async function auditLog(action: string, data: {
  channel_id?: number | null;
  channel_label?: string;
  normalized_input?: string;
  resolved_chat_id?: number | null;
  result?: string;
  error_reason?: string;
  metadata?: any;
}) {
  try {
    await pool.query(
      `INSERT INTO channel_audit_log (action, actor, channel_id, channel_label, normalized_input, resolved_chat_id, result, error_reason, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [action, 'admin', data.channel_id || null, data.channel_label || null,
       data.normalized_input || null, data.resolved_chat_id || null,
       data.result || null, data.error_reason || null,
       data.metadata ? JSON.stringify(data.metadata) : null]
    );
  } catch (e) {
    console.error('Channel audit log error:', e);
  }
}

function normalizeChannelInput(raw: string): { normalized: string; type: 'username' | 'numeric_id' | 'invite_link' | 'invalid'; display: string } {
  const input = (raw || '').trim();
  if (!input) return { normalized: '', type: 'invalid', display: '' };

  if (/^-?\d+$/.test(input)) {
    return { normalized: input, type: 'numeric_id', display: `Chat ID: ${input}` };
  }

  if (/^https?:\/\/t\.me\/\+/.test(input) || /^https?:\/\/t\.me\/joinchat\//.test(input)) {
    return { normalized: input, type: 'invite_link', display: `Invite link: ${input}` };
  }

  let username = input;
  const tmeMatch = input.match(/^https?:\/\/t\.me\/([a-zA-Z_][a-zA-Z0-9_]{3,})(?:\/\d+)?(?:\?.*)?$/);
  if (tmeMatch) {
    username = tmeMatch[1];
  } else {
    username = username.replace(/^@+/, '');
    username = username.split('/')[0].split('?')[0];
  }

  if (/^[a-zA-Z_][a-zA-Z0-9_]{3,}$/.test(username)) {
    return { normalized: '@' + username.toLowerCase(), type: 'username', display: `@${username.toLowerCase()}` };
  }

  return { normalized: '', type: 'invalid', display: '' };
}

async function telegramApi(botToken: string, method: string, body: any): Promise<any> {
  const resp = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  return resp.json();
}

async function validateChannel(input: string): Promise<{
  ok: boolean;
  resolved_chat_id: number | null;
  resolved_username: string | null;
  resolved_title: string | null;
  chat_type: string | null;
  bot_is_member: boolean;
  bot_is_admin: boolean;
  can_post_messages: boolean;
  error: string | null;
  detail: string;
}> {
  const fail = (error: string) => ({
    ok: false, resolved_chat_id: null, resolved_username: null, resolved_title: null,
    chat_type: null, bot_is_member: false, bot_is_admin: false, can_post_messages: false,
    error, detail: error,
  });

  const botToken = process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) return fail('Bot token not configured on server');

  const parsed = normalizeChannelInput(input);
  if (parsed.type === 'invalid') return fail('Invalid channel format — enter a @username, numeric ID, or t.me link');

  if (parsed.type === 'invite_link') {
    return fail('Private invite links cannot be validated — the bot must already be inside the channel. Use the numeric channel ID (e.g. -1001234567890) or a public @username instead.');
  }

  const chatIdentifier = parsed.type === 'numeric_id' ? parsed.normalized : parsed.normalized;

  let chatData: any;
  try {
    chatData = await telegramApi(botToken, 'getChat', { chat_id: chatIdentifier });
  } catch (e: any) {
    if (e.name === 'TimeoutError' || e.name === 'AbortError') {
      return fail('Validation timed out — try again');
    }
    return fail(`Telegram API error: ${e.message}`);
  }

  if (!chatData.ok) {
    const desc = chatData.description || 'Unknown error';
    if (desc.includes('not found')) return fail('Channel not found');
    if (desc.includes('Forbidden')) return fail('Telegram API error: access denied');
    return fail(`Channel not found or inaccessible: ${desc}`);
  }

  const chat = chatData.result;
  const resolvedId = chat.id;
  const resolvedUsername = chat.username || null;
  const resolvedTitle = chat.title || null;
  const chatType = chat.type || null;

  if (!['channel', 'supergroup', 'group'].includes(chatType)) {
    return fail(`This chat is not a channel — it is a "${chatType}". Only channels, supergroups, and groups are supported.`);
  }

  const botId = parseInt(botToken.split(':')[0]);
  let memberData: any;
  try {
    memberData = await telegramApi(botToken, 'getChatMember', { chat_id: resolvedId, user_id: botId });
  } catch (e: any) {
    return fail(`Could not check bot membership: ${e.message}`);
  }

  if (!memberData.ok) {
    return fail('Bot is not a member of this channel');
  }

  const botStatus = memberData.result.status;
  const botIsMember = ['administrator', 'creator', 'member', 'restricted'].includes(botStatus);
  const botIsAdmin = ['administrator', 'creator'].includes(botStatus);

  if (!botIsMember) {
    return fail('Bot is not a member of this channel');
  }

  if (!botIsAdmin) {
    return fail('Bot is a member but not an admin — make the bot an administrator in this channel');
  }

  let canPost = false;
  if (botStatus === 'creator') {
    canPost = true;
  } else if (botStatus === 'administrator') {
    const rights = memberData.result;
    canPost = rights.can_post_messages === true || chatType !== 'channel';
  }

  if (!canPost) {
    return {
      ok: false,
      resolved_chat_id: resolvedId,
      resolved_username: resolvedUsername,
      resolved_title: resolvedTitle,
      chat_type: chatType,
      bot_is_member: true,
      bot_is_admin: true,
      can_post_messages: false,
      error: 'Bot is an admin but cannot post messages — enable "Post Messages" permission for the bot',
      detail: 'Bot is admin but lacks post permission',
    };
  }

  return {
    ok: true,
    resolved_chat_id: resolvedId,
    resolved_username: resolvedUsername,
    resolved_title: resolvedTitle,
    chat_type: chatType,
    bot_is_member: true,
    bot_is_admin: true,
    can_post_messages: true,
    error: null,
    detail: `Validated — bot is ${botStatus} in ${resolvedTitle || chatIdentifier}`,
  };
}

router.get('/', async (_req: Request, res: Response) => {
  try {
    await ensureTables();
    const { rows } = await pool.query('SELECT * FROM configured_channels ORDER BY created_at DESC');
    res.json({ channels: rows });
  } catch (err) {
    console.error('Channels list error:', err);
    res.status(500).json({ error: 'Failed to load channels' });
  }
});

router.post('/validate', async (req: Request, res: Response) => {
  try {
    const { input } = req.body;
    if (!input || typeof input !== 'string') {
      return res.json({ ok: false, error: 'No input provided' });
    }

    const parsed = normalizeChannelInput(input);
    const result = await validateChannel(input);

    await auditLog(result.ok ? 'channel_validation_passed' : 'channel_validation_failed', {
      normalized_input: parsed.normalized,
      resolved_chat_id: result.resolved_chat_id,
      result: result.ok ? 'passed' : 'failed',
      error_reason: result.error || undefined,
      metadata: {
        original_input: input,
        resolved_title: result.resolved_title,
        chat_type: result.chat_type,
        bot_is_admin: result.bot_is_admin,
        can_post: result.can_post_messages,
      },
    });

    res.json({
      ...result,
      normalized: parsed.normalized,
      input_type: parsed.type,
      display: parsed.display,
    });
  } catch (err) {
    console.error('Channel validate error:', err);
    res.status(500).json({ ok: false, error: 'Validation failed unexpectedly' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  try {
    await ensureTables();
    const { label, input, notes, validation } = req.body;

    if (!validation || !validation.ok) {
      return res.status(400).json({ error: 'Channel must be validated before saving' });
    }

    const parsed = normalizeChannelInput(input);
    if (parsed.type === 'invalid') {
      return res.status(400).json({ error: 'Invalid channel input' });
    }

    const existing = await pool.query(
      'SELECT id FROM configured_channels WHERE resolved_chat_id = $1',
      [validation.resolved_chat_id]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'This channel is already configured', existing_id: existing.rows[0].id });
    }

    const { rows } = await pool.query(
      `INSERT INTO configured_channels
       (label, original_input, normalized_input, resolved_chat_id, resolved_username, resolved_title,
        chat_type, is_validated, bot_is_member, bot_is_admin, can_post_messages, is_enabled,
        last_validated_at, last_validation_status, last_validation_error, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,NOW(),$13,$14,$15) RETURNING *`,
      [
        (label || '').trim(),
        input,
        parsed.normalized,
        validation.resolved_chat_id,
        validation.resolved_username,
        validation.resolved_title,
        validation.chat_type,
        true,
        validation.bot_is_member,
        validation.bot_is_admin,
        validation.can_post_messages,
        true,
        'valid',
        null,
        (notes || '').trim(),
      ]
    );

    await auditLog('channel_created', {
      channel_id: rows[0].id,
      channel_label: (label || '').trim(),
      normalized_input: parsed.normalized,
      resolved_chat_id: validation.resolved_chat_id,
      result: 'created',
    });

    res.json({ ok: true, channel: rows[0] });
  } catch (err) {
    console.error('Channel create error:', err);
    res.status(500).json({ error: 'Failed to save channel' });
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  try {
    await ensureTables();
    const { id } = req.params;
    const { label, notes, input, validation } = req.body;

    const existing = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Channel not found' });
    }

    const old = existing.rows[0];
    const parsed = input ? normalizeChannelInput(input) : null;
    const targetChanged = parsed && parsed.normalized !== old.normalized_input;

    if (targetChanged) {
      if (!validation || !validation.ok) {
        return res.status(400).json({ error: 'Changed channel target requires fresh validation before saving' });
      }

      const dupe = await pool.query(
        'SELECT id FROM configured_channels WHERE resolved_chat_id = $1 AND id != $2',
        [validation.resolved_chat_id, id]
      );
      if (dupe.rows.length > 0) {
        return res.status(409).json({ error: 'This channel is already configured under another entry' });
      }

      await pool.query(
        `UPDATE configured_channels SET
           label=$1, original_input=$2, normalized_input=$3, resolved_chat_id=$4,
           resolved_username=$5, resolved_title=$6, chat_type=$7,
           is_validated=$8, bot_is_member=$9, bot_is_admin=$10, can_post_messages=$11,
           last_validated_at=NOW(), last_validation_status=$12, last_validation_error=$13,
           notes=$14, updated_at=NOW()
         WHERE id=$15`,
        [
          (label || '').trim(), input, parsed!.normalized,
          validation.resolved_chat_id, validation.resolved_username, validation.resolved_title,
          validation.chat_type, true, validation.bot_is_member, validation.bot_is_admin,
          validation.can_post_messages, 'valid', null, (notes || '').trim(), id,
        ]
      );
    } else {
      await pool.query(
        `UPDATE configured_channels SET label=$1, notes=$2, updated_at=NOW() WHERE id=$3`,
        [(label || '').trim(), (notes || '').trim(), id]
      );
    }

    const { rows } = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    await auditLog('channel_updated', {
      channel_id: parseInt(id),
      channel_label: (label || '').trim(),
      normalized_input: rows[0]?.normalized_input,
      resolved_chat_id: rows[0]?.resolved_chat_id,
      result: targetChanged ? 'target_changed' : 'metadata_updated',
    });

    res.json({ ok: true, channel: rows[0] });
  } catch (err) {
    console.error('Channel update error:', err);
    res.status(500).json({ error: 'Failed to update channel' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    await ensureTables();
    const { id } = req.params;
    const existing = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Channel not found' });
    }

    const ch = existing.rows[0];
    await pool.query('DELETE FROM configured_channels WHERE id = $1', [id]);

    await auditLog('channel_deleted', {
      channel_id: parseInt(id),
      channel_label: ch.label,
      normalized_input: ch.normalized_input,
      resolved_chat_id: ch.resolved_chat_id,
      result: 'deleted',
    });

    res.json({ ok: true });
  } catch (err) {
    console.error('Channel delete error:', err);
    res.status(500).json({ error: 'Failed to delete channel' });
  }
});

router.post('/:id/revalidate', async (req: Request, res: Response) => {
  try {
    await ensureTables();
    const { id } = req.params;
    const existing = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Channel not found' });
    }

    const ch = existing.rows[0];
    const input = ch.resolved_chat_id ? String(ch.resolved_chat_id) : ch.normalized_input;
    const result = await validateChannel(input);

    const newStatus = result.ok ? 'valid'
      : (result.bot_is_admin === false && result.bot_is_member === true) ? 'permission_lost'
      : result.error ? 'invalid'
      : 'needs_validation';

    await pool.query(
      `UPDATE configured_channels SET
         is_validated=$1, bot_is_member=$2, bot_is_admin=$3, can_post_messages=$4,
         last_validated_at=NOW(), last_validation_status=$5, last_validation_error=$6,
         resolved_title=COALESCE($7, resolved_title), chat_type=COALESCE($8, chat_type),
         resolved_username=COALESCE($9, resolved_username), updated_at=NOW()
       WHERE id=$10`,
      [
        result.ok, result.bot_is_member, result.bot_is_admin, result.can_post_messages,
        newStatus, result.error, result.resolved_title, result.chat_type,
        result.resolved_username, id,
      ]
    );

    await auditLog(result.ok ? 'channel_validation_passed' : 'channel_validation_failed', {
      channel_id: parseInt(id),
      channel_label: ch.label,
      normalized_input: ch.normalized_input,
      resolved_chat_id: result.resolved_chat_id || ch.resolved_chat_id,
      result: result.ok ? 'passed' : 'failed',
      error_reason: result.error || undefined,
    });

    const { rows } = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    res.json({ ok: result.ok, channel: rows[0], validation: result });
  } catch (err) {
    console.error('Channel revalidate error:', err);
    res.status(500).json({ error: 'Revalidation failed' });
  }
});

router.post('/:id/toggle', async (req: Request, res: Response) => {
  try {
    await ensureTables();
    const { id } = req.params;
    const existing = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Channel not found' });
    }

    const ch = existing.rows[0];
    const newEnabled = !ch.is_enabled;
    await pool.query('UPDATE configured_channels SET is_enabled=$1, updated_at=NOW() WHERE id=$2', [newEnabled, id]);

    await auditLog(newEnabled ? 'channel_enabled' : 'channel_disabled', {
      channel_id: parseInt(id),
      channel_label: ch.label,
      normalized_input: ch.normalized_input,
      resolved_chat_id: ch.resolved_chat_id,
      result: newEnabled ? 'enabled' : 'disabled',
    });

    const { rows } = await pool.query('SELECT * FROM configured_channels WHERE id = $1', [id]);
    res.json({ ok: true, channel: rows[0] });
  } catch (err) {
    console.error('Channel toggle error:', err);
    res.status(500).json({ error: 'Failed to toggle channel' });
  }
});

router.get('/audit', async (_req: Request, res: Response) => {
  try {
    await ensureTables();
    const { rows } = await pool.query(
      'SELECT * FROM channel_audit_log ORDER BY created_at DESC LIMIT 200'
    );
    res.json({ logs: rows });
  } catch (err) {
    console.error('Channel audit error:', err);
    res.status(500).json({ error: 'Failed to load audit log' });
  }
});

router.get('/active', async (_req: Request, res: Response) => {
  try {
    await ensureTables();
    const { rows } = await pool.query(
      `SELECT id, label, normalized_input, resolved_chat_id, resolved_username, resolved_title,
              chat_type, is_validated, bot_is_admin, can_post_messages, last_validation_status, last_validated_at
       FROM configured_channels
       WHERE is_enabled = true AND is_validated = true AND last_validation_status = 'valid'
       ORDER BY label ASC, id ASC`
    );
    res.json({ channels: rows });
  } catch (err) {
    console.error('Active channels error:', err);
    res.status(500).json({ error: 'Failed to load active channels' });
  }
});

export default router;
