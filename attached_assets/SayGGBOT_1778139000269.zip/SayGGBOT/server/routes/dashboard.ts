import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { tgPhotoProxyUrl } from './users';

const router = express.Router();
router.use(authMiddleware);

router.get('/', async (req: Request, res: Response) => {
  try {
    const [
      catRows,
      durRows,
      keyStats,
      orderStats,
      userRows,
      resellerRows,
      paidUserRows,
      recentOrders,
      todaySales,
      yesterdaySales,
      weeklySales,
      monthlySales,
      dailySalesChart,
      recentActivity,
    ] = await Promise.all([
      pool.query('SELECT COUNT(*) AS total FROM categories'),
      pool.query('SELECT COUNT(*) AS total FROM durations'),
      pool.query(`
        SELECT
          COUNT(*) AS total_keys,
          SUM(CASE WHEN is_sold = 0 THEN 1 ELSE 0 END) AS available_keys,
          SUM(CASE WHEN is_sold = 2 THEN 1 ELSE 0 END) AS reserved_keys,
          SUM(CASE WHEN is_sold = 1 THEN 1 ELSE 0 END) AS sold_keys
        FROM product_keys
      `),
      pool.query(`
        SELECT
          COUNT(*) AS total_orders,
          SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_orders,
          SUM(CASE WHEN status = 'awaiting_payment' THEN 1 ELSE 0 END) AS awaiting_orders,
          SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) AS paid_orders,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders,
          SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) AS total_revenue
        FROM orders
      `),
      pool.query('SELECT COUNT(*) AS total FROM users'),
      pool.query('SELECT COUNT(*) AS total FROM resellers'),
      pool.query('SELECT COUNT(DISTINCT user_id) AS total FROM purchased_keys_history'),
      pool.query(`
        SELECT o.id, o.status, o.amount, o.created_at,
          u.username, u.first_name, u.telegram_id, u.profile_photo_url
        FROM orders o
        JOIN users u ON o.user_id = u.id
        ORDER BY o.id DESC LIMIT 5
      `),
      pool.query(`
        SELECT
          COALESCE(SUM(amount), 0) AS revenue,
          COUNT(*) AS orders
        FROM orders
        WHERE status = 'paid'
          AND verified_at >= CURRENT_DATE
      `),
      pool.query(`
        SELECT
          COALESCE(SUM(amount), 0) AS revenue,
          COUNT(*) AS orders
        FROM orders
        WHERE status = 'paid'
          AND verified_at >= CURRENT_DATE - INTERVAL '1 day'
          AND verified_at < CURRENT_DATE
      `),
      pool.query(`
        SELECT
          COALESCE(SUM(amount), 0) AS revenue,
          COUNT(*) AS orders
        FROM orders
        WHERE status = 'paid'
          AND verified_at >= CURRENT_DATE - INTERVAL '7 days'
      `),
      pool.query(`
        SELECT
          COALESCE(SUM(amount), 0) AS revenue,
          COUNT(*) AS orders
        FROM orders
        WHERE status = 'paid'
          AND verified_at >= CURRENT_DATE - INTERVAL '30 days'
      `),
      pool.query(`
        SELECT
          d.day::date AS date,
          COALESCE(SUM(o.amount), 0) AS revenue,
          COUNT(o.id) AS orders
        FROM generate_series(
          CURRENT_DATE - INTERVAL '29 days',
          CURRENT_DATE,
          '1 day'
        ) AS d(day)
        LEFT JOIN orders o
          ON o.verified_at::date = d.day::date
          AND o.status = 'paid'
        GROUP BY d.day
        ORDER BY d.day ASC
      `),
      pool.query(`
        SELECT
          o.id,
          o.status,
          o.amount,
          o.created_at,
          u.first_name,
          u.username,
          u.profile_photo_url,
          COALESCE(o.purchased_category_name, c.name) AS category_name,
          COALESCE(o.purchased_duration_name, dur.name) AS duration_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        LEFT JOIN product_keys pk ON o.key_id = pk.id
        LEFT JOIN categories c ON pk.category_id = c.id
        LEFT JOIN durations dur ON pk.duration_id = dur.id
        ORDER BY o.created_at DESC
        LIMIT 10
      `),
    ]);

    res.json({
      categories: parseInt(catRows.rows[0].total),
      durations: parseInt(durRows.rows[0].total),
      keys: {
        total_keys: parseInt(keyStats.rows[0].total_keys || 0),
        available_keys: parseInt(keyStats.rows[0].available_keys || 0),
        reserved_keys: parseInt(keyStats.rows[0].reserved_keys || 0),
        sold_keys: parseInt(keyStats.rows[0].sold_keys || 0),
      },
      orders: {
        total_orders: parseInt(orderStats.rows[0].total_orders || 0),
        pending_orders: parseInt(orderStats.rows[0].pending_orders || 0),
        awaiting_orders: parseInt(orderStats.rows[0].awaiting_orders || 0),
        paid_orders: parseInt(orderStats.rows[0].paid_orders || 0),
        cancelled_orders: parseInt(orderStats.rows[0].cancelled_orders || 0),
        total_revenue: parseFloat(orderStats.rows[0].total_revenue || 0),
      },
      sales: {
        today: { revenue: parseFloat(todaySales.rows[0].revenue), orders: parseInt(todaySales.rows[0].orders) },
        yesterday: { revenue: parseFloat(yesterdaySales.rows[0].revenue), orders: parseInt(yesterdaySales.rows[0].orders) },
        weekly: { revenue: parseFloat(weeklySales.rows[0].revenue), orders: parseInt(weeklySales.rows[0].orders) },
        monthly: { revenue: parseFloat(monthlySales.rows[0].revenue), orders: parseInt(monthlySales.rows[0].orders) },
      },
      chart: dailySalesChart.rows.map((r: any) => ({
        date: r.date,
        revenue: parseFloat(r.revenue),
        orders: parseInt(r.orders),
      })),
      users: parseInt(userRows.rows[0].total),
      resellers: parseInt(resellerRows.rows[0].total),
      paidUsers: parseInt(paidUserRows.rows[0].total),
      recentOrders: recentOrders.rows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) })),
      recentActivity: recentActivity.rows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) })),
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: 'Failed to load dashboard data' });
  }
});

export default router;
