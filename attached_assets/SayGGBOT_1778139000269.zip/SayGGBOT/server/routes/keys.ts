import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT
        COUNT(*) AS total_keys,
        SUM(CASE WHEN is_sold = 0 THEN 1 ELSE 0 END) AS available_keys,
        SUM(CASE WHEN is_sold = 2 THEN 1 ELSE 0 END) AS reserved_keys,
        SUM(CASE WHEN is_sold = 1 THEN 1 ELSE 0 END) AS sold_keys
      FROM product_keys
    `);
    const s = result.rows[0];
    res.json({ total_keys: parseInt(s.total_keys||0), available_keys: parseInt(s.available_keys||0), reserved_keys: parseInt(s.reserved_keys||0), sold_keys: parseInt(s.sold_keys||0) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load stats' });
  }
});

router.get('/', async (req: Request, res: Response) => {
  try {
    const { filter_category_id, filter_duration_id, filter_status, search, page = 1, limit = 50 } = req.query as Record<string, string>;
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;

    if (parseInt(filter_category_id) > 0) { where.push(`k.category_id = $${idx++}`); params.push(parseInt(filter_category_id)); }
    if (parseInt(filter_duration_id) > 0) { where.push(`k.duration_id = $${idx++}`); params.push(parseInt(filter_duration_id)); }
    if (filter_status === 'available') where.push('k.is_sold = 0');
    else if (filter_status === 'reserved') where.push('k.is_sold = 2');
    else if (filter_status === 'sold') where.push('k.is_sold = 1');
    if (search) { where.push(`k.key_value ILIKE $${idx++}`); params.push(`%${search}%`); }

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset = (Math.max(1, parseInt(page as string)) - 1) * parseInt(limit as string);

    const countResult = await pool.query(`SELECT COUNT(*) AS total FROM product_keys k ${whereClause}`, params);
    const total = parseInt(countResult.rows[0].total);

    const rows = await pool.query(`
      SELECT k.id, k.category_id, k.duration_id, k.key_value, k.is_sold, k.created_at,
        c.name AS category_name, d.name AS duration_name, d.price AS duration_price
      FROM product_keys k
      LEFT JOIN categories c ON k.category_id = c.id
      LEFT JOIN durations d ON k.duration_id = d.id
      ${whereClause}
      ORDER BY k.id DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `, [...params, parseInt(limit as string), offset]);

    const result = rows.rows.map((r: any) => ({
      ...r,
      categoryDisplayName: cleanEmojiName(r.category_name),
      durationDisplayName: cleanEmojiName(r.duration_name),
    }));
    res.json({ keys: result, total, page: parseInt(page as string), totalPages: Math.ceil(total / parseInt(limit as string)) });
  } catch (err) {
    console.error('Keys list error:', err);
    res.status(500).json({ error: 'Failed to load keys' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  try {
    const { category_id, duration_id, key_value, keys_bulk } = req.body;
    if (!category_id || !duration_id) return res.status(400).json({ error: 'Category and duration are required' });

    const validDur = await pool.query('SELECT id FROM durations WHERE id = $1 AND category_id = $2 LIMIT 1', [duration_id, category_id]);
    if (!validDur.rows.length) return res.status(400).json({ error: 'Invalid category-duration combination' });

    const inputKeys: string[] = [];
    if (keys_bulk) {
      keys_bulk.split(/\r\n|\r|\n/).forEach((line: string) => {
        const val = line.trim();
        if (val) inputKeys.push(val);
      });
    }
    if (key_value && key_value.trim()) inputKeys.push(key_value.trim());
    if (!inputKeys.length) return res.status(400).json({ error: 'At least one key is required' });

    const added: string[] = [];
    const duplicates: string[] = [];
    const seen = new Set<string>();

    for (const keyVal of inputKeys) {
      const lower = keyVal.toLowerCase();
      if (seen.has(lower)) { duplicates.push(`${keyVal} (duplicate in upload)`); continue; }
      seen.add(lower);

      const existing = await pool.query('SELECT id, is_sold FROM product_keys WHERE key_value = $1 LIMIT 1', [keyVal]);
      if (existing.rows.length) {
        const status = existing.rows[0].is_sold === 1 ? 'sold' : existing.rows[0].is_sold === 2 ? 'reserved' : 'available';
        duplicates.push(`${keyVal} (already exists, status: ${status})`);
        continue;
      }

      await pool.query('INSERT INTO product_keys (category_id, duration_id, key_value) VALUES ($1, $2, $3)', [category_id, duration_id, keyVal]);
      added.push(keyVal);
    }

    res.json({ added, duplicates, message: `${added.length} key(s) added, ${duplicates.length} skipped` });
  } catch (err) {
    console.error('Keys add error:', err);
    res.status(500).json({ error: 'Failed to add keys' });
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { category_id, duration_id, key_value, is_sold = 0 } = req.body;
    if (!category_id || !duration_id || !key_value) return res.status(400).json({ error: 'All fields required' });

    const validDur = await pool.query('SELECT id FROM durations WHERE id = $1 AND category_id = $2 LIMIT 1', [duration_id, category_id]);
    if (!validDur.rows.length) return res.status(400).json({ error: 'Invalid category-duration combination' });

    const dup = await pool.query('SELECT id FROM product_keys WHERE key_value = $1 AND id <> $2 LIMIT 1', [key_value.trim(), id]);
    if (dup.rows.length) return res.status(400).json({ error: 'Key value already exists' });

    const status = [0, 1, 2].includes(parseInt(is_sold)) ? parseInt(is_sold) : 0;
    await pool.query('UPDATE product_keys SET category_id = $1, duration_id = $2, key_value = $3, is_sold = $4 WHERE id = $5',
      [category_id, duration_id, key_value.trim(), status, id]);
    res.json({ message: 'Key updated successfully' });
  } catch (err) {
    console.error('Key update error:', err);
    res.status(500).json({ error: 'Failed to update key' });
  }
});

router.put('/:id/status', async (req: Request, res: Response) => {
  try {
    const status = parseInt(req.body.is_sold);
    if (![0, 1, 2].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    await pool.query('UPDATE product_keys SET is_sold = $1 WHERE id = $2', [status, req.params.id]);
    res.json({ message: 'Status updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update status' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    await pool.query('DELETE FROM product_keys WHERE id = $1', [req.params.id]);
    res.json({ message: 'Key deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete key' });
  }
});

export default router;
