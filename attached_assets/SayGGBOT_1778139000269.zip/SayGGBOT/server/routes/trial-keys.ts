import { Router, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { AuthenticatedRequest } from '../types';

const router = Router();
router.use(authMiddleware as any);

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

router.get('/stats', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        tk.category_id,
        COALESCE(c.name, tk.category_name_snapshot, 'Deleted Category (ID ' || tk.category_id || ')') AS category_name,
        CASE WHEN c.id IS NULL THEN true ELSE false END AS is_orphaned,
        tk.duration_hours,
        tk.max_devices,
        COUNT(*) AS total_keys,
        SUM(CASE WHEN tk.status = 'available' THEN 1 ELSE 0 END) AS available_keys,
        SUM(CASE WHEN tk.status = 'used' THEN 1 ELSE 0 END) AS used_keys,
        SUM(CASE WHEN tk.status = 'disabled' THEN 1 ELSE 0 END) AS disabled_keys
      FROM trial_keys tk
      LEFT JOIN categories c ON c.id = tk.category_id
      GROUP BY tk.category_id, c.id, c.name, tk.category_name_snapshot, tk.duration_hours, tk.max_devices
      ORDER BY COALESCE(c.name, tk.category_name_snapshot, ''), tk.duration_hours
    `);
    const result = rows.map((r: any) => ({
      ...r,
      categoryDisplayName: cleanEmojiName(r.category_name),
      is_orphaned: r.is_orphaned,
      total_keys: parseInt(r.total_keys || 0),
      available_keys: parseInt(r.available_keys || 0),
      used_keys: parseInt(r.used_keys || 0),
      disabled_keys: parseInt(r.disabled_keys || 0),
    }));
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { filter_category_id, filter_status, filter_duration_hours, filter_orphaned, search, page = '1', limit = '50' } = req.query as Record<string, string>;
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;

    if (parseInt(filter_category_id) > 0) { where.push(`tk.category_id = $${idx++}`); params.push(parseInt(filter_category_id)); }
    if (filter_status && ['available', 'used', 'disabled'].includes(filter_status)) { where.push(`tk.status = $${idx++}`); params.push(filter_status); }
    if (parseInt(filter_duration_hours) > 0) { where.push(`tk.duration_hours = $${idx++}`); params.push(parseInt(filter_duration_hours)); }
    if (filter_orphaned === 'true') { where.push(`NOT EXISTS (SELECT 1 FROM categories c2 WHERE c2.id = tk.category_id)`); }
    if (search) { where.push(`tk.key_value ILIKE $${idx++}`); params.push(`%${search}%`); }

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);

    const countResult = await pool.query(`SELECT COUNT(*) AS total FROM trial_keys tk ${whereClause}`, params);
    const total = parseInt(countResult.rows[0].total);

    const rows = await pool.query(`
      SELECT tk.*,
        COALESCE(c.name, tk.category_name_snapshot, 'Deleted Category (ID ' || tk.category_id || ')') AS category_name,
        CASE WHEN c.id IS NULL THEN true ELSE false END AS is_orphaned
      FROM trial_keys tk
      LEFT JOIN categories c ON tk.category_id = c.id
      ${whereClause}
      ORDER BY tk.id DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `, [...params, parseInt(limit), offset]);

    const result = rows.rows.map((r: any) => ({
      ...r,
      categoryDisplayName: cleanEmojiName(r.category_name),
      is_orphaned: r.is_orphaned,
    }));

    res.json({ keys: result, total, page: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)) });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/orphan-categories', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(`
      SELECT DISTINCT tk.category_id,
        COALESCE(tk.category_name_snapshot, 'Deleted Category (ID ' || tk.category_id || ')') AS category_name
      FROM trial_keys tk
      WHERE NOT EXISTS (SELECT 1 FROM categories c WHERE c.id = tk.category_id)
      ORDER BY tk.category_id
    `);
    res.json(rows.map((r: any) => ({ ...r, categoryDisplayName: cleanEmojiName(r.category_name), is_orphaned: true })));
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { category_id, duration_hours, max_devices, key_value, keys_bulk } = req.body;
    if (!category_id || !duration_hours) return res.status(400).json({ error: 'Category and duration hours are required' });

    const catCheck = await pool.query('SELECT id, name FROM categories WHERE id = $1', [category_id]);
    if (!catCheck.rows.length) return res.status(400).json({ error: 'Invalid category' });

    const catName = catCheck.rows[0].name;
    const dh = parseInt(duration_hours);
    const md = parseInt(max_devices) || 1;

    if (keys_bulk) {
      const lines = keys_bulk.split('\n').map((l: string) => l.trim()).filter((l: string) => l);
      if (!lines.length) return res.status(400).json({ error: 'No valid keys found in bulk input' });

      const uniqueKeys = [...new Set(lines)];
      const existing = await pool.query('SELECT key_value FROM trial_keys WHERE key_value = ANY($1)', [uniqueKeys]);
      const existingSet = new Set(existing.rows.map((r: any) => r.key_value));
      const toInsert = uniqueKeys.filter(k => !existingSet.has(k));

      let inserted = 0;
      for (const kv of toInsert) {
        await pool.query(
          'INSERT INTO trial_keys (category_id, category_name_snapshot, duration_hours, max_devices, key_value) VALUES ($1, $2, $3, $4, $5)',
          [category_id, catName, dh, md, kv]
        );
        inserted++;
      }
      return res.json({ inserted, duplicates: uniqueKeys.length - inserted, total: uniqueKeys.length });
    }

    if (!key_value) return res.status(400).json({ error: 'Key value is required' });

    const dupCheck = await pool.query('SELECT id FROM trial_keys WHERE key_value = $1', [key_value]);
    if (dupCheck.rows.length) return res.status(400).json({ error: 'Key already exists' });

    const { rows } = await pool.query(
      'INSERT INTO trial_keys (category_id, category_name_snapshot, duration_hours, max_devices, key_value) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [category_id, catName, dh, md, key_value]
    );
    res.json(rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.put('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    if (!status || !['available', 'used', 'disabled'].includes(status)) {
      return res.status(400).json({ error: 'Valid status required (available, used, disabled)' });
    }
    const { rows } = await pool.query(
      'UPDATE trial_keys SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
      [status, id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Trial key not found' });
    res.json(rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.delete('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query('DELETE FROM trial_keys WHERE id = $1 RETURNING id', [id]);
    if (!rows.length) return res.status(404).json({ error: 'Trial key not found' });
    res.json({ deleted: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.delete('/bulk/by-category', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { category_id, status_filter } = req.body;
    if (!category_id) return res.status(400).json({ error: 'category_id required' });
    let query = 'DELETE FROM trial_keys WHERE category_id = $1';
    const params: any[] = [parseInt(category_id)];
    if (status_filter && ['available', 'used', 'disabled'].includes(status_filter)) {
      query += ' AND status = $2';
      params.push(status_filter);
    }
    const result = await pool.query(query + ' RETURNING id', params);
    res.json({ deleted: result.rows.length });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.delete('/bulk/by-ids', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: 'ids array required' });
    const intIds = ids.map(Number).filter(n => n > 0);
    if (!intIds.length) return res.status(400).json({ error: 'No valid ids' });
    const result = await pool.query('DELETE FROM trial_keys WHERE id = ANY($1::int[]) RETURNING id', [intIds]);
    res.json({ deleted: result.rows.length });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
