import express, { Request, Response, NextFunction } from 'express';
import pool from '../db';
import { UserKeyRequest } from '../types';

const router = express.Router();

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

async function tokenAuth(req: UserKeyRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const token = ((req.query.token as string) || (req.headers['x-user-token'] as string) || '').trim();
    if (!token) { res.status(403).json({ error: 'Access denied' }); return; }
    const result = await pool.query('SELECT * FROM users WHERE token = $1 LIMIT 1', [token]);
    if (!result.rows.length) { res.status(403).json({ error: 'Invalid token' }); return; }
    req.userRow = result.rows[0];
    next();
  } catch (err) {
    console.error('Token auth error:', err);
    res.status(500).json({ error: 'Authentication failed' });
  }
}

router.use(tokenAuth);

router.get('/profile', (req: UserKeyRequest, res: Response) => {
  const u = req.userRow!;
  let displayName = ((u.first_name || '') + ' ' + (u.last_name || '')).trim();
  if (!displayName) displayName = u.username || ('User ' + u.telegram_id);
  res.json({
    displayName,
    telegramId: u.telegram_id,
    username: u.username,
    isReseller: !!u.reseller_id,
  });
});

router.get('/summary', async (req: UserKeyRequest, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT
        COUNT(*) AS total_keys,
        COUNT(DISTINCT order_id) AS total_orders,
        COUNT(DISTINCT category_name) AS total_categories,
        COUNT(DISTINCT duration_name) AS total_durations,
        COALESCE(SUM(amount), 0) AS total_amount,
        MAX(COALESCE(verified_at, purchased_at)) AS latest_purchase_at
      FROM purchased_keys_history WHERE user_id = $1
    `, [req.userRow!.id]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load summary' });
  }
});

router.get('/recent', async (req: UserKeyRequest, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT id, order_id, category_name, duration_name, key_value, amount, txn_ref,
        gateway_txn_id, gateway_bank_txn_id, verified_at, purchased_at
      FROM purchased_keys_history WHERE user_id = $1
      ORDER BY purchased_at DESC NULLS LAST, id DESC LIMIT 8
    `, [req.userRow!.id]);
    res.json(result.rows.map((r: any) => ({
      ...r,
      categoryDisplayName: cleanEmojiName(r.category_name),
      durationDisplayName: cleanEmojiName(r.duration_name),
    })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load recent activity' });
  }
});

router.get('/keys', async (req: UserKeyRequest, res: Response) => {
  try {
    const { key, order_id, category, duration, txn, date_from, date_to, sort = 'latest', page = '1' } = req.query as Record<string, string>;
    const perPage = 25;
    const offset = (Math.max(1, parseInt(page)) - 1) * perPage;
    const userId = req.userRow!.id;

    const where = ['user_id = $1'];
    const params: any[] = [userId];
    let idx = 2;

    if (key) { where.push(`key_value ILIKE $${idx++}`); params.push(`%${key}%`); }
    if (order_id) { where.push(`CAST(order_id AS TEXT) ILIKE $${idx++}`); params.push(`%${order_id}%`); }
    if (category) { where.push(`category_name ILIKE $${idx++}`); params.push(`%${category}%`); }
    if (duration) { where.push(`duration_name ILIKE $${idx++}`); params.push(`%${duration}%`); }
    if (txn) {
      where.push(`(txn_ref ILIKE $${idx} OR gateway_txn_id ILIKE $${idx} OR gateway_bank_txn_id ILIKE $${idx})`);
      params.push(`%${txn}%`);
      idx++;
    }
    if (date_from) { where.push(`COALESCE(verified_at, purchased_at)::date >= $${idx++}`); params.push(date_from); }
    if (date_to) { where.push(`COALESCE(verified_at, purchased_at)::date <= $${idx++}`); params.push(date_to); }

    const whereSql = 'WHERE ' + where.join(' AND ');
    let orderSql = 'ORDER BY purchased_at DESC NULLS LAST, id DESC';
    if (sort === 'oldest') orderSql = 'ORDER BY purchased_at ASC NULLS LAST, id ASC';
    else if (sort === 'amount_high') orderSql = 'ORDER BY amount DESC NULLS LAST, purchased_at DESC';
    else if (sort === 'amount_low') orderSql = 'ORDER BY amount ASC NULLS LAST, purchased_at DESC';

    const countResult = await pool.query(`SELECT COUNT(*) AS total FROM purchased_keys_history ${whereSql}`, params);
    const total = parseInt(countResult.rows[0].total);
    const totalPages = Math.max(1, Math.ceil(total / perPage));

    const result = await pool.query(`SELECT * FROM purchased_keys_history ${whereSql} ${orderSql} LIMIT $${idx++} OFFSET $${idx++}`,
      [...params, perPage, offset]);

    res.json({
      keys: result.rows.map((r: any) => ({
        ...r,
        categoryDisplayName: cleanEmojiName(r.category_name),
        durationDisplayName: cleanEmojiName(r.duration_name),
      })),
      total,
      page: parseInt(page),
      totalPages,
    });
  } catch (err) {
    console.error('User keys error:', err);
    res.status(500).json({ error: 'Failed to load keys' });
  }
});

router.get('/category-stats', async (req: UserKeyRequest, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT category_name, COUNT(*) AS total_keys, COUNT(DISTINCT order_id) AS total_orders,
        COALESCE(SUM(amount), 0) AS total_amount, MAX(COALESCE(verified_at, purchased_at)) AS latest_at
      FROM purchased_keys_history WHERE user_id = $1
      GROUP BY category_name ORDER BY total_keys DESC LIMIT 10
    `, [req.userRow!.id]);
    res.json(result.rows.map((r: any) => ({ ...r, displayName: cleanEmojiName(r.category_name) })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load stats' });
  }
});

export default router;
