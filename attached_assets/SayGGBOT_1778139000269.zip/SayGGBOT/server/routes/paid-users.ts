import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { tgPhotoProxyUrl } from './users';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

router.get('/summary', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT
        COUNT(*) AS total_purchases,
        COUNT(DISTINCT user_id) AS total_paid_users,
        SUM(CASE WHEN is_reseller_purchase = 1 THEN 1 ELSE 0 END) AS reseller_purchases,
        SUM(CASE WHEN is_reseller_purchase = 0 THEN 1 ELSE 0 END) AS customer_purchases,
        COALESCE(SUM(amount), 0) AS total_revenue
      FROM purchased_keys_history
    `);
    const s = result.rows[0];
    res.json({
      total_purchases: parseInt(s.total_purchases||0),
      total_paid_users: parseInt(s.total_paid_users||0),
      reseller_purchases: parseInt(s.reseller_purchases||0),
      customer_purchases: parseInt(s.customer_purchases||0),
      total_revenue: parseFloat(s.total_revenue||0),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load summary' });
  }
});

router.get('/profiles', async (req: Request, res: Response) => {
  try {
    const { search, duration_name, role } = req.query as Record<string, string>;
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;

    if (search) {
      where.push(`(
        CAST(p.user_id AS TEXT) ILIKE $${idx} OR CAST(p.telegram_id AS TEXT) ILIKE $${idx} OR
        p.username ILIKE $${idx} OR p.first_name ILIKE $${idx} OR p.last_name ILIKE $${idx} OR
        p.key_value ILIKE $${idx} OR p.category_name ILIKE $${idx} OR p.duration_name ILIKE $${idx} OR
        p.txn_ref ILIKE $${idx} OR p.gateway_txn_id ILIKE $${idx} OR p.gateway_bank_txn_id ILIKE $${idx}
      )`);
      params.push(`%${search}%`);
      idx++;
    }
    if (duration_name) { where.push(`p.duration_name = $${idx++}`); params.push(duration_name); }
    if (role === 'reseller') where.push('p.is_reseller_purchase = 1');
    else if (role === 'customer') where.push('p.is_reseller_purchase = 0');

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';

    const result = await pool.query(`
      SELECT
        p.user_id,
        MAX(p.telegram_id) AS telegram_id,
        MAX(p.username) AS username,
        MAX(p.first_name) AS first_name,
        MAX(p.last_name) AS last_name,
        MAX(p.is_reseller_purchase) AS is_reseller_purchase,
        COUNT(*) AS total_keys,
        COALESCE(SUM(p.amount), 0) AS total_spent,
        MAX(p.verified_at) AS last_purchase_at,
        MIN(p.verified_at) AS first_purchase_at,
        MAX(u.profile_photo_url) AS profile_photo_url
      FROM purchased_keys_history p
      LEFT JOIN users u ON u.id = p.user_id
      ${whereClause}
      GROUP BY p.user_id
      ORDER BY MAX(p.verified_at) DESC NULLS LAST, p.user_id DESC
    `, params);
    res.json(result.rows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) })));
  } catch (err) {
    console.error('Paid users profiles error:', err);
    res.status(500).json({ error: 'Failed to load profiles' });
  }
});

router.get('/profile/:userId', async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.params.userId);
    const profile = await pool.query(`
      SELECT
        p.user_id,
        MAX(p.telegram_id) AS telegram_id,
        MAX(p.username) AS username,
        MAX(p.first_name) AS first_name,
        MAX(p.last_name) AS last_name,
        MAX(p.is_reseller_purchase) AS is_reseller_purchase,
        COUNT(*) AS total_keys,
        COALESCE(SUM(p.amount), 0) AS total_spent,
        MAX(p.verified_at) AS last_purchase_at,
        MIN(p.verified_at) AS first_purchase_at,
        MAX(u.profile_photo_url) AS profile_photo_url
      FROM purchased_keys_history p
      LEFT JOIN users u ON u.id = p.user_id
      WHERE p.user_id = $1
      GROUP BY p.user_id
      LIMIT 1
    `, [userId]);

    if (!profile.rows.length) return res.status(404).json({ error: 'User not found' });

    const purchases = await pool.query(`
      SELECT * FROM purchased_keys_history
      WHERE user_id = $1
      ORDER BY verified_at DESC NULLS LAST, id DESC
    `, [userId]);

    const prof = { ...profile.rows[0], profile_photo_url: tgPhotoProxyUrl(profile.rows[0].profile_photo_url) };
    res.json({
      profile: prof,
      purchases: purchases.rows.map((p: any) => ({
        ...p,
        categoryDisplayName: cleanEmojiName(p.category_name),
        durationDisplayName: cleanEmojiName(p.duration_name),
      })),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load profile' });
  }
});

router.get('/recent', async (req: Request, res: Response) => {
  try {
    const { search, duration_name, role } = req.query as Record<string, string>;
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;

    if (duration_name) { where.push(`p.duration_name = $${idx++}`); params.push(duration_name); }
    if (role === 'reseller') where.push('p.is_reseller_purchase = 1');
    else if (role === 'customer') where.push('p.is_reseller_purchase = 0');
    if (search) {
      where.push(`(
        CAST(p.user_id AS TEXT) ILIKE $${idx} OR CAST(p.telegram_id AS TEXT) ILIKE $${idx} OR
        p.username ILIKE $${idx} OR p.first_name ILIKE $${idx} OR p.last_name ILIKE $${idx} OR
        p.key_value ILIKE $${idx} OR p.category_name ILIKE $${idx} OR p.duration_name ILIKE $${idx} OR
        p.txn_ref ILIKE $${idx} OR p.gateway_txn_id ILIKE $${idx} OR p.gateway_bank_txn_id ILIKE $${idx}
      )`);
      params.push(`%${search}%`);
      idx++;
    }

    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const result = await pool.query(`
      SELECT * FROM purchased_keys_history p
      ${whereClause}
      ORDER BY p.verified_at DESC NULLS LAST, p.id DESC LIMIT 50
    `, params);

    res.json(result.rows.map((r: any) => ({
      ...r,
      categoryDisplayName: cleanEmojiName(r.category_name),
      durationDisplayName: cleanEmojiName(r.duration_name),
    })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load recent activities' });
  }
});

router.get('/duration-filters', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT DISTINCT duration_name FROM purchased_keys_history
      WHERE duration_name IS NOT NULL AND duration_name <> ''
      ORDER BY duration_name ASC
    `);
    res.json(result.rows.map((r: any) => ({ raw: r.duration_name, display: cleanEmojiName(r.duration_name) })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load filters' });
  }
});

export default router;
