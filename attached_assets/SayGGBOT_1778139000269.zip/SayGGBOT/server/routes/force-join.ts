import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

async function ensureTable(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS force_join_channels (
      id SERIAL PRIMARY KEY,
      channel_identifier TEXT NOT NULL,
      channel_id BIGINT,
      channel_username TEXT,
      channel_title TEXT NOT NULL DEFAULT '',
      invite_link TEXT NOT NULL DEFAULT '',
      is_active BOOLEAN NOT NULL DEFAULT true,
      sort_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'pending',
      status_detail TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  const { rows: cols } = await pool.query(
    `SELECT column_name FROM information_schema.columns WHERE table_name = 'force_join_channels'`
  );
  const colSet = new Set(cols.map((c: any) => c.column_name));

  try {
    if (!colSet.has('channel_identifier') && colSet.has('channel_id')) {
      await pool.query(`ALTER TABLE force_join_channels RENAME COLUMN channel_id TO channel_identifier`);
      await pool.query(`ALTER TABLE force_join_channels ALTER COLUMN channel_identifier TYPE TEXT`);
      colSet.delete('channel_id');
      colSet.add('channel_identifier');
    }
  } catch (_) {}

  try {
    if (!colSet.has('channel_title') && colSet.has('channel_name')) {
      await pool.query(`ALTER TABLE force_join_channels RENAME COLUMN channel_name TO channel_title`);
      await pool.query(`ALTER TABLE force_join_channels ALTER COLUMN channel_title SET DEFAULT ''`);
      await pool.query(`UPDATE force_join_channels SET channel_title = '' WHERE channel_title IS NULL`);
      await pool.query(`ALTER TABLE force_join_channels ALTER COLUMN channel_title SET NOT NULL`);
      colSet.delete('channel_name');
      colSet.add('channel_title');
    }
  } catch (_) {}

  try {
    const { rows: idDefault } = await pool.query(
      `SELECT column_default FROM information_schema.columns WHERE table_name = 'force_join_channels' AND column_name = 'id'`
    );
    if (idDefault.length > 0 && !idDefault[0].column_default) {
      const seqName = 'force_join_channels_id_seq';
      await pool.query(`CREATE SEQUENCE IF NOT EXISTS ${seqName} OWNED BY force_join_channels.id`);
      const { rows: maxRow } = await pool.query(`SELECT COALESCE(MAX(id), 0) + 1 AS next_val FROM force_join_channels`);
      await pool.query(`SELECT setval('${seqName}', $1, false)`, [maxRow[0].next_val]);
      await pool.query(`ALTER TABLE force_join_channels ALTER COLUMN id SET DEFAULT nextval('${seqName}')`);
    }
  } catch (_) {}

  const addCols = [
    { name: 'sort_order', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS sort_order INTEGER NOT NULL DEFAULT 0` },
    { name: 'channel_id', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS channel_id BIGINT` },
    { name: 'channel_username', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS channel_username TEXT` },
    { name: 'status', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending'` },
    { name: 'status_detail', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS status_detail TEXT NOT NULL DEFAULT ''` },
    { name: 'channel_title', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS channel_title TEXT NOT NULL DEFAULT ''` },
    { name: 'invite_link', sql: `ALTER TABLE force_join_channels ADD COLUMN IF NOT EXISTS invite_link TEXT NOT NULL DEFAULT ''` },
  ];
  for (const col of addCols) {
    if (!colSet.has(col.name)) {
      try { await pool.query(col.sql); } catch (_) {}
    }
  }
}

let _tableEnsured = false;
async function ensureTableOnce(): Promise<void> {
  if (_tableEnsured) return;
  await ensureTable();
  _tableEnsured = true;
}

interface ParsedChat {
  chatId: string | null;
  isPrivateInvite: boolean;
  raw: string;
}

function parseChatIdentifier(raw: string | null): ParsedChat {
  const identifier = (raw || '').trim();
  if (!identifier) return { chatId: null, isPrivateInvite: false, raw: identifier };

  if (/^-?\d+$/.test(identifier)) {
    return { chatId: identifier, isPrivateInvite: false, raw: identifier };
  }

  if (/^https?:\/\/t\.me\/\+/.test(identifier) || /^https?:\/\/t\.me\/joinchat\//.test(identifier)) {
    return { chatId: null, isPrivateInvite: true, raw: identifier };
  }

  let username = identifier;
  if (username.startsWith('https://t.me/')) username = username.replace('https://t.me/', '');
  if (username.startsWith('http://t.me/')) username = username.replace('http://t.me/', '');
  username = username.replace(/^@/, '');
  username = username.split('/')[0].split('?')[0];
  if (username) return { chatId: '@' + username, isPrivateInvite: false, raw: identifier };

  return { chatId: null, isPrivateInvite: false, raw: identifier };
}

async function telegramApi(botToken: string, method: string, body: any): Promise<any> {
  const resp = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return resp.json();
}

router.get('/', async (req: Request, res: Response) => {
  try {
    await ensureTableOnce();
    const { rows: channels } = await pool.query(
      'SELECT * FROM force_join_channels ORDER BY sort_order ASC, id ASC'
    );
    const { rows: settingRows } = await pool.query(
      "SELECT value FROM bot_settings WHERE key = 'force_join_enabled' LIMIT 1"
    );
    const enabled = settingRows.length > 0 ? settingRows[0].value === '1' : false;
    res.json({ enabled, channels });
  } catch (err) {
    console.error('Force join load error:', err);
    res.status(500).json({ error: 'Failed to load force join settings' });
  }
});

router.put('/', async (req: Request, res: Response) => {
  try {
    await ensureTableOnce();
    const { enabled, channels } = req.body;

    await pool.query(
      `INSERT INTO bot_settings (key, value) VALUES ('force_join_enabled', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1`,
      [enabled ? '1' : '0']
    );

    const { rows: existing } = await pool.query('SELECT id FROM force_join_channels');
    const existingIds = new Set(existing.map((r: any) => r.id));
    const incomingIds = new Set<number>();

    for (let i = 0; i < channels.length; i++) {
      const ch = channels[i];
      const vals = {
        identifier: (ch.channel_identifier || '').trim(),
        title: (ch.channel_title || '').trim(),
        invite_link: (ch.invite_link || '').trim(),
        is_active: ch.is_active !== false,
        sort_order: i,
        channel_id: ch.channel_id || null,
        channel_username: ch.channel_username || null,
        status: ch.status || 'pending',
        status_detail: ch.status_detail || '',
      };

      if (!vals.identifier) continue;

      if (ch.id && existingIds.has(ch.id)) {
        incomingIds.add(ch.id);
        await pool.query(
          `UPDATE force_join_channels
           SET channel_identifier = $1, channel_title = $2, invite_link = $3,
               is_active = $4, sort_order = $5, channel_id = $6, channel_username = $7,
               status = $8, status_detail = $9
           WHERE id = $10`,
          [vals.identifier, vals.title, vals.invite_link, vals.is_active,
           vals.sort_order, vals.channel_id, vals.channel_username,
           vals.status, vals.status_detail, ch.id]
        );
      } else {
        const { rows } = await pool.query(
          `INSERT INTO force_join_channels
           (channel_identifier, channel_title, invite_link, is_active, sort_order, channel_id, channel_username, status, status_detail)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`,
          [vals.identifier, vals.title, vals.invite_link, vals.is_active,
           vals.sort_order, vals.channel_id, vals.channel_username,
           vals.status, vals.status_detail]
        );
        incomingIds.add(rows[0].id);
      }
    }

    for (const eid of existingIds) {
      if (!incomingIds.has(eid)) {
        await pool.query('DELETE FROM force_join_channels WHERE id = $1', [eid]);
      }
    }

    const { rows: finalChannels } = await pool.query(
      'SELECT * FROM force_join_channels ORDER BY sort_order ASC, id ASC'
    );
    res.json({ ok: true, enabled: !!enabled, channels: finalChannels });
  } catch (err) {
    console.error('Force join save error:', err);
    res.status(500).json({ error: 'Failed to save force join settings' });
  }
});

router.post('/validate', async (req: Request, res: Response) => {
  try {
    const { channels } = req.body;
    if (!channels || !Array.isArray(channels)) {
      return res.json({ results: [] });
    }

    const botToken = process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return res.json({
        results: channels.map(() => ({
          status: 'error',
          detail: 'Bot token not configured on server',
          status_code: 'no_token'
        }))
      });
    }

    const results: any[] = [];
    for (const ch of channels) {
      const parsed = parseChatIdentifier(ch.channel_identifier);

      if (!parsed.chatId && !parsed.isPrivateInvite) {
        results.push({
          status: 'error',
          detail: 'Empty or invalid identifier',
          status_code: 'invalid_identifier'
        });
        continue;
      }

      if (parsed.isPrivateInvite) {
        if (ch.channel_id) {
          parsed.chatId = String(ch.channel_id);
          parsed.isPrivateInvite = false;
        } else {
          results.push({
            status: 'warning',
            detail: 'Private invite link cannot be auto-resolved. Use the numeric channel ID (e.g. -1001234567890) for full functionality. Forward any message from the channel to @userinfobot to find it.',
            status_code: 'private_invite_link',
            channel_id: null,
            channel_username: null,
            channel_title: ch.channel_title || '',
            invite_link: parsed.raw
          });
          continue;
        }
      }

      try {
        const chatData = await telegramApi(botToken, 'getChat', { chat_id: parsed.chatId });

        if (!chatData.ok) {
          results.push({
            status: 'error',
            detail: chatData.description || 'Channel not found or bot has no access',
            status_code: 'channel_not_found'
          });
          continue;
        }

        const chat = chatData.result;
        const resolvedId = chat.id;
        const resolvedUsername = chat.username || null;
        const resolvedTitle = chat.title || ch.channel_title || '';

        const memberData = await telegramApi(botToken, 'getChatMember', {
          chat_id: resolvedId,
          user_id: parseInt(botToken.split(':')[0])
        });

        let botStatus = 'unknown';
        if (memberData.ok) {
          botStatus = memberData.result.status;
        }

        if (!['administrator', 'creator'].includes(botStatus)) {
          let statusCode = 'bot_not_admin';
          let detail = `Bot status: ${botStatus} \u2014 must be admin to verify membership`;
          if (botStatus === 'member') {
            detail = 'Bot is member but not admin \u2014 make the bot an administrator to verify membership';
            statusCode = 'bot_not_admin';
          }
          let fallbackLink = '';
          if (resolvedUsername) {
            fallbackLink = `https://t.me/${resolvedUsername}`;
          }
          results.push({
            status: 'error',
            detail,
            status_code: statusCode,
            channel_id: resolvedId,
            channel_username: resolvedUsername,
            channel_title: resolvedTitle,
            invite_link: fallbackLink
          });
          continue;
        }

        let generatedLink = '';
        let linkNote = '';
        let linkError = '';

        try {
          const inviteData = await telegramApi(botToken, 'createChatInviteLink', {
            chat_id: resolvedId,
            name: 'Force Join (auto-generated)',
            creates_join_request: false
          });
          if (inviteData.ok && inviteData.result && inviteData.result.invite_link) {
            generatedLink = inviteData.result.invite_link;
            linkNote = 'Fresh invite link generated';
          } else if (inviteData.description) {
            linkError = inviteData.description;
          }
        } catch (e: any) {
          linkError = e.message;
        }

        if (!generatedLink) {
          try {
            const exportData = await telegramApi(botToken, 'exportChatInviteLink', {
              chat_id: resolvedId
            });
            if (exportData.ok && exportData.result) {
              generatedLink = exportData.result;
              linkNote = 'Primary invite link exported';
              linkError = '';
            }
          } catch (e) {}
        }

        if (!generatedLink && resolvedUsername) {
          generatedLink = `https://t.me/${resolvedUsername}`;
          linkNote = 'Public link used (fallback)';
          linkError = '';
        }

        let statusCode = 'valid';
        let detail = `Bot is ${botStatus} \u2014 can verify membership`;

        if (!generatedLink && linkError) {
          statusCode = 'valid';
          detail += ` \u00B7 Link generation failed: ${linkError}. Grant the bot "Invite Users" admin right.`;
        } else if (linkNote) {
          detail += ` \u00B7 ${linkNote}`;
        }

        results.push({
          status: generatedLink ? 'ok' : 'warning',
          detail,
          status_code: statusCode,
          channel_id: resolvedId,
          channel_username: resolvedUsername,
          channel_title: resolvedTitle,
          invite_link: generatedLink
        });
      } catch (fetchErr: any) {
        results.push({
          status: 'error',
          detail: 'Failed to reach Telegram API: ' + fetchErr.message,
          status_code: 'api_error'
        });
      }
    }

    res.json({ results });
  } catch (err) {
    console.error('Force join validate error:', err);
    res.status(500).json({ error: 'Validation failed' });
  }
});

export default router;
