import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

async function bumpCacheVersion(): Promise<void> {
  try {
    await pool.query(
      `INSERT INTO bot_settings (key, value) VALUES ('_discount_cache_version', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1`,
      [Date.now().toString()]
    );
  } catch (err: any) {
    console.error('Failed to bump discount cache version:', err.message);
  }
}

router.get('/categories', async (req: Request, res: Response) => {
  try {
    const result = await pool.query('SELECT id, name FROM categories ORDER BY sort_order ASC, id ASC');
    res.json(result.rows.map((c: any) => ({ ...c, displayName: cleanEmojiName(c.name) })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load categories' });
  }
});

router.get('/durations', async (req: Request, res: Response) => {
  try {
    const result = await pool.query('SELECT id, category_id, name, price FROM durations ORDER BY category_id ASC, sort_order ASC, id ASC');
    res.json(result.rows.map((d: any) => ({ ...d, displayName: cleanEmojiName(d.name) })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load durations' });
  }
});

router.get('/broadcast/status/:queueId', async (req: Request, res: Response) => {
  try {
    const queueId = parseInt(req.params.queueId);
    const row = await pool.query('SELECT * FROM broadcast_queue WHERE id = $1', [queueId]);
    if (!row.rows.length) return res.status(404).json({ error: 'Broadcast not found' });
    res.json(row.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get broadcast status' });
  }
});

router.get('/', async (req: Request, res: Response) => {
  try {
    const plans = await pool.query('SELECT * FROM discount_plans WHERE COALESCE(is_campaign_generated, false) = false ORDER BY id DESC');
    const allRules = await pool.query(`
      SELECT dr.*, c.name AS category_name, d.name AS duration_name
      FROM discount_rules dr
      LEFT JOIN categories c ON dr.category_id = c.id
      LEFT JOIN durations d ON dr.duration_id = d.id
      ORDER BY dr.id ASC
    `);

    const rulesByPlan: Record<number, any[]> = {};
    allRules.rows.forEach((r: any) => {
      if (!rulesByPlan[r.plan_id]) rulesByPlan[r.plan_id] = [];
      rulesByPlan[r.plan_id].push({
        ...r,
        category_display: r.category_name ? cleanEmojiName(r.category_name) : null,
        duration_display: r.duration_name ? cleanEmojiName(r.duration_name) : null,
      });
    });

    const result = plans.rows.map((p: any) => ({
      ...p,
      rules: rulesByPlan[p.id] || [],
    }));

    res.json(result);
  } catch (err) {
    console.error('Discount plans load error:', err);
    res.status(500).json({ error: 'Failed to load discount plans' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { name, description, apply_scope, expires_at, rules, is_active } = req.body;

    await client.query('BEGIN');

    if (is_active) {
      await client.query("UPDATE discount_plans SET is_active = false WHERE is_active = true");
    }

    const planResult = await client.query(
      `INSERT INTO discount_plans (name, description, is_active, apply_scope, expires_at)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      [name || 'Untitled Offer', description || '', !!is_active, apply_scope || 'all_categories', expires_at || null]
    );
    const planId = planResult.rows[0].id;

    if (rules && Array.isArray(rules)) {
      for (const rule of rules) {
        await client.query(
          `INSERT INTO discount_rules (plan_id, category_id, duration_id, discount_type, discount_value, override_price)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            planId,
            rule.category_id || null,
            rule.duration_id || null,
            rule.discount_type || null,
            rule.discount_value != null ? rule.discount_value : null,
            rule.override_price != null ? rule.override_price : null,
          ]
        );
      }
    }

    await client.query('COMMIT');
    await bumpCacheVersion();
    res.json({ id: planId, message: 'Discount plan created' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Create discount plan error:', err);
    res.status(500).json({ error: 'Failed to create discount plan' });
  } finally {
    client.release();
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const planId = parseInt(req.params.id);
    const { name, description, apply_scope, expires_at, rules, is_active } = req.body;

    await client.query('BEGIN');

    if (is_active) {
      await client.query("UPDATE discount_plans SET is_active = false WHERE is_active = true AND id != $1", [planId]);
    }

    await client.query(
      `UPDATE discount_plans SET name = $1, description = $2, is_active = $3, apply_scope = $4, expires_at = $5, updated_at = NOW() WHERE id = $6`,
      [name || 'Untitled Offer', description || '', !!is_active, apply_scope || 'all_categories', expires_at || null, planId]
    );

    await client.query('DELETE FROM discount_rules WHERE plan_id = $1', [planId]);

    if (rules && Array.isArray(rules)) {
      for (const rule of rules) {
        await client.query(
          `INSERT INTO discount_rules (plan_id, category_id, duration_id, discount_type, discount_value, override_price)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            planId,
            rule.category_id || null,
            rule.duration_id || null,
            rule.discount_type || null,
            rule.discount_value != null ? rule.discount_value : null,
            rule.override_price != null ? rule.override_price : null,
          ]
        );
      }
    }

    await client.query('COMMIT');
    await bumpCacheVersion();
    res.json({ message: 'Discount plan updated' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Update discount plan error:', err);
    res.status(500).json({ error: 'Failed to update discount plan' });
  } finally {
    client.release();
  }
});

router.post('/:id/activate', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const planId = parseInt(req.params.id);
    await client.query('BEGIN');
    await client.query("UPDATE discount_plans SET is_active = false WHERE is_active = true");
    await client.query("UPDATE discount_plans SET is_active = true, updated_at = NOW() WHERE id = $1", [planId]);
    await client.query('COMMIT');
    await bumpCacheVersion();
    res.json({ message: 'Plan activated' });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to activate plan' });
  } finally {
    client.release();
  }
});

router.post('/:id/deactivate', async (req: Request, res: Response) => {
  try {
    await pool.query("UPDATE discount_plans SET is_active = false, updated_at = NOW() WHERE id = $1", [parseInt(req.params.id)]);
    await bumpCacheVersion();
    res.json({ message: 'Plan deactivated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to deactivate plan' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.id);
    const deleteMessages = req.query.delete_messages === 'true' || req.body?.delete_messages === true;

    if (deleteMessages) {
      try {
        await pool.query(
          `INSERT INTO broadcast_queue (plan_id, queue_type, status) VALUES ($1, 'delete_messages', 'pending')`,
          [planId]
        );
      } catch (qErr: any) {
        console.error('Failed to queue message deletion:', qErr.message);
      }
    }

    await pool.query('DELETE FROM discount_plans WHERE id = $1', [planId]);
    await bumpCacheVersion();
    res.json({ message: 'Discount plan deleted', messages_queued: deleteMessages });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete discount plan' });
  }
});

router.get('/logs', async (req: Request, res: Response) => {
  try {
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit as string) || 50));
    const offset = (page - 1) * limit;

    const planId = req.query.plan_id ? parseInt(req.query.plan_id as string) : null;
    const search = ((req.query.search as string) || '').trim();
    const dateFrom = ((req.query.date_from as string) || '').trim();
    const dateTo = ((req.query.date_to as string) || '').trim();
    const status = ((req.query.status as string) || '').trim();

    const validStatuses = ['paid', 'pending', 'expired'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status filter' });
    }
    if (dateFrom && isNaN(Date.parse(dateFrom))) {
      return res.status(400).json({ error: 'Invalid date_from value' });
    }
    if (dateTo && isNaN(Date.parse(dateTo))) {
      return res.status(400).json({ error: 'Invalid date_to value' });
    }

    let where = "WHERE o.pricing_source = 'user_discount'";
    const params: any[] = [];
    let idx = 1;

    if (planId) {
      where += ` AND o.applied_discount_plan_id = $${idx}`;
      params.push(planId);
      idx++;
    }
    if (status) {
      where += ` AND o.status = $${idx}`;
      params.push(status);
      idx++;
    }
    if (dateFrom) {
      where += ` AND o.created_at >= $${idx}::date`;
      params.push(dateFrom);
      idx++;
    }
    if (dateTo) {
      where += ` AND o.created_at < ($${idx}::date + interval '1 day')`;
      params.push(dateTo);
      idx++;
    }
    if (search) {
      where += ` AND (
        u.username ILIKE $${idx}
        OR u.first_name ILIKE $${idx}
        OR u.last_name ILIKE $${idx}
        OR o.txn_ref ILIKE $${idx}
        OR o.paid_utr ILIKE $${idx}
        OR o.gateway_txn_id ILIKE $${idx}
        OR o.gateway_bank_txn_id ILIKE $${idx}
        OR o.applied_discount_plan_name ILIKE $${idx}
        OR o.purchased_category_name ILIKE $${idx}
        OR o.purchased_duration_name ILIKE $${idx}
        OR CAST(o.id AS TEXT) = $${idx + 1}
      )`;
      params.push(`%${search}%`);
      params.push(search);
      idx += 2;
    }

    const countResult = await pool.query(
      `SELECT COUNT(*) as total FROM orders o JOIN users u ON u.id = o.user_id ${where}`,
      params
    );
    const total = parseInt(countResult.rows[0].total);

    const dataParams = [...params, limit, offset];
    const rows = await pool.query(
      `SELECT
        o.id AS order_id,
        o.status,
        o.txn_ref,
        o.amount AS final_amount,
        o.base_amount,
        o.pricing_source,
        o.applied_discount_plan_id,
        o.applied_discount_plan_name,
        o.paid_utr,
        o.paid_amount,
        o.gateway_txn_id,
        o.gateway_bank_txn_id,
        o.delivered_at,
        o.verified_at,
        o.created_at,
        o.purchased_category_name AS category_name,
        o.purchased_duration_name AS duration_name,
        u.telegram_id,
        u.username,
        u.first_name,
        u.last_name
      FROM orders o
      JOIN users u ON u.id = o.user_id
      ${where}
      ORDER BY o.created_at DESC, o.id DESC
      LIMIT $${idx} OFFSET $${idx + 1}`,
      dataParams
    );

    res.json({
      logs: rows.rows.map((r: any) => {
        const base = r.base_amount != null ? parseFloat(r.base_amount) : null;
        const final_amt = parseFloat(r.final_amount);
        return {
          ...r,
          category_display: r.category_name ? cleanEmojiName(r.category_name) : null,
          duration_display: r.duration_name ? cleanEmojiName(r.duration_name) : null,
          user_display: r.username ? `@${r.username}` : r.first_name || `ID:${r.telegram_id}`,
          savings: base != null ? (base - final_amt).toFixed(2) : null,
        };
      }),
      total,
      page,
      pages: Math.ceil(total / limit),
    });
  } catch (err) {
    console.error('Discount logs error:', err);
    res.status(500).json({ error: 'Failed to load discount logs' });
  }
});

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const stats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE pricing_source = 'user_discount' AND status = 'paid') AS discount_orders,
        COALESCE(SUM(amount) FILTER (WHERE pricing_source = 'user_discount' AND status = 'paid'), 0) AS discount_revenue,
        COALESCE(SUM(base_amount - amount) FILTER (WHERE pricing_source = 'user_discount' AND status = 'paid' AND base_amount IS NOT NULL), 0) AS total_savings,
        COUNT(*) FILTER (WHERE pricing_source = 'base' AND status = 'paid') AS base_orders,
        COALESCE(SUM(amount) FILTER (WHERE pricing_source = 'base' AND status = 'paid'), 0) AS base_revenue,
        COUNT(*) FILTER (WHERE pricing_source = 'reseller' AND status = 'paid') AS reseller_orders,
        COALESCE(SUM(amount) FILTER (WHERE pricing_source = 'reseller' AND status = 'paid'), 0) AS reseller_revenue,
        COALESCE(AVG(amount) FILTER (WHERE pricing_source = 'user_discount' AND status = 'paid'), 0) AS avg_discount_order,
        COUNT(DISTINCT applied_discount_plan_id) FILTER (WHERE pricing_source = 'user_discount' AND status = 'paid') AS unique_plans_used
      FROM orders
    `);

    const planStats = await pool.query(`
      SELECT
        applied_discount_plan_id AS plan_id,
        applied_discount_plan_name AS plan_name,
        COUNT(*) AS order_count,
        COALESCE(SUM(amount), 0) AS revenue,
        COALESCE(SUM(base_amount - amount) FILTER (WHERE base_amount IS NOT NULL), 0) AS savings
      FROM orders
      WHERE pricing_source = 'user_discount' AND status = 'paid' AND applied_discount_plan_id IS NOT NULL
      GROUP BY applied_discount_plan_id, applied_discount_plan_name
      ORDER BY order_count DESC
    `);

    let broadcastStats = { total_sends: 0, total_messages: 0, total_deletions: 0 };
    try {
      const bcStats = await pool.query(`
        SELECT
          COUNT(*) FILTER (WHERE queue_type = 'broadcast' OR queue_type IS NULL) AS total_sends,
          COUNT(*) FILTER (WHERE queue_type = 'delete_messages') AS total_deletions
        FROM broadcast_queue WHERE status = 'completed'
      `);
      const msgCount = await pool.query(`SELECT COUNT(*) AS cnt FROM discount_broadcast_messages`);
      broadcastStats = {
        total_sends: parseInt(bcStats.rows[0]?.total_sends || '0'),
        total_messages: parseInt(msgCount.rows[0]?.cnt || '0'),
        total_deletions: parseInt(bcStats.rows[0]?.total_deletions || '0'),
      };
    } catch {}

    res.json({
      overview: stats.rows[0],
      by_plan: planStats.rows,
      broadcast: broadcastStats,
    });
  } catch (err) {
    console.error('Discount stats error:', err);
    res.status(500).json({ error: 'Failed to load stats' });
  }
});

router.post('/preview', async (req: Request, res: Response) => {
  try {
    const { apply_scope, rules } = req.body;
    if (!rules || !Array.isArray(rules)) {
      return res.json({ preview: [] });
    }

    const durations = await pool.query(`
      SELECT d.id AS duration_id, d.name AS duration_name, d.price AS base_price,
             d.category_id, c.name AS category_name
      FROM durations d
      JOIN categories c ON c.id = d.category_id
      WHERE d.is_hidden = 0 AND c.is_hidden = 0
      ORDER BY c.sort_order ASC, d.sort_order ASC
    `);

    const preview = durations.rows.map((dur: any) => {
      let matchedRule: any = null;

      if (apply_scope === 'all_categories') {
        matchedRule = rules.find((r: any) => !r.category_id && !r.duration_id)
          || rules.find((r: any) => !r.category_id && r.duration_id === dur.duration_id);
      } else if (apply_scope === 'one_category') {
        const targetCat = rules.find((r: any) => r.category_id)?.category_id;
        if (targetCat && targetCat === dur.category_id) {
          matchedRule = rules.find((r: any) => r.duration_id === dur.duration_id)
            || rules.find((r: any) => !r.duration_id);
        }
      } else if (apply_scope === 'per_categories') {
        matchedRule = rules.find((r: any) => r.category_id === dur.category_id && r.duration_id === dur.duration_id)
          || rules.find((r: any) => r.category_id === dur.category_id && !r.duration_id);
      } else if (apply_scope === 'per_category_duration_prices') {
        matchedRule = rules.find((r: any) => r.category_id === dur.category_id && r.duration_id === dur.duration_id)
          || rules.find((r: any) => r.category_id === dur.category_id && !r.duration_id)
          || rules.find((r: any) => !r.category_id && !r.duration_id);
      }

      let finalPrice = parseFloat(dur.base_price);
      if (matchedRule) {
        if (matchedRule.override_price != null) {
          finalPrice = parseFloat(matchedRule.override_price);
        } else if (matchedRule.discount_type === 'percent') {
          finalPrice = finalPrice - (finalPrice * parseFloat(matchedRule.discount_value || 0) / 100);
        } else if (matchedRule.discount_type === 'fixed') {
          finalPrice = finalPrice - parseFloat(matchedRule.discount_value || 0);
        }
        finalPrice = Math.max(0, finalPrice);
      }

      return {
        category: cleanEmojiName(dur.category_name),
        duration: cleanEmojiName(dur.duration_name),
        base_price: parseFloat(dur.base_price),
        final_price: parseFloat(finalPrice.toFixed(2)),
        has_discount: matchedRule != null,
      };
    });

    res.json({ preview });
  } catch (err) {
    console.error('Discount preview error:', err);
    res.status(500).json({ error: 'Failed to generate preview' });
  }
});

router.get('/:id/broadcast-template', async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.id);
    const plan = await pool.query('SELECT id, name, description, broadcast_template, expires_at FROM discount_plans WHERE id = $1', [planId]);
    if (!plan.rows.length) return res.status(404).json({ error: 'Plan not found' });

    const settingsResult = await pool.query("SELECT key, value FROM bot_settings WHERE key LIKE 'tpl_discount_broadcast%' OR key LIKE 'discount_broadcast%' OR key LIKE 'msg_broadcast%'");
    const defaults: Record<string, string> = {};
    settingsResult.rows.forEach((r: any) => { defaults[r.key] = r.value; });

    res.json({
      plan: plan.rows[0],
      global_defaults: defaults,
    });
  } catch (err) {
    console.error('Get broadcast template error:', err);
    res.status(500).json({ error: 'Failed to load broadcast template' });
  }
});

router.put('/:id/broadcast-template', async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.id);
    const { broadcast_template } = req.body;
    await pool.query(
      'UPDATE discount_plans SET broadcast_template = $1, updated_at = NOW() WHERE id = $2',
      [broadcast_template || '', planId]
    );
    res.json({ message: 'Broadcast template saved' });
  } catch (err) {
    console.error('Save broadcast template error:', err);
    res.status(500).json({ error: 'Failed to save broadcast template' });
  }
});

router.post('/:id/broadcast/preview', async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.id);
    const { template_override } = req.body;

    const plan = await pool.query('SELECT * FROM discount_plans WHERE id = $1', [planId]);
    if (!plan.rows.length) return res.status(404).json({ error: 'Plan not found' });
    const p = plan.rows[0];

    const rules = await pool.query('SELECT * FROM discount_rules WHERE plan_id = $1 ORDER BY id ASC', [planId]);

    const durations = await pool.query(`
      SELECT d.id AS duration_id, d.name AS duration_name, d.price AS base_price,
             d.category_id, c.name AS category_name
      FROM durations d
      JOIN categories c ON c.id = d.category_id
      WHERE d.is_hidden = 0 AND c.is_hidden = 0
      ORDER BY c.sort_order ASC, d.sort_order ASC
    `);

    const examples: any[] = [];
    for (const dur of durations.rows) {
      let matchedRule: any = null;
      const basePrice = parseFloat(dur.base_price);
      const catId = dur.category_id;
      const durId = dur.duration_id;
      const scope = p.apply_scope;

      if (scope === 'all_categories') {
        matchedRule = rules.rows.find((r: any) => !r.category_id && !r.duration_id)
          || rules.rows.find((r: any) => !r.category_id && r.duration_id === durId);
      } else if (scope === 'one_category') {
        const targetCat = rules.rows.find((r: any) => r.category_id)?.category_id;
        if (targetCat && targetCat === catId) {
          matchedRule = rules.rows.find((r: any) => r.duration_id === durId)
            || rules.rows.find((r: any) => !r.duration_id);
        }
      } else if (scope === 'per_categories') {
        matchedRule = rules.rows.find((r: any) => r.category_id === catId && r.duration_id === durId)
          || rules.rows.find((r: any) => r.category_id === catId && !r.duration_id);
      } else if (scope === 'per_category_duration_prices') {
        matchedRule = rules.rows.find((r: any) => r.category_id === catId && r.duration_id === durId)
          || rules.rows.find((r: any) => r.category_id === catId && !r.duration_id)
          || rules.rows.find((r: any) => !r.category_id && !r.duration_id);
      }

      if (!matchedRule) continue;

      let finalPrice = basePrice;
      if (matchedRule.override_price != null) {
        finalPrice = parseFloat(matchedRule.override_price);
      } else if (matchedRule.discount_type === 'percent') {
        finalPrice = basePrice - (basePrice * parseFloat(matchedRule.discount_value || 0) / 100);
      } else if (matchedRule.discount_type === 'fixed') {
        finalPrice = basePrice - parseFloat(matchedRule.discount_value || 0);
      }
      finalPrice = Math.max(0, finalPrice);

      if (finalPrice === basePrice) continue;

      examples.push({
        category: cleanEmojiName(dur.category_name),
        duration: cleanEmojiName(dur.duration_name),
        base_price: basePrice,
        final_price: parseFloat(finalPrice.toFixed(2)),
      });

      if (examples.length >= 6) break;
    }

    const settingsResult = await pool.query("SELECT key, value FROM bot_settings");
    const settings: Record<string, string> = {};
    settingsResult.rows.forEach((r: any) => { settings[r.key] = r.value; });

    const getSetting = (key: string): string => settings[key] || '';
    const currency = getSetting('currency_symbol') || '\u20B9';

    let examplesText = examples.map(e => {
      const savings = (e.base_price - e.final_price).toFixed(2);
      return (
        `\u2022 <b>${e.category}</b> \u00b7 ${e.duration}\n` +
        `   Original: <s>${currency}${e.base_price.toFixed(2)}</s>\n` +
        `   Now: <b>${currency}${e.final_price.toFixed(2)}</b>   <i>(You save ${currency}${savings})</i>`
      );
    }).join('\n\n') || 'Discounted prices are now available!';

    let expiryTime = 'No expiry set';
    if (p.expires_at) {
      try {
        const d = new Date(p.expires_at);
        expiryTime = d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Kolkata' });
      } catch { expiryTime = String(p.expires_at); }
    }

    const brandName = process.env.BRAND_NAME || process.env.SITE_NAME || 'KeyStore';
    const now = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Kolkata' });

    const vals: Record<string, string> = {
      plan_name: p.name || '',
      description: p.description || '',
      pricing_examples: examplesText,
      expiry_time: expiryTime,
      brand: brandName,
      current_time: now,
      first_name: 'User',
    };

    const safeFormat = (tpl: string, v: Record<string, string>): string => {
      let result = tpl || '';
      for (const [k, val] of Object.entries(v)) {
        result = result.split(`{${k}}`).join(val || '');
      }
      return result;
    };

    let messageText: string;
    if (template_override && template_override.trim()) {
      messageText = safeFormat(template_override, vals);
    } else {
      const planTpl = (p.broadcast_template || '').trim();
      if (planTpl) {
        messageText = safeFormat(planTpl, vals);
      } else {
        const defaultTitle = getSetting('tpl_discount_broadcast_title') || '\uD83D\uDCE2 <b>{plan_name} \u2014 Limited Offer</b>';
        const defaultBody = getSetting('tpl_discount_broadcast_body') ||
          'Hi <b>{first_name}</b> \uD83D\uDC4B\n\n{description}\n\n\uD83D\uDCB0 <b>Discounted Prices</b>\n\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n{pricing_examples}\n\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n\n\u23F0 <b>Offer ends:</b> {expiry_time}';
        const defaultFooter = getSetting('tpl_discount_broadcast_footer') || 'Open the store now and claim your deal \u2193';
        messageText = `${safeFormat(defaultTitle, vals)}\n\n${safeFormat(defaultBody, vals)}\n${safeFormat(defaultFooter, vals)}`;
      }
    }

    let buttonsConfig: any[] = [];
    try {
      const btnJson = getSetting('discount_broadcast_buttons') || '[]';
      buttonsConfig = JSON.parse(btnJson);
    } catch { buttonsConfig = []; }

    const userCount = await pool.query("SELECT COUNT(*) as cnt FROM users WHERE (reseller_id IS NULL OR reseller_id = 0) AND is_banned = 0");

    res.json({
      preview_text: messageText,
      examples,
      buttons: buttonsConfig,
      target_user_count: parseInt(userCount.rows[0].cnt),
      plan_name: p.name,
    });
  } catch (err) {
    console.error('Broadcast preview error:', err);
    res.status(500).json({ error: 'Failed to generate broadcast preview' });
  }
});

router.post('/:id/broadcast/send', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const planId = parseInt(req.params.id);
    const { template_override } = req.body;

    const plan = await client.query('SELECT id, name FROM discount_plans WHERE id = $1', [planId]);
    if (!plan.rows.length) {
      client.release();
      return res.status(404).json({ error: 'Plan not found' });
    }

    await client.query('BEGIN');
    const pending = await client.query("SELECT id FROM broadcast_queue WHERE status IN ('pending', 'sending') FOR UPDATE");
    if (pending.rows.length > 0) {
      await client.query('ROLLBACK');
      client.release();
      return res.status(409).json({ error: 'A broadcast is already in progress. Please wait for it to complete.' });
    }

    const result = await client.query(
      "INSERT INTO broadcast_queue (plan_id, template_override, status) VALUES ($1, $2, 'pending') RETURNING id",
      [planId, template_override || '']
    );
    await client.query('COMMIT');

    res.json({
      message: 'Broadcast queued successfully',
      queue_id: result.rows[0].id,
      plan_name: plan.rows[0].name,
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('Broadcast send error:', err);
    res.status(500).json({ error: 'Failed to queue broadcast' });
  } finally {
    client.release();
  }
});

router.get('/:id/broadcasts', async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.id);
    const rows = await pool.query(
      `SELECT bq.id, bq.status, bq.result, bq.created_at, bq.completed_at,
              bq.queue_type,
              (SELECT COUNT(*) FROM discount_broadcast_messages dbm WHERE dbm.queue_id = bq.id) AS message_count
       FROM broadcast_queue bq
       WHERE bq.plan_id = $1 AND (bq.queue_type = 'broadcast' OR bq.queue_type IS NULL)
       ORDER BY bq.id DESC
       LIMIT 50`,
      [planId]
    );
    res.json(rows.rows);
  } catch (err) {
    console.error('Plan broadcasts error:', err);
    res.status(500).json({ error: 'Failed to load broadcasts' });
  }
});

router.post('/broadcasts/:queueId/delete-messages', async (req: Request, res: Response) => {
  try {
    const queueId = parseInt(req.params.queueId);
    const orig = await pool.query('SELECT plan_id FROM broadcast_queue WHERE id = $1', [queueId]);
    if (!orig.rows.length) return res.status(404).json({ error: 'Broadcast not found' });
    const planId = orig.rows[0].plan_id;

    const result = await pool.query(
      `INSERT INTO broadcast_queue (plan_id, queue_type, delete_target_queue_id, status)
       VALUES ($1, 'delete_messages', $2, 'pending') RETURNING id`,
      [planId, queueId]
    );
    res.json({ queue_id: result.rows[0].id, message: 'Message deletion queued' });
  } catch (err) {
    console.error('Delete broadcast messages error:', err);
    res.status(500).json({ error: 'Failed to queue message deletion' });
  }
});

router.post('/broadcasts/plan/:planId/delete-messages', async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.planId);
    const result = await pool.query(
      `INSERT INTO broadcast_queue (plan_id, queue_type, status)
       VALUES ($1, 'delete_messages', 'pending') RETURNING id`,
      [planId]
    );
    res.json({ queue_id: result.rows[0].id, message: 'Plan message deletion queued' });
  } catch (err) {
    console.error('Delete plan messages error:', err);
    res.status(500).json({ error: 'Failed to queue plan message deletion' });
  }
});

router.get('/settings/templates', async (req: Request, res: Response) => {
  try {
    const keys = [
      'tpl_discount_broadcast_title', 'tpl_discount_broadcast_body', 'tpl_discount_broadcast_footer',
      'discount_broadcast_buttons', 'discount_broadcast_send_categories',
      'discount_offer_ended_title', 'discount_offer_ended_body',
      'broadcast_pin_message',
      'msg_broadcast_progress', 'msg_broadcast_complete', 'msg_broadcast_error',
    ];
    const result = await pool.query(
      `SELECT key, value FROM bot_settings WHERE key = ANY($1)`,
      [keys]
    );
    const settings: Record<string, string> = {};
    result.rows.forEach((r: any) => { settings[r.key] = r.value; });
    res.json(settings);
  } catch (err) {
    console.error('Get template settings error:', err);
    res.status(500).json({ error: 'Failed to load settings' });
  }
});

router.put('/settings/templates', async (req: Request, res: Response) => {
  try {
    const updates = req.body;
    const allowed = [
      'tpl_discount_broadcast_title', 'tpl_discount_broadcast_body', 'tpl_discount_broadcast_footer',
      'discount_broadcast_buttons', 'discount_broadcast_send_categories',
      'discount_offer_ended_title', 'discount_offer_ended_body',
      'broadcast_pin_message',
      'msg_broadcast_progress', 'msg_broadcast_complete', 'msg_broadcast_error',
    ];
    for (const [key, value] of Object.entries(updates)) {
      if (!allowed.includes(key)) continue;
      await pool.query(
        `INSERT INTO bot_settings (key, value) VALUES ($1, $2)
         ON CONFLICT (key) DO UPDATE SET value = $2`,
        [key, String(value)]
      );
    }
    await bumpCacheVersion();
    res.json({ message: 'Template settings updated' });
  } catch (err) {
    console.error('Update template settings error:', err);
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

export default router;
