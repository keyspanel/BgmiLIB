import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

const SETTING_DEFAULTS: Record<string, string> = {
  bot_welcome_msg: 'Welcome to {brand}.',
  bot_welcome_instruction: 'Use the menu below to browse categories and purchase keys.',
  bot_store_title: '{brand} \u2014 Digital Key Store',
  bot_store_subtitle: 'Choose a category below to browse available products.',
  bot_store_empty: 'There are no active categories available right now. Please check again later.',
  bot_btn_my_keys: '\uD83D\uDCE6 My Purchased Keys',
  bot_btn_how_to: '\uD83D\uDED2 How to Purchase?',
  bot_btn_categories: '\uD83C\uDFE0 Categories Menu',
  bot_btn_verify: '\u2705 Verify Payment',
  bot_btn_copy_key: '\uD83D\uDCCB Copy Key',
  bot_btn_manage_keys: '\uD83D\uDDC2 Manage Keys',
  bot_how_to_text: '<b>\uD83D\uDED2 How to Purchase</b>\n\n1) Tap <b>/start</b>\n2) Select a <b>Category</b>\n3) Choose a <b>Duration</b>\n4) Pay using the <b>QR / UPI</b>\n5) Tap <b>Verify Payment</b>\n\n\u2705 After verification, your key will be delivered instantly.',
  bot_payment_success: 'Thank you for your purchase.',
  bot_admin_sale_title: '\uD83D\uDD14 <b>New Sale</b>',
  bot_keys_title: '\uD83D\uDCE6 <b>Your Purchased Keys</b>',
  bot_keys_reseller_title: '\uD83D\uDCE6 <b>Reseller Purchased Keys</b>',
  bot_keys_empty: "You don't have any delivered keys yet.",
  order_timeout_minutes: '15',
  currency_symbol: '\u20B9',
  start_preview_url: '',
  payment_label_name: '',
  reply_mykeys_style: '',
  reply_howto_style: '',
  reply_mykeys_emoji_id: '',
  reply_howto_emoji_id: '',
  categories_btn_style: '',
  categories_btn_emoji_id: '',
  verify_btn_style: '',
  verify_btn_emoji_id: '',
  copy_key_btn_style: '',
  copy_key_btn_emoji_id: '',
  manage_keys_btn_style: '',
  manage_keys_btn_emoji_id: '',

  msg_banned: '\uD83D\uDEAB You are banned from using this service.',
  msg_store_unavailable_title: '\uD83D\uDED2 <b>Store Currently Unavailable</b>',
  msg_select_duration_title: '\u23F1\uFE0F <b>Select Duration</b>',
  msg_select_duration_sub: 'Select a duration below:',
  msg_discount_duration_banner: '\uD83D\uDD25 <b>{plan_name}</b> \u2014 Special prices applied!',

  tpl_payment_caption: '\uD83E\uDDFE <b>Payment Invoice</b>\n\n<b>Category:</b>  {category}\n<b>Duration:</b>  {duration}\n<b>Amount:</b>  {currency}{amount}\n<b>Order ID:</b>  <code>{order_id}</code>\n<b>Ref:</b>  <code>{txn_ref}</code>\n\n\uD83D\uDD50 <b>Created:</b>  {created_time}\n\u23F3 <b>Expires:</b>  {expiry_time}\n\nScan the QR code or use UPI ID <code>{upi_id}</code> to complete payment.\n\nAfter payment, tap <b>{verify_btn}</b> below to verify.\nOnce verified, your key will be delivered instantly.',
  tpl_reseller_caption: '\uD83E\uDDFE <b>Payment \u2014 Reseller Order</b>\n\n<b>Category:</b>  {category}\n<b>Duration:</b>  {duration}\n<b>Base Price:</b>  {currency}{base_amount}\n<b>Your Price:</b>  {currency}{amount}\n<b>Order ID:</b>  <code>{order_id}</code>\n<b>Ref:</b>  <code>{txn_ref}</code>\n\n\uD83D\uDD50 <b>Created:</b>  {created_time}\n\u23F3 <b>Expires:</b>  {expiry_time}\n\nScan the QR code or use UPI ID <code>{upi_id}</code> to complete payment.\n\nAfter payment, tap <b>{verify_btn}</b> below to confirm instantly.',
  msg_no_keys_available: '\uD83D\uDEAB Sorry, no keys available for this category and duration.',
  msg_key_taken: '\u26A0\uFE0F This key was just taken. Please try again.',
  msg_upi_not_configured: '\u26A0\uFE0F UPI ID is not configured. Please contact the administrator.',
  msg_payment_qr_failed: '\u26A0\uFE0F Failed to send payment QR. Please try again.',
  msg_invalid_cat_dur: '\u274C Invalid category or duration.',

  msg_verify_not_received: 'Hey {first_name}, payment was not received yet. I only verify completed gateway payments. Please pay the QR first, then tap Verify Payment.',
  msg_inactive_verify_btn: 'This verify button is no longer active. Please use the latest payment QR only.',
  msg_order_not_found: '\u274C <b>Order not found</b>\n\nPlease create a new order.',
  msg_order_not_yours: '\u26D4 <b>This order does not belong to you.</b>',
  msg_already_paid: '\u2705 Payment already verified.',
  msg_order_expired: '\u231B <b>This order has expired.</b>\n\nPlease create a new order.',
  msg_order_inactive: '\u2139\uFE0F <b>This order is not active anymore.</b>',
  msg_verify_error: '\u26A0\uFE0F <b>Payment verification encountered an error.</b>\n\nPlease try again in a moment.',
  msg_verify_failed_title: '\u26A0\uFE0F <b>Payment Verification Failed</b>',
  msg_payment_not_received_title: '\u274C <b>Payment Not Received</b>',
  msg_verify_generic_error: '\u26A0\uFE0F <b>Something went wrong during verification.</b>\n\nPlease try again.',
  msg_fulfillment_pending: '\u2705 Payment verified! Your key is being processed.\nThe admin has been notified and your key will be delivered shortly.',

  msg_payment_not_found: 'No payment was found for this order. Please complete the payment first, then tap Verify.',
  msg_payment_pending: 'Your payment is still being processed. Please wait a moment and try again.',
  msg_payment_failed: 'Payment was not successful. Please try again with a new order.',
  msg_amount_mismatch: 'Payment amount does not match the order. Please contact support.',
  msg_verification_issue: 'Payment could not be verified at this time. Please try again.',
  msg_gateway_error: 'Payment verification is temporarily unavailable. Please try again shortly.',

  msg_payment_verified_title: '\u2705 <b>Payment Verified Successfully</b>',
  tpl_success_body: '{verified_title}\n\n<b>Category:</b>  {category}\n<b>Duration:</b>  {duration}\n<b>Order ID:</b>  <code>{order_id}</code>\n\n{key_label}\n<code>{key}</code>\n\n{apk_notice}\n\n{footer}',
  msg_key_label: '\uD83D\uDD11 <b>Your Key:</b>',
  msg_apk_caption: '\uD83D\uDCF2 <b>Application for {category}</b>\n\nInstall this app and use your key below to activate.',
  msg_apk_notice: '\uD83D\uDCF2 The application file has been sent above. Install it and use your key to activate.',
  delivery_link_buttons: '',
  duration_link_buttons: '',
  tpl_admin_sale: '{admin_sale_title}\nOrder #{order_id}\nUser: {buyer_label}\nCategory: {category}\nDuration: {duration}\nAmount: {currency}{amount}',

  msg_order_expired_notice: '\u23F3 <b>Order Expired</b>\n\nYour previous order has expired as payment was not completed in time.\n\nTo continue, browse our categories and place a new order whenever you\'re ready.',

  cb_banned: '\uD83D\uDEAB You are banned from using this service.',
  cb_category_unavailable: '\u274C This category is no longer available.',
  cb_no_durations: '\u274C No durations available in this category.',
  cb_category_error: '\u274C Unable to open this category.',
  cb_generating_qr: 'Generating payment QR...',
  cb_unknown_action: 'Unknown action.',
  cb_order_not_found: 'Order not found.',
  cb_order_not_yours: 'This order does not belong to you.',
  cb_already_paid: 'Payment already verified.',
  cb_order_expired: 'This order has expired.',
  cb_order_inactive: 'This order is not active anymore.',
  cb_verify_error: 'Verification error. Please try again.',

  msg_reseller_prompt: '\uD83D\uDD10 <b>Reseller Access Activation</b>\n\nSend your <b>6-digit reseller code</b> below to activate reseller pricing.\n\n\uD83D\uDCA1 Only a valid reseller code will activate special pricing.\nAfter activation, your reseller prices will appear automatically in the duration buttons.\n\n<i>Send /cancel to exit.</i>',
  msg_invalid_code_format: '\u274C <b>Invalid Code Format</b>\n\nReseller codes are exactly <b>6 digits</b>.\nPlease check your code and try again.\n\n<i>Send /cancel to exit.</i>',
  msg_reseller_cancelled: '\u2716 Reseller code activation cancelled.',
  msg_reseller_invalid_code: '\u274C <b>Invalid Reseller Code</b>\n\nThe code you entered is not valid. Please check and try again.',
  msg_reseller_code_expired: '\u274C <b>Code Expired</b>\n\nThis reseller code is no longer active.',
  msg_reseller_usage_limit: '\u274C <b>Usage Limit Reached</b>\n\nThis reseller code has already reached its maximum allowed users.',
  msg_reseller_already_active_title: '\u2705 <b>Reseller Access Already Active</b>',
  msg_reseller_activation_failed: '\u26A0\uFE0F <b>Activation Failed</b>\n\nSomething went wrong while activating your code. Please try again.',
  msg_reseller_activated_title: '\uD83C\uDF89 <b>Reseller Access Activated Successfully</b>',
  msg_reseller_activated_footer: '\u2705 You will now see your reseller prices automatically inside the category duration buttons.',
  msg_no_keys_found_title: '\uD83D\uDCE6 <b>No Purchased Keys Found</b>',
  msg_keys_load_error: 'Unable to load your keys right now. Please try again.',
  msg_reference_label: 'Reference',
  msg_reseller_switched_label: 'Previous Code Replaced',
  btn_prev_page: '\u2B05\uFE0F Previous',
  btn_next_page: 'Next \u27A1\uFE0F',
  msg_categories_footer: '\uD83D\uDC47 <b>Select a category to continue</b>',

  tpl_keys_item: '<b>Key {index} of {total}</b>\n<b>Order ID:</b> <code>{order_id}</code>\n<b>Category:</b> {category}\n<b>Duration:</b> {duration}\n<b>Amount:</b> {currency}{amount}\n<b>Purchased:</b> {purchased_time}\n<b>Buyer:</b> {buyer}\n\n\uD83D\uDD11 <b>Key:</b>\n<code>{key}</code>{reference_section}',
  welcome_greeting: '\u2728 <b>Hey {name_link}!</b>',
  tpl_welcome: '{welcome_greeting}\n\n<b>{welcome_title}</b>\n{welcome_body}',
  tpl_store_header: '\uD83D\uDD10 <b>{store_title}</b>\n\n{store_subtitle}\n\n{categories_footer}',
  tpl_duration_caption: '{duration_title}\nCategory: <b>{category}</b>\n{duration_sub}',
  tpl_reseller_activated: '{reseller_title}\n\n<b>Code:</b> <code>{code}</code>\n{switched_section}<b>Expires:</b> {expires}\n<b>Usage Limit:</b> {max_users}\n\n<b>Your Active Offer Details:</b>\n{offer_summary}\n\n{reseller_footer}',
  tpl_reseller_already_active: '{reseller_title}\n\n<b>Code:</b> <code>{code}</code>\n<b>Expires:</b> {expires}\n\n<b>Active Offer Details:</b>\n{offer_summary}',

  help_btn_style: '2',
  owner_btn_style: '3',

  discount_offer_ended_title: '\u23F3 <b>Offer Ended</b>',
  discount_offer_ended_body: 'Sorry, this discount offer has already ended.\n\nPlease tap /start to see the latest prices.',

  tpl_delivery_body: '<b>Category:</b>  {category}\n<b>Duration:</b>  {duration}\n<b>Order ID:</b>  <code>{order_id}</code>\n\n\uD83D\uDD11 <b>Your Key:</b>\n<code>{key_value}</code>',

  tpl_discount_broadcast_title: '\uD83C\uDF89 <b>Special Discount Offer!</b>',
  tpl_discount_broadcast_body: "We're excited to announce <b>{plan_name}</b>!\n\n{description}\n\n{pricing_examples}\n\n\u23F0 <b>Valid until:</b> {expiry_time}",
  tpl_discount_broadcast_footer: '\nOpen the store now and grab your keys at discounted prices!',
  discount_broadcast_buttons: '[]',
  discount_broadcast_send_categories: '0',
  msg_broadcast_progress: '\u23F3 Sending broadcast... {sent}/{total}',
  msg_broadcast_complete: '\u2705 <b>Broadcast Complete</b>\n\nSent: {sent}\nFailed: {failed}\nSkipped: {skipped}\nTotal: {total}',
  msg_broadcast_error: '\u274C Broadcast failed: {error}',
  broadcast_pin_message: '0',
  force_join_enabled: '0',
  force_join_show_verify_btn: '1',
  force_join_title: '\uD83D\uDD12 <b>Channel Membership Required</b>',
  force_join_body: "Hey {user_mention},\n\nYou selected <b>{category}</b> \u2014 <b>{duration}</b>.\n\nBefore we create your order, please join our required channel(s) below.\n\n\uD83D\uDCA1 <i>Your order has not been created yet \u2014 no need to start over.</i>\nAs soon as you join, I\u2019ll automatically detect your membership and continue your order flow seamlessly.",
  force_join_btn_verify: '\u2705 I Joined \u2014 Verify',
  force_join_missing_msg: '\u26A0\uFE0F <b>You haven\'t joined all required channels yet.</b>\n\nPlease join the channels below and try again:',
  force_join_expired_msg: '\u26A0\uFE0F <b>Your pending order has expired.</b>\n\nPlease go back to the store and select a product again.',
  force_join_join_btn_text: '\uD83D\uDCE2 Join {channel}',
  force_join_join_btn_style: '',
  force_join_join_btn_emoji_id: '',
  force_join_verify_btn_style: '',
  force_join_verify_btn_emoji_id: '',
};

const SAFE_KEYS = Object.keys(SETTING_DEFAULTS);

router.get('/', async (req: Request, res: Response) => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS bot_settings (
        key VARCHAR(100) PRIMARY KEY,
        value TEXT NOT NULL DEFAULT ''
      )
    `);

    const result = await pool.query('SELECT key, value FROM bot_settings');
    const dbValues: Record<string, string> = {};
    for (const row of result.rows) {
      dbValues[row.key] = row.value;
    }

    const settings: Record<string, string> = {};
    for (const key of SAFE_KEYS) {
      settings[key] = dbValues[key] !== undefined ? dbValues[key] : SETTING_DEFAULTS[key];
    }

    res.json({ settings, defaults: SETTING_DEFAULTS });
  } catch (err) {
    console.error('Bot settings load error:', err);
    res.status(500).json({ error: 'Failed to load bot settings' });
  }
});

router.put('/', async (req: Request, res: Response) => {
  try {
    const { settings } = req.body;
    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({ error: 'Invalid settings payload' });
    }

    await pool.query(`
      CREATE TABLE IF NOT EXISTS bot_settings (
        key VARCHAR(100) PRIMARY KEY,
        value TEXT NOT NULL DEFAULT ''
      )
    `);

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      for (const [key, value] of Object.entries(settings)) {
        if (!SAFE_KEYS.includes(key)) continue;
        const val = value == null ? '' : String(value);
        await client.query(
          `INSERT INTO bot_settings (key, value) VALUES ($1, $2)
           ON CONFLICT (key) DO UPDATE SET value = $2`,
          [key, val]
        );
      }
      await client.query('COMMIT');
    } catch (txErr) {
      await client.query('ROLLBACK');
      throw txErr;
    } finally {
      client.release();
    }

    res.json({ message: 'Bot settings saved successfully' });
  } catch (err) {
    console.error('Bot settings save error:', err);
    res.status(500).json({ error: 'Failed to save bot settings' });
  }
});

router.post('/reload', async (req: Request, res: Response) => {
  res.json({ message: 'Settings saved. Bot will pick up changes on next /start or restart.' });
});

const CATEGORY_DURATION_SAFE_KEYS = ['tpl_duration_caption', 'msg_select_duration_title', 'msg_select_duration_sub', 'duration_link_buttons'];

router.get('/category-duration/:categoryId', async (req: Request, res: Response) => {
  try {
    const catId = parseInt(req.params.categoryId, 10);
    if (isNaN(catId)) return res.status(400).json({ error: 'Invalid category ID' });

    await pool.query(`
      CREATE TABLE IF NOT EXISTS category_duration_settings (
        category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
        setting_key VARCHAR(100) NOT NULL,
        value TEXT NOT NULL DEFAULT '',
        PRIMARY KEY (category_id, setting_key)
      )
    `);

    const result = await pool.query(
      'SELECT setting_key, value FROM category_duration_settings WHERE category_id = $1',
      [catId]
    );

    const settings: Record<string, string> = {};
    for (const row of result.rows) {
      if (CATEGORY_DURATION_SAFE_KEYS.includes(row.setting_key)) {
        settings[row.setting_key] = row.value;
      }
    }

    const defaults: Record<string, string> = {};
    for (const key of CATEGORY_DURATION_SAFE_KEYS) {
      defaults[key] = SETTING_DEFAULTS[key] || '';
    }

    res.json({ settings, defaults });
  } catch (err) {
    console.error('Category duration settings load error:', err);
    res.status(500).json({ error: 'Failed to load category duration settings' });
  }
});

router.put('/category-duration/:categoryId', async (req: Request, res: Response) => {
  try {
    const catId = parseInt(req.params.categoryId, 10);
    if (isNaN(catId)) return res.status(400).json({ error: 'Invalid category ID' });

    const { settings } = req.body;
    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({ error: 'Invalid settings payload' });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      for (const [key, value] of Object.entries(settings)) {
        if (!CATEGORY_DURATION_SAFE_KEYS.includes(key)) continue;
        const val = value == null ? '' : String(value);
        if (val === '') {
          await client.query(
            'DELETE FROM category_duration_settings WHERE category_id = $1 AND setting_key = $2',
            [catId, key]
          );
        } else {
          await client.query(
            `INSERT INTO category_duration_settings (category_id, setting_key, value)
             VALUES ($1, $2, $3)
             ON CONFLICT (category_id, setting_key) DO UPDATE SET value = $3`,
            [catId, key, val]
          );
        }
      }
      await client.query('COMMIT');
    } catch (txErr) {
      await client.query('ROLLBACK');
      throw txErr;
    } finally {
      client.release();
    }

    res.json({ message: 'Category duration settings saved' });
  } catch (err) {
    console.error('Category duration settings save error:', err);
    res.status(500).json({ error: 'Failed to save category duration settings' });
  }
});

export default router;
