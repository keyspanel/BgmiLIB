import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { tgPhotoProxyUrl } from './users';
import https from 'https';
import http from 'http';
import { EventEmitter } from 'events';

const router = express.Router();

const sseEmitter = new EventEmitter();
sseEmitter.setMaxListeners(20);

function emitSSE(event: string, data?: any) {
  sseEmitter.emit('sc-event', { type: event, data: data || {}, ts: Date.now() });
}

async function ensureSourceTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS api_providers (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      base_url TEXT NOT NULL,
      token TEXT DEFAULT NULL,
      is_active BOOLEAN NOT NULL DEFAULT true,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS source_rules (
      id SERIAL PRIMARY KEY,
      category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
      duration_id INT NOT NULL REFERENCES durations(id) ON DELETE CASCADE,
      source_type VARCHAR(20) NOT NULL CHECK (source_type IN ('manual', 'api', 'api_and_manual')),
      api_provider_id INT REFERENCES api_providers(id) ON DELETE SET NULL,
      api_game_value VARCHAR(255) DEFAULT NULL,
      api_duration_value VARCHAR(255) DEFAULT NULL,
      api_device_value VARCHAR(255) DEFAULT NULL,
      api_currency_value VARCHAR(255) DEFAULT NULL,
      is_active BOOLEAN NOT NULL DEFAULT true,
      last_test_result TEXT DEFAULT NULL,
      last_test_success BOOLEAN DEFAULT NULL,
      last_test_at TIMESTAMP DEFAULT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
      UNIQUE(category_id, duration_id)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS source_fulfillment_logs (
      id BIGSERIAL PRIMARY KEY,
      order_id INT DEFAULT NULL,
      category_id INT DEFAULT NULL,
      duration_id INT DEFAULT NULL,
      category_name VARCHAR(255) DEFAULT NULL,
      duration_name VARCHAR(255) DEFAULT NULL,
      source_type VARCHAR(20) DEFAULT NULL,
      provider_id INT DEFAULT NULL,
      provider_name VARCHAR(255) DEFAULT NULL,
      resolution_success BOOLEAN NOT NULL DEFAULT false,
      delivery_success BOOLEAN NOT NULL DEFAULT false,
      key_value TEXT DEFAULT NULL,
      api_request_url TEXT DEFAULT NULL,
      api_raw_response TEXT DEFAULT NULL,
      failure_reason TEXT DEFAULT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS source_audit_logs (
      id BIGSERIAL PRIMARY KEY,
      action_type VARCHAR(50) NOT NULL,
      target_type VARCHAR(50) NOT NULL,
      target_id INT DEFAULT NULL,
      target_name VARCHAR(255) DEFAULT NULL,
      actor VARCHAR(255) DEFAULT 'admin',
      changes JSONB DEFAULT NULL,
      metadata JSONB DEFAULT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS fulfillment_issues (
      id SERIAL PRIMARY KEY,
      order_id INT NOT NULL,
      user_id INT DEFAULT NULL,
      category_id INT DEFAULT NULL,
      duration_id INT DEFAULT NULL,
      source_rule_id INT DEFAULT NULL,
      provider_id INT DEFAULT NULL,
      source_type VARCHAR(30) DEFAULT NULL,
      failure_reason TEXT DEFAULT NULL,
      failure_code VARCHAR(100) DEFAULT NULL,
      payload_snapshot JSONB DEFAULT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'open',
      recovery_key TEXT DEFAULT NULL,
      recovery_note TEXT DEFAULT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
      resolved_at TIMESTAMP DEFAULT NULL,
      resolved_by VARCHAR(255) DEFAULT NULL,
      send_attempts INT NOT NULL DEFAULT 0,
      last_send_error TEXT DEFAULT NULL
    )
  `);

  try {
    await pool.query(`ALTER TABLE source_fulfillment_logs ADD COLUMN IF NOT EXISTS user_telegram_id BIGINT DEFAULT NULL`);
    await pool.query(`ALTER TABLE source_fulfillment_logs ADD COLUMN IF NOT EXISTS user_display_name VARCHAR(255) DEFAULT NULL`);
    await pool.query(`ALTER TABLE source_fulfillment_logs ADD COLUMN IF NOT EXISTS delivered_source VARCHAR(30) DEFAULT NULL`);
    await pool.query(`ALTER TABLE source_fulfillment_logs ADD COLUMN IF NOT EXISTS fallback_used BOOLEAN DEFAULT false`);
    await pool.query(`ALTER TABLE source_fulfillment_logs ADD COLUMN IF NOT EXISTS response_time_ms INT DEFAULT NULL`);
    await pool.query(`ALTER TABLE source_fulfillment_logs ADD COLUMN IF NOT EXISTS http_status INT DEFAULT NULL`);
    await pool.query(`ALTER TABLE api_providers ADD COLUMN IF NOT EXISTS token TEXT DEFAULT NULL`);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_fi_order ON fulfillment_issues(order_id)`);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_fi_status ON fulfillment_issues(status)`);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_fi_created ON fulfillment_issues(created_at)`);
  } catch {}
}

ensureSourceTables().catch((err) => console.error('Source tables creation error:', err));

async function logAudit(actionType: string, targetType: string, targetId: number | null, targetName: string, changes?: any, metadata?: any) {
  try {
    await pool.query(
      `INSERT INTO source_audit_logs (action_type, target_type, target_id, target_name, changes, metadata) VALUES ($1, $2, $3, $4, $5, $6)`,
      [actionType, targetType, targetId, targetName, changes ? JSON.stringify(changes) : null, metadata ? JSON.stringify(metadata) : null]
    );
    emitSSE('audit_added');
  } catch (err) {
    console.error('Audit log error:', err);
  }
}

router.get('/events', (req: Request, res: Response) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write('data: {"type":"connected"}\n\n');

  const handler = (payload: any) => {
    try {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    } catch {}
  };

  sseEmitter.on('sc-event', handler);

  const keepAlive = setInterval(() => {
    try { res.write(': keepalive\n\n'); } catch {}
  }, 25000);

  req.on('close', () => {
    sseEmitter.off('sc-event', handler);
    clearInterval(keepAlive);
  });
});

router.use(authMiddleware);

router.get('/stats', async (_req: Request, res: Response) => {
  try {
    const rulesResult = await pool.query(`
      SELECT
        COUNT(*) AS total_rules,
        COUNT(*) FILTER (WHERE is_active) AS active_rules,
        COUNT(*) FILTER (WHERE source_type = 'manual') AS manual_rules,
        COUNT(*) FILTER (WHERE source_type = 'api') AS api_rules,
        COUNT(*) FILTER (WHERE source_type = 'api_and_manual') AS hybrid_rules
      FROM source_rules
    `);

    const providersResult = await pool.query(`
      SELECT
        COUNT(*) AS total_providers,
        COUNT(*) FILTER (WHERE is_active) AS active_providers
      FROM api_providers
    `);

    const fulfillment24h = await pool.query(`
      SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE delivery_success = true) AS delivered,
        COUNT(*) FILTER (WHERE delivery_success = false) AS failed,
        COUNT(*) FILTER (WHERE fallback_used = true) AS fallback_used
      FROM source_fulfillment_logs
      WHERE created_at > NOW() - INTERVAL '24 hours'
    `);

    const fulfillment7d = await pool.query(`
      SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE delivery_success = true) AS delivered,
        COUNT(*) FILTER (WHERE delivery_success = false) AS failed
      FROM source_fulfillment_logs
      WHERE created_at > NOW() - INTERVAL '7 days'
    `);

    const pendingReview = await pool.query(`
      SELECT COUNT(*) FROM source_rules WHERE last_test_success = false AND is_active = true
    `);

    const issuesStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE status = 'open') AS open_issues,
        COUNT(*) FILTER (WHERE status IN ('sent','closed') AND resolved_at > NOW() - INTERVAL '24 hours') AS recovered_today,
        COUNT(*) FILTER (WHERE status = 'failed') AS failed_sends,
        AVG(EXTRACT(EPOCH FROM (resolved_at - created_at)) / 60) FILTER (WHERE resolved_at IS NOT NULL) AS avg_recovery_min
      FROM fulfillment_issues
    `);

    const r = rulesResult.rows[0];
    const p = providersResult.rows[0];
    const f24 = fulfillment24h.rows[0];
    const f7d = fulfillment7d.rows[0];
    const total7d = parseInt(f7d.total) || 0;
    const delivered7d = parseInt(f7d.delivered) || 0;
    const is = issuesStats.rows[0];

    res.json({
      total_rules: parseInt(r.total_rules),
      active_rules: parseInt(r.active_rules),
      manual_rules: parseInt(r.manual_rules),
      api_rules: parseInt(r.api_rules),
      hybrid_rules: parseInt(r.hybrid_rules),
      total_providers: parseInt(p.total_providers),
      active_providers: parseInt(p.active_providers),
      fulfilled_24h: parseInt(f24.delivered),
      failed_24h: parseInt(f24.failed),
      fallback_24h: parseInt(f24.fallback_used) || 0,
      total_24h: parseInt(f24.total),
      success_rate_7d: total7d > 0 ? Math.round((delivered7d / total7d) * 100) : 100,
      pending_review: parseInt(pendingReview.rows[0].count),
      open_issues: parseInt(is.open_issues) || 0,
      recovered_today: parseInt(is.recovered_today) || 0,
      failed_sends: parseInt(is.failed_sends) || 0,
      avg_recovery_min: is.avg_recovery_min ? Math.round(parseFloat(is.avg_recovery_min)) : null,
    });
  } catch (err) {
    console.error('Stats error:', err);
    res.status(500).json({ error: 'Failed to load stats' });
  }
});

router.get('/providers', async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT ap.*,
        (SELECT COUNT(*) FROM source_rules WHERE api_provider_id = ap.id) AS rules_count,
        (SELECT COUNT(*) FROM source_fulfillment_logs WHERE provider_id = ap.id AND created_at > NOW() - INTERVAL '7 days') AS fulfillments_7d,
        (SELECT COUNT(*) FROM source_fulfillment_logs WHERE provider_id = ap.id AND delivery_success = false AND created_at > NOW() - INTERVAL '7 days') AS failures_7d,
        (SELECT last_test_at FROM source_rules WHERE api_provider_id = ap.id AND last_test_at IS NOT NULL ORDER BY last_test_at DESC LIMIT 1) AS last_tested_at,
        (SELECT last_test_success FROM source_rules WHERE api_provider_id = ap.id AND last_test_at IS NOT NULL ORDER BY last_test_at DESC LIMIT 1) AS last_test_ok
      FROM api_providers ap
      ORDER BY ap.id ASC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error('Providers list error:', err);
    res.status(500).json({ error: 'Failed to load providers' });
  }
});

function validateProviderUrl(url: string): string | null {
  try {
    const parsed = new URL(url.split('?')[0]);
    if (!['http:', 'https:'].includes(parsed.protocol)) return 'URL must use http or https protocol';
    const host = parsed.hostname.toLowerCase();
    if (host === 'localhost' || host === '127.0.0.1' || host === '0.0.0.0' || host === '::1') return 'localhost URLs are not allowed';
    if (host.startsWith('10.') || host.startsWith('192.168.') || host.startsWith('172.')) return 'Private network URLs are not allowed';
    if (host === '169.254.169.254' || host.endsWith('.internal')) return 'Metadata/internal URLs are not allowed';
    return null;
  } catch {
    return 'Invalid URL format';
  }
}

router.post('/providers', async (req: Request, res: Response) => {
  try {
    const { name, base_url, token, is_active = true } = req.body;
    if (!name?.trim() || !base_url?.trim()) return res.status(400).json({ error: 'Name and base URL are required' });
    const urlErr = validateProviderUrl(base_url);
    if (urlErr) return res.status(400).json({ error: urlErr });
    const trimmedToken = (token || '').trim() || null;
    const result = await pool.query(
      'INSERT INTO api_providers (name, base_url, token, is_active) VALUES ($1, $2, $3, $4) RETURNING id',
      [name.trim(), base_url.trim(), trimmedToken, is_active]
    );
    await logAudit('created', 'provider', result.rows[0].id, name.trim(), { name: name.trim(), base_url: base_url.trim(), token: trimmedToken, is_active });
    emitSSE('provider_changed');
    res.json({ id: result.rows[0].id, message: 'Provider created' });
  } catch (err) {
    console.error('Provider create error:', err);
    res.status(500).json({ error: 'Failed to create provider' });
  }
});

router.put('/providers/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, base_url, token, is_active } = req.body;
    if (!name?.trim() || !base_url?.trim()) return res.status(400).json({ error: 'Name and base URL are required' });
    const urlErr = validateProviderUrl(base_url);
    if (urlErr) return res.status(400).json({ error: urlErr });
    const trimmedToken = (token || '').trim() || null;

    const before = await pool.query('SELECT name, base_url, token, is_active FROM api_providers WHERE id = $1', [id]);
    const updateResult = await pool.query(
      'UPDATE api_providers SET name = $1, base_url = $2, token = $3, is_active = $4 WHERE id = $5',
      [name.trim(), base_url.trim(), trimmedToken, is_active ?? true, id]
    );
    if (updateResult.rowCount === 0) return res.status(404).json({ error: 'Provider not found' });
    const bv = before.rows[0] || {};
    const changes: any = {};
    if (bv.name !== name.trim()) changes.name = { before: bv.name, after: name.trim() };
    if (bv.base_url !== base_url.trim()) changes.base_url = { before: bv.base_url, after: base_url.trim() };
    if (bv.token !== trimmedToken) changes.token = { before: bv.token, after: trimmedToken };
    if (bv.is_active !== (is_active ?? true)) changes.is_active = { before: bv.is_active, after: is_active ?? true };
    await logAudit('updated', 'provider', parseInt(id), name.trim(), changes);
    emitSSE('provider_changed');
    res.json({ message: 'Provider updated' });
  } catch (err) {
    console.error('Provider update error:', err);
    res.status(500).json({ error: 'Failed to update provider' });
  }
});

router.delete('/providers/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const usedBy = await pool.query('SELECT COUNT(*) FROM source_rules WHERE api_provider_id = $1', [id]);
    if (parseInt(usedBy.rows[0].count) > 0) {
      return res.status(400).json({ error: 'Provider is used by source rules. Remove those rules first.' });
    }
    const prov = await pool.query('SELECT name FROM api_providers WHERE id = $1', [id]);
    await pool.query('DELETE FROM api_providers WHERE id = $1', [id]);
    await logAudit('deleted', 'provider', parseInt(id), prov.rows[0]?.name || 'unknown');
    emitSSE('provider_changed');
    res.json({ message: 'Provider deleted' });
  } catch (err) {
    console.error('Provider delete error:', err);
    res.status(500).json({ error: 'Failed to delete provider' });
  }
});

router.get('/rules', async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT sr.*,
        c.name AS category_name,
        d.name AS duration_name,
        ap.name AS provider_name,
        ap.base_url AS provider_base_url
      FROM source_rules sr
      JOIN categories c ON c.id = sr.category_id
      JOIN durations d ON d.id = sr.duration_id
      LEFT JOIN api_providers ap ON ap.id = sr.api_provider_id
      ORDER BY c.name ASC, d.sort_order ASC, sr.id ASC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error('Rules list error:', err);
    res.status(500).json({ error: 'Failed to load rules' });
  }
});

router.post('/rules', async (req: Request, res: Response) => {
  try {
    const { category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active = true } = req.body;
    if (!category_id || !duration_id) return res.status(400).json({ error: 'Category and duration are required' });
    if (!['manual', 'api', 'api_and_manual'].includes(source_type)) return res.status(400).json({ error: 'Source type must be manual, api, or api_and_manual' });
    if ((source_type === 'api' || source_type === 'api_and_manual') && !api_provider_id) return res.status(400).json({ error: 'API provider is required for API source types' });

    const catCheck = await pool.query('SELECT id, name FROM categories WHERE id = $1', [category_id]);
    if (catCheck.rows.length === 0) return res.status(400).json({ error: 'Category not found' });
    const durCheck = await pool.query('SELECT id, name FROM durations WHERE id = $1 AND category_id = $2', [duration_id, category_id]);
    if (durCheck.rows.length === 0) return res.status(400).json({ error: 'Duration not found for this category' });

    const existing = await pool.query('SELECT id FROM source_rules WHERE category_id = $1 AND duration_id = $2', [category_id, duration_id]);
    if (existing.rows.length > 0) return res.status(400).json({ error: 'A source rule already exists for this category + duration. Edit it instead.' });

    const result = await pool.query(
      `INSERT INTO source_rules (category_id, duration_id, source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`,
      [category_id, duration_id, source_type, (source_type === 'api' || source_type === 'api_and_manual') ? api_provider_id : null,
       api_game_value || null, api_duration_value || null, api_device_value || null, api_currency_value || null, is_active]
    );
    const catName = catCheck.rows[0].name;
    const durName = durCheck.rows[0].name;
    await logAudit('created', 'rule', result.rows[0].id, `${catName} / ${durName}`, { source_type, api_provider_id, is_active });
    emitSSE('rule_changed');
    res.json({ id: result.rows[0].id, message: 'Source rule created' });
  } catch (err: any) {
    console.error('Rule create error:', err);
    if (err.code === '23505') return res.status(400).json({ error: 'A rule for this category + duration already exists' });
    res.status(500).json({ error: 'Failed to create rule' });
  }
});

router.put('/rules/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { source_type, api_provider_id, api_game_value, api_duration_value, api_device_value, api_currency_value, is_active } = req.body;
    if (!['manual', 'api', 'api_and_manual'].includes(source_type)) return res.status(400).json({ error: 'Source type must be manual, api, or api_and_manual' });
    if ((source_type === 'api' || source_type === 'api_and_manual') && !api_provider_id) return res.status(400).json({ error: 'API provider is required for API source types' });

    const before = await pool.query(`
      SELECT sr.source_type, sr.api_provider_id, sr.api_game_value, sr.api_duration_value, sr.api_device_value, sr.api_currency_value, sr.is_active,
        c.name AS category_name, d.name AS duration_name
      FROM source_rules sr JOIN categories c ON c.id = sr.category_id JOIN durations d ON d.id = sr.duration_id WHERE sr.id = $1
    `, [id]);
    const bv = before.rows[0] || {};

    const ruleUpdate = await pool.query(
      `UPDATE source_rules SET source_type = $1, api_provider_id = $2, api_game_value = $3, api_duration_value = $4,
       api_device_value = $5, api_currency_value = $6, is_active = $7, updated_at = NOW() WHERE id = $8`,
      [source_type, (source_type === 'api' || source_type === 'api_and_manual') ? api_provider_id : null,
       api_game_value || null, api_duration_value || null, api_device_value || null, api_currency_value || null,
       is_active ?? true, id]
    );
    if (ruleUpdate.rowCount === 0) return res.status(404).json({ error: 'Rule not found' });

    const changes: any = {};
    if (bv.source_type !== source_type) changes.source_type = { before: bv.source_type, after: source_type };
    if (bv.is_active !== (is_active ?? true)) changes.is_active = { before: bv.is_active, after: is_active ?? true };
    if (String(bv.api_provider_id) !== String(api_provider_id || null)) changes.api_provider_id = { before: bv.api_provider_id, after: api_provider_id || null };
    if (bv.api_game_value !== (api_game_value || null)) changes.api_game_value = { before: bv.api_game_value, after: api_game_value || null };
    if (bv.api_duration_value !== (api_duration_value || null)) changes.api_duration_value = { before: bv.api_duration_value, after: api_duration_value || null };
    await logAudit('updated', 'rule', parseInt(id), `${bv.category_name} / ${bv.duration_name}`, changes);
    emitSSE('rule_changed');
    res.json({ message: 'Source rule updated' });
  } catch (err) {
    console.error('Rule update error:', err);
    res.status(500).json({ error: 'Failed to update rule' });
  }
});

router.delete('/rules/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const ruleInfo = await pool.query(`
      SELECT c.name AS category_name, d.name AS duration_name, sr.source_type
      FROM source_rules sr JOIN categories c ON c.id = sr.category_id JOIN durations d ON d.id = sr.duration_id WHERE sr.id = $1
    `, [id]);
    const ri = ruleInfo.rows[0];
    await pool.query('DELETE FROM source_rules WHERE id = $1', [id]);
    if (ri) await logAudit('deleted', 'rule', parseInt(id), `${ri.category_name} / ${ri.duration_name}`, { source_type: ri.source_type });
    emitSSE('rule_changed');
    res.json({ message: 'Source rule deleted' });
  } catch (err) {
    console.error('Rule delete error:', err);
    res.status(500).json({ error: 'Failed to delete rule' });
  }
});

function applyToken(url: string, token?: string | null): string {
  if (!token) return url;
  try {
    const u = new URL(url);
    u.searchParams.set('token', token);
    return u.toString();
  } catch {
    if (url.includes('?')) {
      const replaced = url.replace(/([?&])token=[^&]*/g, '');
      const sep = replaced.includes('?') ? '&' : '?';
      return replaced + sep + `token=${encodeURIComponent(token)}`;
    }
    return url + `?token=${encodeURIComponent(token)}`;
  }
}

function buildApiUrl(baseUrl: string, gameValue?: string, durationValue?: string, deviceValue?: string, currencyValue?: string, token?: string | null): string {
  let url = baseUrl;
  if (url.includes('?')) {
    const parts = url.split('?');
    let queryStr = parts[1] || '';
    if (gameValue) queryStr = queryStr.replace(/game=[^&]*/g, `game=${encodeURIComponent(gameValue)}`);
    if (durationValue) queryStr = queryStr.replace(/duration=[^&]*/g, `duration=${encodeURIComponent(durationValue)}`);
    if (deviceValue) queryStr = queryStr.replace(/max_devices=[^&]*/g, `max_devices=${encodeURIComponent(deviceValue)}`);
    if (currencyValue) queryStr = queryStr.replace(/currency=[^&]*/g, `currency=${encodeURIComponent(currencyValue)}`);
    url = parts[0] + '?' + queryStr;
  } else {
    const params: string[] = [];
    if (gameValue) params.push(`game=${encodeURIComponent(gameValue)}`);
    if (durationValue) params.push(`duration=${encodeURIComponent(durationValue)}`);
    if (deviceValue) params.push(`max_devices=${encodeURIComponent(deviceValue)}`);
    if (currencyValue) params.push(`currency=${encodeURIComponent(currencyValue)}`);
    if (params.length) url += '?' + params.join('&');
  }
  url = applyToken(url, token);
  return url;
}

const API_REQUEST_HEADERS: Record<string, string> = {
  'User-Agent': 'Mozilla/5.0 (compatible; KeyStoreBot/1.0)',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'en-US,en;q=0.9',
};

function fetchUrl(url: string, timeout: number = 10000): Promise<{ status: number; body: string }> {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { timeout, headers: API_REQUEST_HEADERS }, (resp) => {
      let data = '';
      resp.on('data', (chunk: string) => { data += chunk; });
      resp.on('end', () => resolve({ status: resp.statusCode || 0, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Request timed out')); });
  });
}

router.post('/test', async (req: Request, res: Response) => {
  try {
    const { provider_id, base_url_override, api_game_value, api_duration_value, api_device_value, api_currency_value } = req.body;

    let baseUrl = base_url_override || '';
    let providerName = 'Custom';
    let providerToken: string | null = null;
    if (baseUrl) {
      const urlErr = validateProviderUrl(baseUrl);
      if (urlErr) return res.status(400).json({ error: urlErr });
    }
    if (!baseUrl && provider_id) {
      const provResult = await pool.query('SELECT base_url, name, token FROM api_providers WHERE id = $1', [provider_id]);
      if (provResult.rows.length === 0) return res.status(400).json({ error: 'Provider not found' });
      baseUrl = provResult.rows[0].base_url;
      providerName = provResult.rows[0].name;
      providerToken = provResult.rows[0].token || null;
    }
    if (!baseUrl) return res.status(400).json({ error: 'No base URL provided' });

    const finalUrl = buildApiUrl(baseUrl, api_game_value, api_duration_value, api_device_value, api_currency_value, providerToken);
    const startTime = Date.now();

    let response;
    try {
      response = await fetchUrl(finalUrl);
    } catch (e: any) {
      await logAudit('test_run', 'provider', provider_id ? parseInt(provider_id) : null, providerName, null, { success: false, error: e.message });
      emitSSE('test_result');
      return res.json({
        success: false,
        request_url: finalUrl,
        error: e.message,
        raw_response: null,
        parsed: null,
        latency_ms: Date.now() - startTime
      });
    }

    const latency = Date.now() - startTime;
    let parsed = null;
    try {
      parsed = JSON.parse(response.body);
    } catch {}

    const isSuccess = parsed && (parsed.success === true || parsed.status === 'success' || parsed.ok === true);
    const keysList = parsed?.keys || parsed?.data?.keys || (parsed?.key ? [parsed.key] : []);
    const firstKey = keysList.length > 0 ? keysList[0] : null;
    const extractedUserKey = firstKey && typeof firstKey === 'object' ? (firstKey.user_key || null) : (typeof firstKey === 'string' ? firstKey : null);
    const testPassed = isSuccess && keysList.length > 0 && !!extractedUserKey;

    await logAudit('test_run', 'provider', provider_id ? parseInt(provider_id) : null, providerName, null, {
      success: testPassed, http_status: response.status, keys_found: keysList.length, latency_ms: latency
    });
    emitSSE('test_result');

    res.json({
      success: testPassed,
      request_url: finalUrl,
      http_status: response.status,
      raw_response: response.body.substring(0, 5000),
      parsed,
      keys_found: keysList.length,
      extracted_user_key: extractedUserKey,
      sample_key_object: firstKey,
      latency_ms: latency
    });
  } catch (err) {
    console.error('Test source error:', err);
    res.status(500).json({ error: 'Test failed' });
  }
});

router.post('/rules/:id/test', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const ruleResult = await pool.query(`
      SELECT sr.*, ap.base_url AS provider_base_url, ap.name AS provider_name, ap.token AS provider_token,
        c.name AS category_name, d.name AS duration_name
      FROM source_rules sr
      LEFT JOIN api_providers ap ON ap.id = sr.api_provider_id
      JOIN categories c ON c.id = sr.category_id
      JOIN durations d ON d.id = sr.duration_id
      WHERE sr.id = $1
    `, [id]);
    if (ruleResult.rows.length === 0) return res.status(404).json({ error: 'Rule not found' });

    const rule = ruleResult.rows[0];
    const ruleName = `${rule.category_name} / ${rule.duration_name}`;

    if (rule.source_type === 'manual') {
      const stockResult = await pool.query(
        'SELECT COUNT(*) FROM product_keys WHERE category_id = $1 AND duration_id = $2 AND is_sold = 0',
        [rule.category_id, rule.duration_id]
      );
      const count = parseInt(stockResult.rows[0].count);
      const testResult = count > 0 ? `Manual stock available: ${count} keys` : 'No manual stock available';
      await pool.query(
        'UPDATE source_rules SET last_test_result = $1, last_test_success = $2, last_test_at = NOW() WHERE id = $3',
        [testResult, count > 0, id]
      );
      await logAudit('test_run', 'rule', parseInt(id), ruleName, null, { success: count > 0, stock_count: count, source_type: 'manual' });
      emitSSE('test_result');
      return res.json({ success: count > 0, message: testResult, stock_count: count });
    }

    if (!rule.provider_base_url) {
      await pool.query(
        'UPDATE source_rules SET last_test_result = $1, last_test_success = false, last_test_at = NOW() WHERE id = $2',
        ['No API provider configured', id]
      );
      await logAudit('test_run', 'rule', parseInt(id), ruleName, null, { success: false, error: 'No API provider configured' });
      emitSSE('test_result');
      return res.json({ success: false, message: 'No API provider configured' });
    }

    const finalUrl = buildApiUrl(rule.provider_base_url, rule.api_game_value, rule.api_duration_value, rule.api_device_value, rule.api_currency_value, rule.provider_token);
    const startTime = Date.now();

    let response;
    try {
      response = await fetchUrl(finalUrl);
    } catch (e: any) {
      const errMsg = `API request failed: ${e.message}`;
      await pool.query(
        'UPDATE source_rules SET last_test_result = $1, last_test_success = false, last_test_at = NOW() WHERE id = $2',
        [errMsg, id]
      );
      await logAudit('test_run', 'rule', parseInt(id), ruleName, null, { success: false, error: e.message, latency_ms: Date.now() - startTime });
      emitSSE('test_result');
      return res.json({ success: false, message: errMsg, request_url: finalUrl, latency_ms: Date.now() - startTime });
    }

    const latency = Date.now() - startTime;
    let parsed = null;
    try { parsed = JSON.parse(response.body); } catch {}

    const isSuccess = parsed && (parsed.success === true || parsed.status === 'success' || parsed.ok === true);
    const keysList = parsed?.keys || parsed?.data?.keys || (parsed?.key ? [parsed.key] : []);
    const firstKey = keysList.length > 0 ? keysList[0] : null;
    const extractedUserKey = firstKey && typeof firstKey === 'object' ? (firstKey.user_key || null) : (typeof firstKey === 'string' ? firstKey : null);

    let testMsg: string;
    const testPassed = isSuccess && keysList.length > 0 && !!extractedUserKey;
    if (testPassed) {
      testMsg = `API test passed. Key: ${extractedUserKey}`;
    } else if (isSuccess && keysList.length > 0 && !extractedUserKey) {
      testMsg = `API responded but user_key not found in key object.`;
    } else {
      testMsg = `API test failed. HTTP ${response.status}. ${parsed ? JSON.stringify(parsed).substring(0, 200) : response.body.substring(0, 200)}`;
    }

    await pool.query(
      'UPDATE source_rules SET last_test_result = $1, last_test_success = $2, last_test_at = NOW() WHERE id = $3',
      [testMsg, testPassed, id]
    );

    await logAudit('test_run', 'rule', parseInt(id), ruleName, null, {
      success: testPassed, http_status: response.status, keys_found: keysList.length, latency_ms: latency
    });
    emitSSE('test_result');

    res.json({
      success: testPassed,
      message: testMsg,
      request_url: finalUrl,
      http_status: response.status,
      raw_response: response.body.substring(0, 5000),
      parsed,
      keys_found: keysList.length,
      extracted_user_key: extractedUserKey,
      latency_ms: latency
    });
  } catch (err) {
    console.error('Rule test error:', err);
    res.status(500).json({ error: 'Test failed' });
  }
});

router.get('/logs', async (req: Request, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const offset = parseInt(req.query.offset as string) || 0;
    const category_id = req.query.category_id as string;
    const source_type = req.query.source_type as string;
    const provider_id = req.query.provider_id as string;
    const result_filter = req.query.result as string;

    const conditions: string[] = [];
    const params: any[] = [];
    let pi = 1;

    if (category_id) { conditions.push(`category_id = $${pi++}`); params.push(category_id); }
    if (source_type) { conditions.push(`source_type = $${pi++}`); params.push(source_type); }
    if (provider_id) { conditions.push(`provider_id = $${pi++}`); params.push(provider_id); }
    if (result_filter === 'delivered') { conditions.push('delivery_success = true'); }
    else if (result_filter === 'failed') { conditions.push('delivery_success = false'); }
    else if (result_filter === 'fallback') { conditions.push('fallback_used = true'); }

    const where = conditions.length > 0 ? ' WHERE ' + conditions.join(' AND ') : '';

    const sql = `SELECT sfl.*,
      o.purchaser_label AS order_username, u.telegram_id AS telegram_user_id, u.username AS user_tg_username, u.profile_photo_url
      FROM source_fulfillment_logs sfl
      LEFT JOIN orders o ON o.id = sfl.order_id
      LEFT JOIN users u ON u.id = o.user_id
      ${where}
      ORDER BY sfl.created_at DESC LIMIT $${pi++} OFFSET $${pi++}`;
    params.push(limit, offset);

    const result = await pool.query(sql, params);
    const countParams = params.slice(0, -2);
    const countResult = await pool.query(`SELECT COUNT(*) FROM source_fulfillment_logs sfl ${where}`, countParams);

    res.json({ logs: result.rows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) })), total: parseInt(countResult.rows[0].count) });
  } catch (err) {
    console.error('Logs error:', err);
    res.status(500).json({ error: 'Failed to load logs' });
  }
});

router.get('/audit', async (req: Request, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const offset = parseInt(req.query.offset as string) || 0;
    const action_type = req.query.action_type as string;
    const target_type = req.query.target_type as string;

    const conditions: string[] = [];
    const params: any[] = [];
    let pi = 1;

    if (action_type) { conditions.push(`action_type = $${pi++}`); params.push(action_type); }
    if (target_type) { conditions.push(`target_type = $${pi++}`); params.push(target_type); }

    const where = conditions.length > 0 ? ' WHERE ' + conditions.join(' AND ') : '';
    const sql = `SELECT * FROM source_audit_logs ${where} ORDER BY created_at DESC LIMIT $${pi++} OFFSET $${pi++}`;
    params.push(limit, offset);

    const result = await pool.query(sql, params);
    const countParams = params.slice(0, -2);
    const countResult = await pool.query(`SELECT COUNT(*) FROM source_audit_logs ${where}`, countParams);

    res.json({ logs: result.rows, total: parseInt(countResult.rows[0].count) });
  } catch (err) {
    console.error('Audit logs error:', err);
    res.status(500).json({ error: 'Failed to load audit logs' });
  }
});

router.get('/issues', async (req: Request, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const offset = parseInt(req.query.offset as string) || 0;
    const status = req.query.status as string;
    const source_type = req.query.source_type as string;

    const conditions: string[] = [];
    const params: any[] = [];
    let pi = 1;

    if (status && status !== 'all') { conditions.push(`fi.status = $${pi++}`); params.push(status); }
    if (source_type) { conditions.push(`fi.source_type = $${pi++}`); params.push(source_type); }

    const where = conditions.length > 0 ? ' WHERE ' + conditions.join(' AND ') : '';

    const sql = `
      SELECT fi.*,
        o.txn_ref, o.amount AS order_amount, o.status AS order_status,
        o.purchased_category_name AS category_name,
        o.purchased_duration_name AS duration_name,
        o.delivered_at,
        u.telegram_id, u.username, u.first_name, u.last_name,
        u.profile_photo_url,
        ap.name AS provider_name
      FROM fulfillment_issues fi
      LEFT JOIN orders o ON o.id = fi.order_id
      LEFT JOIN users u ON u.id = fi.user_id
      LEFT JOIN api_providers ap ON ap.id = fi.provider_id
      ${where}
      ORDER BY fi.created_at DESC
      LIMIT $${pi++} OFFSET $${pi++}
    `;
    params.push(limit, offset);

    const result = await pool.query(sql, params);
    const countParams = params.slice(0, -2);
    const countResult = await pool.query(`SELECT COUNT(*) FROM fulfillment_issues fi ${where}`, countParams);

    res.json({
      issues: result.rows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) })),
      total: parseInt(countResult.rows[0].count),
    });
  } catch (err) {
    console.error('Issues list error:', err);
    res.status(500).json({ error: 'Failed to load issues' });
  }
});

function sendTelegramMessage(chatId: string | number, text: string, replyMarkup?: any): Promise<any> {
  const botToken = process.env.BOT_TOKEN || '';
  if (!botToken) return Promise.reject(new Error('BOT_TOKEN not set'));
  const payload: any = { chat_id: chatId, text, parse_mode: 'HTML' };
  if (replyMarkup) payload.reply_markup = JSON.stringify(replyMarkup);
  const body = JSON.stringify(payload);
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.telegram.org',
      path: `/bot${botToken}/sendMessage`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    }, (resp) => {
      let data = '';
      resp.on('data', (c: string) => { data += c; });
      resp.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.ok) resolve(parsed.result);
          else reject(new Error(parsed.description || 'Telegram API error'));
        } catch { reject(new Error('Invalid Telegram response')); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function cleanName(raw: string): string {
  return (raw || '').replace(/\{\d{5,32}\}/g, '').trim();
}

router.post('/issues/:id/send', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { key, note } = req.body;

    if (!key?.trim()) return res.status(400).json({ error: 'Key is required' });

    await client.query('BEGIN');

    const issueResult = await client.query(
      `SELECT * FROM fulfillment_issues WHERE id = $1 FOR UPDATE`,
      [id]
    );

    if (issueResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Issue not found' });
    }

    const issue = issueResult.rows[0];

    if (issue.status === 'sent' || issue.status === 'closed') {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Issue already resolved' });
    }

    if (issue.status === 'sending') {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Send already in progress' });
    }

    const orderCheck = await client.query(
      `SELECT status, delivered_at, amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at FROM orders WHERE id = $1`,
      [issue.order_id]
    );
    const order_row = orderCheck.rows[0];

    if (!order_row || order_row.status !== 'paid') {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Order status is "${order_row?.status || 'not found'}", expected "paid"` });
    }

    if (order_row.delivered_at) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Order already delivered' });
    }

    issue.order_status = order_row.status;
    issue.delivered_at = order_row.delivered_at;
    issue.order_amount = order_row.amount;
    issue.txn_ref = order_row.txn_ref;
    issue.gateway_txn_id = order_row.gateway_txn_id;
    issue.gateway_bank_txn_id = order_row.gateway_bank_txn_id;
    issue.verified_at = order_row.verified_at;

    await client.query(
      `UPDATE fulfillment_issues SET status = 'sending', send_attempts = send_attempts + 1, updated_at = NOW() WHERE id = $1`,
      [id]
    );

    await client.query('COMMIT');

    const keyValue = key.trim();
    const noteValue = (note || '').trim() || null;

    let sendSuccess = false;
    let sendError = '';

    try {
      const userRow = await pool.query(
        'SELECT id, telegram_id, username, first_name, last_name, reseller_id FROM users WHERE id = $1',
        [issue.user_id]
      );
      if (userRow.rows.length === 0) throw new Error('User not found');
      const user = userRow.rows[0];

      const orderRow = await pool.query(
        `SELECT o.*, c.name AS live_cat_name, d.name AS live_dur_name
         FROM orders o
         LEFT JOIN product_keys pk ON pk.id = o.key_id
         LEFT JOIN categories c ON COALESCE(pk.category_id, NULL) = c.id
         LEFT JOIN durations d ON COALESCE(pk.duration_id, NULL) = d.id
         WHERE o.id = $1`,
        [issue.order_id]
      );
      if (orderRow.rows.length === 0) throw new Error('Order not found');
      const order = orderRow.rows[0];

      const catName = cleanName(order.purchased_category_name || order.live_cat_name || 'Unknown');
      const durName = cleanName(order.purchased_duration_name || order.live_dur_name || 'Unknown');
      const amount = parseFloat(order.amount || '0').toFixed(2);

      const settingsResult = await pool.query(
        `SELECT key, value FROM bot_settings WHERE key IN ('msg_payment_verified_title','msg_key_label','currency_symbol','bot_btn_copy_key','brand_name','tpl_success_body')`,
      );
      const s: Record<string, string> = {};
      for (const row of settingsResult.rows) s[row.key] = row.value;

      const verifiedTitle = s['msg_payment_verified_title'] || '✅ Payment Verified!';
      const keyLabel = s['msg_key_label'] || 'Your Key';
      const currency = s['currency_symbol'] || '₹';
      const copyBtnText = s['bot_btn_copy_key'] || '📋 Copy Key';

      const firstName = (user.first_name || '').trim();
      const deliveryText = [
        `<b>${verifiedTitle}</b>`,
        '',
        `<b>${catName}</b> — ${durName}`,
        `Order: #${issue.order_id}`,
        `Amount: ${currency}${amount}`,
        '',
        `<b>${keyLabel}:</b>`,
        `<code>${keyValue}</code>`,
      ].join('\n');

      const replyMarkup = {
        inline_keyboard: [
          [{ text: copyBtnText, copy_text: { text: keyValue } }],
        ],
      };

      await sendTelegramMessage(user.telegram_id, deliveryText, replyMarkup);

      await pool.query(
        `UPDATE orders SET delivered_at = NOW(), purchased_key_value = $1 WHERE id = $2`,
        [keyValue, issue.order_id]
      );

      const isReseller = user.reseller_id ? 1 : 0;

      await pool.query(
        `INSERT INTO purchased_keys_history (
          user_id, order_id, telegram_id, username, first_name, last_name,
          is_reseller_purchase, category_name, duration_name, key_value,
          amount, txn_ref, gateway_txn_id, gateway_bank_txn_id, verified_at
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
        ON CONFLICT (order_id) DO UPDATE SET
          key_value = EXCLUDED.key_value,
          category_name = EXCLUDED.category_name,
          duration_name = EXCLUDED.duration_name`,
        [
          user.id, issue.order_id, user.telegram_id, user.username,
          user.first_name, user.last_name, isReseller,
          catName, durName, keyValue,
          order.amount || 0, order.txn_ref, order.gateway_txn_id,
          order.gateway_bank_txn_id, order.verified_at,
        ]
      );

      await pool.query(
        `INSERT INTO source_fulfillment_logs (
          order_id, category_id, duration_id, category_name, duration_name,
          source_type, delivery_success, key_value, delivered_source
        ) VALUES ($1, $2, $3, $4, $5, 'manual_recovery', true, $6, 'manual_recovery')`,
        [issue.order_id, issue.category_id, issue.duration_id, catName, durName, keyValue]
      );

      await pool.query(
        `UPDATE fulfillment_issues
         SET status = 'sent', recovery_key = $1, recovery_note = $2,
             resolved_at = NOW(), resolved_by = 'admin', updated_at = NOW(),
             last_send_error = NULL
         WHERE id = $3`,
        [keyValue, noteValue, id]
      );

      await logAudit('manual_recovery', 'issue', parseInt(id), `Order #${issue.order_id}`, {
        key_sent: keyValue,
        note: noteValue,
        telegram_id: user.telegram_id,
        username: user.username,
      });

      emitSSE('issue_changed');
      emitSSE('fulfillment_changed');

      sendSuccess = true;
    } catch (err: any) {
      sendError = err.message || 'Unknown error';
      await pool.query(
        `UPDATE fulfillment_issues SET status = 'open', last_send_error = $1, updated_at = NOW() WHERE id = $2`,
        [sendError, id]
      );
    }

    if (sendSuccess) {
      res.json({ success: true, message: 'Key sent and delivery recorded' });
    } else {
      res.status(500).json({ error: `Send failed: ${sendError}` });
    }
  } catch (err: any) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('Issue send error:', err);
    res.status(500).json({ error: 'Failed to send recovery key' });
  } finally {
    client.release();
  }
});

router.post('/issues/:id/close', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { note } = req.body;

    const result = await pool.query(
      `UPDATE fulfillment_issues
       SET status = 'closed', recovery_note = $1, resolved_at = NOW(), resolved_by = 'admin', updated_at = NOW()
       WHERE id = $2 AND status NOT IN ('sending')
       RETURNING id`,
      [(note || '').trim() || null, id]
    );

    if (result.rowCount === 0) return res.status(400).json({ error: 'Issue not found or cannot be closed' });

    await logAudit('issue_closed', 'issue', parseInt(id), `Issue #${id}`, { note: (note || '').trim() });
    emitSSE('issue_changed');

    res.json({ success: true });
  } catch (err) {
    console.error('Issue close error:', err);
    res.status(500).json({ error: 'Failed to close issue' });
  }
});

router.get('/issues/stats', async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE status = 'open') AS open_issues,
        COUNT(*) FILTER (WHERE status IN ('sent','closed') AND resolved_at > NOW() - INTERVAL '24 hours') AS recovered_today,
        COUNT(*) FILTER (WHERE status = 'failed') AS failed_sends,
        AVG(EXTRACT(EPOCH FROM (resolved_at - created_at)) / 60) FILTER (WHERE resolved_at IS NOT NULL) AS avg_recovery_min
      FROM fulfillment_issues
    `);
    const s = result.rows[0];
    res.json({
      open_issues: parseInt(s.open_issues) || 0,
      recovered_today: parseInt(s.recovered_today) || 0,
      failed_sends: parseInt(s.failed_sends) || 0,
      avg_recovery_min: s.avg_recovery_min ? Math.round(parseFloat(s.avg_recovery_min)) : null,
    });
  } catch (err) {
    console.error('Issue stats error:', err);
    res.status(500).json({ error: 'Failed to load issue stats' });
  }
});

export default router;
export { buildApiUrl, fetchUrl, emitSSE };
