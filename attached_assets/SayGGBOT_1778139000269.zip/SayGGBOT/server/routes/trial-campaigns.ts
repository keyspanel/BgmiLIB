import { Router, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { AuthenticatedRequest } from '../types';

const router = Router();
router.use(authMiddleware as any);

function safePagination(rawPage: string, rawLimit: string): { page: number; limit: number; offset: number } {
  const page = Math.max(1, parseInt(rawPage) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(rawLimit) || 50));
  return { page, limit, offset: (page - 1) * limit };
}

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(`
      SELECT tc.*,
        (SELECT COUNT(*) FROM trial_campaign_runs tcr WHERE tcr.campaign_id = tc.id) AS total_runs,
        st.name AS start_template_name,
        et.name AS expire_template_name,
        sc.name AS linked_promo_name
      FROM trial_campaigns tc
      LEFT JOIN campaign_templates st ON st.id = tc.start_template_id
      LEFT JOIN campaign_templates et ON et.id = tc.expire_template_id
      LEFT JOIN scheduled_campaigns sc ON sc.id = tc.linked_promo_campaign_id
      ORDER BY tc.created_at DESC
    `);
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/templates', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, name, template_type, category_id FROM campaign_templates WHERE template_type IN ('trial_start', 'trial_expire', 'trial_apk_caption') AND is_active = true ORDER BY template_type, name"
    );
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/apk-caption-templates', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(
      `SELECT DISTINCT ON (ct.category_id) ct.*,
         COALESCE(c.name, ct.category_name_snapshot, 'Deleted Category (ID ' || ct.category_id || ')') AS category_display_name,
         CASE WHEN c.id IS NULL THEN true ELSE false END AS is_orphaned
       FROM campaign_templates ct
       LEFT JOIN categories c ON c.id = ct.category_id
       WHERE ct.template_type = 'trial_apk_caption' AND ct.is_active = true
       ORDER BY ct.category_id, ct.updated_at DESC`
    );
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/apk-caption-templates', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { category_id, body_text, inline_buttons_json, name } = req.body;
    if (!category_id) return res.status(400).json({ error: 'category_id required' });
    const catRow = await pool.query('SELECT name FROM categories WHERE id = $1', [category_id]);
    const catName = catRow.rows[0]?.name || null;
    const cleanedCatName = catName ? cleanEmojiName(catName) : `Category ${category_id}`;
    const tplName = name || `APK Caption — ${cleanedCatName}`;
    const { rows: existing } = await pool.query(
      "SELECT id FROM campaign_templates WHERE template_type = 'trial_apk_caption' AND category_id = $1 AND is_active = true",
      [category_id]
    );
    if (existing.length > 0) {
      await pool.query(
        "UPDATE campaign_templates SET is_active = false WHERE id = ANY($1::int[])",
        [existing.map((r: any) => r.id)]
      );
    }
    const { rows } = await pool.query(
      `INSERT INTO campaign_templates
         (name, template_type, category_id, category_name_snapshot, body_text, parse_mode, inline_buttons_json, is_active, edited_via, updated_by)
       VALUES ($1, 'trial_apk_caption', $2, $3, $4, 'HTML', $5, true, 'web', 'web') RETURNING *`,
      [tplName, category_id, catName, body_text || '', inline_buttons_json || null]
    );
    res.json(rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.delete('/apk-caption-templates/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      "DELETE FROM campaign_templates WHERE id = $1 AND template_type = 'trial_apk_caption' RETURNING id",
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: 'APK caption template not found' });
    res.json({ deleted: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.put('/apk-caption-templates/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { body_text, inline_buttons_json, name, is_active } = req.body;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows: [old] } = await client.query(
        "SELECT body_text, inline_buttons_json, template_type FROM campaign_templates WHERE id = $1", [req.params.id]
      );
      if (!old) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Template not found' });
      }
      if (old.template_type !== 'trial_apk_caption') {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Not an APK caption template' });
      }
      await client.query(
          `INSERT INTO template_versions (template_id, body_text, inline_buttons_json, changed_by, changed_via, change_note)
           VALUES ($1, $2, $3, 'web', 'web', 'updated apk caption via admin panel')`,
          [req.params.id, old.body_text || '', old.inline_buttons_json || null]
        );
      const updates: string[] = ['updated_at = NOW()', "edited_via = 'web'", "updated_by = 'web'"];
      const params: any[] = [];
      let idx = 1;
      if (body_text !== undefined) { updates.push(`body_text = $${idx++}`); params.push(body_text); }
      if (inline_buttons_json !== undefined) { updates.push(`inline_buttons_json = $${idx++}`); params.push(inline_buttons_json || null); }
      if (name !== undefined) { updates.push(`name = $${idx++}`); params.push(name); }
      if (is_active !== undefined) { updates.push(`is_active = $${idx++}`); params.push(is_active); }
      params.push(req.params.id);
      const { rows } = await client.query(
        `UPDATE campaign_templates SET ${updates.join(', ')} WHERE id = $${idx} RETURNING *`, params
      );
      await client.query('COMMIT');
      res.json(rows[0]);
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/seed-apk-caption-defaults', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows: cats } = await pool.query('SELECT id, name FROM categories ORDER BY id');
    let seeded = 0;
    const defaultCaption = '📦 <b>{category_name}</b>\n🔑 Key: <code>{trial_key}</code>\n\n⏱ Duration: <b>{trial_duration}h</b>\n⏰ Expires: <b>{expire_time}</b>';
    for (const cat of cats) {
      const { rows: existing } = await pool.query(
        "SELECT id FROM campaign_templates WHERE template_type = 'trial_apk_caption' AND category_id = $1 LIMIT 1",
        [cat.id]
      );
      if (existing.length === 0) {
        const cleanedName = (cat.name || '').replace(/\{\d{5,32}\}/, '').trim().replace(/\s+/g, ' ');
        await pool.query(
          `INSERT INTO campaign_templates (name, template_type, category_id, body_text, parse_mode, is_active, edited_via, updated_by)
           VALUES ($1, 'trial_apk_caption', $2, $3, 'HTML', true, 'system', 'system')`,
          [`APK Caption — ${cleanedName}`, cat.id, defaultCaption]
        );
        seeded++;
      }
    }
    res.json({ seeded, message: seeded > 0 ? `Seeded ${seeded} APK caption templates` : 'All categories already have caption templates' });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/categories-with-media', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, name, file_id FROM categories ORDER BY name`
    );
    const result = rows.map((r: any) => ({
      id: r.id,
      name: cleanEmojiName(r.name),
      has_apk: !!(r.file_id && r.file_id.trim()),
      file_id: (r.file_id && r.file_id.trim()) || null,
    }));
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/inventory-check', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const categoryIds = (req.query.category_ids as string || '').split(',').map(Number).filter(n => n > 0);
    const durationHours = parseInt(req.query.duration_hours as string) || 0;

    if (!categoryIds.length || !durationHours) {
      return res.status(400).json({ error: 'category_ids and duration_hours required' });
    }

    const results: any[] = [];
    for (const catId of categoryIds) {
      const { rows } = await pool.query(
        `SELECT COUNT(*) AS available FROM trial_keys
         WHERE category_id = $1 AND duration_hours = $2 AND status = 'available'`,
        [catId, durationHours]
      );
      const catRow = await pool.query('SELECT name FROM categories WHERE id = $1', [catId]);
      const catName = catRow.rows[0]?.name || null;
      const isOrphaned = !catName;
      const snapshotQuery = isOrphaned
        ? await pool.query("SELECT category_name_snapshot FROM trial_keys WHERE category_id = $1 AND category_name_snapshot IS NOT NULL LIMIT 1", [catId])
        : { rows: [] };
      const displayName = catName || snapshotQuery.rows[0]?.category_name_snapshot || `Deleted Category (ID ${catId})`;
      results.push({
        category_id: catId,
        category_name: displayName,
        categoryDisplayName: cleanEmojiName(displayName),
        is_orphaned: isOrphaned,
        duration_hours: durationHours,
        available: parseInt(rows[0].available),
      });
    }
    res.json(results);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/runs/all', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { campaign_id, status, page: rawPage = '1', limit: rawLimit = '50' } = req.query as Record<string, string>;
    const pg = safePagination(rawPage, rawLimit);
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;
    if (parseInt(campaign_id) > 0) { where.push(`tcr.campaign_id = $${idx++}`); params.push(parseInt(campaign_id)); }
    if (status) { where.push(`tcr.status = $${idx++}`); params.push(status); }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const countRes = await pool.query(`SELECT COUNT(*) AS total FROM trial_campaign_runs tcr ${whereClause}`, params);
    const total = parseInt(countRes.rows[0].total);
    const { rows } = await pool.query(`
      SELECT tcr.*, tc.name AS campaign_name,
        (SELECT json_agg(json_build_object(
          'category_id', rk.category_id, 'key_value_snapshot', rk.key_value_snapshot,
          'duration_hours', rk.duration_hours, 'max_devices', rk.max_devices,
          'category_name', COALESCE(c.name, rk.category_name_snapshot, 'Deleted Category (ID ' || rk.category_id || ')'),
          'is_orphaned', CASE WHEN c.id IS NULL THEN true ELSE false END
        )) FROM trial_campaign_run_keys rk
        LEFT JOIN categories c ON c.id = rk.category_id
        WHERE rk.run_id = tcr.id) AS run_keys
      FROM trial_campaign_runs tcr
      LEFT JOIN trial_campaigns tc ON tc.id = tcr.campaign_id
      ${whereClause}
      ORDER BY tcr.started_at DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `, [...params, pg.limit, pg.offset]);
    const result = rows.map((r: any) => ({
      ...r,
      run_keys: (r.run_keys || []).map((rk: any) => ({ ...rk, categoryDisplayName: cleanEmojiName(rk.category_name) })),
    }));
    res.json({ runs: result, total, page: pg.page, totalPages: Math.ceil(total / pg.limit) });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/delivery-logs', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { run_id, campaign_id, target_type, delivery_status, page: rawPage = '1', limit: rawLimit = '50' } = req.query as Record<string, string>;
    const pg = safePagination(rawPage, rawLimit);
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;
    if (parseInt(run_id) > 0) { where.push(`dl.run_id = $${idx++}`); params.push(parseInt(run_id)); }
    if (parseInt(campaign_id) > 0) { where.push(`dl.campaign_id = $${idx++}`); params.push(parseInt(campaign_id)); }
    if (target_type) { where.push(`dl.target_type = $${idx++}`); params.push(target_type); }
    if (delivery_status) { where.push(`dl.delivery_status = $${idx++}`); params.push(delivery_status); }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const countRes = await pool.query(`SELECT COUNT(*) AS total FROM trial_campaign_delivery_logs dl ${whereClause}`, params);
    const total = parseInt(countRes.rows[0].total);
    const { rows } = await pool.query(`
      SELECT dl.*, tc.name AS campaign_name, u.first_name, u.username
      FROM trial_campaign_delivery_logs dl
      LEFT JOIN trial_campaigns tc ON tc.id = dl.campaign_id
      LEFT JOIN users u ON u.telegram_id = dl.telegram_id
      ${whereClause}
      ORDER BY dl.created_at DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `, [...params, pg.limit, pg.offset]);
    res.json({ logs: rows, total, page: pg.page, totalPages: Math.ceil(total / pg.limit) });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/inventory-usage', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { campaign_id, page: rawPage = '1', limit: rawLimit = '50' } = req.query as Record<string, string>;
    const pg = safePagination(rawPage, rawLimit);
    const where: string[] = [];
    const params: any[] = [];
    let idx = 1;
    if (parseInt(campaign_id) > 0) { where.push(`rk.campaign_id = $${idx++}`); params.push(parseInt(campaign_id)); }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const countRes = await pool.query(`SELECT COUNT(*) AS total FROM trial_campaign_run_keys rk ${whereClause}`, params);
    const total = parseInt(countRes.rows[0].total);
    const { rows } = await pool.query(`
      SELECT rk.*,
        COALESCE(c.name, rk.category_name_snapshot, 'Deleted Category (ID ' || rk.category_id || ')') AS category_name,
        CASE WHEN c.id IS NULL THEN true ELSE false END AS is_orphaned,
        tc.name AS campaign_name,
        tcr.run_type, tcr.started_at AS run_started_at
      FROM trial_campaign_run_keys rk
      LEFT JOIN categories c ON c.id = rk.category_id
      LEFT JOIN trial_campaigns tc ON tc.id = rk.campaign_id
      LEFT JOIN trial_campaign_runs tcr ON tcr.id = rk.run_id
      ${whereClause}
      ORDER BY rk.created_at DESC
      LIMIT $${idx++} OFFSET $${idx++}
    `, [...params, pg.limit, pg.offset]);
    const result = rows.map((r: any) => ({ ...r, categoryDisplayName: cleanEmojiName(r.category_name), is_orphaned: r.is_orphaned }));
    res.json({ usage: result, total, page: pg.page, totalPages: Math.ceil(total / pg.limit) });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/estimate-recipients', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const audience = (req.query.target_audience as string) || 'all_users';
    let query = '';
    if (audience === 'all_users') query = 'SELECT COUNT(*) AS c FROM users WHERE is_banned = 0';
    else if (audience === 'paid_users') query = "SELECT COUNT(DISTINCT u.id) AS c FROM users u JOIN orders o ON o.user_id = u.id WHERE u.is_banned = 0 AND o.status IN ('paid','completed','delivered')";
    else if (audience === 'active_users') query = "SELECT COUNT(*) AS c FROM users WHERE is_banned = 0 AND created_at >= NOW() - INTERVAL '30 days'";
    else if (audience === 'resellers') query = 'SELECT COUNT(*) AS c FROM users WHERE is_banned = 0 AND reseller_id IS NOT NULL';
    else if (audience === 'purchasers') query = "SELECT COUNT(DISTINCT u.id) AS c FROM users u JOIN orders o ON o.user_id = u.id WHERE u.is_banned = 0 AND o.status = 'delivered'";
    else if (audience === 'channels') query = 'SELECT 0 AS c';
    else query = 'SELECT COUNT(*) AS c FROM users WHERE is_banned = 0';
    const { rows } = await pool.query(query);
    const channelIds = ((req.query.channel_ids as string) || '').split(',').map(Number).filter(n => n > 0);
    let channelCount = 0;
    if (channelIds.length) {
      const cr = await pool.query('SELECT COUNT(*) AS c FROM configured_channels WHERE id = ANY($1::int[]) AND is_enabled = true AND is_validated = true', [channelIds]);
      channelCount = parseInt(cr.rows[0].c);
    }
    res.json({ users: parseInt(rows[0].c), channels: channelCount });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/seed-defaults', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const defaults = [
      {
        name: 'Default Trial Start',
        template_type: 'trial_start',
        body_text: '🎉 <b>Free Trial Activated!</b>\n\nHey {user_name}, your trial has been activated!\n\n{TrialCategoryBlocks}\n\n⏱ Duration: <b>{trial_duration} hours</b>\n📱 Devices: <b>{trial_devices}</b>\n⏰ Expires: <b>{expire_time}</b>\n\nEnjoy your trial from <b>{bot_name}</b>!',
        parse_mode: 'HTML',
      },
      {
        name: 'Default Trial Expire',
        template_type: 'trial_expire',
        body_text: '⏰ <b>Trial Expired</b>\n\nHey {user_name}, your trial for <b>{campaign_name}</b> has expired.\n\nWant to continue? Purchase a full key from <b>{bot_name}</b>!',
        parse_mode: 'HTML',
      },
    ];
    let seeded = 0;
    for (const d of defaults) {
      const { rows } = await pool.query(
        'SELECT id FROM campaign_templates WHERE name = $1 AND template_type = $2 LIMIT 1',
        [d.name, d.template_type]
      );
      if (rows.length === 0) {
        await pool.query(
          'INSERT INTO campaign_templates (name, template_type, body_text, parse_mode, is_active) VALUES ($1, $2, $3, $4, true)',
          [d.name, d.template_type, d.body_text, d.parse_mode]
        );
        seeded++;
      }
    }
    const defaultApkCaption = '📦 <b>{category_name}</b>\n🔑 Key: <code>{trial_key}</code>\n\n⏱ Duration: <b>{trial_duration}h</b>\n⏰ Expires: <b>{expire_time}</b>';
    const { rows: cats } = await pool.query('SELECT id, name FROM categories ORDER BY id');
    for (const cat of cats) {
      const { rows: existingApk } = await pool.query(
        "SELECT id FROM campaign_templates WHERE template_type = 'trial_apk_caption' AND category_id = $1 LIMIT 1",
        [cat.id]
      );
      if (existingApk.length === 0) {
        const cleanedName = (cat.name || '').replace(/\{\d{5,32}\}/, '').trim().replace(/\s+/g, ' ');
        await pool.query(
          `INSERT INTO campaign_templates (name, template_type, category_id, body_text, parse_mode, is_active, edited_via, updated_by)
           VALUES ($1, 'trial_apk_caption', $2, $3, 'HTML', true, 'system', 'system')`,
          [`APK Caption — ${cleanedName}`, cat.id, defaultApkCaption]
        );
        seeded++;
      }
    }
    res.json({ seeded, message: seeded > 0 ? `Seeded ${seeded} default templates` : 'Defaults already exist' });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(`
      SELECT tc.*,
        (SELECT COUNT(*) FROM trial_campaign_runs tcr WHERE tcr.campaign_id = tc.id) AS total_runs,
        st.name AS start_template_name,
        et.name AS expire_template_name,
        sc.name AS linked_promo_name
      FROM trial_campaigns tc
      LEFT JOIN campaign_templates st ON st.id = tc.start_template_id
      LEFT JOIN campaign_templates et ON et.id = tc.expire_template_id
      LEFT JOIN scheduled_campaigns sc ON sc.id = tc.linked_promo_campaign_id
      WHERE tc.id = $1
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Trial campaign not found' });
    res.json(rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id/runs', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows: runs } = await pool.query(
      `SELECT tcr.*,
        (SELECT json_agg(json_build_object(
          'category_id', rk.category_id,
          'key_value_snapshot', rk.key_value_snapshot,
          'duration_hours', rk.duration_hours,
          'max_devices', rk.max_devices,
          'category_name', COALESCE(c.name, rk.category_name_snapshot, 'Deleted Category (ID ' || rk.category_id || ')'),
          'is_orphaned', CASE WHEN c.id IS NULL THEN true ELSE false END
        )) FROM trial_campaign_run_keys rk
        LEFT JOIN categories c ON c.id = rk.category_id
        WHERE rk.run_id = tcr.id) AS run_keys
       FROM trial_campaign_runs tcr
       WHERE tcr.campaign_id = $1
       ORDER BY tcr.started_at DESC
       LIMIT 50`,
      [req.params.id]
    );
    const result = runs.map((r: any) => ({
      ...r,
      run_keys: (r.run_keys || []).map((rk: any) => ({
        ...rk,
        categoryDisplayName: cleanEmojiName(rk.category_name),
      })),
    }));
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      name, description, category_ids, trial_duration_hours, max_devices,
      repeat_mode, timezone, start_at, expire_at,
      start_template_id, expire_template_id,
      send_to_users, send_to_channels, channel_targets_json,
      reveal_keys_in_channels, linked_promo_campaign_id,
      target_audience, apk_delivery_config_json, delivery_mode,
    } = req.body;

    if (!name) return res.status(400).json({ error: 'Name is required' });
    if (!category_ids || !category_ids.length) return res.status(400).json({ error: 'At least one category required' });
    if (!trial_duration_hours || trial_duration_hours < 1) return res.status(400).json({ error: 'Trial duration hours required' });

    const apkCfg = apk_delivery_config_json != null
      ? (typeof apk_delivery_config_json === 'string' ? apk_delivery_config_json : JSON.stringify(apk_delivery_config_json))
      : null;
    const validModes = ['mode_1_separate', 'mode_2_single_combined', 'mode_3_combined_plus_summary'];
    const safeMode = validModes.includes(delivery_mode) ? delivery_mode : 'mode_1_separate';

    const catNameSnaps: {id: number, name: string}[] = [];
    for (const cid of category_ids) {
      const cr = await pool.query('SELECT name FROM categories WHERE id = $1', [cid]);
      catNameSnaps.push({ id: cid, name: cr.rows[0]?.name || `Deleted Category (ID ${cid})` });
    }

    const { rows } = await pool.query(
      `INSERT INTO trial_campaigns
        (name, description, category_ids_json, category_names_snapshot_json, trial_duration_hours, max_devices,
         repeat_mode, timezone, start_at, expire_at, next_run_at, next_expire_at,
         start_template_id, expire_template_id,
         send_to_users, send_to_channels, channel_targets_json,
         reveal_keys_in_channels, linked_promo_campaign_id, target_audience,
         apk_delivery_config_json, delivery_mode)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
       RETURNING *`,
      [
        name, description || '', JSON.stringify(category_ids), JSON.stringify(catNameSnaps),
        trial_duration_hours, max_devices || null,
        repeat_mode || 'once', timezone || 'Asia/Kolkata', start_at, expire_at,
        start_template_id || null, expire_template_id || null,
        send_to_users !== false, send_to_channels || false,
        JSON.stringify(channel_targets_json || []),
        reveal_keys_in_channels || false, linked_promo_campaign_id || null,
        target_audience || 'all_users',
        apkCfg, safeMode,
      ]
    );
    res.json(rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.put('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const {
      name, description, category_ids, trial_duration_hours, max_devices,
      repeat_mode, timezone, start_at, expire_at,
      start_template_id, expire_template_id,
      send_to_users, send_to_channels, channel_targets_json,
      reveal_keys_in_channels, linked_promo_campaign_id,
      target_audience, is_enabled, status,
    } = req.body;

    const updates: string[] = [];
    const params: any[] = [];
    let idx = 1;

    if (name !== undefined) { updates.push(`name = $${idx++}`); params.push(name); }
    if (description !== undefined) { updates.push(`description = $${idx++}`); params.push(description); }
    if (category_ids !== undefined) {
      updates.push(`category_ids_json = $${idx++}`); params.push(JSON.stringify(category_ids));
      const catNameSnaps: {id: number, name: string}[] = [];
      for (const cid of category_ids) {
        const cr = await pool.query('SELECT name FROM categories WHERE id = $1', [cid]);
        catNameSnaps.push({ id: cid, name: cr.rows[0]?.name || `Deleted Category (ID ${cid})` });
      }
      updates.push(`category_names_snapshot_json = $${idx++}`); params.push(JSON.stringify(catNameSnaps));
    }
    if (trial_duration_hours !== undefined) { updates.push(`trial_duration_hours = $${idx++}`); params.push(trial_duration_hours); }
    if (max_devices !== undefined) { updates.push(`max_devices = $${idx++}`); params.push(max_devices || null); }
    if (repeat_mode !== undefined) { updates.push(`repeat_mode = $${idx++}`); params.push(repeat_mode); }
    if (timezone !== undefined) { updates.push(`timezone = $${idx++}`); params.push(timezone); }
    if (start_at !== undefined) { updates.push(`start_at = $${idx++}`); params.push(start_at); updates.push(`next_run_at = $${idx++}`); params.push(start_at); }
    if (expire_at !== undefined) { updates.push(`expire_at = $${idx++}`); params.push(expire_at); updates.push(`next_expire_at = $${idx++}`); params.push(expire_at); }
    if (start_template_id !== undefined) { updates.push(`start_template_id = $${idx++}`); params.push(start_template_id || null); }
    if (expire_template_id !== undefined) { updates.push(`expire_template_id = $${idx++}`); params.push(expire_template_id || null); }
    if (send_to_users !== undefined) { updates.push(`send_to_users = $${idx++}`); params.push(send_to_users); }
    if (send_to_channels !== undefined) { updates.push(`send_to_channels = $${idx++}`); params.push(send_to_channels); }
    if (channel_targets_json !== undefined) { updates.push(`channel_targets_json = $${idx++}`); params.push(JSON.stringify(channel_targets_json)); }
    if (reveal_keys_in_channels !== undefined) { updates.push(`reveal_keys_in_channels = $${idx++}`); params.push(reveal_keys_in_channels); }
    if (linked_promo_campaign_id !== undefined) { updates.push(`linked_promo_campaign_id = $${idx++}`); params.push(linked_promo_campaign_id || null); }
    if (target_audience !== undefined) { updates.push(`target_audience = $${idx++}`); params.push(target_audience); }
    if (is_enabled !== undefined) { updates.push(`is_enabled = $${idx++}`); params.push(is_enabled); }
    if (status !== undefined) { updates.push(`status = $${idx++}`); params.push(status); }
    if (req.body.apk_delivery_config_json !== undefined) {
      const apkCfg = req.body.apk_delivery_config_json != null
        ? (typeof req.body.apk_delivery_config_json === 'string' ? req.body.apk_delivery_config_json : JSON.stringify(req.body.apk_delivery_config_json))
        : null;
      updates.push(`apk_delivery_config_json = $${idx++}`); params.push(apkCfg);
    }
    if (req.body.delivery_mode !== undefined) {
      const validModes = ['mode_1_separate', 'mode_2_single_combined', 'mode_3_combined_plus_summary'];
      if (validModes.includes(req.body.delivery_mode)) {
        updates.push(`delivery_mode = $${idx++}`); params.push(req.body.delivery_mode);
      }
    }

    updates.push('updated_at = NOW()');
    params.push(id);

    const { rows } = await pool.query(
      `UPDATE trial_campaigns SET ${updates.join(', ')} WHERE id = $${idx} RETURNING *`,
      params
    );
    if (!rows.length) return res.status(404).json({ error: 'Trial campaign not found' });
    res.json(rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.delete('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query('DELETE FROM trial_campaigns WHERE id = $1 RETURNING id', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Trial campaign not found' });
    res.json({ deleted: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
