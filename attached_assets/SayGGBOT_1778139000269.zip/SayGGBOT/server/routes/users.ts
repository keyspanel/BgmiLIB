import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const BOT_TOKEN = process.env.BOT_TOKEN || '';
const TG_FILE_PREFIX = `https://api.telegram.org/file/bot`;

function extractRelativePath(stored: string): string {
  if (!stored) return '';
  const idx = stored.indexOf('/photos/');
  if (idx !== -1) return stored.substring(idx + 1);
  if (stored.startsWith('http')) {
    const match = stored.match(/\/file\/bot[^/]+\/(.+)$/);
    if (match) return match[1];
  }
  return stored;
}

export function tgPhotoProxyUrl(filePath: string | null | undefined): string | null {
  if (!filePath) return null;
  const rel = extractRelativePath(filePath);
  if (!rel) return null;
  return `/api/users/photo?p=${encodeURIComponent(rel)}`;
}

const router = express.Router();
router.use(authMiddleware);

router.get('/', async (req: Request, res: Response) => {
  try {
    const search = ((req.query.search as string) || '').trim();
    let sql = 'SELECT * FROM users';
    const params: any[] = [];
    if (search) {
      sql += ' WHERE username ILIKE $1 OR first_name ILIKE $1 OR last_name ILIKE $1 OR CAST(telegram_id AS TEXT) ILIKE $1';
      params.push(`%${search}%`);
    }
    sql += ' ORDER BY id DESC';
    const result = await pool.query(sql, params);
    res.json(result.rows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) })));
  } catch (err) {
    console.error('Users list error:', err);
    res.status(500).json({ error: 'Failed to load users' });
  }
});

router.put('/:id/ban', async (req: Request, res: Response) => {
  try {
    await pool.query('UPDATE users SET is_banned = 1 WHERE id = $1', [req.params.id]);
    res.json({ message: 'User banned' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to ban user' });
  }
});

router.put('/:id/unban', async (req: Request, res: Response) => {
  try {
    await pool.query('UPDATE users SET is_banned = 0 WHERE id = $1', [req.params.id]);
    res.json({ message: 'User unbanned' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to unban user' });
  }
});

export default router;
