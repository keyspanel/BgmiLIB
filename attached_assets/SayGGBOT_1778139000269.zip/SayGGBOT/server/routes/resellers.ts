import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { PoolClient } from 'pg';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): string {
  raw = (raw || '').trim();
  raw = raw.replace(/\{\d{5,32}\}/, '');
  return raw.trim().replace(/\s+/g, ' ');
}

async function generateUniqueCode(): Promise<string> {
  let code: string;
  let exists = true;
  while (exists) {
    code = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
    const result = await pool.query('SELECT COUNT(*) AS c FROM resellers WHERE code = $1', [code]);
    exists = parseInt(result.rows[0].c) > 0;
  }
  return code!;
}

async function insertPricingRules(client: PoolClient, resellerId: number, body: any): Promise<void> {
  const { apply_scope = 'all_categories', rule_mode = 'percent', category_id, rule_value = 0, duration_prices = {}, category_rules = {}, selected_categories = [], category_duration_prices = {} } = body;
  const ruleValue = Math.max(0, parseFloat(rule_value) || 0);

  if (rule_mode === 'custom_prices' && apply_scope === 'per_categories') {
    const selCats = (Array.isArray(selected_categories) ? selected_categories : []).map((id: any) => parseInt(id)).filter((id: number) => id > 0);
    if (selCats.length === 0) return;
    const validDurs = await client.query('SELECT id, category_id FROM durations WHERE category_id = ANY($1::int[])', [selCats]);
    const validSet = new Set(validDurs.rows.map((d: any) => `${d.category_id}_${d.id}`));
    for (const catIdStr of Object.keys(category_duration_prices)) {
      const catId = parseInt(catIdStr);
      if (!selCats.includes(catId)) continue;
      const durMap = category_duration_prices[catIdStr] || {};
      for (const [durIdStr, priceVal] of Object.entries(durMap)) {
        const durId = parseInt(durIdStr);
        if (!validSet.has(`${catId}_${durId}`)) continue;
        const pv = (priceVal === '' || priceVal === null || priceVal === undefined) ? null : parseFloat(priceVal as string);
        if (pv === null || isNaN(pv) || pv < 0) continue;
        await client.query(
          'INSERT INTO reseller_prices (reseller_id, category_id, duration_id, price, discount_type, discount_value) VALUES ($1, $2, $3, $4, $5, $6)',
          [resellerId, catId, durId, pv, null, null]
        );
      }
    }
  } else if (rule_mode === 'custom_prices' && category_id) {
    const validDurs = await client.query('SELECT id FROM durations WHERE category_id = $1', [category_id]);
    const validMap = new Set(validDurs.rows.map((d: any) => d.id));
    for (const [durId, priceValue] of Object.entries(duration_prices)) {
      if (!validMap.has(parseInt(durId)) || priceValue === '') continue;
      await client.query(
        'INSERT INTO reseller_prices (reseller_id, category_id, duration_id, price, discount_type, discount_value) VALUES ($1, $2, $3, $4, $5, $6)',
        [resellerId, category_id, parseInt(durId), Math.max(0, parseFloat(priceValue as string)), null, null]
      );
    }
  } else if (apply_scope === 'per_categories') {
    const allCats = await client.query('SELECT id FROM categories ORDER BY sort_order ASC, id ASC');
    for (const cat of allCats.rows) {
      const inputValue = (category_rules[cat.id] || '').toString().trim();
      if (!inputValue) continue;
      const valueFloat = Math.max(0, parseFloat(inputValue));
      const price = rule_mode === 'price' ? valueFloat : null;
      const discountType = rule_mode === 'percent' ? 'percent' : rule_mode === 'fixed' ? 'fixed' : null;
      const discountValue = (rule_mode === 'percent' || rule_mode === 'fixed') ? valueFloat : null;
      await client.query(
        'INSERT INTO reseller_prices (reseller_id, category_id, duration_id, price, discount_type, discount_value) VALUES ($1, $2, $3, $4, $5, $6)',
        [resellerId, cat.id, null, price, discountType, discountValue]
      );
    }
  } else {
    const price = rule_mode === 'price' ? ruleValue : null;
    const discountType = rule_mode === 'percent' ? 'percent' : rule_mode === 'fixed' ? 'fixed' : null;
    const discountValue = (rule_mode === 'percent' || rule_mode === 'fixed') ? ruleValue : null;
    await client.query(
      'INSERT INTO reseller_prices (reseller_id, category_id, duration_id, price, discount_type, discount_value) VALUES ($1, $2, $3, $4, $5, $6)',
      [resellerId, apply_scope === 'one_category' ? category_id : null, null, price, discountType, discountValue]
    );
  }
}

router.get('/categories', async (req: Request, res: Response) => {
  try {
    const result = await pool.query('SELECT id, name FROM categories ORDER BY sort_order ASC, id ASC');
    res.json(result.rows.map((c: any) => ({ ...c, displayName: cleanEmojiName(c.name) })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load categories' });
  }
});

router.get('/durations', async (req: Request, res: Response) => {
  try {
    const result = await pool.query('SELECT id, category_id, name, price FROM durations ORDER BY category_id ASC, sort_order ASC, id ASC');
    res.json(result.rows.map((d: any) => ({ ...d, displayName: cleanEmojiName(d.name) })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load durations' });
  }
});

router.get('/', async (req: Request, res: Response) => {
  try {
    const search = ((req.query.search as string) || '').trim();
    let sql = `
      SELECT r.*,
        (SELECT COUNT(*) FROM reseller_users ru WHERE ru.reseller_id = r.id) AS used_count
      FROM resellers r
    `;
    const params: any[] = [];
    if (search) {
      sql += ` WHERE r.code ILIKE $1 OR EXISTS (
        SELECT 1 FROM reseller_users ru JOIN users u ON ru.user_id = u.id
        WHERE ru.reseller_id = r.id AND (
          CAST(u.telegram_id AS TEXT) ILIKE $1 OR u.username ILIKE $1 OR u.first_name ILIKE $1 OR u.last_name ILIKE $1
        )
      )`;
      params.push(`%${search}%`);
    }
    sql += ' ORDER BY r.id DESC';
    const resellers = await pool.query(sql, params);

    const allRules = await pool.query(`
      SELECT rp.*, c.name AS category_name, d.name AS duration_name
      FROM reseller_prices rp
      LEFT JOIN categories c ON rp.category_id = c.id
      LEFT JOIN durations d ON rp.duration_id = d.id
      ORDER BY rp.id ASC
    `);

    const usedUsers = await pool.query(`
      SELECT ru.reseller_id, ru.assigned_at, u.telegram_id, u.username, u.first_name, u.last_name
      FROM reseller_users ru
      JOIN users u ON ru.user_id = u.id
      ORDER BY ru.assigned_at DESC
    `);

    const rulesByReseller: Record<number, any[]> = {};
    allRules.rows.forEach((r: any) => {
      if (!rulesByReseller[r.reseller_id]) rulesByReseller[r.reseller_id] = [];
      rulesByReseller[r.reseller_id].push({
        ...r,
        categoryDisplayName: cleanEmojiName(r.category_name),
        durationDisplayName: cleanEmojiName(r.duration_name),
      });
    });

    const usersByReseller: Record<number, any[]> = {};
    usedUsers.rows.forEach((u: any) => {
      if (!usersByReseller[u.reseller_id]) usersByReseller[u.reseller_id] = [];
      usersByReseller[u.reseller_id].push(u);
    });

    const result = resellers.rows.map((r: any) => ({
      ...r,
      rules: rulesByReseller[r.id] || [],
      users: usersByReseller[r.id] || [],
    }));

    res.json(result);
  } catch (err) {
    console.error('Resellers list error:', err);
    res.status(500).json({ error: 'Failed to load resellers' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { expires_at, max_users } = req.body;
    const expiresAt = expires_at ? new Date(expires_at).toISOString() : null;
    const maxUsers = max_users !== '' && max_users !== null && max_users !== undefined ? parseInt(max_users) : null;

    await client.query('BEGIN');
    const code = await generateUniqueCode();
    const ins = await client.query(
      'INSERT INTO resellers (code, expires_at, max_users, total_price, discount_type, discount_value) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
      [code, expiresAt, maxUsers, null, 'percent', 0]
    );
    const resellerId = ins.rows[0].id;

    await insertPricingRules(client, resellerId, req.body);

    await client.query('COMMIT');
    res.json({ id: resellerId, code, message: 'Reseller code created successfully' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Reseller create error:', err);
    res.status(500).json({ error: 'Failed to create reseller code' });
  } finally {
    client.release();
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const resellerId = parseInt(req.params.id);
    const { expires_at, max_users } = req.body;
    const expiresAt = expires_at ? new Date(expires_at).toISOString() : null;
    const maxUsers = max_users !== '' && max_users !== null && max_users !== undefined ? parseInt(max_users) : null;

    await client.query('BEGIN');

    await client.query('UPDATE resellers SET expires_at = $1, max_users = $2, total_price = $3, discount_type = $4, discount_value = $5 WHERE id = $6',
      [expiresAt, maxUsers, null, 'percent', 0, resellerId]);

    await client.query('DELETE FROM reseller_prices WHERE reseller_id = $1', [resellerId]);

    await insertPricingRules(client, resellerId, req.body);

    await client.query('COMMIT');
    res.json({ message: 'Reseller updated successfully' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Reseller update error:', err);
    res.status(500).json({ error: 'Failed to update reseller' });
  } finally {
    client.release();
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    await pool.query('DELETE FROM reseller_prices WHERE reseller_id = $1', [id]);
    await pool.query('DELETE FROM reseller_users WHERE reseller_id = $1', [id]);
    await pool.query('DELETE FROM resellers WHERE id = $1', [id]);
    res.json({ message: 'Reseller deleted successfully' });
  } catch (err) {
    console.error('Reseller delete error:', err);
    res.status(500).json({ error: 'Failed to delete reseller' });
  }
});

export default router;
