import { Router, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';
import { AuthenticatedRequest } from '../types';
import { tgPhotoProxyUrl } from './users';
import crypto from 'crypto';

const router = Router();
router.use(authMiddleware as any);

let _channelColAdded = false;
async function ensureChannelTargetsCol() {
  if (_channelColAdded) return;
  try {
    await pool.query(`ALTER TABLE scheduled_campaigns ADD COLUMN IF NOT EXISTS channel_targets_json TEXT DEFAULT '[]'`);
    _channelColAdded = true;
  } catch { _channelColAdded = true; }
}

function generateCode(): string {
  return 'promo_' + crypto.randomBytes(4).toString('hex');
}

async function bumpDiscountCacheVersion(): Promise<void> {
  try {
    await pool.query(
      `INSERT INTO bot_settings (key, value) VALUES ('_discount_cache_version', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1`,
      [Date.now().toString()]
    );
  } catch (err: any) {
    console.error('Campaign: failed to bump discount cache version:', err.message);
  }
}

router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(`
      SELECT sc.*,
        (SELECT COUNT(*) FROM campaign_runs cr WHERE cr.campaign_id = sc.id) AS total_runs,
        (SELECT COUNT(*) FROM campaign_link_events cle WHERE cle.campaign_id = sc.id AND cle.event_type = 'open') AS total_opens,
        (SELECT COUNT(*) FROM campaign_link_events cle WHERE cle.campaign_id = sc.id AND cle.event_type = 'purchase') AS total_purchases,
        (SELECT COALESCE(SUM(cle.revenue_amount), 0) FROM campaign_link_events cle WHERE cle.campaign_id = sc.id AND cle.event_type = 'purchase') AS total_revenue
      FROM scheduled_campaigns sc
      ORDER BY sc.created_at DESC
    `);
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/stats', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const stats = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM scheduled_campaigns) AS total_campaigns,
        (SELECT COUNT(*) FROM scheduled_campaigns WHERE status = 'active') AS active_campaigns,
        (SELECT COUNT(*) FROM scheduled_campaigns WHERE status IN ('active','expiring')) AS active_or_expiring,
        (SELECT COUNT(*) FROM scheduled_campaigns WHERE status = 'scheduled') AS scheduled_campaigns,
        (SELECT COUNT(*) FROM campaign_runs WHERE executed_at > NOW() - INTERVAL '24 hours') AS runs_24h,
        (SELECT COUNT(*) FROM campaign_link_events WHERE event_type = 'open') AS total_opens,
        (SELECT COUNT(*) FROM campaign_link_events WHERE event_type = 'purchase') AS total_purchases,
        (SELECT COALESCE(SUM(revenue_amount), 0) FROM campaign_link_events WHERE event_type = 'purchase') AS total_revenue,
        (SELECT COUNT(DISTINCT telegram_user_id) FROM campaign_link_events) AS unique_users
    `);
    res.json(stats.rows[0]);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/summary', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId   = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;
    const dateFrom = req.query.date_from as string || '';
    const dateTo   = req.query.date_to   as string || '';

    const oArgs: any[] = [];
    let oIdx = 1;
    let oWhere = `WHERE o.campaign_deep_link_id IS NOT NULL AND o.status IN ('paid','completed','delivered')`;
    if (campId) { oWhere += ` AND cdl.campaign_id = $${oIdx++}`; oArgs.push(campId); }

    const { rows: [rev] } = await pool.query(`
      SELECT
        COALESCE(SUM(CASE WHEN DATE(o.created_at)=CURRENT_DATE AND NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS today_revenue,
        COUNT(CASE WHEN DATE(o.created_at)=CURRENT_DATE AND NOT o.is_campaign_late_conversion THEN 1 END) AS today_purchases,
        COALESCE(SUM(CASE WHEN DATE(o.created_at)=CURRENT_DATE AND o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS today_late_revenue,
        COALESCE(SUM(CASE WHEN DATE(o.created_at)=CURRENT_DATE-1 AND NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS yesterday_revenue,
        COUNT(CASE WHEN DATE(o.created_at)=CURRENT_DATE-1 AND NOT o.is_campaign_late_conversion THEN 1 END) AS yesterday_purchases,
        COALESCE(SUM(CASE WHEN DATE(o.created_at)=CURRENT_DATE-1 AND o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS yesterday_late_revenue,
        COUNT(CASE WHEN DATE(o.created_at)=CURRENT_DATE-1 AND o.is_campaign_late_conversion THEN 1 END) AS yesterday_late_purchases,
        COALESCE(SUM(CASE WHEN o.created_at>=NOW()-INTERVAL '7 days' AND NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS last7d_revenue,
        COUNT(CASE WHEN o.created_at>=NOW()-INTERVAL '7 days' AND NOT o.is_campaign_late_conversion THEN 1 END) AS last7d_purchases,
        COALESCE(SUM(CASE WHEN o.created_at>=NOW()-INTERVAL '7 days' AND o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS last7d_late_revenue,
        COUNT(CASE WHEN o.created_at>=NOW()-INTERVAL '7 days' AND o.is_campaign_late_conversion THEN 1 END) AS last7d_late_purchases,
        COALESCE(SUM(CASE WHEN o.created_at>=NOW()-INTERVAL '30 days' AND NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS last30d_revenue,
        COUNT(CASE WHEN o.created_at>=NOW()-INTERVAL '30 days' AND NOT o.is_campaign_late_conversion THEN 1 END) AS last30d_purchases,
        COALESCE(SUM(CASE WHEN o.created_at>=NOW()-INTERVAL '30 days' AND o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS last30d_late_revenue,
        COUNT(CASE WHEN o.created_at>=NOW()-INTERVAL '30 days' AND o.is_campaign_late_conversion THEN 1 END) AS last30d_late_purchases,
        COALESCE(SUM(CASE WHEN NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS total_revenue,
        COUNT(CASE WHEN NOT o.is_campaign_late_conversion THEN 1 END) AS total_purchases,
        COALESCE(SUM(CASE WHEN o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS total_late_revenue,
        COUNT(CASE WHEN o.is_campaign_late_conversion THEN 1 END) AS total_late_purchases
      FROM orders o
      JOIN campaign_deep_links cdl ON cdl.id = o.campaign_deep_link_id
      ${oWhere}
    `, oArgs);

    const eArgs: any[] = [];
    let eIdx = 1;
    let eWhere = 'WHERE 1=1';
    if (campId) { eWhere += ` AND campaign_id = $${eIdx++}`; eArgs.push(campId); }

    const { rows: [opens] } = await pool.query(`
      SELECT
        COUNT(CASE WHEN DATE(created_at)=CURRENT_DATE AND event_type='open' THEN 1 END) AS today_opens,
        COUNT(CASE WHEN DATE(created_at)=CURRENT_DATE-1 AND event_type='open' THEN 1 END) AS yesterday_opens,
        COUNT(CASE WHEN created_at>=NOW()-INTERVAL '7 days' AND event_type='open' THEN 1 END) AS last7d_opens,
        COUNT(CASE WHEN created_at>=NOW()-INTERVAL '30 days' AND event_type='open' THEN 1 END) AS last30d_opens,
        COUNT(CASE WHEN event_type='open' THEN 1 END) AS total_opens,
        COUNT(DISTINCT CASE WHEN event_type='open' THEN telegram_user_id END) AS unique_openers
      FROM campaign_link_events
      ${eWhere}
    `, eArgs);

    let periodData: any = {};
    if (dateFrom || dateTo) {
      const pOArgs = [...oArgs]; let pOI = oIdx;
      let pOW = oWhere;
      if (dateFrom) { pOW += ` AND o.created_at >= $${pOI++}`; pOArgs.push(dateFrom); }
      if (dateTo)   { pOW += ` AND o.created_at < $${pOI++}::date + INTERVAL '1 day'`; pOArgs.push(dateTo); }

      const pEArgs = [...eArgs]; let pEI = eIdx;
      let pEW = eWhere;
      if (dateFrom) { pEW += ` AND created_at >= $${pEI++}`; pEArgs.push(dateFrom); }
      if (dateTo)   { pEW += ` AND created_at < $${pEI++}::date + INTERVAL '1 day'`; pEArgs.push(dateTo); }

      const [{ rows: [pR] }, { rows: [pO] }] = await Promise.all([
        pool.query(`
          SELECT
            COALESCE(SUM(CASE WHEN NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS period_revenue,
            COUNT(CASE WHEN NOT o.is_campaign_late_conversion THEN 1 END) AS period_purchases,
            COALESCE(SUM(CASE WHEN o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS period_late_revenue,
            COUNT(CASE WHEN o.is_campaign_late_conversion THEN 1 END) AS period_late_purchases
          FROM orders o
          JOIN campaign_deep_links cdl ON cdl.id = o.campaign_deep_link_id
          ${pOW}
        `, pOArgs),
        pool.query(`
          SELECT
            COUNT(CASE WHEN event_type='open' THEN 1 END) AS period_opens,
            COUNT(DISTINCT CASE WHEN event_type='open' THEN telegram_user_id END) AS period_unique_openers
          FROM campaign_link_events
          ${pEW}
        `, pEArgs),
      ]);
      periodData = { ...pR, ...pO };
    }

    const totalPurchases = Number(rev.total_purchases);
    const totalRevenue   = Number(rev.total_revenue);
    const totalOpens     = Number(opens.total_opens);
    const conv = totalOpens > 0
      ? ((totalPurchases / totalOpens) * 100).toFixed(1)
      : '0.0';
    const avg_order_value = totalPurchases > 0
      ? (totalRevenue / totalPurchases).toFixed(2)
      : '0.00';

    const rcArgs: any[] = [];
    let rcIdx = 1;
    let rcWhere = 'WHERE 1=1';
    if (campId) { rcWhere += ` AND cr.campaign_id = $${rcIdx++}`; rcArgs.push(campId); }

    const { rows: [runCounts] } = await pool.query(`
      SELECT
        COUNT(CASE WHEN cr.status IN ('running','completed') AND sc.status IN ('active','expiring') THEN 1 END) AS active_runs,
        COUNT(CASE WHEN sc.status IN ('expired','completed') THEN 1 END) AS expired_runs
      FROM campaign_runs cr
      JOIN scheduled_campaigns sc ON sc.id = cr.campaign_id
      ${rcWhere}
    `, rcArgs);

    const bcArgs: any[] = [];
    let bcIdx = 1;
    let bcWhere = '';
    if (campId) { bcWhere = `WHERE sc.id = $${bcIdx++}`; bcArgs.push(campId); }

    const { rows: activeCamps } = await pool.query(`
      SELECT sc.id, sc.name, sc.status,
        COALESCE((SELECT SUM(COALESCE(o2.paid_amount,o2.amount)) FROM orders o2 JOIN campaign_deep_links c2 ON c2.id=o2.campaign_deep_link_id WHERE c2.campaign_id=sc.id AND o2.status IN ('paid','completed','delivered') AND NOT o2.is_campaign_late_conversion),0) AS revenue,
        COALESCE((SELECT SUM(COALESCE(o2.paid_amount,o2.amount)) FROM orders o2 JOIN campaign_deep_links c2 ON c2.id=o2.campaign_deep_link_id WHERE c2.campaign_id=sc.id AND o2.status IN ('paid','completed','delivered') AND o2.is_campaign_late_conversion),0) AS late_revenue,
        COALESCE((SELECT COUNT(*) FROM orders o2 JOIN campaign_deep_links c2 ON c2.id=o2.campaign_deep_link_id WHERE c2.campaign_id=sc.id AND o2.status IN ('paid','completed','delivered') AND NOT o2.is_campaign_late_conversion),0) AS purchases,
        COALESCE((SELECT COUNT(*) FROM orders o2 JOIN campaign_deep_links c2 ON c2.id=o2.campaign_deep_link_id WHERE c2.campaign_id=sc.id AND o2.status IN ('paid','completed','delivered') AND o2.is_campaign_late_conversion),0) AS late_purchases,
        COALESCE(COUNT(CASE WHEN cle.event_type='open' THEN 1 END), 0) AS opens,
        COALESCE(COUNT(DISTINCT CASE WHEN cle.event_type='open' THEN cle.telegram_user_id END), 0) AS unique_users,
        (SELECT COUNT(*) FROM campaign_runs cr WHERE cr.campaign_id = sc.id) AS total_runs,
        (SELECT COUNT(*) FROM campaign_runs cr WHERE cr.campaign_id = sc.id AND cr.status IN ('running','completed')) AS active_run_count,
        (SELECT MAX(cr.executed_at) FROM campaign_runs cr WHERE cr.campaign_id = sc.id) AS latest_run_at
      FROM scheduled_campaigns sc
      LEFT JOIN campaign_link_events cle ON cle.campaign_id = sc.id
      ${bcWhere}
      GROUP BY sc.id, sc.name, sc.status
      ORDER BY revenue DESC
      LIMIT 20
    `, bcArgs);

    res.json({
      ...rev,
      ...opens,
      ...periodData,
      conversion_rate: conv,
      avg_order_value,
      active_runs: runCounts?.active_runs || 0,
      expired_runs: runCounts?.expired_runs || 0,
      active_campaigns: activeCamps,
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/daily-series', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const days     = Math.min(parseInt(req.query.days as string || '30'), 90);
    const campId   = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;
    const dateFrom = req.query.date_from as string || '';
    const dateTo   = req.query.date_to   as string || '';

    const oArgs: any[] = [];
    let oIdx = 1;
    let oWhere = `WHERE o.campaign_deep_link_id IS NOT NULL AND o.status IN ('paid','completed','delivered')`;
    if (campId)   { oWhere += ` AND cdl.campaign_id = $${oIdx++}`; oArgs.push(campId); }
    if (dateFrom) { oWhere += ` AND o.created_at >= $${oIdx++}`; oArgs.push(dateFrom); }
    if (dateTo)   { oWhere += ` AND o.created_at < $${oIdx++}::date + INTERVAL '1 day'`; oArgs.push(dateTo); }
    if (!dateFrom && !dateTo) { oWhere += ` AND o.created_at >= NOW() - ($${oIdx++} || ' days')::INTERVAL`; oArgs.push(days); }

    const eArgs: any[] = [];
    let eIdx = 1;
    let eWhere = 'WHERE 1=1';
    if (campId)   { eWhere += ` AND campaign_id = $${eIdx++}`; eArgs.push(campId); }
    if (dateFrom) { eWhere += ` AND created_at >= $${eIdx++}`; eArgs.push(dateFrom); }
    if (dateTo)   { eWhere += ` AND created_at < $${eIdx++}::date + INTERVAL '1 day'`; eArgs.push(dateTo); }
    if (!dateFrom && !dateTo) { eWhere += ` AND created_at >= NOW() - ($${eIdx++} || ' days')::INTERVAL`; eArgs.push(days); }

    const [{ rows: revSeries }, { rows: openSeries }] = await Promise.all([
      pool.query(`
        SELECT
          DATE(o.created_at) AS day,
          COALESCE(SUM(CASE WHEN NOT o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS revenue,
          COALESCE(SUM(CASE WHEN o.is_campaign_late_conversion THEN COALESCE(o.paid_amount,o.amount) ELSE 0 END),0) AS late_revenue,
          COUNT(CASE WHEN NOT o.is_campaign_late_conversion THEN 1 END) AS purchases,
          COUNT(CASE WHEN o.is_campaign_late_conversion THEN 1 END) AS late_purchases
        FROM orders o
        JOIN campaign_deep_links cdl ON cdl.id = o.campaign_deep_link_id
        ${oWhere}
        GROUP BY DATE(o.created_at)
        ORDER BY day ASC
      `, oArgs),
      pool.query(`
        SELECT
          DATE(created_at) AS day,
          COUNT(CASE WHEN event_type='open' THEN 1 END) AS opens
        FROM campaign_link_events
        ${eWhere}
        GROUP BY DATE(created_at)
        ORDER BY day ASC
      `, eArgs),
    ]);

    const startDate = dateFrom ? new Date(dateFrom) : new Date(Date.now() - days * 86400000);
    const endDate   = dateTo   ? new Date(dateTo)   : new Date();
    const filledSeries: any[] = [];
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dayStr = d.toISOString().slice(0, 10);
      const matchDay = (r: any) => r.day?.toISOString?.()?.slice(0, 10) === dayStr || String(r.day).slice(0, 10) === dayStr;
      const rv = revSeries.find(matchDay);
      const op = openSeries.find(matchDay);
      filledSeries.push({
        day: dayStr,
        revenue:        rv ? Number(rv.revenue)        : 0,
        late_revenue:   rv ? Number(rv.late_revenue)   : 0,
        purchases:      rv ? Number(rv.purchases)      : 0,
        late_purchases: rv ? Number(rv.late_purchases) : 0,
        opens:          op ? Number(op.opens)          : 0,
      });
    }
    res.json(filledSeries);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/dispatch-logs', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string || '100'), 500);
    const runType = req.query.run_type as string || '';
    const status = req.query.status as string || '';
    const campId = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;

    let where = 'WHERE 1=1';
    const args: any[] = [];
    let idx = 1;
    if (campId) { where += ` AND cdl.campaign_id = $${idx++}`; args.push(campId); }
    if (runType) { where += ` AND cr.run_type = $${idx++}`; args.push(runType); }
    if (status) { where += ` AND cdl.delivery_status = $${idx++}`; args.push(status); }
    args.push(limit);

    const { rows: rawLogs } = await pool.query(`
      SELECT cdl.id, cdl.campaign_id, cdl.target_type, cdl.telegram_id::text AS telegram_id,
             cdl.message_kind, cdl.delivery_status, cdl.error_text, cdl.created_at,
             cdl.delivery_method, cdl.source_message_id, cdl.telegram_message_id,
             cr.run_type, cr.executed_at AS run_executed_at,
             cr.source_chat_id::text AS run_source_chat_id, cr.source_message_id AS run_source_message_id,
             cr.channel_delivery_method, cr.channels_targeted, cr.channels_copied, cr.channels_failed,
             sc.name AS campaign_name,
             u.first_name, u.last_name, u.profile_photo_url,
             COALESCE(u.username, cdl.username) AS tg_username
      FROM campaign_delivery_logs cdl
      JOIN campaign_runs cr ON cr.id = cdl.campaign_run_id
      JOIN scheduled_campaigns sc ON sc.id = cdl.campaign_id
      LEFT JOIN users u ON u.telegram_id::text = cdl.telegram_id::text
      ${where}
      ORDER BY cdl.created_at DESC
      LIMIT $${idx}
    `, args);
    const logs = rawLogs.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) }));

    const { rows: expLogs } = await pool.query(`
      SELECT cel.*, sc.name AS campaign_name
      FROM campaign_expiry_logs cel
      JOIN scheduled_campaigns sc ON sc.id = cel.campaign_id
      ORDER BY cel.started_at DESC LIMIT 50
    `);

    res.json({ delivery_logs: logs, expiry_logs: expLogs });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/runs', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId   = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;
    const dateFrom = req.query.date_from as string || '';
    const dateTo   = req.query.date_to   as string || '';
    const runId    = req.query.run_id    ? parseInt(req.query.run_id as string) : null;
    const args: any[] = [];
    let idx = 1;
    let where = 'WHERE 1=1';
    if (campId) { where += ` AND cr.campaign_id = $${idx++}`; args.push(campId); }
    if (runId)  { where += ` AND cr.id = $${idx++}`;          args.push(runId); }
    if (dateFrom) { where += ` AND cr.executed_at >= $${idx++}`; args.push(dateFrom); }
    if (dateTo)   { where += ` AND cr.executed_at < $${idx++}::date + INTERVAL '1 day'`; args.push(dateTo); }
    const { rows } = await pool.query(`
      SELECT
        cr.id AS run_id,
        cr.campaign_id,
        sc.name AS campaign_name,
        sc.status AS campaign_status,
        cr.run_type,
        cr.status AS run_status,
        cr.executed_at,
        cr.total_sent,
        cr.total_failed,
        cr.source_chat_id::text AS source_chat_id,
        cr.source_message_id,
        cr.channel_delivery_method,
        cr.channels_targeted,
        cr.channels_copied,
        cr.channels_failed,
        cr.created_at,
        cdl.id AS deep_link_id,
        cdl.code AS deep_link_code,
        cdl.deep_link_url AS deep_link_url,
        cdl.status AS deep_link_status,
        cdl.opens_count,
        cdl.unique_opens_count,
        cdl.starts_count,
        cdl.purchases_count     AS valid_purchases,
        cdl.revenue_total       AS valid_revenue,
        cdl.late_purchases_count AS late_purchases,
        cdl.late_revenue_total   AS late_revenue,
        cdl.attribution_start_at,
        cdl.attribution_end_at,
        cdl.activated_at,
        cdl.expired_at,
        CASE WHEN cdl.opens_count > 0
             THEN ROUND(cdl.purchases_count::numeric / cdl.opens_count * 100, 1)
             ELSE 0 END AS conversion_rate
      FROM campaign_runs cr
      JOIN scheduled_campaigns sc ON sc.id = cr.campaign_id
      LEFT JOIN campaign_deep_links cdl ON cdl.campaign_run_id = cr.id
      ${where}
      ORDER BY cr.executed_at DESC
      LIMIT 200
    `, args);
    res.json({ runs: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/deep-links', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId   = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;
    const dateFrom = req.query.date_from as string || '';
    const dateTo   = req.query.date_to   as string || '';
    const status   = req.query.status   as string || '';
    const args: any[] = [];
    let idx = 1;
    let where = 'WHERE 1=1';
    if (campId)   { where += ` AND cdl.campaign_id = $${idx++}`; args.push(campId); }
    if (status)   { where += ` AND cdl.status = $${idx++}`;      args.push(status); }
    if (dateFrom) { where += ` AND cdl.created_at >= $${idx++}`; args.push(dateFrom); }
    if (dateTo)   { where += ` AND cdl.created_at < $${idx++}::date + INTERVAL '1 day'`; args.push(dateTo); }
    const { rows } = await pool.query(`
      SELECT
        cdl.id,
        cdl.campaign_id,
        sc.name AS campaign_name,
        sc.status AS campaign_status,
        cdl.campaign_run_id,
        cr.run_type,
        cr.executed_at AS run_executed_at,
        cdl.code,
        cdl.deep_link_url AS full_url,
        cdl.status,
        cdl.created_at,
        cdl.activated_at,
        cdl.expired_at,
        cdl.attribution_start_at,
        cdl.attribution_end_at,
        cdl.opens_count,
        cdl.unique_opens_count,
        cdl.starts_count,
        cdl.purchases_count     AS valid_purchases,
        cdl.revenue_total       AS valid_revenue,
        cdl.late_purchases_count AS late_purchases,
        cdl.late_revenue_total   AS late_revenue,
        CASE WHEN cdl.opens_count > 0
             THEN ROUND(cdl.purchases_count::numeric / cdl.opens_count * 100, 1)
             ELSE 0 END AS conversion_rate
      FROM campaign_deep_links cdl
      JOIN scheduled_campaigns sc ON sc.id = cdl.campaign_id
      LEFT JOIN campaign_runs cr ON cr.id = cdl.campaign_run_id
      ${where}
      ORDER BY cdl.created_at DESC
      LIMIT 300
    `, args);
    res.json({ deep_links: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/attributed-orders', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId   = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;
    const dateFrom = req.query.date_from as string || '';
    const dateTo   = req.query.date_to   as string || '';
    const limit    = Math.min(parseInt(req.query.limit as string || '150'), 500);
    const args: any[] = [];
    let idx = 1;
    let where = 'WHERE o.campaign_deep_link_id IS NOT NULL';
    if (campId)   { where += ` AND cdl.campaign_id = $${idx++}`; args.push(campId); }
    if (dateFrom) { where += ` AND o.created_at >= $${idx++}`;   args.push(dateFrom); }
    if (dateTo)   { where += ` AND o.created_at < $${idx++}::date + INTERVAL '1 day'`; args.push(dateTo); }
    args.push(limit);
    const { rows: rawRows } = await pool.query(`
      SELECT
        o.id AS order_id,
        o.status AS payment_status,
        o.purchased_category_name AS category,
        o.purchased_duration_name AS duration,
        COALESCE(o.paid_amount, o.amount) AS amount,
        o.created_at AS purchase_time,
        o.is_campaign_late_conversion,
        o.campaign_run_id,
        o.campaign_deep_link_id,
        cdl.code AS deep_link_code,
        cdl.campaign_id,
        sc.name AS campaign_name,
        cr.run_type,
        cr.executed_at AS run_executed_at,
        u.first_name, u.last_name, u.username AS tg_username, u.telegram_id, u.profile_photo_url,
        ca.first_opened_at AS attribution_first_opened,
        ca.last_opened_at AS attribution_last_opened,
        ca.total_opens AS attribution_total_opens,
        ca.attribution_expires_at,
        ca.attribution_end_at,
        CASE
          WHEN o.status NOT IN ('paid','completed','delivered') THEN 'unpaid'
          WHEN ca.id IS NULL AND o.is_campaign_late_conversion = true THEN 'late'
          WHEN ca.attribution_expires_at IS NOT NULL AND o.created_at > ca.attribution_expires_at THEN 'late'
          WHEN ca.attribution_end_at IS NOT NULL AND o.created_at > ca.attribution_end_at THEN 'late'
          WHEN o.is_campaign_late_conversion = true THEN 'late'
          ELSE 'counted'
        END AS attribution_status,
        CASE
          WHEN o.status NOT IN ('paid','completed','delivered') THEN 'Order not paid/completed'
          WHEN ca.attribution_expires_at IS NOT NULL AND o.created_at > ca.attribution_expires_at THEN 'Purchase after attribution window expired (' || to_char(ca.attribution_expires_at, 'YYYY-MM-DD HH24:MI') || ')'
          WHEN ca.attribution_end_at IS NOT NULL AND o.created_at > ca.attribution_end_at THEN 'Purchase after attribution end (' || to_char(ca.attribution_end_at, 'YYYY-MM-DD HH24:MI') || ')'
          WHEN o.is_campaign_late_conversion = true THEN 'Outside attribution window'
          ELSE NULL
        END AS exclusion_reason
      FROM orders o
      JOIN users u ON u.id = o.user_id
      LEFT JOIN campaign_deep_links cdl ON cdl.id = o.campaign_deep_link_id
      LEFT JOIN scheduled_campaigns sc ON sc.id = cdl.campaign_id
      LEFT JOIN campaign_runs cr ON cr.id = o.campaign_run_id
      LEFT JOIN campaign_attributions ca ON ca.user_id = o.user_id AND ca.campaign_id = cdl.campaign_id
      ${where}
      ORDER BY o.created_at DESC
      LIMIT $${idx}
    `, args);
    const rows = rawRows.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) }));
    res.json({ orders: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/analytics/funnel', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId   = req.query.campaign_id ? parseInt(req.query.campaign_id as string) : null;
    const dateFrom = req.query.date_from as string || '';
    const dateTo   = req.query.date_to   as string || '';

    const delivArgs: any[] = [];
    let delivIdx = 1;
    let delivWhere = `WHERE cdl.delivery_status = 'sent'`;
    if (campId)   { delivWhere += ` AND cdl.campaign_id = $${delivIdx++}`; delivArgs.push(campId); }
    if (dateFrom) { delivWhere += ` AND cdl.created_at >= $${delivIdx++}`; delivArgs.push(dateFrom); }
    if (dateTo)   { delivWhere += ` AND cdl.created_at < $${delivIdx++}::date + INTERVAL '1 day'`; delivArgs.push(dateTo); }

    const eventArgs: any[] = [];
    let eventIdx = 1;
    let eventWhere = 'WHERE 1=1';
    if (campId)   { eventWhere += ` AND campaign_id = $${eventIdx++}`; eventArgs.push(campId); }
    if (dateFrom) { eventWhere += ` AND created_at >= $${eventIdx++}`; eventArgs.push(dateFrom); }
    if (dateTo)   { eventWhere += ` AND created_at < $${eventIdx++}::date + INTERVAL '1 day'`; eventArgs.push(dateTo); }

    const [{ rows: [deliv] }, { rows: [events] }] = await Promise.all([
      pool.query(
        `SELECT COUNT(*) AS delivered FROM campaign_delivery_logs cdl ${delivWhere}`,
        delivArgs
      ),
      pool.query(`
        SELECT
          COUNT(CASE WHEN event_type='open' THEN 1 END) AS opened,
          COUNT(DISTINCT CASE WHEN event_type='open' THEN telegram_user_id END) AS unique_openers,
          COUNT(CASE WHEN event_type='start' THEN 1 END) AS started,
          COUNT(CASE WHEN event_type='purchase' AND NOT is_late_conversion THEN 1 END) AS purchased
        FROM campaign_link_events
        ${eventWhere}
      `, eventArgs),
    ]);

    res.json({
      delivered:      Number(deliv?.delivered     || 0),
      opened:         Number(events?.opened       || 0),
      unique_openers: Number(events?.unique_openers || 0),
      started:        Number(events?.started      || 0),
      purchased:      Number(events?.purchased    || 0),
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/templates', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const typeFilter = req.query.type as string | undefined;
    let whereClause = '';
    const params: any[] = [];
    if (typeFilter === 'promo') {
      whereClause = "WHERE ct.template_type IN ('promo_start', 'promo_expiry')";
    } else if (typeFilter === 'trial') {
      whereClause = "WHERE ct.template_type IN ('trial_start', 'trial_expire')";
    }
    const { rows } = await pool.query(`
      SELECT ct.*,
        COALESCE((SELECT COUNT(*) FROM template_versions tv WHERE tv.template_id = ct.id), 0)::int AS version_count
      FROM campaign_templates ct
      ${whereClause}
      ORDER BY ct.created_at DESC
    `);
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/templates', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, apk_captions_json, start_delivery_config_json } = req.body;
    if (template_type === 'trial_start' && start_delivery_config_json) {
      try {
        const cfg = JSON.parse(start_delivery_config_json);
        if (cfg.send_media === false && cfg.send_summary === false) {
          return res.status(400).json({ error: 'At least one Trial Start delivery block must be enabled.' });
        }
      } catch {}
    }
    const { rows } = await pool.query(
      `INSERT INTO campaign_templates
         (name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json,
          button_style_json, media_type, media_url, is_active, apk_captions_json, start_delivery_config_json, edited_via, updated_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, 'web', 'web') RETURNING *`,
      [name || 'Untitled', template_type || 'promo_start', body_text || '', parse_mode || 'HTML',
       custom_emoji_json || null, inline_buttons_json || null, button_style_json || null,
       media_type || null, media_url || null, is_active !== false, apk_captions_json || null,
       start_delivery_config_json || null]
    );
    res.json({ ...rows[0], version_count: 0 });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.put('/templates/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, template_type, body_text, parse_mode, custom_emoji_json, inline_buttons_json, button_style_json, media_type, media_url, is_active, apk_captions_json, start_delivery_config_json } = req.body;
    if (template_type === 'trial_start' && start_delivery_config_json) {
      try {
        const cfg = JSON.parse(start_delivery_config_json);
        if (cfg.send_media === false && cfg.send_summary === false) {
          return res.status(400).json({ error: 'At least one Trial Start delivery block must be enabled.' });
        }
      } catch {}
    }
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows: [old] } = await client.query(
        'SELECT body_text, inline_buttons_json FROM campaign_templates WHERE id = $1',
        [req.params.id]
      );
      if (old) {
        await client.query(
          `INSERT INTO template_versions (template_id, body_text, inline_buttons_json, changed_by, changed_via, change_note)
           VALUES ($1, $2, $3, 'web', 'web', 'updated via admin panel')`,
          [req.params.id, old.body_text || '', old.inline_buttons_json || null]
        );
      }
      const { rows } = await client.query(
        `UPDATE campaign_templates
           SET name=$1, template_type=$2, body_text=$3, parse_mode=$4,
               custom_emoji_json=$5, inline_buttons_json=$6, button_style_json=$7,
               media_type=$8, media_url=$9, is_active=$10, apk_captions_json=$11,
               start_delivery_config_json=$12,
               edited_via='web', updated_by='web', updated_at=NOW()
         WHERE id=$13 RETURNING *`,
        [name, template_type, body_text, parse_mode, custom_emoji_json || null,
         inline_buttons_json || null, button_style_json || null, media_type || null, media_url || null,
         is_active !== false, apk_captions_json || null, start_delivery_config_json || null, req.params.id]
      );
      await client.query('COMMIT');
      const { rows: [{ version_count }] } = await client.query(
        'SELECT COUNT(*)::int AS version_count FROM template_versions WHERE template_id = $1',
        [req.params.id]
      );
      res.json({ ...rows[0], version_count });
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.delete('/templates/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    await pool.query('DELETE FROM campaign_templates WHERE id = $1', [req.params.id]);
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

const VALID_DELIVERY_MODES = ['copy', 'forward', 'direct'] as const;

router.get('/channel-delivery-mode', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows } = await pool.query(
      "SELECT value FROM bot_settings WHERE key = 'campaign_channel_delivery_mode'"
    );
    const mode = rows.length > 0 && VALID_DELIVERY_MODES.includes(rows[0].value as any)
      ? rows[0].value
      : 'direct';

    const { rows: metaRows } = await pool.query(
      "SELECT value FROM bot_settings WHERE key = 'campaign_channel_delivery_mode_updated_at'"
    );
    const updatedAt = metaRows.length > 0 ? metaRows[0].value : null;

    const { rows: byRows } = await pool.query(
      "SELECT value FROM bot_settings WHERE key = 'campaign_channel_delivery_mode_updated_by'"
    );
    const updatedBy = byRows.length > 0 ? byRows[0].value : null;

    res.json({ mode, updated_at: updatedAt, updated_by: updatedBy });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.put('/channel-delivery-mode', async (req: AuthenticatedRequest, res: Response) => {
  const { mode } = req.body;
  if (!mode || !VALID_DELIVERY_MODES.includes(mode)) {
    return res.status(400).json({ error: `Invalid mode. Must be one of: ${VALID_DELIVERY_MODES.join(', ')}` });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    await client.query(
      `INSERT INTO bot_settings (key, value) VALUES ('campaign_channel_delivery_mode', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1`,
      [mode]
    );

    const now = new Date().toISOString();
    await client.query(
      `INSERT INTO bot_settings (key, value) VALUES ('campaign_channel_delivery_mode_updated_at', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1`,
      [now]
    );

    const adminUser = (req as any).user?.username || 'admin';
    await client.query(
      `INSERT INTO bot_settings (key, value) VALUES ('campaign_channel_delivery_mode_updated_by', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1`,
      [adminUser]
    );

    await client.query('COMMIT');
    res.json({ ok: true, mode, updated_at: now, updated_by: adminUser });
  } catch (e: any) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

router.get('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows: [campaign] } = await pool.query('SELECT * FROM scheduled_campaigns WHERE id = $1', [req.params.id]);
    if (!campaign) return res.status(404).json({ error: 'Not found' });

    const { rows: rules } = await pool.query('SELECT * FROM campaign_discount_rules WHERE campaign_id = $1', [req.params.id]);
    const { rows: targets } = await pool.query('SELECT * FROM campaign_targets WHERE campaign_id = $1', [req.params.id]);
    const { rows: deepLinks } = await pool.query('SELECT * FROM campaign_deep_links WHERE campaign_id = $1', [req.params.id]);
    const { rows: runs } = await pool.query('SELECT * FROM campaign_runs WHERE campaign_id = $1 ORDER BY executed_at DESC LIMIT 20', [req.params.id]);

    res.json({ ...campaign, discount_rules: rules, targets, deep_links: deepLinks, runs });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  const client = await pool.connect();
  try {
    await ensureChannelTargetsCol();
    await client.query('BEGIN');
    const {
      name, description, campaign_mode, linked_discount_plan_id,
      category_scope_json, duration_scope_json, repeat_mode, timezone,
      start_at, expire_at, promo_template_id, expiry_template_id,
      send_to_users, send_to_channels, discount_rules, targets, channel_targets
    } = req.body;

    const { rows: [campaign] } = await client.query(
      `INSERT INTO scheduled_campaigns
       (name, description, status, campaign_mode, linked_discount_plan_id,
        category_scope_json, duration_scope_json, repeat_mode, timezone,
        start_at, expire_at, next_run_at, next_expire_at,
        promo_template_id, expiry_template_id, send_to_users, send_to_channels, channel_targets_json)
       VALUES ($1,$2,'draft',$3,$4,$5,$6,$7,$8,$9,$10,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,
      [name || 'Untitled Campaign', description || '', campaign_mode || 'fixed_plan',
       linked_discount_plan_id || null,
       JSON.stringify(category_scope_json || []), JSON.stringify(duration_scope_json || []),
       repeat_mode || 'once', timezone || 'Asia/Kolkata',
       start_at || new Date(), expire_at || new Date(),
       promo_template_id || null, expiry_template_id || null,
       send_to_users !== false, send_to_channels === true,
       JSON.stringify(Array.isArray(channel_targets) ? channel_targets : [])]
    );

    const campId = campaign.id;

    if (discount_rules && Array.isArray(discount_rules)) {
      for (const r of discount_rules) {
        await client.query(
          `INSERT INTO campaign_discount_rules (campaign_id, discount_mode, fixed_value, min_value, max_value, applies_to_category_id, applies_to_duration_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [campId, r.discount_mode || 'fixed_percent', r.fixed_value || null, r.min_value || null, r.max_value || null,
           r.applies_to_category_id || null, r.applies_to_duration_id || null]
        );
      }
    }

    if (targets && Array.isArray(targets)) {
      for (const t of targets) {
        await client.query(
          `INSERT INTO campaign_targets (campaign_id, target_type, target_value, message_kind) VALUES ($1,$2,$3,$4)`,
          [campId, t.target_type || 'all_users', t.target_value || null, t.message_kind || 'promo_start']
        );
      }
    }

    const code = generateCode();
    await client.query(
      `INSERT INTO campaign_deep_links (campaign_id, code, deep_link_url) VALUES ($1,$2,$3)`,
      [campId, code, '']
    );

    await client.query('COMMIT');
    res.json({ ...campaign, deep_link_code: code });
  } catch (e: any) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

router.put('/:id', async (req: AuthenticatedRequest, res: Response) => {
  const client = await pool.connect();
  try {
    await ensureChannelTargetsCol();
    await client.query('BEGIN');
    const {
      name, description, campaign_mode, linked_discount_plan_id,
      category_scope_json, duration_scope_json, repeat_mode, timezone,
      start_at, expire_at, promo_template_id, expiry_template_id,
      send_to_users, send_to_channels, discount_rules, targets, status, channel_targets
    } = req.body;
    const campId = req.params.id;

    await client.query(
      `UPDATE scheduled_campaigns SET
       name=$1, description=$2, campaign_mode=$3, linked_discount_plan_id=$4,
       category_scope_json=$5, duration_scope_json=$6, repeat_mode=$7, timezone=$8,
       start_at=$9, expire_at=$10, next_run_at=$9, next_expire_at=$10,
       promo_template_id=$11, expiry_template_id=$12, send_to_users=$13, send_to_channels=$14,
       status=COALESCE($15, status), channel_targets_json=$16, updated_at=NOW()
       WHERE id=$17`,
      [name, description, campaign_mode, linked_discount_plan_id || null,
       JSON.stringify(category_scope_json || []), JSON.stringify(duration_scope_json || []),
       repeat_mode || 'once', timezone || 'Asia/Kolkata',
       start_at, expire_at,
       promo_template_id || null, expiry_template_id || null,
       send_to_users !== false, send_to_channels === true,
       status || null,
       JSON.stringify(Array.isArray(channel_targets) ? channel_targets : []),
       campId]
    );

    if (discount_rules && Array.isArray(discount_rules)) {
      await client.query('DELETE FROM campaign_discount_rules WHERE campaign_id = $1', [campId]);
      for (const r of discount_rules) {
        await client.query(
          `INSERT INTO campaign_discount_rules (campaign_id, discount_mode, fixed_value, min_value, max_value, applies_to_category_id, applies_to_duration_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7)`,
          [campId, r.discount_mode || 'fixed_percent', r.fixed_value || null, r.min_value || null, r.max_value || null,
           r.applies_to_category_id || null, r.applies_to_duration_id || null]
        );
      }
    }

    if (targets && Array.isArray(targets)) {
      await client.query('DELETE FROM campaign_targets WHERE campaign_id = $1', [campId]);
      for (const t of targets) {
        await client.query(
          `INSERT INTO campaign_targets (campaign_id, target_type, target_value, message_kind) VALUES ($1,$2,$3,$4)`,
          [campId, t.target_type || 'all_users', t.target_value || null, t.message_kind || 'promo_start']
        );
      }
    }

    await client.query('COMMIT');
    const { rows: [updated] } = await pool.query('SELECT * FROM scheduled_campaigns WHERE id = $1', [campId]);
    res.json(updated);
  } catch (e: any) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

router.post('/:id/enable', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId = req.params.id;
    const { rows: [c] } = await pool.query('SELECT * FROM scheduled_campaigns WHERE id = $1', [campId]);
    if (!c) return res.status(404).json({ error: 'Not found' });

    const overlap = await pool.query(
      `SELECT id, name FROM scheduled_campaigns
       WHERE id != $1 AND status IN ('active','scheduled') AND is_enabled = true
         AND category_scope_json = $2 AND campaign_mode != 'message_only'
       LIMIT 1`,
      [campId, c.category_scope_json]
    );
    if (overlap.rows.length > 0 && c.campaign_mode !== 'message_only') {
      return res.status(409).json({
        error: `Conflicts with active campaign "${overlap.rows[0].name}" (ID: ${overlap.rows[0].id}). Disable it first or use a different category scope.`
      });
    }

    await pool.query(
      `UPDATE scheduled_campaigns SET is_enabled = true, status = 'scheduled', updated_at = NOW(),
       next_run_at = start_at, next_expire_at = expire_at WHERE id = $1`,
      [campId]
    );
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/:id/disable', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const camp = await pool.query(`SELECT * FROM scheduled_campaigns WHERE id = $1`, [req.params.id]);
    const c = camp.rows[0];
    if (c) {
      if (c.campaign_mode === 'fixed_plan' && c.linked_discount_plan_id) {
        await pool.query(`UPDATE discount_plans SET is_active = false WHERE id = $1`, [c.linked_discount_plan_id]);
      }
      if (c.auto_discount_plan_id) {
        await pool.query(`UPDATE discount_plans SET is_active = false WHERE id = $1`, [c.auto_discount_plan_id]);
      }
      await bumpDiscountCacheVersion();
    }
    await pool.query(
      `UPDATE scheduled_campaigns SET is_enabled = false, status = 'disabled', updated_at = NOW() WHERE id = $1`,
      [req.params.id]
    );
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/:id/pause', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const camp = await pool.query(`SELECT * FROM scheduled_campaigns WHERE id = $1`, [req.params.id]);
    const c = camp.rows[0];
    if (c && c.status === 'active') {
      if (c.campaign_mode === 'fixed_plan' && c.linked_discount_plan_id) {
        await pool.query(`UPDATE discount_plans SET is_active = false WHERE id = $1`, [c.linked_discount_plan_id]);
      }
      if (c.auto_discount_plan_id) {
        await pool.query(`UPDATE discount_plans SET is_active = false WHERE id = $1`, [c.auto_discount_plan_id]);
      }
      await bumpDiscountCacheVersion();
    }
    await pool.query(
      `UPDATE scheduled_campaigns SET status = 'paused', updated_at = NOW() WHERE id = $1`,
      [req.params.id]
    );
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/:id/resume', async (req: AuthenticatedRequest, res: Response) => {
  try {
    await pool.query(
      `UPDATE scheduled_campaigns SET status = 'scheduled', updated_at = NOW() WHERE id = $1`,
      [req.params.id]
    );
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/:id/duplicate', async (req: AuthenticatedRequest, res: Response) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: [orig] } = await client.query('SELECT * FROM scheduled_campaigns WHERE id = $1', [req.params.id]);
    if (!orig) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Not found' }); }

    const { rows: [dup] } = await client.query(
      `INSERT INTO scheduled_campaigns
       (name, description, status, campaign_mode, linked_discount_plan_id,
        category_scope_json, duration_scope_json, repeat_mode, timezone,
        start_at, expire_at, promo_template_id, expiry_template_id,
        send_to_users, send_to_channels)
       VALUES ($1,$2,'draft',$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [orig.name + ' (Copy)', orig.description, orig.campaign_mode, orig.linked_discount_plan_id,
       orig.category_scope_json, orig.duration_scope_json, orig.repeat_mode, orig.timezone,
       orig.start_at, orig.expire_at, orig.promo_template_id, orig.expiry_template_id,
       orig.send_to_users, orig.send_to_channels]
    );

    const { rows: rules } = await client.query('SELECT * FROM campaign_discount_rules WHERE campaign_id = $1', [req.params.id]);
    for (const r of rules) {
      await client.query(
        `INSERT INTO campaign_discount_rules (campaign_id, discount_mode, fixed_value, min_value, max_value, applies_to_category_id, applies_to_duration_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [dup.id, r.discount_mode, r.fixed_value, r.min_value, r.max_value, r.applies_to_category_id, r.applies_to_duration_id]
      );
    }

    const { rows: targets } = await client.query('SELECT * FROM campaign_targets WHERE campaign_id = $1', [req.params.id]);
    for (const t of targets) {
      await client.query(
        `INSERT INTO campaign_targets (campaign_id, target_type, target_value, message_kind) VALUES ($1,$2,$3,$4)`,
        [dup.id, t.target_type, t.target_value, t.message_kind]
      );
    }

    const code = generateCode();
    await client.query('INSERT INTO campaign_deep_links (campaign_id, code) VALUES ($1,$2)', [dup.id, code]);

    await client.query('COMMIT');
    res.json(dup);
  } catch (e: any) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

router.delete('/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const camp = await pool.query(`SELECT * FROM scheduled_campaigns WHERE id = $1`, [req.params.id]);
    const c = camp.rows[0];
    let needCacheBump = false;
    if (c) {
      if (c.auto_discount_plan_id) {
        await pool.query(`DELETE FROM discount_plans WHERE id = $1 AND is_campaign_generated = true`, [c.auto_discount_plan_id]);
        needCacheBump = true;
      }
      if (c.linked_discount_plan_id && c.campaign_mode === 'fixed_plan') {
        await pool.query(`UPDATE discount_plans SET is_active = false WHERE id = $1`, [c.linked_discount_plan_id]);
        needCacheBump = true;
      }
    }
    await pool.query('DELETE FROM scheduled_campaigns WHERE id = $1', [req.params.id]);
    if (needCacheBump) await bumpDiscountCacheVersion();
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id/analytics', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId = req.params.id;
    const { rows: [analytics] } = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM campaign_link_events WHERE campaign_id = $1 AND event_type = 'open') AS total_opens,
        (SELECT COUNT(DISTINCT telegram_user_id) FROM campaign_link_events WHERE campaign_id = $1 AND event_type = 'open') AS unique_opens,
        (SELECT COUNT(*) FROM campaign_link_events WHERE campaign_id = $1 AND event_type = 'start') AS bot_starts,
        (SELECT COUNT(*) FROM campaign_link_events WHERE campaign_id = $1 AND event_type = 'purchase') AS purchases,
        (SELECT COALESCE(SUM(revenue_amount), 0) FROM campaign_link_events WHERE campaign_id = $1 AND event_type = 'purchase') AS revenue,
        (SELECT COUNT(*) FROM campaign_delivery_logs WHERE campaign_id = $1 AND delivery_status = 'sent') AS total_sent,
        (SELECT COUNT(*) FROM campaign_delivery_logs WHERE campaign_id = $1 AND delivery_status = 'failed') AS total_failed,
        -- Time-segmented revenue
        (SELECT COALESCE(SUM(revenue_amount),0) FROM campaign_link_events WHERE campaign_id=$1 AND event_type='purchase' AND DATE(created_at)=CURRENT_DATE) AS today_revenue,
        (SELECT COALESCE(SUM(revenue_amount),0) FROM campaign_link_events WHERE campaign_id=$1 AND event_type='purchase' AND DATE(created_at)=CURRENT_DATE-1) AS yesterday_revenue,
        (SELECT COALESCE(SUM(revenue_amount),0) FROM campaign_link_events WHERE campaign_id=$1 AND event_type='purchase' AND created_at >= NOW()-INTERVAL '7 days') AS last7d_revenue,
        (SELECT COALESCE(SUM(revenue_amount),0) FROM campaign_link_events WHERE campaign_id=$1 AND event_type='purchase' AND created_at >= NOW()-INTERVAL '30 days') AS last30d_revenue,
        (SELECT COUNT(*) FROM campaign_link_events WHERE campaign_id=$1 AND event_type='purchase' AND DATE(created_at)=CURRENT_DATE) AS today_purchases,
        (SELECT COUNT(*) FROM campaign_link_events WHERE campaign_id=$1 AND event_type='purchase' AND DATE(created_at)=CURRENT_DATE-1) AS yesterday_purchases
    `, [campId]);

    const { rows: runs } = await pool.query(
      `SELECT * FROM campaign_runs WHERE campaign_id = $1 ORDER BY executed_at DESC LIMIT 50`, [campId]
    );

    const { rows: events } = await pool.query(
      `SELECT * FROM campaign_link_events WHERE campaign_id = $1 ORDER BY created_at DESC LIMIT 100`, [campId]
    );

    const { rows: expiryLogs } = await pool.query(
      `SELECT * FROM campaign_expiry_logs WHERE campaign_id = $1 ORDER BY started_at DESC LIMIT 20`, [campId]
    );

    // Daily series for this campaign
    const { rows: dailySeries } = await pool.query(`
      SELECT DATE(created_at) AS day,
             COALESCE(SUM(CASE WHEN event_type='purchase' THEN revenue_amount ELSE 0 END),0) AS revenue,
             COUNT(CASE WHEN event_type='purchase' THEN 1 END) AS purchases,
             COUNT(CASE WHEN event_type='open' THEN 1 END) AS opens
      FROM campaign_link_events
      WHERE campaign_id = $1 AND created_at >= NOW() - INTERVAL '30 days'
      GROUP BY DATE(created_at)
      ORDER BY day ASC
    `, [campId]);

    res.json({
      ...analytics,
      runs,
      events,
      expiry_logs: expiryLogs,
      daily_series: dailySeries,
      conversion_rate: Number(analytics.total_opens) > 0
        ? ((Number(analytics.purchases) / Number(analytics.total_opens)) * 100).toFixed(1)
        : '0.0'
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id/attributed-orders', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId = req.params.id;
    const limit = Math.min(parseInt(req.query.limit as string || '100'), 500);
    const { rows } = await pool.query(`
      SELECT
        o.id AS order_id,
        u.username, u.first_name,
        u.telegram_id,
        o.campaign_deep_link_code AS deep_link_code,
        o.campaign_id,
        sc.name AS campaign_name,
        o.purchased_category_name AS category,
        o.purchased_duration_name AS duration,
        COALESCE(o.paid_amount, o.amount) AS amount,
        o.status AS payment_status,
        o.created_at AS purchase_time,
        o.delivered_at,
        o.paid_utr,
        cle.created_at AS attribution_event_at,
        EXTRACT(EPOCH FROM (cle.created_at - ca.first_opened_at)) / 3600 AS hours_from_open_to_purchase
      FROM campaign_link_events cle
      JOIN orders o ON o.id = cle.order_id
      JOIN users u ON u.id = o.user_id
      JOIN scheduled_campaigns sc ON sc.id = cle.campaign_id
      LEFT JOIN campaign_attributions ca ON ca.user_id = o.user_id AND ca.campaign_id = cle.campaign_id
      WHERE cle.campaign_id = $1 AND cle.event_type = 'purchase'
      ORDER BY cle.created_at DESC
      LIMIT $2
    `, [campId, limit]);
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id/deep-links', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const campId = req.params.id;
    const { rows: links } = await pool.query(`
      SELECT
        cdl.id,
        cdl.campaign_id,
        cdl.campaign_run_id,
        cdl.code,
        cdl.deep_link_url       AS full_url,
        cdl.status,
        cdl.created_at,
        cdl.activated_at,
        cdl.expired_at,
        cdl.attribution_start_at,
        cdl.attribution_end_at,
        cdl.opens_count,
        cdl.unique_opens_count,
        cdl.starts_count,
        cdl.purchases_count,
        cdl.revenue_total,
        cdl.late_purchases_count,
        cdl.late_revenue_total,
        cr.run_type,
        cr.executed_at AS run_executed_at,
        cr.status      AS run_status,
        cr.total_sent  AS run_sent,
        CASE WHEN cdl.opens_count > 0
             THEN ROUND(cdl.purchases_count::numeric / cdl.opens_count * 100, 1)
             ELSE 0
        END AS conversion_rate
      FROM campaign_deep_links cdl
      LEFT JOIN campaign_runs cr ON cr.id = cdl.campaign_run_id
      WHERE cdl.campaign_id = $1
      ORDER BY cdl.created_at DESC
    `, [campId]);

    res.json({ deep_links: links });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/deep-links/:linkId', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const linkId = req.params.linkId;

    const { rows: [link] } = await pool.query(`
      SELECT
        cdl.*,
        cdl.deep_link_url AS full_url,
        sc.name  AS campaign_name,
        sc.status AS campaign_status,
        cr.run_type, cr.executed_at AS run_executed_at, cr.status AS run_status,
        CASE WHEN cdl.opens_count > 0
             THEN ROUND(cdl.purchases_count::numeric / cdl.opens_count * 100, 1)
             ELSE 0
        END AS conversion_rate
      FROM campaign_deep_links cdl
      JOIN scheduled_campaigns sc ON sc.id = cdl.campaign_id
      LEFT JOIN campaign_runs cr ON cr.id = cdl.campaign_run_id
      WHERE cdl.id = $1
    `, [linkId]);

    if (!link) return res.status(404).json({ error: 'Deep link not found' });

    const { rows: events } = await pool.query(`
      SELECT cle.*, u.first_name, u.last_name, u.username AS tg_username
      FROM campaign_link_events cle
      LEFT JOIN users u ON u.telegram_id = cle.telegram_user_id
      WHERE cle.deep_link_id = $1
      ORDER BY cle.created_at DESC
      LIMIT 200
    `, [linkId]);

    const { rows: orders } = await pool.query(`
      SELECT
        o.id AS order_id,
        u.first_name, u.last_name, u.username AS tg_username, u.telegram_id,
        o.purchased_category_name AS category,
        o.purchased_duration_name AS duration,
        COALESCE(o.paid_amount, o.amount) AS amount,
        o.status AS payment_status,
        o.created_at AS purchase_time,
        o.delivered_at,
        o.is_campaign_late_conversion,
        o.campaign_run_id,
        cle.created_at AS attribution_event_at,
        cle.is_late_conversion AS event_is_late
      FROM orders o
      JOIN users u ON u.id = o.user_id
      LEFT JOIN campaign_link_events cle ON cle.order_id = o.id AND cle.deep_link_id = $1
      WHERE o.campaign_deep_link_id = $1
         OR (cle.order_id IS NOT NULL)
      ORDER BY o.created_at DESC
      LIMIT 100
    `, [linkId]);

    const { rows: dailySeries } = await pool.query(`
      SELECT
        DATE(created_at) AS day,
        COALESCE(SUM(CASE WHEN event_type='purchase' AND NOT is_late_conversion THEN revenue_amount ELSE 0 END), 0) AS revenue,
        COUNT(CASE WHEN event_type='purchase' AND NOT is_late_conversion THEN 1 END) AS purchases,
        COUNT(CASE WHEN event_type='open' THEN 1 END) AS opens,
        COUNT(CASE WHEN event_type='purchase' AND is_late_conversion THEN 1 END) AS late_purchases
      FROM campaign_link_events
      WHERE deep_link_id = $1
      GROUP BY DATE(created_at)
      ORDER BY day ASC
    `, [linkId]);

    res.json({ link, events, orders, daily_series: dailySeries });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/:id/logs', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { rows: rawDeliveryLogs } = await pool.query(
      `SELECT cdl.id, cdl.campaign_id, cdl.campaign_run_id, cdl.target_type,
              cdl.telegram_id::text AS telegram_id, cdl.message_kind,
              cdl.delivery_status, cdl.telegram_message_id, cdl.error_text, cdl.created_at,
              cdl.delivery_method, cdl.source_message_id,
              cr.run_type, cr.executed_at AS run_executed_at,
              cr.source_chat_id::text AS run_source_chat_id, cr.source_message_id AS run_source_message_id,
              cr.channel_delivery_method, cr.channels_targeted, cr.channels_copied, cr.channels_failed,
              u.first_name, u.last_name, u.profile_photo_url,
              COALESCE(u.username, cdl.username) AS tg_username
       FROM campaign_delivery_logs cdl
       JOIN campaign_runs cr ON cr.id = cdl.campaign_run_id
       LEFT JOIN users u ON u.telegram_id::text = cdl.telegram_id::text
       WHERE cdl.campaign_id = $1
       ORDER BY cdl.created_at DESC LIMIT 200`,
      [req.params.id]
    );
    const deliveryLogs = rawDeliveryLogs.map((r: any) => ({ ...r, profile_photo_url: tgPhotoProxyUrl(r.profile_photo_url) }));
    const { rows: runLogs } = await pool.query(
      `SELECT * FROM campaign_runs WHERE campaign_id = $1 ORDER BY executed_at DESC LIMIT 50`,
      [req.params.id]
    );
    res.json({ delivery_logs: deliveryLogs, run_logs: runLogs });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/seed-demo', async (req: AuthenticatedRequest, res: Response) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(8675309)');

    const { rows: existingTpl } = await client.query("SELECT id FROM campaign_templates WHERE name IN ('Night Offer Start','Night Offer Expired') LIMIT 1");
    const { rows: existingCamp } = await client.query("SELECT id FROM scheduled_campaigns WHERE name = 'Night Flash Sale' LIMIT 1");
    if (existingTpl.length > 0 || existingCamp.length > 0) {
      await client.query('COMMIT');
      return res.json({ ok: true, msg: 'Demo data already exists' });
    }

    const { rows: [tplStart] } = await client.query(
      `INSERT INTO campaign_templates (name, template_type, body_text, parse_mode, inline_buttons_json)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [
        'Night Offer Start', 'promo_start',
        '🔥 <b>{campaign_name}</b> is now live!\n\n🎯 Category: <b>{category_name}</b>\n⏳ Duration: <b>{duration_name}</b>\n\n💸 Original Price: <b>{original_price}</b>\n🎁 Discount: <b>{discount_percent}% OFF</b>\n✅ Offer Price: <b>{discounted_price}</b>\n\n⚠️ Hurry! Offer expires at <b>{expires_at}</b>\n\nTap below to open the promo offer.',
        'HTML',
        JSON.stringify([{ text: '🛒 Buy Now', url: '{deep_link}' }])
      ]
    );

    const { rows: [tplExpiry] } = await client.query(
      `INSERT INTO campaign_templates (name, template_type, body_text, parse_mode, inline_buttons_json)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [
        'Night Offer Expired', 'promo_expiry',
        '⌛ <b>{campaign_name}</b> has expired.\n\n📦 Category: <b>{category_name}</b>\n⏳ Duration: <b>{duration_name}</b>\n\n💰 Current Price: <b>{current_price}</b>\n\nThe promo price is no longer active.\nCheck the bot for the latest available offers.',
        'HTML',
        JSON.stringify([{ text: '📲 Open Bot', url: '{deep_link}' }])
      ]
    );

    const { rows: cats } = await client.query('SELECT id FROM categories LIMIT 1');
    const { rows: durs } = await client.query('SELECT id FROM durations LIMIT 1');

    const catScope = cats.length > 0 ? JSON.stringify([cats[0].id]) : '[]';
    const durScope = durs.length > 0 ? JSON.stringify([durs[0].id]) : '[]';

    const now = new Date();
    const istOffsetMs = 5.5 * 60 * 60 * 1000;
    const nowIST = new Date(now.getTime() + istOffsetMs);
    const todayIST = new Date(Date.UTC(nowIST.getUTCFullYear(), nowIST.getUTCMonth(), nowIST.getUTCDate()));
    const startAt = new Date(todayIST.getTime() + 22 * 60 * 60 * 1000 - istOffsetMs);
    const expireAt = new Date(todayIST.getTime() + 23 * 60 * 60 * 1000 - istOffsetMs);
    if (startAt <= now) { startAt.setDate(startAt.getDate() + 1); expireAt.setDate(expireAt.getDate() + 1); }

    const { rows: [camp] } = await client.query(
      `INSERT INTO scheduled_campaigns
       (name, description, status, campaign_mode, category_scope_json, duration_scope_json,
        repeat_mode, timezone, start_at, expire_at, next_run_at, next_expire_at,
        promo_template_id, expiry_template_id, send_to_users, send_to_channels)
       VALUES ($1,$2,'scheduled','random_discount',$3,$4,'once','Asia/Kolkata',$5,$6,$5,$6,$7,$8,true,false) RETURNING *`,
      ['Night Flash Sale', 'Auto-created demo promo campaign', catScope, durScope,
       startAt.toISOString(), expireAt.toISOString(), tplStart.id, tplExpiry.id]
    );

    await client.query(
      `INSERT INTO campaign_discount_rules (campaign_id, discount_mode, min_value, max_value)
       VALUES ($1,'random_percent',5,25)`, [camp.id]
    );
    await client.query(
      `INSERT INTO campaign_targets (campaign_id, target_type, target_value, message_kind)
       VALUES ($1,'all_users',null,'promo_start')`, [camp.id]
    );
    const code = generateCode();
    await client.query(
      `INSERT INTO campaign_deep_links (campaign_id, code, deep_link_url) VALUES ($1,$2,$3)`,
      [camp.id, code, '']
    );

    await client.query('COMMIT');
    res.json({ ok: true, campaign_id: camp.id, templates: [tplStart.id, tplExpiry.id] });
  } catch (e: any) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

router.post('/seed-default-templates', async (req: AuthenticatedRequest, res: Response) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(8675310)');

    const { rows: existing } = await client.query(
      "SELECT id FROM campaign_templates WHERE name IN ('Default Promo Start','Default Promo Expiry') LIMIT 2"
    );
    if (existing.length >= 2) {
      await client.query('COMMIT');
      return res.json({ ok: true, msg: 'Default templates already exist' });
    }

    const names = existing.map((r: any) => r.name);
    const created: number[] = [];

    if (!names.includes('Default Promo Start')) {
      const { rows: [t] } = await client.query(
        `INSERT INTO campaign_templates (name, template_type, body_text, parse_mode, inline_buttons_json, custom_emoji_json)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
        [
          'Default Promo Start',
          'promo_start',
          `📢 <b>{campaign_name}</b> — Limited Offer\n\nHi <b>{user_name}</b> 👋\n\n💰 <b>{discount_percent}% Discounted Prices</b>\n──────────────\n{product_discount_lines}\n──────────────\n\n⏰ <b>Offer ends:</b> {expires_at}\n\nTap below to open the store and claim your deal ↓`,
          'HTML',
          JSON.stringify([{ text: '🛒 Buy Now', url: '{deep_link}', style: 'primary', emoji_id: '' }]),
          '[]',
        ]
      );
      created.push(t.id);
    }

    if (!names.includes('Default Promo Expiry')) {
      const { rows: [t] } = await client.query(
        `INSERT INTO campaign_templates (name, template_type, body_text, parse_mode, inline_buttons_json, custom_emoji_json)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
        [
          'Default Promo Expiry',
          'promo_expiry',
          `⏰ <b>{campaign_name} Expired</b>\n\nHi <b>{user_name}</b> 👋\n\nThe promotional prices have ended. Current prices are now:\n\n──────────────\n{product_expiry_lines}\n──────────────\n\nCheck the store for active offers and new discounts.`,
          'HTML',
          JSON.stringify([{ text: '📦 Open Store', url: '{deep_link}', style: 'secondary', emoji_id: '' }]),
          '[]',
        ]
      );
      created.push(t.id);
    }

    await client.query('COMMIT');
    res.json({ ok: true, created });
  } catch (e: any) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

export default router;
