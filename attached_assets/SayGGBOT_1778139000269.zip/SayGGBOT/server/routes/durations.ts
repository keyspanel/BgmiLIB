import express, { Request, Response } from 'express';
import pool from '../db';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
router.use(authMiddleware);

function cleanEmojiName(raw: string | null): { name: string; emojiId: string | null } {
  raw = (raw || '').trim();
  let emojiId: string | null = null;
  const m = raw.match(/\{(\d{5,32})\}/);
  if (m) {
    emojiId = m[1];
    raw = raw.replace(/\{\d{5,32}\}/, '');
  }
  return { name: raw.trim().replace(/\s+/g, ' '), emojiId };
}

router.get('/', async (req: Request, res: Response) => {
  try {
    const search = ((req.query.search as string) || '').trim();
    const categoryId = parseInt(req.query.category_id as string) || 0;
    let sql = `
      SELECT d.*, c.name AS category_name,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.duration_id = d.id) AS total_keys,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.duration_id = d.id AND pk.is_sold = 0) AS available_keys,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.duration_id = d.id AND pk.is_sold = 2) AS reserved_keys,
        (SELECT COUNT(*) FROM product_keys pk WHERE pk.duration_id = d.id AND pk.is_sold = 1) AS sold_keys,
        sr.source_type AS source_type,
        sr.is_active AS source_active,
        ap.name AS provider_name,
        ap.is_active AS provider_active,
        CASE
          WHEN sr.source_type IN ('api', 'api_and_manual') AND sr.is_active = true AND ap.is_active = true THEN true
          ELSE false
        END AS has_active_api_source
      FROM durations d
      LEFT JOIN categories c ON d.category_id = c.id
      LEFT JOIN source_rules sr ON sr.category_id = d.category_id AND sr.duration_id = d.id
      LEFT JOIN api_providers ap ON ap.id = sr.api_provider_id
    `;
    const where: string[] = [];
    const params: any[] = [];
    let paramIdx = 1;
    if (categoryId > 0) { where.push(`d.category_id = $${paramIdx++}`); params.push(categoryId); }
    if (search) { where.push(`d.name ILIKE $${paramIdx++}`); params.push(`%${search}%`); }
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    sql += ' ORDER BY c.name ASC, d.sort_order ASC, d.id ASC';
    const result = await pool.query(sql, params);
    const rows = result.rows.map((r: any) => {
      const parsed = cleanEmojiName(r.name);
      const parsedCat = cleanEmojiName(r.category_name);
      return { ...r, displayName: parsed.name, customEmojiId: parsed.emojiId, categoryDisplayName: parsedCat.name };
    });
    res.json(rows);
  } catch (err) {
    console.error('Durations list error:', err);
    res.status(500).json({ error: 'Failed to load durations' });
  }
});

router.get('/by-category/:categoryId', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(
      'SELECT id, name, price FROM durations WHERE category_id = $1 ORDER BY sort_order ASC, id ASC',
      [req.params.categoryId]
    );
    res.json(result.rows.map((r: any) => ({ ...r, displayName: cleanEmojiName(r.name).name })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load durations' });
  }
});

router.post('/', async (req: Request, res: Response) => {
  try {
    const { category_id, name, sort_order = 0, button_style = 4, price = 0, is_hidden = 0 } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    if (!category_id) return res.status(400).json({ error: 'Category is required' });
    const style = Math.min(4, Math.max(1, parseInt(button_style) || 4));
    const result = await pool.query(
      'INSERT INTO durations (category_id, name, sort_order, button_style, price, is_hidden) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
      [category_id, name.trim(), parseInt(sort_order) || 0, style, Math.max(0, parseFloat(price) || 0), is_hidden ? 1 : 0]
    );
    res.json({ id: result.rows[0].id, message: 'Duration created successfully' });
  } catch (err) {
    console.error('Duration create error:', err);
    res.status(500).json({ error: 'Failed to create duration' });
  }
});

router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { category_id, name, sort_order = 0, button_style = 4, price = 0, is_hidden = 0 } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    const style = Math.min(4, Math.max(1, parseInt(button_style) || 4));
    await pool.query(
      'UPDATE durations SET category_id = $1, name = $2, sort_order = $3, button_style = $4, price = $5, is_hidden = $6 WHERE id = $7',
      [category_id, name.trim(), parseInt(sort_order) || 0, style, Math.max(0, parseFloat(price) || 0), is_hidden ? 1 : 0, id]
    );
    res.json({ message: 'Duration updated successfully' });
  } catch (err) {
    console.error('Duration update error:', err);
    res.status(500).json({ error: 'Failed to update duration' });
  }
});

router.put('/:id/visibility', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { is_hidden } = req.body;
    await pool.query('UPDATE durations SET is_hidden = $1 WHERE id = $2', [is_hidden ? 1 : 0, id]);
    res.json({ message: is_hidden ? 'Duration hidden' : 'Duration visible' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update visibility' });
  }
});

router.delete('/:id', async (req: Request, res: Response) => {
  try {
    await pool.query('DELETE FROM durations WHERE id = $1', [req.params.id]);
    res.json({ message: 'Duration deleted successfully' });
  } catch (err) {
    console.error('Duration delete error:', err);
    res.status(500).json({ error: 'Failed to delete duration' });
  }
});

export default router;
