const config = {
  brandName: import.meta.env.VITE_BRAND_NAME || 'KeyStore',
  brandShortName: import.meta.env.VITE_BRAND_SHORT_NAME || 'KS',
  brandTagline: import.meta.env.VITE_BRAND_TAGLINE || 'Secure management console',
  currency: import.meta.env.VITE_CURRENCY_SYMBOL || '\u20B9',
  locale: import.meta.env.VITE_LOCALE || 'en-IN',
  apiBase: import.meta.env.VITE_API_BASE || '/api',
  portalTitle: import.meta.env.VITE_PORTAL_TITLE || 'My Keys',
  themeColor: import.meta.env.VITE_THEME_COLOR || '#1a1a2e',
  loginFooter: import.meta.env.VITE_LOGIN_FOOTER || 'Protected by secure authentication',
  productLabel: import.meta.env.VITE_PRODUCT_LABEL || 'Keys',
};

export default config;
