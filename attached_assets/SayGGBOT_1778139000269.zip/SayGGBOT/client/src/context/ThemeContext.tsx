import React, { createContext, useContext, useEffect } from 'react';

const ThemeContext = createContext<null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', '#050508');
  }, []);

  return (
    <ThemeContext.Provider value={null}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return { theme: 'dark' as const };
}
