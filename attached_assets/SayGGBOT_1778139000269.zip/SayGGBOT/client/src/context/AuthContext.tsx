import React, { createContext, useContext, useState, useEffect } from 'react';
import { setToken, clearToken, apiGet, apiPost } from '../api';

interface AuthContextValue {
  user: { username: string } | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<any>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<{ username: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      apiGet('/auth/verify')
        .then(data => { if (data.valid) setUser({ username: data.username }); })
        .catch(() => clearToken())
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (username: string, password: string) => {
    const data = await apiPost('/auth/login', { username, password });
    setToken(data.token);
    setUser({ username: data.username });
    return data;
  };

  const logout = () => {
    clearToken();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  return useContext(AuthContext)!;
}
