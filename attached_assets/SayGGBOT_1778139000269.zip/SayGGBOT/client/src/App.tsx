import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Categories from './pages/Categories';
import Durations from './pages/Durations';
import Keys from './pages/Keys';
import Orders from './pages/Orders';
import Users from './pages/Users';
import PaidUsers from './pages/PaidUsers';
import Resellers from './pages/Resellers';
import UserDiscounts from './pages/UserDiscounts';
import BotManage from './pages/BotManage';
import ForceJoin from './pages/ForceJoin';
import UserKeys from './pages/UserKeys';
import SourceConfig from './pages/SourceConfig';
import Campaigns from './pages/Campaigns';
import Channels from './pages/Channels';
import TrialCampaigns from './pages/TrialCampaigns';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading...</span></div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function AppRoutes() {
  const { user, loading } = useAuth();
  if (loading) return <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading...</span></div>;

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/keys-portal" element={<UserKeys />} />
      <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="categories" element={<Categories />} />
        <Route path="durations" element={<Durations />} />
        <Route path="keys" element={<Keys />} />
        <Route path="orders" element={<Orders />} />
        <Route path="users" element={<Users />} />
        <Route path="paid-users" element={<PaidUsers />} />
        <Route path="resellers" element={<Resellers />} />
        <Route path="user-discounts" element={<UserDiscounts />} />
        <Route path="bot-manage" element={<BotManage />} />
        <Route path="force-join" element={<ForceJoin />} />
        <Route path="source-config" element={<SourceConfig />} />
        <Route path="campaigns" element={<Campaigns />} />
        <Route path="channels" element={<Channels />} />
        <Route path="trial-campaigns" element={<TrialCampaigns />} />
        <Route path="trial-keys" element={<Navigate to="/trial-campaigns" replace />} />
        <Route path="trial-templates" element={<Navigate to="/trial-campaigns" replace />} />
        <Route path="trial-logs" element={<Navigate to="/trial-campaigns" replace />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
