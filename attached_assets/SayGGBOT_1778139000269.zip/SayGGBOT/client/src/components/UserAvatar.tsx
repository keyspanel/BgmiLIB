import { useState, useEffect } from 'react';

interface UserAvatarProps {
  name: string;
  photoUrl?: string | null;
  className?: string;
  size?: 'sm' | 'md';
}

export default function UserAvatar({ name, photoUrl, className = '', size = 'md' }: UserAvatarProps) {
  const [imgError, setImgError] = useState(false);
  const initials = (name || 'U').substring(0, 2).toUpperCase();

  useEffect(() => {
    setImgError(false);
  }, [photoUrl]);

  if (photoUrl && !imgError) {
    return (
      <div className={`avatar ${className}`}>
        <img
          src={photoUrl}
          alt={name}
          className={`avatar-img ${size === 'sm' ? 'avatar-img-sm' : ''}`}
          onError={() => setImgError(true)}
          loading="lazy"
        />
      </div>
    );
  }

  return <div className={`avatar ${className}`}>{initials}</div>;
}
