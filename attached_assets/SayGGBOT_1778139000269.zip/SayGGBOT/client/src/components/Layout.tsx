import React, { useState, useEffect } from 'react';
import { Outlet, useLocation, NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import cfg from '../config';

const pageConfig: Record<string, { title: string; desc: string }> = {
  '/': { title: 'Dashboard', desc: 'Overview of your business performance' },
  '/categories': { title: 'Categories', desc: 'Organize your product catalog' },
  '/durations': { title: 'Durations', desc: 'Manage time-based pricing plans' },
  '/keys': { title: cfg.productLabel, desc: `View and manage your ${cfg.productLabel.toLowerCase()} inventory` },
  '/orders': { title: 'Orders', desc: 'Track transactions and payment status' },
  '/users': { title: 'Bot Users', desc: 'Manage your Telegram user base' },
  '/paid-users': { title: 'Paid Users', desc: 'Customer purchase history and profiles' },
  '/resellers': { title: 'Resellers', desc: 'Partner network and pricing rules' },
  '/user-discounts': { title: 'User Discounts', desc: 'Promotional discount plans for all users' },
  '/bot-manage': { title: 'Bot Settings', desc: 'Configure bot behavior and display settings' },
  '/force-join': { title: 'Force Join', desc: 'Require channel membership before ordering' },
  '/source-config': { title: 'Source Config', desc: 'Configure key source rules per category and duration' },
  '/campaigns': { title: 'Campaigns', desc: 'Scheduled promo campaigns with auto-discount and deep link tracking' },
  '/channels': { title: 'Channel Configuration', desc: 'Manage Telegram channels used for campaign and scheduled delivery' },
  '/trial-campaigns': { title: 'Trial Campaigns', desc: 'Trial campaigns, templates, keys & logs — one key per category per run' },
};

const navGroups = [
  {
    label: 'Overview',
    items: [
      {
        to: '/',
        label: 'Dashboard',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
            <rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Store',
    items: [
      {
        to: '/categories',
        label: 'Categories',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
          </svg>
        ),
      },
      {
        to: '/durations',
        label: 'Durations',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 12"/>
          </svg>
        ),
      },
      {
        to: '/keys',
        label: cfg.productLabel,
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
          </svg>
        ),
      },
      {
        to: '/source-config',
        label: 'Source Config',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Orders & Users',
    items: [
      {
        to: '/orders',
        label: 'Orders',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
          </svg>
        ),
      },
      {
        to: '/users',
        label: 'Bot Users',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>
            <path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
          </svg>
        ),
      },
      {
        to: '/paid-users',
        label: 'Paid Users',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
          </svg>
        ),
      },
      {
        to: '/resellers',
        label: 'Resellers',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="9" cy="7" r="3"/><path d="M3 21v-2a4 4 0 014-4h4a4 4 0 014 4v2"/>
            <path d="M16 3.13a4 4 0 010 7.75M21 21v-2a4 4 0 00-3-3.87"/>
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Promotions',
    items: [
      {
        to: '/user-discounts',
        label: 'User Discounts',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
          </svg>
        ),
      },
      {
        to: '/campaigns',
        label: 'Campaigns',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Trials',
    items: [
      {
        to: '/trial-campaigns',
        label: 'Trial Campaigns',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Bot & Access',
    items: [
      {
        to: '/bot-manage',
        label: 'Bot Settings',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3"/>
            <path d="M19.07 4.93a10 10 0 010 14.14M4.93 4.93a10 10 0 000 14.14M12 2v2m0 16v2M2 12h2m16 0h2"/>
          </svg>
        ),
      },
      {
        to: '/force-join',
        label: 'Force Join',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        ),
      },
      {
        to: '/channels',
        label: 'Channels',
        icon: (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 10h16M4 14h16M8 6l-2 12M18 6l-2 12"/>
          </svg>
        ),
      },
    ],
  },
];

function LogoutIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
      <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
    </svg>
  );
}

function DrawerNavContent({ onClose }: { onClose: () => void }) {
  const { logout } = useAuth();

  return (
    <>
      <div className="drawer-header">
        <div className="drawer-brand">
          <div className="drawer-brand-icon">{cfg.brandShortName}</div>
          <div className="drawer-brand-text">
            <div className="drawer-brand-name">{cfg.brandName}</div>
            <div className="drawer-brand-tag">{cfg.brandTagline}</div>
          </div>
        </div>
        <button className="drawer-close-btn" onClick={onClose} aria-label="Close menu">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      <nav className="drawer-nav">
        {navGroups.map(group => (
          <div key={group.label} className="sb-group">
            <div className="sb-group-label">{group.label}</div>
            {group.items.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) => `sb-item${isActive ? ' active' : ''}`}
                onClick={onClose}
              >
                <span className="sb-item-icon">{item.icon}</span>
                <span className="sb-item-label">{item.label}</span>
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="drawer-footer">
        <button className="drawer-signout-btn" onClick={() => { logout(); onClose(); }}>
          <span className="drawer-signout-icon"><LogoutIcon /></span>
          <span>Sign out</span>
        </button>
      </div>
    </>
  );
}

function SidebarContent() {
  const { logout } = useAuth();

  return (
    <>
      <div className="sb-brand">
        <div className="sb-brand-icon">{cfg.brandShortName}</div>
        <div className="sb-brand-text">
          <div className="sb-brand-name">{cfg.brandName}</div>
          <div className="sb-brand-tag">{cfg.brandTagline}</div>
        </div>
      </div>

      <nav className="sb-nav">
        {navGroups.map(group => (
          <div key={group.label} className="sb-group">
            <div className="sb-group-label">{group.label}</div>
            {group.items.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) => `sb-item${isActive ? ' active' : ''}`}
              >
                <span className="sb-item-icon">{item.icon}</span>
                <span className="sb-item-label">{item.label}</span>
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="sb-footer">
        <button className="sb-footer-btn sb-footer-btn-danger" onClick={logout}>
          <span className="sb-footer-btn-icon"><LogoutIcon /></span>
          <span>Sign out</span>
        </button>
      </div>
    </>
  );
}

export default function Layout() {
  const location = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const config = pageConfig[location.pathname] || { title: cfg.brandName, desc: '' };
  const isDashboard = location.pathname === '/';

  useEffect(() => { setDrawerOpen(false); }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = drawerOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [drawerOpen]);

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <SidebarContent />
      </aside>

      <div
        className={`nav-backdrop${drawerOpen ? ' open' : ''}`}
        onClick={() => setDrawerOpen(false)}
        aria-hidden="true"
      />
      <div className={`mobile-drawer${drawerOpen ? ' open' : ''}`} role="dialog" aria-modal="true">
        <DrawerNavContent onClose={() => setDrawerOpen(false)} />
      </div>

      <div className={`admin-body${drawerOpen ? ' blurred' : ''}`}>
        <header className="admin-topbar">
          <div className="topbar-brand">
            <div className="topbar-brand-icon">{cfg.brandShortName}</div>
            <span className="topbar-brand-name">{cfg.brandName}</span>
          </div>

          <div className="topbar-actions">
            <button
              className="topbar-btn topbar-menu-btn"
              onClick={() => setDrawerOpen(!drawerOpen)}
              aria-label="Toggle navigation"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {drawerOpen ? (
                  <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>
                ) : (
                  <><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></>
                )}
              </svg>
            </button>
          </div>
        </header>

        <main className="admin-main">
          <div className="page-container">
            {!isDashboard && location.pathname !== '/source-config' && location.pathname !== '/campaigns' && location.pathname !== '/trial-campaigns' && (
              <div className="page-head">
                <h1 className="page-title">{config.title}</h1>
                {config.desc && <p className="page-desc">{config.desc}</p>}
              </div>
            )}
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
