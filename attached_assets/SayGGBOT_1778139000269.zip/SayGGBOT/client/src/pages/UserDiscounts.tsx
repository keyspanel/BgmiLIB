import React, { useEffect, useState, useCallback, useRef } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';
import cfg from '../config';

const SCOPE_OPTIONS = [
  { value: 'all_categories', label: 'All Categories' },
  { value: 'one_category', label: 'One Category' },
  { value: 'per_categories', label: 'Per Category Rules' },
  { value: 'per_category_duration_prices', label: 'Custom Per Duration Prices' },
];

const SCOPE_LABELS: Record<string, string> = { all_categories: 'All Categories', one_category: 'Single Category', per_categories: 'Per Category', per_category_duration_prices: 'Custom Prices' };

const MODE_OPTIONS = [
  { value: 'percent', label: 'Percentage Discount' },
  { value: 'fixed', label: 'Fixed Amount Discount' },
  { value: 'price', label: 'Override Fixed Price' },
  { value: 'custom_prices', label: 'Custom Per Duration Prices' },
];

const TAB_PLANS = 'plans';
const TAB_LOGS = 'logs';
const TAB_STATS = 'stats';
const TAB_BROADCASTS = 'broadcasts';
const TAB_TEMPLATES = 'templates';

const SvgIcon = ({ d, size = 18, className = '' }: { d: string; size?: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d={d} />
  </svg>
);

const ICONS: Record<string, string> = {
  plans: 'M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z',
  active: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
  orders: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2',
  revenue: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  savings: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6',
  edit: 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z',
  broadcast: 'M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z',
  trash: 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16',
  power: 'M18.364 5.636a9 9 0 010 12.728M5.636 5.636a9 9 0 000 12.728M12 3v9',
  clock: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
  plus: 'M12 6v6m0 0v6m0-6h6m-6 0H6',
  refresh: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
  filter: 'M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z',
  check: 'M5 13l4 4L19 7',
  x: 'M6 18L18 6M6 6l12 12',
  send: 'M3 3l1.664 1.664M3 3v5.868l6.708-1.336M21 3l-1.664 1.664M21 3v5.868l-6.708-1.336M3 21l1.664-1.664M3 21v-5.868l6.708 1.336M21 21l-1.664-1.664M21 21v-5.868l-6.708 1.336',
  eye: 'M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z',
  chart: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
  users: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z',
  shield: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
  save: 'M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4',
  chevDown: 'M19 9l-7 7-7-7',
  chevLeft: 'M15 19l-7-7 7-7',
  chevRight: 'M9 5l7 7-7 7',
  scope: 'M4 6h16M4 10h16M4 14h16M4 18h16',
  tag: 'M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z',
  search: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z',
  calendar: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
  clearAll: 'M6 18L18 6M6 6l12 12',
};

const TEMPLATE_DEFAULTS: Record<string, string> = {
  tpl_discount_broadcast_title: '\uD83D\uDCE2 <b>{plan_name} \u2014 Limited Offer</b>',
  tpl_discount_broadcast_body:
    'Hi <b>{first_name}</b> \uD83D\uDC4B\n\n' +
    '{description}\n\n' +
    '\uD83D\uDCB0 <b>Discounted Prices</b>\n' +
    '\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n' +
    '{pricing_examples}\n' +
    '\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n\n' +
    '\u23F0 <b>Offer ends:</b> {expiry_time}',
  tpl_discount_broadcast_footer: 'Open the store now and claim your deal \u2193',
  discount_broadcast_buttons: '[]',
  discount_broadcast_send_categories: '0',
  discount_offer_ended_title: '\u23F3 <b>This Offer Has Ended</b>',
  discount_offer_ended_body:
    'Sorry, this discount offer is no longer active.\n\n' +
    'Tap /start to see current prices \u2014 new deals drop regularly.',
  msg_broadcast_progress: '\u23F3 Broadcasting\u2026 {sent}/{total} sent',
  msg_broadcast_complete:
    '\u2705 <b>Broadcast Complete</b>\n\n' +
    '\u2022 Delivered: <b>{sent}</b>\n' +
    '\u2022 Failed: <b>{failed}</b>\n' +
    '\u2022 Skipped: <b>{skipped}</b>\n' +
    '\u2022 Total: <b>{total}</b>',
  msg_broadcast_error: '\u274C <b>Broadcast Failed</b>\n{error}',
  broadcast_pin_message: '0',
};

export default function UserDiscounts() {
  const [tab, setTab] = useState(TAB_PLANS);
  const [plans, setPlans] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [durations, setDurations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({
    name: '', description: '', expires_at: '', apply_scope: 'all_categories', rule_mode: 'percent',
    category_id: '', rule_value: 0, duration_prices: {}, category_rules: {}, is_active: false,
  });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [msgType, setMsgType] = useState('info');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const [logs, setLogs] = useState<any[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);
  const [logsPage, setLogsPage] = useState(1);
  const [logsTotal, setLogsTotal] = useState(0);
  const [logsTotalPages, setLogsTotalPages] = useState(1);
  const [logFilters, setLogFilters] = useState({ planId: '', search: '', dateFrom: '', dateTo: '', status: '' });

  const [stats, setStats] = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(false);

  const [preview, setPreview] = useState<any[] | null>(null);

  const [deleteModal, setDeleteModal] = useState<any>(null);

  const [broadcasts, setBroadcasts] = useState<any[]>([]);
  const [broadcastsLoading, setBroadcastsLoading] = useState(false);
  const [broadcastsPlanId, setBroadcastsPlanId] = useState<number | null>(null);

  const [tplSettings, setTplSettings] = useState<Record<string, string>>({});
  const [tplLoading, setTplLoading] = useState(false);
  const [tplSaving, setTplSaving] = useState(false);

  const [bcModal, setBcModal] = useState<any>(null);
  const [bcTemplate, setBcTemplate] = useState('');
  const [bcPreview, setBcPreview] = useState<any>(null);
  const [bcSending, setBcSending] = useState(false);
  const [bcResult, setBcResult] = useState<any>(null);
  const [bcQueueId, setBcQueueId] = useState<string | null>(null);
  const pollRef = useRef<any>(null);

  const showMsg = (text: string, type = 'info') => {
    setMsg(text);
    setMsgType(type);
    if (type !== 'error') setTimeout(() => setMsg(''), 3000);
  };

  const openBroadcast = async (plan: any) => {
    setBcResult(null);
    setBcSending(false);
    setBcPreview(null);
    setBcQueueId(null);
    try {
      const data = await apiGet(`/discount-plans/${plan.id}/broadcast-template`);
      const planTpl = (data.plan?.broadcast_template || '').trim();
      setBcTemplate(planTpl);
      setBcModal({ plan: data.plan, planId: plan.id, planName: plan.name });
      loadBcPreview(plan.id, planTpl);
    } catch (err: any) {
      showMsg('Failed to load broadcast data: ' + err.message, 'error');
    }
  };

  const loadBcPreview = async (planId: number, tplOverride: string) => {
    try {
      const data = await apiPost(`/discount-plans/${planId}/broadcast/preview`, { template_override: tplOverride || '' });
      setBcPreview(data);
    } catch { setBcPreview(null); }
  };

  const saveBcTemplate = async () => {
    if (!bcModal) return;
    try {
      await apiPut(`/discount-plans/${bcModal.planId}/broadcast-template`, { broadcast_template: bcTemplate });
      showMsg('Plan broadcast template saved', 'success');
    } catch (err: any) { showMsg(err.message, 'error'); }
  };

  const sendBroadcast = async () => {
    if (!bcModal) return;
    if (!confirm(`Send this broadcast to all normal users for "${bcModal.planName}"? Reseller users will be excluded.`)) return;
    setBcSending(true);
    setBcResult(null);
    try {
      const data = await apiPost(`/discount-plans/${bcModal.planId}/broadcast/send`, { template_override: bcTemplate || '' });
      setBcQueueId(data.queue_id);
      showMsg('Broadcast queued — sending...', 'info');
      pollBroadcastStatus(data.queue_id);
    } catch (err: any) {
      setBcSending(false);
      showMsg('Broadcast failed: ' + err.message, 'error');
    }
  };

  const pollBroadcastStatus = useCallback((qId: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const data = await apiGet(`/discount-plans/broadcast/status/${qId}`);
        if (data.status === 'completed' || data.status === 'failed') {
          clearInterval(pollRef.current);
          pollRef.current = null;
          setBcSending(false);
          setBcResult(data.result || { error: 'Unknown result' });
        }
      } catch {
        clearInterval(pollRef.current);
        pollRef.current = null;
        setBcSending(false);
        setBcResult({ error: 'Failed to check broadcast status' });
      }
    }, 2000);
  }, []);

  useEffect(() => {
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []);

  const closeBroadcast = () => {
    setBcModal(null);
    setBcPreview(null);
    setBcResult(null);
    setBcSending(false);
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
  };

  const load = () => {
    setLoading(true);
    apiGet('/discount-plans').then(setPlans).catch(() => {}).finally(() => setLoading(false));
  };

  const loadLogs = (page = 1, f?: any) => {
    const ff = f || logFilters;
    setLogsLoading(true);
    const p = new URLSearchParams({ page: String(page), limit: '50' });
    if (ff.planId) p.set('plan_id', ff.planId);
    if (ff.search) p.set('search', ff.search);
    if (ff.dateFrom) p.set('date_from', ff.dateFrom);
    if (ff.dateTo) p.set('date_to', ff.dateTo);
    if (ff.status) p.set('status', ff.status);
    apiGet(`/discount-plans/logs?${p.toString()}`).then((data: any) => {
      setLogs(data.logs || []);
      setLogsTotal(data.total || 0);
      setLogsTotalPages(data.pages || 1);
      setLogsPage(data.page || 1);
    }).catch(() => {}).finally(() => setLogsLoading(false));
  };

  const updateLogFilter = (key: string, value: string) => {
    const updated = { ...logFilters, [key]: value };
    setLogFilters(updated);
    loadLogs(1, updated);
  };

  const clearLogFilters = () => {
    const cleared = { planId: '', search: '', dateFrom: '', dateTo: '', status: '' };
    setLogFilters(cleared);
    loadLogs(1, cleared);
  };

  const loadStats = () => {
    setStatsLoading(true);
    apiGet('/discount-plans/stats').then(setStats).catch(() => {}).finally(() => setStatsLoading(false));
  };

  useEffect(() => {
    apiGet('/discount-plans/categories').then(setCategories).catch(() => {});
    apiGet('/discount-plans/durations').then(setDurations).catch(() => {});
    load();
  }, []);

  useEffect(() => {
    if (tab === TAB_LOGS) loadLogs(1);
    if (tab === TAB_STATS) loadStats();
    if (tab === TAB_TEMPLATES) loadTemplateSettings();
  }, [tab]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      name: '', description: '', expires_at: '', apply_scope: 'all_categories', rule_mode: 'percent',
      category_id: '', rule_value: 0, duration_prices: {}, category_rules: {}, is_active: false,
    });
    setPreview(null);
    setShowForm(true);
  };

  const openEdit = (item: any) => {
    setEditing(item);
    let scope = item.apply_scope || 'all_categories';
    let mode = 'percent', catId: any = '', ruleVal: any = 0, durPrices: any = {}, catRules: any = {};
    const rules = item.rules || [];

    if (scope === 'per_category_duration_prices' || (rules.length > 0 && rules[0].duration_id && rules[0].override_price !== null)) {
      mode = 'custom_prices';
      catId = rules[0]?.category_id || '';
      rules.forEach((r: any) => {
        if (r.duration_id) {
          const key = scope === 'per_category_duration_prices' && r.category_id ? `${r.category_id}_${r.duration_id}` : r.duration_id;
          durPrices[key] = r.override_price ?? r.discount_value ?? 0;
        }
      });
    } else if (scope === 'per_categories') {
      const r0 = rules[0];
      if (r0) {
        mode = r0.override_price !== null ? 'price' : r0.discount_type === 'percent' ? 'percent' : 'fixed';
        rules.forEach((r: any) => {
          catRules[r.category_id] = r.override_price !== null ? r.override_price : r.discount_value || 0;
        });
      }
    } else if (scope === 'one_category') {
      catId = rules[0]?.category_id || '';
      if (rules.some((r: any) => r.duration_id)) {
        mode = 'custom_prices';
        rules.forEach((r: any) => { if (r.duration_id) durPrices[r.duration_id] = r.override_price ?? r.discount_value ?? 0; });
      } else if (rules[0]) {
        const r = rules[0];
        mode = r.override_price !== null ? 'price' : r.discount_type === 'percent' ? 'percent' : 'fixed';
        ruleVal = r.override_price !== null ? r.override_price : r.discount_value || 0;
      }
    } else {
      if (rules[0]) {
        const r = rules[0];
        mode = r.override_price !== null ? 'price' : r.discount_type === 'percent' ? 'percent' : 'fixed';
        ruleVal = r.override_price !== null ? r.override_price : r.discount_value || 0;
      }
    }

    setForm({
      name: item.name || '',
      description: item.description || '',
      expires_at: item.expires_at ? item.expires_at.slice(0, 16) : '',
      apply_scope: scope,
      rule_mode: mode,
      category_id: catId,
      rule_value: ruleVal,
      duration_prices: durPrices,
      category_rules: catRules,
      is_active: item.is_active,
    });
    setPreview(null);
    setShowForm(true);
  };

  const buildRulesPayload = () => {
    const rules: any[] = [];
    const { apply_scope, rule_mode, category_id, rule_value, duration_prices, category_rules } = form;

    const makeRule = (catId: any, durId: any, val: any) => {
      if (rule_mode === 'price') return { category_id: catId, duration_id: durId, discount_type: null, discount_value: null, override_price: parseFloat(val) || 0 };
      if (rule_mode === 'percent') return { category_id: catId, duration_id: durId, discount_type: 'percent', discount_value: parseFloat(val) || 0, override_price: null };
      if (rule_mode === 'fixed') return { category_id: catId, duration_id: durId, discount_type: 'fixed', discount_value: parseFloat(val) || 0, override_price: null };
      return { category_id: catId, duration_id: durId, discount_type: null, discount_value: null, override_price: parseFloat(val) || 0 };
    };

    if (apply_scope === 'all_categories') {
      if (rule_mode === 'custom_prices') {
        Object.entries(duration_prices).forEach(([dId, price]) => {
          rules.push({ category_id: null, duration_id: parseInt(dId), discount_type: null, discount_value: null, override_price: parseFloat(price as string) || 0 });
        });
      } else {
        rules.push(makeRule(null, null, rule_value));
      }
    } else if (apply_scope === 'one_category') {
      const cid = parseInt(category_id) || null;
      if (rule_mode === 'custom_prices') {
        Object.entries(duration_prices).forEach(([dId, price]) => {
          rules.push({ category_id: cid, duration_id: parseInt(dId), discount_type: null, discount_value: null, override_price: parseFloat(price as string) || 0 });
        });
      } else {
        rules.push(makeRule(cid, null, rule_value));
      }
    } else if (apply_scope === 'per_categories') {
      Object.entries(category_rules).forEach(([cId, val]) => {
        rules.push(makeRule(parseInt(cId), null, val));
      });
    } else if (apply_scope === 'per_category_duration_prices') {
      Object.entries(duration_prices).forEach(([key, price]) => {
        const [cId, dId] = key.split('_').map(Number);
        rules.push({ category_id: cId, duration_id: dId, discount_type: null, discount_value: null, override_price: parseFloat(price as string) || 0 });
      });
    }
    return rules;
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        description: form.description,
        apply_scope: form.apply_scope,
        expires_at: form.expires_at || null,
        is_active: form.is_active,
        rules: buildRulesPayload(),
      };
      if (editing) await apiPut(`/discount-plans/${editing.id}`, payload);
      else await apiPost('/discount-plans', payload);
      setShowForm(false);
      showMsg(editing ? 'Discount plan updated' : 'Discount plan created', 'success');
      load();
    } catch (err: any) { showMsg(err.message, 'error'); }
    setSaving(false);
  };

  const toggleActive = async (item: any) => {
    try {
      if (item.is_active) {
        await apiPost(`/discount-plans/${item.id}/deactivate`);
      } else {
        await apiPost(`/discount-plans/${item.id}/activate`);
      }
      load();
    } catch (err: any) { showMsg(err.message, 'error'); }
  };

  const remove = (item: any) => {
    setDeleteModal(item);
  };

  const confirmDelete = async (deleteMessages: boolean) => {
    if (!deleteModal) return;
    try {
      await apiDelete(`/discount-plans/${deleteModal.id}?delete_messages=${deleteMessages}`);
      setDeleteModal(null);
      showMsg(deleteMessages ? 'Plan deleted, messages being removed...' : 'Discount plan deleted', 'success');
      load();
    } catch (err: any) { showMsg(err.message, 'error'); }
  };

  const loadBroadcasts = async (planId: number) => {
    if (!planId) { setBroadcastsPlanId(null); setBroadcasts([]); return; }
    setBroadcastsPlanId(planId);
    setBroadcastsLoading(true);
    try {
      const data = await apiGet(`/discount-plans/${planId}/broadcasts`);
      setBroadcasts(data || []);
    } catch { setBroadcasts([]); }
    setBroadcastsLoading(false);
  };

  const deleteBroadcastMessages = async (queueId: number) => {
    if (!confirm('Delete all sent messages for this broadcast from user chats?')) return;
    try {
      await apiPost(`/discount-plans/broadcasts/${queueId}/delete-messages`);
      showMsg('Message deletion queued', 'success');
      if (broadcastsPlanId) loadBroadcasts(broadcastsPlanId);
    } catch (err: any) { showMsg(err.message, 'error'); }
  };

  const loadTemplateSettings = async () => {
    setTplLoading(true);
    try {
      const data = await apiGet('/discount-plans/settings/templates');
      const merged: Record<string, string> = { ...TEMPLATE_DEFAULTS };
      if (data && typeof data === 'object') {
        for (const key of Object.keys(TEMPLATE_DEFAULTS)) {
          const v = data[key];
          if (v !== undefined && v !== null && v !== '') merged[key] = v;
        }
      }
      setTplSettings(merged);
    } catch { setTplSettings({ ...TEMPLATE_DEFAULTS }); }
    setTplLoading(false);
  };

  const saveTemplateSettings = async () => {
    setTplSaving(true);
    try {
      await apiPut('/discount-plans/settings/templates', tplSettings);
      showMsg('Template settings saved', 'success');
    } catch (err: any) { showMsg(err.message, 'error'); }
    setTplSaving(false);
  };

  const loadPreview = async () => {
    try {
      const data = await apiPost('/discount-plans/preview', {
        apply_scope: form.apply_scope,
        rules: buildRulesPayload(),
      });
      setPreview(data.preview || []);
    } catch { setPreview(null); }
  };

  const catDurations = durations.filter((d: any) => d.category_id === parseInt(form.category_id));
  const formatDate = (d: string | null) => d ? new Date(d).toLocaleString(cfg.locale, { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }) : 'No expiry';
  const isExpired = (d: string | null) => d ? new Date(d) < new Date() : false;

  const ruleDescription = (r: any) => {
    if (r.override_price !== null && r.override_price !== undefined) return `Fixed ${cfg.currency}${r.override_price}`;
    if (r.discount_type === 'percent') return `${r.discount_value}% off`;
    if (r.discount_type === 'fixed') return `${cfg.currency}${r.discount_value} off`;
    return '-';
  };

  const activePlan = plans.find((p: any) => p.is_active);

  const getStatusClass = (item: any) => {
    if (item.is_active) return 'active';
    if (isExpired(item.expires_at)) return 'expired';
    return 'inactive';
  };

  const getStatusLabel = (item: any) => {
    if (item.is_active) return 'Active';
    if (isExpired(item.expires_at)) return 'Expired';
    return 'Inactive';
  };

  const PLACEHOLDERS = ['{plan_name}', '{description}', '{pricing_examples}', '{expiry_time}', '{brand}', '{first_name}', '{current_time}'];

  return (
    <div className="ud-page">
      {msg && (
        <div className={`ud-toast ${msgType}`}>
          <SvgIcon d={msgType === 'success' ? ICONS.check : msgType === 'error' ? ICONS.x : ICONS.active} size={16} />
          <span>{msg}</span>
          <button className="ud-toast-close" onClick={() => setMsg('')}>&times;</button>
        </div>
      )}

      <div className="ud-tabs">
        {[
          { key: TAB_PLANS, label: 'Plans', icon: ICONS.tag },
          { key: TAB_LOGS, label: 'Discount Audit', icon: ICONS.orders },
          { key: TAB_STATS, label: 'Stats', icon: ICONS.chart },
          { key: TAB_BROADCASTS, label: 'Broadcasts', icon: ICONS.broadcast },
          { key: TAB_TEMPLATES, label: 'Templates', icon: ICONS.edit },
        ].map(t => (
          <button
            key={t.key}
            className={`ud-tab ${tab === t.key ? 'active' : ''}`}
            onClick={() => setTab(t.key)}
          >
            <SvgIcon d={t.icon} size={15} />
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {tab === TAB_PLANS && (
        <>
          {!loading && plans.length > 0 && (
            <div className="ud-metrics">
              <div className="ud-metric-card">
                <div className="ud-metric-icon">
                  <SvgIcon d={ICONS.plans} size={18} />
                </div>
                <div className="ud-metric-body">
                  <span className="ud-metric-value">{plans.length}</span>
                  <span className="ud-metric-label">Total Plans</span>
                </div>
              </div>
              <div className={`ud-metric-card ud-metric-card--name ${activePlan ? 'glow-green' : ''}`}>
                <div className={`ud-metric-icon ${activePlan ? 'green' : 'muted'}`}>
                  <SvgIcon d={ICONS.active} size={18} />
                </div>
                <div className="ud-metric-body">
                  <span className={`ud-metric-value ${activePlan ? 'green' : 'muted'}`}>
                    {activePlan ? activePlan.name : 'None'}
                  </span>
                  <span className="ud-metric-label">Active Plan</span>
                </div>
              </div>
            </div>
          )}

          <div className="ud-toolbar">
            <button className="ud-btn ud-btn-primary" onClick={openAdd}>
              <SvgIcon d={ICONS.plus} size={16} />
              <span>New Discount Plan</span>
            </button>
          </div>

          {showForm && <PlanEditorModal
            editing={editing}
            form={form}
            setForm={setForm}
            save={save}
            saving={saving}
            preview={preview}
            loadPreview={loadPreview}
            categories={categories}
            durations={durations}
            catDurations={catDurations}
            onClose={() => setShowForm(false)}
          />}

          {deleteModal && <DeletePlanModal
            plan={deleteModal}
            onConfirm={confirmDelete}
            onCancel={() => setDeleteModal(null)}
          />}

          {bcModal && <BroadcastModal
            bcModal={bcModal}
            bcTemplate={bcTemplate}
            setBcTemplate={setBcTemplate}
            bcPreview={bcPreview}
            bcSending={bcSending}
            bcResult={bcResult}
            loadBcPreview={loadBcPreview}
            saveBcTemplate={saveBcTemplate}
            sendBroadcast={sendBroadcast}
            closeBroadcast={closeBroadcast}
            placeholders={PLACEHOLDERS}
          />}

          {loading ? (
            <div className="ud-loader">
              <div className="loader-spinner" />
              <span className="ud-loader-text">Loading discount plans...</span>
            </div>
          ) : plans.length === 0 ? (
            <div className="ud-empty">
              <div className="ud-empty-icon">
                <SvgIcon d={ICONS.plans} size={48} />
              </div>
              <h3 className="ud-empty-title">No discount plans yet</h3>
              <p className="ud-empty-desc">Create your first promotional pricing plan to offer special discounts to your users.</p>
              <button className="ud-btn ud-btn-primary" onClick={openAdd}>
                <SvgIcon d={ICONS.plus} size={16} />
                <span>Create First Plan</span>
              </button>
            </div>
          ) : (
            <div className="ud-plan-list">
              {plans.map((item: any) => (
                <PlanCard
                  key={item.id}
                  item={item}
                  expanded={expandedId === item.id}
                  onToggle={() => setExpandedId(expandedId === item.id ? null : item.id)}
                  onEdit={() => openEdit(item)}
                  onToggleActive={() => toggleActive(item)}
                  onBroadcast={() => openBroadcast(item)}
                  onDelete={() => remove(item)}
                  getStatusClass={getStatusClass}
                  getStatusLabel={getStatusLabel}
                  ruleDescription={ruleDescription}
                  formatDate={formatDate}
                  isExpired={isExpired}
                />
              ))}
            </div>
          )}
        </>
      )}

      {tab === TAB_LOGS && (
        <LogsTab
          logs={logs}
          logsLoading={logsLoading}
          logsPage={logsPage}
          logsTotal={logsTotal}
          logsTotalPages={logsTotalPages}
          filters={logFilters}
          updateFilter={updateLogFilter}
          clearFilters={clearLogFilters}
          loadLogs={loadLogs}
          plans={plans}
          categories={categories}
          formatDate={formatDate}
        />
      )}

      {tab === TAB_STATS && (
        <StatsTab stats={stats} statsLoading={statsLoading} />
      )}

      {tab === TAB_BROADCASTS && (
        <BroadcastsTab
          plans={plans}
          broadcasts={broadcasts}
          broadcastsLoading={broadcastsLoading}
          broadcastsPlanId={broadcastsPlanId}
          loadBroadcasts={loadBroadcasts}
          deleteBroadcastMessages={deleteBroadcastMessages}
          formatDate={formatDate}
        />
      )}

      {tab === TAB_TEMPLATES && (
        <TemplatesTab
          settings={tplSettings}
          setSettings={setTplSettings}
          loading={tplLoading}
          saving={tplSaving}
          onSave={saveTemplateSettings}
        />
      )}
    </div>
  );
}


function PlanCard({ item, expanded, onToggle, onEdit, onToggleActive, onBroadcast, onDelete, getStatusClass, getStatusLabel, ruleDescription, formatDate, isExpired }: any) {
  const status = getStatusClass(item);
  const [countdown, setCountdown] = useState('');

  useEffect(() => {
    if (!item.expires_at) return;
    const target = new Date(item.expires_at).getTime();
    const update = () => {
      const diff = target - Date.now();
      if (diff <= 0) {
        const elapsed = Math.abs(diff);
        const h = Math.floor(elapsed / 3600000);
        const m = Math.floor((elapsed % 3600000) / 60000);
        if (h > 24) setCountdown(`Expired ${Math.floor(h / 24)}d ago`);
        else if (h > 0) setCountdown(`Expired ${h}h ${m}m ago`);
        else setCountdown(`Expired ${m}m ago`);
      } else {
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        if (d > 0) setCountdown(`${d}d ${h}h ${m}m left`);
        else if (h > 0) setCountdown(`${h}h ${m}m ${s}s left`);
        else setCountdown(`${m}m ${s}s left`);
      }
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [item.expires_at]);

  const expired = isExpired(item.expires_at);

  return (
    <div className={`ud-plan-card ${status}`}>
      <button className="ud-plan-header" onClick={onToggle}>
        <div className="ud-plan-header-left">
          <div className={`ud-plan-status-dot ${status}`} />
          <div className="ud-plan-header-text">
            <span className="ud-plan-name">{item.name || 'Untitled Plan'}</span>
            <div className="ud-plan-meta-row">
              <span className={`ud-plan-badge ${status}`}>{getStatusLabel(item)}</span>
              <span className="ud-plan-meta-chip">{SCOPE_LABELS[item.apply_scope] || item.apply_scope}</span>
              {countdown && (
                <span className={`ud-plan-countdown ${expired ? 'expired' : 'active'}`}>
                  <SvgIcon d={ICONS.clock} size={11} />
                  <span>{countdown}</span>
                </span>
              )}
            </div>
          </div>
        </div>
        <SvgIcon d={ICONS.chevDown} size={18} className={`ud-plan-chevron ${expanded ? 'open' : ''}`} />
      </button>

      {expanded && (
        <div className="ud-plan-body">
          {expired && item.is_active && (
            <div className="ud-plan-expired-banner">
              <SvgIcon d={ICONS.clock} size={14} />
              <span>This plan has expired but is still active. Consider deactivating or deleting it.</span>
            </div>
          )}

          <div className="ud-plan-details">
            {item.description && (
              <div className="ud-plan-detail-row">
                <span className="ud-plan-detail-label">Description</span>
                <span className="ud-plan-detail-value">{item.description}</span>
              </div>
            )}
            <div className="ud-plan-detail-row">
              <span className="ud-plan-detail-label">Expires</span>
              <span className={`ud-plan-detail-value ${expired ? 'expired' : ''}`}>
                {formatDate(item.expires_at)}
              </span>
            </div>
            {item.created_at && (
              <div className="ud-plan-detail-row">
                <span className="ud-plan-detail-label">Created</span>
                <span className="ud-plan-detail-value">{formatDate(item.created_at)}</span>
              </div>
            )}
          </div>

          {item.rules && item.rules.length > 0 && (
            <div className="ud-plan-rules">
              <span className="ud-plan-rules-title">Pricing Rules</span>
              <div className="ud-plan-rules-list">
                {item.rules.map((r: any, idx: number) => (
                  <div key={idx} className="ud-plan-rule-chip">
                    <span className="ud-rule-target">
                      {r.category_display || 'All Categories'}
                      <span className="ud-rule-arrow">&rarr;</span>
                      {r.duration_display || 'All Durations'}
                    </span>
                    <span className="ud-rule-value">{ruleDescription(r)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="ud-plan-actions">
            <button className="ud-action-btn edit" onClick={onEdit}>
              <SvgIcon d={ICONS.edit} size={14} />
              <span>Edit</span>
            </button>
            <button className={`ud-action-btn ${item.is_active ? 'warning' : 'success'}`} onClick={onToggleActive}>
              <SvgIcon d={ICONS.power} size={14} />
              <span>{item.is_active ? 'Deactivate' : 'Activate'}</span>
            </button>
            <button className="ud-action-btn accent" onClick={onBroadcast}>
              <SvgIcon d={ICONS.broadcast} size={14} />
              <span>Broadcast</span>
            </button>
            <button className="ud-action-btn danger" onClick={onDelete}>
              <SvgIcon d={ICONS.trash} size={14} />
              <span>Delete</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}


function PlanEditorModal({ editing, form, setForm, save, saving, preview, loadPreview, categories, durations, catDurations, onClose }: any) {
  return (
    <div className="ud-overlay" onClick={onClose}>
      <div className="ud-editor-panel" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
        <div className="ud-editor-header">
          <div>
            <h3 className="ud-editor-title">{editing ? 'Edit Discount Plan' : 'Create New Plan'}</h3>
            <p className="ud-editor-subtitle">{editing ? 'Modify plan configuration and rules' : 'Set up a new promotional pricing plan'}</p>
          </div>
          <button className="ud-editor-close" onClick={onClose}>
            <SvgIcon d={ICONS.x} size={20} />
          </button>
        </div>

        <form onSubmit={save} className="ud-editor-body">
          <div className="ud-editor-section">
            <div className="ud-editor-section-title">Plan Information</div>

            <div className="ud-field">
              <label className="ud-label">Plan Name</label>
              <input className="ud-input" type="text" value={form.name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Summer Sale 20% OFF" />
            </div>
            <div className="ud-field">
              <label className="ud-label">Description <span className="ud-label-opt">(optional)</span></label>
              <input className="ud-input" type="text" value={form.description} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, description: e.target.value })} placeholder="Internal note for this plan" />
            </div>
            <div className="ud-field">
              <label className="ud-label">Expiry Date <span className="ud-label-opt">(optional)</span></label>
              <input className="ud-input" type="datetime-local" value={form.expires_at} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, expires_at: e.target.value })} />
            </div>

            <div className="ud-toggle-field" onClick={() => setForm({ ...form, is_active: !form.is_active })}>
              <div className={`ud-toggle ${form.is_active ? 'on' : ''}`}>
                <div className="ud-toggle-knob" />
              </div>
              <div className="ud-toggle-text">
                <span className="ud-toggle-label">Activate Plan</span>
                <span className="ud-toggle-hint">Only one plan can be active at a time</span>
              </div>
            </div>
          </div>

          <div className="ud-editor-section">
            <div className="ud-editor-section-title">Pricing Configuration</div>

            <div className="ud-field">
              <label className="ud-label">Apply Scope</label>
              <select className="ud-select" value={form.apply_scope} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setForm({ ...form, apply_scope: e.target.value })}>
                {SCOPE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>

            {form.apply_scope === 'one_category' && (
              <div className="ud-field">
                <label className="ud-label">Category</label>
                <select className="ud-select" value={form.category_id} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setForm({ ...form, category_id: e.target.value, duration_prices: {} })}>
                  <option value="">Select category</option>
                  {categories.map((c: any) => <option key={c.id} value={c.id}>{c.displayName || c.name}</option>)}
                </select>
              </div>
            )}

            {form.apply_scope !== 'per_categories' && form.apply_scope !== 'per_category_duration_prices' && (
              <div className="ud-field">
                <label className="ud-label">Discount Mode</label>
                <select className="ud-select" value={form.rule_mode} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setForm({ ...form, rule_mode: e.target.value })}>
                  {MODE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
            )}
          </div>

          <div className="ud-editor-section">
            <div className="ud-editor-section-title">Pricing Rules</div>

            {form.rule_mode === 'custom_prices' && form.apply_scope === 'one_category' && form.category_id && (
              <div className="ud-duration-grid">
                {catDurations.map((d: any) => (
                  <div key={d.id} className="ud-duration-row">
                    <div className="ud-duration-info">
                      <span className="ud-duration-name">{d.displayName || d.name}</span>
                      <span className="ud-duration-base">Base: {cfg.currency}{d.price}</span>
                    </div>
                    <input className="ud-input ud-input-sm" type="number" step="0.01" min="0"
                      value={form.duration_prices[d.id] ?? ''} placeholder={d.price}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, duration_prices: { ...form.duration_prices, [d.id]: e.target.value } })} />
                  </div>
                ))}
              </div>
            )}

            {form.rule_mode === 'custom_prices' && form.apply_scope === 'all_categories' && (
              <div className="ud-duration-grid">
                {durations.map((d: any) => (
                  <div key={d.id} className="ud-duration-row">
                    <div className="ud-duration-info">
                      <span className="ud-duration-name">
                        {(categories.find((c: any) => c.id === d.category_id)?.displayName || '')} &rarr; {d.displayName || d.name}
                      </span>
                      <span className="ud-duration-base">Base: {cfg.currency}{d.price}</span>
                    </div>
                    <input className="ud-input ud-input-sm" type="number" step="0.01" min="0"
                      value={form.duration_prices[d.id] ?? ''} placeholder={d.price}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, duration_prices: { ...form.duration_prices, [d.id]: e.target.value } })} />
                  </div>
                ))}
              </div>
            )}

            {form.apply_scope === 'per_categories' && (
              <>
                <div className="ud-field">
                  <label className="ud-label">Discount Mode</label>
                  <select className="ud-select" value={form.rule_mode} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setForm({ ...form, rule_mode: e.target.value })}>
                    {MODE_OPTIONS.filter(o => o.value !== 'custom_prices').map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </div>
                <div className="ud-duration-grid">
                  {categories.map((c: any) => (
                    <div key={c.id} className="ud-duration-row">
                      <div className="ud-duration-info">
                        <span className="ud-duration-name">{c.displayName || c.name}</span>
                      </div>
                      <input className="ud-input ud-input-sm" type="number" step="0.01" min="0"
                        value={form.category_rules[c.id] ?? ''} placeholder="0"
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, category_rules: { ...form.category_rules, [c.id]: e.target.value } })} />
                    </div>
                  ))}
                </div>
              </>
            )}

            {form.apply_scope === 'per_category_duration_prices' && (
              <div className="ud-catdur-grid">
                {categories.map((c: any) => {
                  const cDurs = durations.filter((d: any) => d.category_id === c.id);
                  if (!cDurs.length) return null;
                  return (
                    <div key={c.id} className="ud-catdur-group">
                      <div className="ud-catdur-group-title">{c.displayName || c.name}</div>
                      {cDurs.map((d: any) => (
                        <div key={d.id} className="ud-duration-row">
                          <div className="ud-duration-info">
                            <span className="ud-duration-name">{d.displayName || d.name}</span>
                            <span className="ud-duration-base">Base: {cfg.currency}{d.price}</span>
                          </div>
                          <input className="ud-input ud-input-sm" type="number" step="0.01" min="0"
                            value={form.duration_prices[`${c.id}_${d.id}`] ?? ''} placeholder={d.price}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, duration_prices: { ...form.duration_prices, [`${c.id}_${d.id}`]: e.target.value } })} />
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            )}

            {form.rule_mode !== 'custom_prices' && form.apply_scope !== 'per_categories' && form.apply_scope !== 'per_category_duration_prices' && (
              <div className="ud-field">
                <label className="ud-label">
                  {form.rule_mode === 'percent' ? 'Percentage (%)' : form.rule_mode === 'fixed' ? `Amount (${cfg.currency})` : `Fixed Price (${cfg.currency})`}
                </label>
                <input className="ud-input" type="number" step="0.01" min="0" value={form.rule_value} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, rule_value: e.target.value })} />
              </div>
            )}

            <button type="button" className="ud-btn ud-btn-ghost ud-btn-preview" onClick={loadPreview}>
              <SvgIcon d={ICONS.eye} size={15} />
              <span>Preview Prices</span>
            </button>

            {preview && (
              <div className="ud-preview-grid">
                {preview.map((p: any, i: number) => (
                  <div key={i} className={`ud-preview-row ${p.has_discount ? 'discounted' : ''}`}>
                    <span className="ud-preview-target">{p.category} &rarr; {p.duration}</span>
                    <span className="ud-preview-price">
                      {p.has_discount ? (
                        <>
                          <s className="ud-preview-base">{cfg.currency}{p.base_price}</s>
                          <strong className="ud-preview-final">{cfg.currency}{p.final_price}</strong>
                        </>
                      ) : (
                        <span className="ud-preview-base">{cfg.currency}{p.base_price}</span>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="ud-editor-footer">
            <button type="button" className="ud-btn ud-btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="ud-btn ud-btn-primary" disabled={saving}>
              {saving ? (
                <><div className="loader-spinner-sm" /> <span>Saving...</span></>
              ) : (
                <><SvgIcon d={ICONS.check} size={16} /> <span>{editing ? 'Update Plan' : 'Create Plan'}</span></>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}


function BroadcastModal({ bcModal, bcTemplate, setBcTemplate, bcPreview, bcSending, bcResult, loadBcPreview, saveBcTemplate, sendBroadcast, closeBroadcast, placeholders }: any) {
  return (
    <div className="ud-overlay" onClick={closeBroadcast}>
      <div className="ud-broadcast-panel" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
        <div className="ud-editor-header">
          <div>
            <h3 className="ud-editor-title">Broadcast Campaign</h3>
            <p className="ud-editor-subtitle">{bcModal.planName}</p>
          </div>
          <button className="ud-editor-close" onClick={closeBroadcast}>
            <SvgIcon d={ICONS.x} size={20} />
          </button>
        </div>

        <div className="ud-broadcast-body">
          <div className="ud-broadcast-targeting">
            <div className="ud-targeting-row">
              <div className="ud-targeting-icon users">
                <SvgIcon d={ICONS.users} size={16} />
              </div>
              <div className="ud-targeting-info">
                <span className="ud-targeting-label">Target Audience</span>
                <span className="ud-targeting-value">
                  {bcPreview ? <><strong>{bcPreview.target_user_count}</strong> normal users</> : 'Calculating...'}
                </span>
              </div>
            </div>
            <div className="ud-targeting-row">
              <div className="ud-targeting-icon shield">
                <SvgIcon d={ICONS.shield} size={16} />
              </div>
              <div className="ud-targeting-info">
                <span className="ud-targeting-label">Resellers</span>
                <span className="ud-targeting-value excluded">Automatically excluded</span>
              </div>
            </div>
          </div>

          <div className="ud-broadcast-section">
            <div className="ud-broadcast-section-title">
              <SvgIcon d={ICONS.edit} size={15} />
              <span>Template Editor</span>
            </div>
            <p className="ud-broadcast-hint">Leave empty to use the global default from Templates settings.</p>
            <div className="ud-placeholder-chips">
              {placeholders.map((ph: string) => (
                <button key={ph} className="ud-placeholder-chip" type="button"
                  onClick={() => setBcTemplate((prev: string) => prev + ph)}>
                  <code>{ph}</code>
                </button>
              ))}
            </div>
            <textarea
              className="ud-textarea"
              value={bcTemplate}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setBcTemplate(e.target.value)}
              rows={8}
              placeholder="Leave empty for global default template..."
            />
            <div className="ud-broadcast-tpl-actions">
              <button className="ud-btn ud-btn-ghost ud-btn-sm" onClick={() => loadBcPreview(bcModal.planId, bcTemplate)}>
                <SvgIcon d={ICONS.refresh} size={14} />
                <span>Refresh Preview</span>
              </button>
              <button className="ud-btn ud-btn-ghost ud-btn-sm" onClick={saveBcTemplate}>
                <SvgIcon d={ICONS.save} size={14} />
                <span>Save Template</span>
              </button>
              {bcTemplate && (
                <button className="ud-btn ud-btn-ghost ud-btn-sm" onClick={() => { setBcTemplate(''); loadBcPreview(bcModal.planId, ''); }}>
                  <SvgIcon d={ICONS.x} size={14} />
                  <span>Clear</span>
                </button>
              )}
            </div>
          </div>

          {bcPreview && (
            <div className="ud-broadcast-section">
              <div className="ud-broadcast-section-title">
                <SvgIcon d={ICONS.eye} size={15} />
                <span>Live Preview</span>
              </div>
              <div className="ud-preview-message">
                <div className="ud-preview-bubble" dangerouslySetInnerHTML={{ __html: bcPreview.preview_text }} />
              </div>

              {bcPreview.buttons && bcPreview.buttons.length > 0 && (
                <div className="ud-preview-buttons">
                  {bcPreview.buttons.map((btn: any, i: number) => (
                    <span key={i} className="ud-preview-button">{btn.text}</span>
                  ))}
                </div>
              )}

              {bcPreview.examples && bcPreview.examples.length > 0 && (
                <div className="ud-preview-examples">
                  <span className="ud-preview-examples-title">Pricing Examples</span>
                  {bcPreview.examples.map((ex: any, i: number) => (
                    <div key={i} className="ud-preview-example-row">
                      <span className="ud-preview-example-target">{ex.category} &rarr; {ex.duration}</span>
                      <span className="ud-preview-example-price">
                        <s>{cfg.currency}{ex.base_price.toFixed(2)}</s>
                        <strong>{cfg.currency}{ex.final_price.toFixed(2)}</strong>
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {bcResult && (
            <div className={`ud-broadcast-result ${bcResult.error ? 'error' : 'success'}`}>
              {bcResult.error ? (
                <div className="ud-broadcast-result-content">
                  <SvgIcon d={ICONS.x} size={18} />
                  <div>
                    <strong>Broadcast Failed</strong>
                    <p>{bcResult.error}</p>
                  </div>
                </div>
              ) : (
                <div className="ud-broadcast-result-content">
                  <SvgIcon d={ICONS.check} size={18} />
                  <div>
                    <strong>Broadcast Complete</strong>
                    <div className="ud-broadcast-stats">
                      <span className="ud-bc-stat sent">Sent: <strong>{bcResult.sent}</strong></span>
                      <span className="ud-bc-stat failed">Failed: <strong>{bcResult.failed}</strong></span>
                      <span className="ud-bc-stat skipped">Skipped: <strong>{bcResult.skipped}</strong></span>
                      <span className="ud-bc-stat total">Total: <strong>{bcResult.total}</strong></span>
                    </div>
                    {bcResult.categories_sent && (
                      <p className="ud-bc-note">Categories menu was also sent to each user.</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="ud-editor-footer">
            <button className="ud-btn ud-btn-ghost" onClick={closeBroadcast}>Close</button>
            <button
              className="ud-btn ud-btn-send"
              onClick={sendBroadcast}
              disabled={bcSending || (bcResult && !bcResult.error)}
            >
              {bcSending ? (
                <><div className="loader-spinner-sm" /> <span>Sending...</span></>
              ) : bcResult && !bcResult.error ? (
                <><SvgIcon d={ICONS.check} size={16} /> <span>Sent</span></>
              ) : (
                <><SvgIcon d={ICONS.broadcast} size={16} /> <span>Send Broadcast</span></>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}


function LogsTab({ logs, logsLoading, logsPage, logsTotal, logsTotalPages, filters, updateFilter, clearFilters, loadLogs, plans, categories, formatDate }: any) {
  const hasFilters = filters.planId || filters.search || filters.dateFrom || filters.dateTo || filters.status;
  const [searchDraft, setSearchDraft] = useState(filters.search || '');

  const submitSearch = () => { updateFilter('search', searchDraft); };

  const statusLabel = (s: string) => {
    if (s === 'paid') return 'Paid';
    if (s === 'pending') return 'Pending';
    if (s === 'expired') return 'Expired';
    return s;
  };
  const statusClass = (s: string) => {
    if (s === 'paid') return 'paid';
    if (s === 'pending') return 'pending';
    if (s === 'expired') return 'expired';
    return 'default';
  };

  return (
    <div className="ud-logs-section">
      <div className="ud-audit-filters">
        <div className="ud-audit-filter-row">
          <div className="ud-audit-search-wrap">
            <SvgIcon d={ICONS.search} size={14} />
            <input
              className="ud-audit-search"
              type="text"
              placeholder="Search user, order #, UTR, txn ref, plan..."
              value={searchDraft}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchDraft(e.target.value)}
              onKeyDown={(e: React.KeyboardEvent) => { if (e.key === 'Enter') submitSearch(); }}
            />
            {searchDraft && (
              <button className="ud-audit-search-clear" onClick={() => { setSearchDraft(''); updateFilter('search', ''); }}>
                <SvgIcon d={ICONS.clearAll} size={10} />
              </button>
            )}
          </div>
          <button className="ud-btn ud-btn-ghost ud-btn-sm" onClick={() => loadLogs(logsPage)}>
            <SvgIcon d={ICONS.refresh} size={14} />
          </button>
        </div>
        <div className="ud-audit-filter-row">
          <div className="ud-filter-select-wrap">
            <SvgIcon d={ICONS.tag} size={13} />
            <select className="ud-filter-select" value={filters.planId} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => updateFilter('planId', e.target.value)}>
              <option value="">All Plans</option>
              {plans.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="ud-filter-select-wrap ud-filter-sm">
            <select className="ud-filter-select" value={filters.status} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => updateFilter('status', e.target.value)}>
              <option value="">All Status</option>
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
              <option value="expired">Expired</option>
            </select>
          </div>
        </div>
        <div className="ud-audit-filter-row">
          <div className="ud-audit-date-wrap">
            <SvgIcon d={ICONS.calendar} size={13} />
            <input type="date" className="ud-audit-date" value={filters.dateFrom} onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateFilter('dateFrom', e.target.value)} />
            <span className="ud-audit-date-sep">to</span>
            <input type="date" className="ud-audit-date" value={filters.dateTo} onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateFilter('dateTo', e.target.value)} />
          </div>
          {hasFilters && (
            <button className="ud-btn ud-btn-ghost ud-btn-sm ud-btn-clear" onClick={clearFilters}>
              <SvgIcon d={ICONS.clearAll} size={12} />
              <span>Clear</span>
            </button>
          )}
        </div>
      </div>

      {logsLoading ? (
        <div className="ud-loader"><div className="loader-spinner" /><span className="ud-loader-text">Loading audit logs...</span></div>
      ) : logs.length === 0 ? (
        <div className="ud-empty">
          <div className="ud-empty-icon"><SvgIcon d={ICONS.orders} size={40} /></div>
          <h3 className="ud-empty-title">{hasFilters ? 'No matching logs' : 'No discount audit logs'}</h3>
          <p className="ud-empty-desc">{hasFilters ? 'Try adjusting your filters.' : 'Discount purchase records will appear here once orders are placed under a discount plan.'}</p>
          {hasFilters && <button className="ud-btn ud-btn-ghost ud-btn-sm" style={{ marginTop: 12 }} onClick={clearFilters}>Clear Filters</button>}
        </div>
      ) : (
        <>
          <div className="ud-logs-count">
            {logsTotal} discount record{logsTotal !== 1 ? 's' : ''} found &middot; Page {logsPage} of {logsTotalPages}
          </div>
          <div className="ud-logs-list">
            {logs.map((log: any) => (
              <div key={log.order_id} className="ud-log-card">
                <div className="ud-log-header">
                  <div className="ud-log-header-left">
                    <span className="ud-log-order-id">#{log.order_id}</span>
                    <span className={`ud-log-status-badge ${statusClass(log.status)}`}>{statusLabel(log.status)}</span>
                  </div>
                  <span className="ud-log-date">{formatDate(log.created_at)}</span>
                </div>
                <div className="ud-log-body">
                  <div className="ud-log-row">
                    <span className="ud-log-label">User</span>
                    <span className="ud-log-value">{log.user_display}</span>
                  </div>
                  <div className="ud-log-row">
                    <span className="ud-log-label">Product</span>
                    <span className="ud-log-value">{log.category_display || log.category_name || '-'} &middot; {log.duration_display || log.duration_name || '-'}</span>
                  </div>
                  {log.applied_discount_plan_name && (
                    <div className="ud-log-row">
                      <span className="ud-log-label">Plan</span>
                      <span className="ud-log-value ud-log-plan-name">{log.applied_discount_plan_name}</span>
                    </div>
                  )}
                  <div className="ud-log-pricing">
                    <div className="ud-log-price-item">
                      <span className="ud-log-price-label">Base</span>
                      <span className="ud-log-price-value">{log.base_amount != null ? `${cfg.currency}${parseFloat(log.base_amount).toFixed(2)}` : '-'}</span>
                    </div>
                    <div className="ud-log-price-item">
                      <span className="ud-log-price-label">Final</span>
                      <span className="ud-log-price-value final">{cfg.currency}{parseFloat(log.final_amount).toFixed(2)}</span>
                    </div>
                    {log.savings != null && parseFloat(log.savings) > 0 && (
                      <div className="ud-log-price-item">
                        <span className="ud-log-price-label">Saved</span>
                        <span className="ud-log-price-value saved">{cfg.currency}{parseFloat(log.savings).toFixed(2)}</span>
                      </div>
                    )}
                  </div>
                  <div className="ud-log-refs">
                    {log.txn_ref && (
                      <div className="ud-log-ref-item">
                        <span className="ud-log-ref-label">Txn Ref</span>
                        <span className="ud-log-ref-value">{log.txn_ref}</span>
                      </div>
                    )}
                    {log.paid_utr && (
                      <div className="ud-log-ref-item">
                        <span className="ud-log-ref-label">UTR</span>
                        <span className="ud-log-ref-value ud-log-ref-utr">{log.paid_utr}</span>
                      </div>
                    )}
                    {log.gateway_txn_id && (
                      <div className="ud-log-ref-item">
                        <span className="ud-log-ref-label">Gateway TXN</span>
                        <span className="ud-log-ref-value">{log.gateway_txn_id}</span>
                      </div>
                    )}
                    {log.gateway_bank_txn_id && (
                      <div className="ud-log-ref-item">
                        <span className="ud-log-ref-label">Bank TXN</span>
                        <span className="ud-log-ref-value">{log.gateway_bank_txn_id}</span>
                      </div>
                    )}
                  </div>
                  {(log.verified_at || log.delivered_at) && (
                    <div className="ud-log-timestamps">
                      {log.verified_at && <span className="ud-log-ts-item">Verified: {formatDate(log.verified_at)}</span>}
                      {log.delivered_at && <span className="ud-log-ts-item">Delivered: {formatDate(log.delivered_at)}</span>}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {logsTotalPages > 1 && (
            <div className="ud-pagination">
              <button className="ud-btn ud-btn-ghost ud-btn-sm" disabled={logsPage <= 1} onClick={() => loadLogs(logsPage - 1)}>
                <SvgIcon d={ICONS.chevLeft} size={14} />
                <span>Prev</span>
              </button>
              <span className="ud-pagination-info">Page {logsPage} of {logsTotalPages}</span>
              <button className="ud-btn ud-btn-ghost ud-btn-sm" disabled={logsPage >= logsTotalPages} onClick={() => loadLogs(logsPage + 1)}>
                <span>Next</span>
                <SvgIcon d={ICONS.chevRight} size={14} />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}


function DeletePlanModal({ plan, onConfirm, onCancel }: any) {
  const [deleteMessages, setDeleteMessages] = useState(false);
  return (
    <div className="ud-overlay ud-overlay--center" onClick={onCancel}>
      <div className="ud-delete-panel" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
        <div className="ud-delete-header">
          <div className="ud-delete-icon-wrap">
            <SvgIcon d={ICONS.trash} size={24} />
          </div>
          <h3 className="ud-delete-title">Delete Discount Plan</h3>
        </div>
        <div className="ud-delete-body">
          <p className="ud-delete-msg">
            This will permanently remove <strong>{plan.name}</strong> and all its pricing rules. This action cannot be undone.
          </p>
          <div className={`ud-delete-toggle ${deleteMessages ? 'on' : ''}`} onClick={() => setDeleteMessages(!deleteMessages)}>
            <div className={`ud-toggle ${deleteMessages ? 'on' : ''}`}>
              <div className="ud-toggle-knob" />
            </div>
            <div className="ud-toggle-text">
              <span className="ud-toggle-label">Also delete broadcast messages</span>
              <span className="ud-toggle-hint">Removes all previously sent broadcast messages from user chats via a background job</span>
            </div>
          </div>
        </div>
        <div className="ud-delete-footer">
          <button className="ud-btn ud-btn-ghost" onClick={onCancel}>Cancel</button>
          <button className="ud-btn ud-btn-danger" onClick={() => onConfirm(deleteMessages)}>
            <SvgIcon d={ICONS.trash} size={14} />
            <span>Delete Plan</span>
          </button>
        </div>
      </div>
    </div>
  );
}


function BroadcastsTab({ plans, broadcasts, broadcastsLoading, broadcastsPlanId, loadBroadcasts, deleteBroadcastMessages, formatDate }: any) {
  return (
    <div className="ud-broadcasts-section">
      <div className="ud-broadcasts-header">
        <div className="ud-filter-select-wrap">
          <SvgIcon d={ICONS.tag} size={13} />
          <select
            className="ud-filter-select"
            value={broadcastsPlanId || ''}
            onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
              const val = e.target.value;
              if (!val) { loadBroadcasts(0); return; }
              const id = parseInt(val);
              if (id) loadBroadcasts(id);
            }}
          >
            <option value="">Select a plan...</option>
            {plans.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
      </div>

      {!broadcastsPlanId ? (
        <div className="ud-empty">
          <div className="ud-empty-icon"><SvgIcon d={ICONS.broadcast} size={40} /></div>
          <h3 className="ud-empty-title">Select a plan</h3>
          <p className="ud-empty-desc">Choose a discount plan above to view its broadcast history.</p>
        </div>
      ) : broadcastsLoading ? (
        <div className="ud-loader"><div className="loader-spinner" /><span className="ud-loader-text">Loading broadcasts...</span></div>
      ) : broadcasts.length === 0 ? (
        <div className="ud-empty">
          <div className="ud-empty-icon"><SvgIcon d={ICONS.broadcast} size={40} /></div>
          <h3 className="ud-empty-title">No broadcasts sent</h3>
          <p className="ud-empty-desc">No broadcast messages have been sent for this plan yet.</p>
        </div>
      ) : (
        <div className="ud-broadcasts-list">
          {broadcasts.map((bc: any) => {
            const result = bc.result || {};
            const sent = result.sent || 0;
            const failed = result.failed || 0;
            const skipped = result.skipped || 0;
            const msgCount = parseInt(bc.message_count || '0');

            return (
              <div key={bc.id} className="ud-broadcast-card">
                <div className="ud-broadcast-card-header">
                  <div className="ud-broadcast-card-left">
                    <span className="ud-broadcast-card-id">#{bc.id}</span>
                    <span className={`ud-log-status-badge ${bc.status === 'completed' ? 'paid' : bc.status === 'failed' ? 'expired' : 'pending'}`}>
                      {bc.status}
                    </span>
                  </div>
                  <span className="ud-broadcast-card-date">{formatDate(bc.created_at)}</span>
                </div>
                {bc.status === 'completed' && (
                  <div className="ud-broadcast-card-stats">
                    <span className="ud-bc-stat sent">Sent: <strong>{sent}</strong></span>
                    <span className="ud-bc-stat failed">Failed: <strong>{failed}</strong></span>
                    <span className="ud-bc-stat skipped">Skipped: <strong>{skipped}</strong></span>
                  </div>
                )}
                {bc.status === 'failed' && result.error && (
                  <div className="ud-broadcast-card-error">{result.error}</div>
                )}
                <div className="ud-broadcast-card-footer">
                  <span className="ud-broadcast-msg-count">
                    <SvgIcon d={ICONS.send} size={12} />
                    {msgCount} stored message{msgCount !== 1 ? 's' : ''}
                  </span>
                  {msgCount > 0 && (
                    <button className="ud-btn ud-btn-ghost ud-btn-sm ud-btn-danger-text" onClick={() => deleteBroadcastMessages(bc.id)}>
                      <SvgIcon d={ICONS.trash} size={12} />
                      <span>Delete Messages</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}


function TemplatesTab({ settings, setSettings, loading, saving, onSave }: any) {
  const update = (key: string, value: string) => setSettings({ ...settings, [key]: value });
  const BC_PH = ['{plan_name}', '{description}', '{pricing_examples}', '{expiry_time}', '{brand}', '{first_name}', '{current_time}'];

  if (loading) {
    return <div className="ud-loader"><div className="loader-spinner" /><span className="ud-loader-text">Loading template settings...</span></div>;
  }

  return (
    <div className="ud-templates-section">
      <div className="ud-templates-group">
        <div className="ud-templates-group-header">
          <div className="ud-templates-group-icon">
            <SvgIcon d={ICONS.broadcast} size={16} />
          </div>
          <div>
            <div className="ud-templates-group-title">Broadcast Message Template</div>
            <div className="ud-templates-group-desc">Default template sent to all normal users when you broadcast a discount plan</div>
          </div>
        </div>

        <div className="ud-field">
          <label className="ud-label">Title Line</label>
          <input className="ud-input" type="text" value={settings.tpl_discount_broadcast_title || ''} onChange={(e: React.ChangeEvent<HTMLInputElement>) => update('tpl_discount_broadcast_title', e.target.value)} placeholder="e.g. \ud83d\udd25 <b>Limited-Time Discount!</b>" />
          <span className="ud-field-hint">HTML supported. This appears as the first line of the broadcast message.</span>
        </div>
        <div className="ud-field">
          <label className="ud-label">Message Body</label>
          <textarea className="ud-textarea" rows={6} value={settings.tpl_discount_broadcast_body || ''} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => update('tpl_discount_broadcast_body', e.target.value)} placeholder="Hey {first_name}, {plan_name} is now live!..." />
          <div className="ud-placeholder-pills">
            {BC_PH.map(ph => <span key={ph} className="ud-ph-pill" onClick={() => update('tpl_discount_broadcast_body', (settings.tpl_discount_broadcast_body || '') + ph)}>{ph}</span>)}
          </div>
          <span className="ud-field-hint">Main broadcast content. Click placeholders above to insert them.</span>
        </div>
        <div className="ud-field">
          <label className="ud-label">Footer Line</label>
          <input className="ud-input" type="text" value={settings.tpl_discount_broadcast_footer || ''} onChange={(e: React.ChangeEvent<HTMLInputElement>) => update('tpl_discount_broadcast_footer', e.target.value)} placeholder="e.g. Open the store now!" />
          <span className="ud-field-hint">Appended at the bottom of the broadcast message.</span>
        </div>
        <div className="ud-field">
          <label className="ud-label">Link Buttons <span className="ud-label-opt">(JSON)</span></label>
          <textarea className="ud-textarea" rows={2} value={settings.discount_broadcast_buttons || '[]'} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => update('discount_broadcast_buttons', e.target.value)} placeholder='[{"text":"Open Store","url":"https://t.me/yourbot"}]' />
          <span className="ud-field-hint">URL buttons below the message. Format: [{'{"text":"...", "url":"..."}'}]</span>
        </div>
      </div>

      <div className="ud-templates-group">
        <div className="ud-templates-group-header">
          <div className="ud-templates-group-icon rose">
            <SvgIcon d={ICONS.clock} size={16} />
          </div>
          <div>
            <div className="ud-templates-group-title">Offer Ended Message</div>
            <div className="ud-templates-group-desc">Sent when a user tries to access an expired discount offer</div>
          </div>
        </div>
        <div className="ud-field">
          <label className="ud-label">Ended Title</label>
          <input className="ud-input" type="text" value={settings.discount_offer_ended_title || ''} onChange={(e: React.ChangeEvent<HTMLInputElement>) => update('discount_offer_ended_title', e.target.value)} placeholder="\u23f3 <b>Offer Has Ended</b>" />
        </div>
        <div className="ud-field">
          <label className="ud-label">Ended Body</label>
          <textarea className="ud-textarea" rows={3} value={settings.discount_offer_ended_body || ''} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => update('discount_offer_ended_body', e.target.value)} placeholder="Sorry, this discount offer is no longer available..." />
        </div>
      </div>

      <div className="ud-templates-group">
        <div className="ud-templates-group-header">
          <div className="ud-templates-group-icon amber">
            <SvgIcon d={ICONS.send} size={16} />
          </div>
          <div>
            <div className="ud-templates-group-title">Status Messages</div>
            <div className="ud-templates-group-desc">Bot replies shown during broadcast progress, completion, and errors</div>
          </div>
        </div>
        <div className="ud-field">
          <label className="ud-label">Progress Message</label>
          <input className="ud-input" type="text" value={settings.msg_broadcast_progress || ''} onChange={(e: React.ChangeEvent<HTMLInputElement>) => update('msg_broadcast_progress', e.target.value)} placeholder="\u23f3 Sending broadcast... {sent}/{total}" />
          <span className="ud-field-hint">Placeholders: {'{sent}'} {'{total}'}</span>
        </div>
        <div className="ud-field">
          <label className="ud-label">Complete Message</label>
          <textarea className="ud-textarea" rows={3} value={settings.msg_broadcast_complete || ''} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => update('msg_broadcast_complete', e.target.value)} placeholder="\u2705 Broadcast Complete..." />
          <span className="ud-field-hint">Placeholders: {'{sent}'} {'{failed}'} {'{skipped}'} {'{total}'}</span>
        </div>
        <div className="ud-field">
          <label className="ud-label">Error Message</label>
          <input className="ud-input" type="text" value={settings.msg_broadcast_error || ''} onChange={(e: React.ChangeEvent<HTMLInputElement>) => update('msg_broadcast_error', e.target.value)} placeholder="\u274c Broadcast failed: {error}" />
          <span className="ud-field-hint">Placeholder: {'{error}'}</span>
        </div>
      </div>

      <div className="ud-templates-group">
        <div className="ud-templates-group-header">
          <div className="ud-templates-group-icon emerald">
            <SvgIcon d={ICONS.power} size={16} />
          </div>
          <div>
            <div className="ud-templates-group-title">Broadcast Behavior</div>
            <div className="ud-templates-group-desc">Controls how broadcast messages are delivered and displayed</div>
          </div>
        </div>
        <div className="ud-toggle-field" onClick={() => update('discount_broadcast_send_categories', settings.discount_broadcast_send_categories === '1' ? '0' : '1')}>
          <div className={`ud-toggle ${settings.discount_broadcast_send_categories === '1' ? 'on' : ''}`}>
            <div className="ud-toggle-knob" />
          </div>
          <div className="ud-toggle-text">
            <span className="ud-toggle-label">Send categories menu after broadcast</span>
            <span className="ud-toggle-hint">Sends the store categories keyboard as a follow-up message after each broadcast</span>
          </div>
        </div>
        <div className="ud-toggle-field" onClick={() => update('broadcast_pin_message', settings.broadcast_pin_message === '1' ? '0' : '1')}>
          <div className={`ud-toggle ${settings.broadcast_pin_message === '1' ? 'on' : ''}`}>
            <div className="ud-toggle-knob" />
          </div>
          <div className="ud-toggle-text">
            <span className="ud-toggle-label">Pin broadcast message</span>
            <span className="ud-toggle-hint">Pins the broadcast message in each user's chat after sending</span>
          </div>
        </div>
      </div>

      <div className="ud-templates-footer">
        <button className="ud-btn ud-btn-primary" onClick={onSave} disabled={saving}>
          {saving ? (
            <><div className="loader-spinner-sm" /><span>Saving...</span></>
          ) : (
            <><SvgIcon d={ICONS.save} size={15} /><span>Save All Settings</span></>
          )}
        </button>
      </div>
    </div>
  );
}


function StatsTab({ stats, statsLoading }: any) {
  if (statsLoading) {
    return <div className="ud-loader"><div className="loader-spinner" /><span className="ud-loader-text">Loading statistics...</span></div>;
  }
  if (!stats) {
    return (
      <div className="ud-empty">
        <div className="ud-empty-icon"><SvgIcon d={ICONS.chart} size={40} /></div>
        <h3 className="ud-empty-title">No stats available</h3>
        <p className="ud-empty-desc">Revenue and order statistics will appear once there are transactions.</p>
      </div>
    );
  }

  const ov = stats.overview;
  const bc = stats.broadcast || {};

  return (
    <div className="ud-stats-section">
      <div className="ud-stats-group">
        <div className="ud-stats-group-title">Discount Performance</div>
        <div className="ud-stats-grid">
          <StatCard icon={ICONS.orders} label="Discount Orders" value={ov.discount_orders} color="accent" />
          <StatCard icon={ICONS.revenue} label="Discount Revenue" value={`${cfg.currency}${parseFloat(ov.discount_revenue).toFixed(2)}`} color="accent" />
          <StatCard icon={ICONS.savings} label="Total Savings Given" value={`${cfg.currency}${parseFloat(ov.total_savings).toFixed(2)}`} color="green" />
          <StatCard icon={ICONS.revenue} label="Avg Discount Order" value={`${cfg.currency}${parseFloat(ov.avg_discount_order || 0).toFixed(2)}`} color="accent" />
        </div>
      </div>

      <div className="ud-stats-group">
        <div className="ud-stats-group-title">Overall Revenue</div>
        <div className="ud-stats-grid">
          <StatCard icon={ICONS.orders} label="Base Orders" value={ov.base_orders} color="default" />
          <StatCard icon={ICONS.revenue} label="Base Revenue" value={`${cfg.currency}${parseFloat(ov.base_revenue).toFixed(2)}`} color="default" />
          <StatCard icon={ICONS.users} label="Reseller Orders" value={ov.reseller_orders} color="sky" />
          <StatCard icon={ICONS.revenue} label="Reseller Revenue" value={`${cfg.currency}${parseFloat(ov.reseller_revenue).toFixed(2)}`} color="sky" />
        </div>
      </div>

      <div className="ud-stats-group">
        <div className="ud-stats-group-title">Broadcast Activity</div>
        <div className="ud-stats-grid">
          <StatCard icon={ICONS.broadcast} label="Total Sends" value={bc.total_sends || 0} color="accent" />
          <StatCard icon={ICONS.send} label="Stored Messages" value={bc.total_messages || 0} color="default" />
          <StatCard icon={ICONS.trash} label="Deletion Runs" value={bc.total_deletions || 0} color="default" />
          <StatCard icon={ICONS.tag} label="Plans Used" value={ov.unique_plans_used || 0} color="green" />
        </div>
      </div>

      {stats.by_plan && stats.by_plan.length > 0 && (
        <div className="ud-stats-group">
          <div className="ud-stats-group-title">Revenue by Discount Plan</div>
          <div className="ud-plan-stats-list">
            {stats.by_plan.map((p: any, i: number) => (
              <div key={i} className="ud-plan-stat-card">
                <div className="ud-plan-stat-header">
                  <span className="ud-plan-stat-name">{p.plan_name || `Plan #${p.plan_id}`}</span>
                  <span className="ud-plan-stat-orders">{p.order_count} orders</span>
                </div>
                <div className="ud-plan-stat-metrics">
                  <div className="ud-plan-stat-metric">
                    <span className="ud-plan-stat-metric-label">Revenue</span>
                    <span className="ud-plan-stat-metric-value">{cfg.currency}{parseFloat(p.revenue).toFixed(2)}</span>
                  </div>
                  <div className="ud-plan-stat-metric green">
                    <span className="ud-plan-stat-metric-label">Savings</span>
                    <span className="ud-plan-stat-metric-value">{cfg.currency}{parseFloat(p.savings).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}


function StatCard({ icon, label, value, color = 'default' }: { icon: string; label: string; value: any; color?: string }) {
  return (
    <div className={`ud-stat-card ${color}`}>
      <div className={`ud-stat-icon ${color}`}>
        <SvgIcon d={icon} size={18} />
      </div>
      <div className="ud-stat-body">
        <span className="ud-stat-value">{value}</span>
        <span className="ud-stat-label">{label}</span>
      </div>
    </div>
  );
}
