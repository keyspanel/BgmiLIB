import React, { useEffect, useState, useCallback } from 'react';
import { apiGet, apiPut, apiPost } from '../api';

const STATUS_META: Record<string, any> = {
  ok:                  { color: 'var(--c-emerald)', bg: 'var(--c-emerald-surface)', label: 'Validated',       icon: 'check_circle' },
  valid:               { color: 'var(--c-emerald)', bg: 'var(--c-emerald-surface)', label: 'Validated',       icon: 'check_circle' },
  warning:             { color: 'var(--c-amber)',   bg: 'var(--c-amber-surface)',   label: 'Warning',         icon: 'warning' },
  error:               { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'Error',           icon: 'cancel' },
  pending:             { color: 'var(--text-4)',     bg: 'var(--bg-3)',              label: 'Not Validated',   icon: 'radio_button_unchecked' },
  bot_not_admin:       { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'Bot Not Admin',   icon: 'block' },
  private_invite_link: { color: 'var(--c-amber)',   bg: 'var(--c-amber-surface)',   label: 'Private Link',    icon: 'vpn_key' },
  channel_not_found:   { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'Not Found',       icon: 'search_off' },
  invalid_identifier:  { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'Invalid',         icon: 'error_outline' },
  no_token:            { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'No Token',        icon: 'vpn_key_off' },
  api_error:           { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'API Error',       icon: 'cloud_off' },
};

const STYLE_OPTIONS = [
  { value: '',        label: 'Default',  color: null as string | null },
  { value: 'primary', label: 'Primary',  color: '#6366f1' },
  { value: 'success', label: 'Success',  color: '#22c55e' },
  { value: 'danger',  label: 'Danger',   color: '#ef4444' },
];

const FJ_TEXT_KEYS = [
  'force_join_title', 'force_join_body', 'force_join_btn_verify',
  'force_join_missing_msg', 'force_join_expired_msg',
  'force_join_join_btn_text',
  'force_join_join_btn_style', 'force_join_join_btn_emoji_id',
  'force_join_verify_btn_style', 'force_join_verify_btn_emoji_id',
  'force_join_show_verify_btn',
];

const TABS = [
  { key: 'channels', label: 'Channels',  icon: 'cell_tower' },
  { key: 'messages', label: 'Messages',  icon: 'chat_bubble' },
  { key: 'buttons',  label: 'Buttons',   icon: 'smart_button' },
];

function Icon({ name, size = 20, className = '' }: { name: string; size?: number; className?: string }) {
  return (
    <span
      className={`material-symbols-rounded ${className}`}
      style={{ fontSize: size, lineHeight: 1 }}
    >{name}</span>
  );
}

function StatusPill({ statusCode, detail }: { statusCode: string; detail?: string }) {
  const meta = STATUS_META[statusCode] || STATUS_META.pending;
  return (
    <div className="fj-status-pill" style={{ background: meta.bg, color: meta.color }}>
      <Icon name={meta.icon} size={15} />
      <span className="fj-status-pill-label">{meta.label}</span>
      {detail && <span className="fj-status-pill-detail">{detail}</span>}
    </div>
  );
}

function PremiumCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`fj-card ${className}`}>{children}</div>;
}

function CardHeader({ icon, iconColor, title, subtitle, children }: { icon?: string; iconColor?: string; title: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="fj-card-head">
      <div className="fj-card-head-left">
        {icon && (
          <div className="fj-card-icon" style={iconColor ? { background: iconColor, color: '#fff' } : undefined}>
            <Icon name={icon} size={20} />
          </div>
        )}
        <div className="fj-card-head-text">
          <h3 className="fj-card-title">{title}</h3>
          {subtitle && <p className="fj-card-subtitle">{subtitle}</p>}
        </div>
      </div>
      {children && <div className="fj-card-head-right">{children}</div>}
    </div>
  );
}

function FieldGroup({ label, hint, children }: { label?: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="fj-fg">
      {label && <label className="fj-fg-label">{label}</label>}
      {children}
      {hint && <span className="fj-fg-hint">{hint}</span>}
    </div>
  );
}

function StyleSelector({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="fj-style-selector">
      {STYLE_OPTIONS.map(o => {
        const active = value === o.value;
        return (
          <button
            key={o.value}
            type="button"
            className={`fj-style-chip${active ? ' active' : ''}`}
            onClick={() => onChange(o.value)}
          >
            {o.color && <span className="fj-style-dot" style={{ background: o.color }} />}
            {!o.color && <Icon name="contrast" size={14} />}
            <span>{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function ToggleSwitch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      className={`fj-switch${checked ? ' on' : ''}`}
      onClick={() => onChange(!checked)}
      aria-checked={checked}
      role="switch"
    >
      <span className="fj-switch-thumb" />
    </button>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button className="fj-copy-btn" onClick={handleCopy} title="Copy link">
      <Icon name={copied ? 'check' : 'content_copy'} size={14} />
    </button>
  );
}

function emptyChannel(): any {
  return { channel_identifier: '', channel_title: '', invite_link: '', is_active: true, channel_id: null, channel_username: null, status: 'pending', status_detail: '' };
}

export default function ForceJoin() {
  const [enabled, setEnabled] = useState(false);
  const [channels, setChannels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [validating, setValidating] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: string }>({ text: '', type: '' });
  const [validationResults, setValidationResults] = useState<any[]>([]);

  const [fjSettings, setFjSettings] = useState<Record<string, string>>({});
  const [fjDefaults, setFjDefaults] = useState<Record<string, string>>({});
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [savingTexts, setSavingTexts] = useState(false);
  const [textMsg, setTextMsg] = useState<{ text: string; type: string }>({ text: '', type: '' });

  const [activeTab, setActiveTab] = useState('channels');

  useEffect(() => {
    Promise.all([
      apiGet('/force-join'),
      apiGet('/bot-settings'),
    ]).then(([fjData, bsData]) => {
      setEnabled(fjData.enabled);
      setChannels(fjData.channels.length > 0 ? fjData.channels : []);
      const vals: Record<string, string> = {};
      const defs: Record<string, string> = {};
      for (const key of FJ_TEXT_KEYS) {
        vals[key] = bsData.settings?.[key] ?? bsData.defaults?.[key] ?? '';
        defs[key] = bsData.defaults?.[key] ?? '';
      }
      setFjSettings(vals);
      setFjDefaults(defs);
      setSettingsLoaded(true);
    }).catch(() => {
      setMsg({ text: 'Failed to load settings', type: 'error' });
    }).finally(() => setLoading(false));
  }, []);

  const validCount = channels.filter((ch: any) => ch.status === 'ok' || ch.status === 'valid').length;
  const activeCount = channels.filter((ch: any) => ch.is_active).length;

  const addChannel = () => {
    setChannels(prev => [...prev, emptyChannel()]);
    setValidationResults([]);
  };

  const removeChannel = (idx: number) => {
    setChannels(prev => prev.filter((_: any, i: number) => i !== idx));
    setValidationResults(prev => prev.filter((_: any, i: number) => i !== idx));
  };

  const updateChannel = (idx: number, field: string, value: any) => {
    setChannels(prev => prev.map((ch: any, i: number) => i === idx ? { ...ch, [field]: value } : ch));
    if (validationResults.length > idx) {
      setValidationResults(prev => prev.map((r: any, i: number) => i === idx ? null : r));
    }
  };

  const handleValidate = async () => {
    setValidating(true);
    setMsg({ text: '', type: '' });
    try {
      const data = await apiPost('/force-join/validate', { channels });
      setValidationResults(data.results);
      const channelsUpdated = channels.map((ch: any, i: number) => {
        const r = data.results[i];
        if (!r) return ch;
        let updated = { ...ch };
        if (r.channel_id) updated.channel_id = r.channel_id;
        if (r.channel_username) updated.channel_username = r.channel_username;
        if (r.channel_title && !ch.channel_title) updated.channel_title = r.channel_title;
        if (r.invite_link) updated.invite_link = r.invite_link;
        if (r.status) updated.status = r.status;
        if (r.status_code) updated.status = r.status_code;
        if (r.detail) updated.status_detail = r.detail;
        return updated;
      });
      setChannels(channelsUpdated);
      const allOk = data.results.every((r: any) => r && (r.status === 'ok' || r.status_code === 'valid'));
      const hasErrors = data.results.some((r: any) => r && r.status === 'error');
      if (allOk) setMsg({ text: 'All channels validated — join links generated', type: 'success' });
      else if (hasErrors) setMsg({ text: 'Some channels have issues — review status below', type: 'error' });
      else setMsg({ text: 'Validation complete — review warnings', type: 'warning' });
    } catch (err: any) {
      setMsg({ text: 'Validation failed: ' + err.message, type: 'error' });
    } finally {
      setValidating(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setMsg({ text: '', type: '' });
    try {
      const filtered = channels.filter((ch: any) => ch.channel_identifier.trim());
      const data = await apiPut('/force-join', { enabled, channels: filtered });
      setChannels(data.channels);
      setMsg({ text: 'Settings saved successfully', type: 'success' });
      setValidationResults([]);
    } catch (err: any) {
      setMsg({ text: 'Save failed: ' + err.message, type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const setFjVal = useCallback((key: string, val: string) => {
    setFjSettings(prev => ({ ...prev, [key]: val }));
  }, []);

  const handleSaveTexts = async () => {
    setSavingTexts(true);
    setTextMsg({ text: '', type: '' });
    try {
      const payload: Record<string, string> = {};
      for (const key of FJ_TEXT_KEYS) {
        if (fjSettings[key] !== undefined) payload[key] = fjSettings[key];
      }
      await apiPut('/bot-settings', { settings: payload });
      setTextMsg({ text: 'Settings saved successfully', type: 'success' });
    } catch (err: any) {
      setTextMsg({ text: 'Save failed: ' + err.message, type: 'error' });
    } finally {
      setSavingTexts(false);
    }
  };

  const handleResetTexts = () => {
    setFjSettings(prev => {
      const next = { ...prev };
      for (const key of FJ_TEXT_KEYS) next[key] = fjDefaults[key] || '';
      return next;
    });
  };

  if (loading) {
    return (
      <div className="page-loader">
        <div className="loader-spinner" />
        <span className="loader-text">Loading Force Join settings...</span>
      </div>
    );
  }

  return (
    <div className="fj-page">
      <div className="fj-hero">
        <div className="fj-hero-glow" />
        <div className="fj-hero-content">
          <div className="fj-hero-left">
            <div className="fj-hero-icon">
              <Icon name="shield_lock" size={28} />
            </div>
            <div className="fj-hero-text">
              <h1 className="fj-hero-title">Force Join</h1>
              <p className="fj-hero-desc">Require channel membership before users can place orders</p>
            </div>
          </div>
          <div className="fj-hero-right">
            <div className="fj-hero-toggle">
              <ToggleSwitch checked={enabled} onChange={setEnabled} />
              <span className={`fj-hero-toggle-label${enabled ? ' on' : ''}`}>
                {enabled ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        </div>
        <div className="fj-hero-stats">
          <div className="fj-hero-stat">
            <span className="fj-hero-stat-val">{channels.length}</span>
            <span className="fj-hero-stat-label">Channels</span>
          </div>
          <div className="fj-hero-stat-sep" />
          <div className="fj-hero-stat">
            <span className="fj-hero-stat-val">{activeCount}</span>
            <span className="fj-hero-stat-label">Active</span>
          </div>
          <div className="fj-hero-stat-sep" />
          <div className="fj-hero-stat">
            <span className="fj-hero-stat-val">{validCount}</span>
            <span className="fj-hero-stat-label">Validated</span>
          </div>
        </div>
      </div>

      <div className="fj-nav">
        {TABS.map(tab => (
          <button
            key={tab.key}
            className={`fj-nav-btn${activeTab === tab.key ? ' active' : ''}`}
            onClick={() => setActiveTab(tab.key)}
          >
            <Icon name={tab.icon} size={18} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {msg.text && (
        <div className={`fj-toast fj-toast-${msg.type}`}>
          <Icon name={msg.type === 'success' ? 'check_circle' : msg.type === 'error' ? 'error' : 'warning'} size={18} />
          <span>{msg.text}</span>
        </div>
      )}

      {activeTab === 'channels' && (
        <div className="fj-tab-content">
          <PremiumCard>
            <CardHeader
              icon="cell_tower"
              iconColor="var(--c-accent)"
              title="Required Channels"
              subtitle="Users must join all active channels to place an order"
            >
              <button className="fj-btn fj-btn-ghost" onClick={addChannel}>
                <Icon name="add" size={18} />
                <span>Add</span>
              </button>
            </CardHeader>

            <div className="fj-card-body">
              {channels.length === 0 && (
                <div className="fj-empty-state">
                  <div className="fj-empty-icon-wrap">
                    <Icon name="cell_tower" size={32} />
                  </div>
                  <p className="fj-empty-title">No channels configured</p>
                  <p className="fj-empty-desc">Add a channel to start requiring membership</p>
                  <button className="fj-btn fj-btn-primary fj-btn-sm" onClick={addChannel}>
                    <Icon name="add" size={16} />
                    Add Channel
                  </button>
                </div>
              )}

              {channels.map((ch: any, idx: number) => {
                const vr = validationResults[idx];
                const statusCode = vr?.status_code || vr?.status || ch.status || 'pending';
                const statusDetail = vr?.detail || ch.status_detail || '';
                const hasResolved = ch.channel_id || ch.channel_username || ch.invite_link;

                return (
                  <div key={ch.id || `new-${idx}`} className={`fj-ch${!ch.is_active ? ' dim' : ''}`}>
                    <div className="fj-ch-top">
                      <div className="fj-ch-top-left">
                        <span className="fj-ch-idx">{idx + 1}</span>
                        <span className="fj-ch-name">{ch.channel_title || ch.channel_identifier || `Channel ${idx + 1}`}</span>
                      </div>
                      <div className="fj-ch-top-right">
                        <ToggleSwitch checked={ch.is_active} onChange={(v: boolean) => updateChannel(idx, 'is_active', v)} />
                        <button className="fj-ch-remove" onClick={() => removeChannel(idx)} title="Remove channel">
                          <Icon name="delete_outline" size={16} />
                        </button>
                      </div>
                    </div>

                    <div className="fj-ch-fields">
                      <FieldGroup label="Channel Identifier" hint="@username, t.me/ link, channel ID, or private invite link">
                        <div className="fj-input-wrap">
                          <Icon name="tag" size={16} className="fj-input-icon" />
                          <input type="text" className="fj-input has-icon" value={ch.channel_identifier}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateChannel(idx, 'channel_identifier', e.target.value)}
                            placeholder="@channel or https://t.me/channel" />
                        </div>
                      </FieldGroup>
                      <FieldGroup label="Display Name" hint="Friendly name shown to users (optional)">
                        <div className="fj-input-wrap">
                          <Icon name="label" size={16} className="fj-input-icon" />
                          <input type="text" className="fj-input has-icon" value={ch.channel_title}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) => updateChannel(idx, 'channel_title', e.target.value)}
                            placeholder="e.g. Our Main Channel" />
                        </div>
                      </FieldGroup>
                    </div>

                    {hasResolved && (
                      <div className="fj-ch-meta">
                        {ch.channel_id && (
                          <div className="fj-meta-item">
                            <span className="fj-meta-key">Channel ID</span>
                            <code className="fj-meta-val">{ch.channel_id}</code>
                          </div>
                        )}
                        {ch.channel_username && (
                          <div className="fj-meta-item">
                            <span className="fj-meta-key">Username</span>
                            <code className="fj-meta-val">@{ch.channel_username}</code>
                          </div>
                        )}
                        {ch.invite_link && (
                          <div className="fj-meta-item fj-meta-link-row">
                            <span className="fj-meta-key">Join Link</span>
                            <div className="fj-meta-link-wrap">
                              <a href={ch.invite_link} target="_blank" rel="noopener noreferrer" className="fj-meta-link">{ch.invite_link}</a>
                              <CopyButton text={ch.invite_link} />
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    <StatusPill statusCode={statusCode} detail={statusDetail} />
                  </div>
                );
              })}
            </div>
          </PremiumCard>

          <div className="fj-actions">
            <button className="fj-btn fj-btn-primary" onClick={handleSave} disabled={saving}>
              <Icon name={saving ? 'hourglass_empty' : 'save'} size={18} />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
            {channels.length > 0 && (
              <button className="fj-btn fj-btn-secondary" onClick={handleValidate} disabled={validating}>
                <Icon name={validating ? 'hourglass_empty' : 'verified'} size={18} />
                {validating ? 'Validating...' : 'Validate & Generate Links'}
              </button>
            )}
          </div>

          <PremiumCard className="fj-flow-card">
            <CardHeader
              icon="integration_instructions"
              iconColor="var(--c-sky)"
              title="How It Works"
              subtitle="Automatic membership verification flow"
            />
            <div className="fj-card-body">
              <div className="fj-flow">
                {[
                  { icon: 'shopping_cart', text: 'User taps Buy on a product' },
                  { icon: 'fact_check', text: 'Bot checks all required channel memberships' },
                  { icon: 'notification_important', text: 'If not joined, bot sends prompt with join buttons' },
                  { icon: 'autorenew', text: 'Bot automatically re-checks every few seconds' },
                  { icon: 'check_circle', text: 'Once joined, prompt is cleaned and order resumes' },
                ].map((step, i) => (
                  <div key={i} className="fj-flow-step">
                    <div className="fj-flow-num">
                      <Icon name={step.icon} size={18} />
                      {i < 4 && <div className="fj-flow-line" />}
                    </div>
                    <p className="fj-flow-text">{step.text}</p>
                  </div>
                ))}
              </div>
              <div className="fj-flow-note">
                <Icon name="info" size={16} />
                <span>Users browse products normally. Force Join only blocks at the order step. After joining, the bot silently resumes the order — no extra confirmation message.</span>
              </div>
            </div>
          </PremiumCard>
        </div>
      )}

      {activeTab === 'messages' && settingsLoaded && (
        <div className="fj-tab-content">
          {textMsg.text && (
            <div className={`fj-toast fj-toast-${textMsg.type}`}>
              <Icon name={textMsg.type === 'success' ? 'check_circle' : 'error'} size={18} />
              <span>{textMsg.text}</span>
            </div>
          )}

          <PremiumCard>
            <CardHeader
              icon="mark_chat_unread"
              iconColor="var(--c-accent)"
              title="Join Prompt Template"
              subtitle="Message shown when user must join channels before ordering"
            />
            <div className="fj-card-body fj-msg-body">
              <FieldGroup label="Title" hint="Bold heading at the top of the force join prompt. HTML supported.">
                <input type="text" className="fj-input" value={fjSettings.force_join_title || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFjVal('force_join_title', e.target.value)}
                  placeholder={fjDefaults.force_join_title} />
              </FieldGroup>
              <FieldGroup label="Body Template" hint="Main message body. Supports Telegram HTML formatting and placeholders below.">
                <textarea className="fj-textarea" rows={7} value={fjSettings.force_join_body || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFjVal('force_join_body', e.target.value)}
                  placeholder={fjDefaults.force_join_body} />
              </FieldGroup>
              <div className="fj-placeholder-help">
                <div className="fj-placeholder-help-header">
                  <Icon name="data_object" size={16} />
                  <span>Available Placeholders</span>
                </div>
                <div className="fj-placeholder-grid">
                  <div className="fj-placeholder-item"><code>{'{user_mention}'}</code><span>Clickable mention link</span></div>
                  <div className="fj-placeholder-item"><code>{'{first_name}'}</code><span>User's first name</span></div>
                  <div className="fj-placeholder-item"><code>{'{username}'}</code><span>User's @username</span></div>
                  <div className="fj-placeholder-item"><code>{'{category}'}</code><span>Selected category name</span></div>
                  <div className="fj-placeholder-item"><code>{'{duration}'}</code><span>Selected duration name</span></div>
                  <div className="fj-placeholder-item"><code>{'{brand}'}</code><span>Store name from settings</span></div>
                  <div className="fj-placeholder-item"><code>{'{current_time}'}</code><span>Current time (IST)</span></div>
                </div>
                <p className="fj-placeholder-note">Missing values render safely as "—" or "there". HTML tags like {'<b>'}, {'<i>'}, {'<a>'} are supported.</p>
              </div>
            </div>
          </PremiumCard>

          <PremiumCard>
            <CardHeader
              icon="task_alt"
              iconColor="var(--c-emerald)"
              title="Status Messages"
              subtitle="Messages shown during verification flow"
            />
            <div className="fj-card-body fj-msg-body">
              <FieldGroup label="Still Missing Channels" hint="Shown when user verifies but hasn't joined all channels yet.">
                <textarea className="fj-textarea" rows={2} value={fjSettings.force_join_missing_msg || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFjVal('force_join_missing_msg', e.target.value)}
                  placeholder={fjDefaults.force_join_missing_msg} />
              </FieldGroup>
              <FieldGroup label="Expired / Invalid Order" hint="Shown if pending order context has expired or is no longer valid.">
                <input type="text" className="fj-input" value={fjSettings.force_join_expired_msg || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFjVal('force_join_expired_msg', e.target.value)}
                  placeholder={fjDefaults.force_join_expired_msg} />
              </FieldGroup>
            </div>
          </PremiumCard>

          <div className="fj-actions">
            <button className="fj-btn fj-btn-primary" onClick={handleSaveTexts} disabled={savingTexts}>
              <Icon name={savingTexts ? 'hourglass_empty' : 'save'} size={18} />
              {savingTexts ? 'Saving...' : 'Save Messages'}
            </button>
            <button className="fj-btn fj-btn-outline" onClick={handleResetTexts}>
              <Icon name="restart_alt" size={18} />
              Reset Defaults
            </button>
          </div>
        </div>
      )}

      {activeTab === 'buttons' && settingsLoaded && (
        <div className="fj-tab-content">
          {textMsg.text && (
            <div className={`fj-toast fj-toast-${textMsg.type}`}>
              <Icon name={textMsg.type === 'success' ? 'check_circle' : 'error'} size={18} />
              <span>{textMsg.text}</span>
            </div>
          )}

          <PremiumCard>
            <CardHeader
              icon="link"
              iconColor="var(--c-accent)"
              title="Join Button"
              subtitle="Customize how channel join buttons appear to users"
            />
            <div className="fj-card-body fj-msg-body">
              <FieldGroup label="Button Text Template" hint="Use {channel} as placeholder for the channel name">
                <div className="fj-input-wrap">
                  <Icon name="text_fields" size={16} className="fj-input-icon" />
                  <input type="text" className="fj-input has-icon" value={fjSettings.force_join_join_btn_text || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFjVal('force_join_join_btn_text', e.target.value)}
                    placeholder={fjDefaults.force_join_join_btn_text} />
                </div>
              </FieldGroup>
              <FieldGroup label="Button Style">
                <StyleSelector value={fjSettings.force_join_join_btn_style || ''} onChange={(v: string) => setFjVal('force_join_join_btn_style', v)} />
              </FieldGroup>
              <FieldGroup label="Custom Emoji ID" hint="Numeric Telegram custom emoji ID for the join button">
                <div className="fj-input-wrap">
                  <Icon name="emoji_symbols" size={16} className="fj-input-icon" />
                  <input type="text" className="fj-input has-icon fj-input-mono" inputMode="numeric"
                    value={fjSettings.force_join_join_btn_emoji_id || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFjVal('force_join_join_btn_emoji_id', e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 5368324170671202286" />
                </div>
              </FieldGroup>
            </div>
          </PremiumCard>

          <PremiumCard>
            <CardHeader
              icon="verified"
              iconColor="var(--c-emerald)"
              title="Verify Button"
              subtitle="Fallback manual verification button"
            >
              <ToggleSwitch
                checked={fjSettings.force_join_show_verify_btn !== '0'}
                onChange={(v: boolean) => setFjVal('force_join_show_verify_btn', v ? '1' : '0')}
              />
            </CardHeader>
            <div className="fj-card-body fj-msg-body">
              <div className="fj-verify-toggle-note">
                <Icon name="info" size={16} />
                <span>
                  {fjSettings.force_join_show_verify_btn === '0'
                    ? 'Verify button is hidden — only channel join buttons are shown. Auto-detection remains active.'
                    : 'Verify button is shown as a manual fallback alongside automatic membership detection.'}
                </span>
              </div>
              <FieldGroup label="Button Text">
                <div className="fj-input-wrap">
                  <Icon name="text_fields" size={16} className="fj-input-icon" />
                  <input type="text" className="fj-input has-icon" value={fjSettings.force_join_btn_verify || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFjVal('force_join_btn_verify', e.target.value)}
                    placeholder={fjDefaults.force_join_btn_verify} />
                </div>
              </FieldGroup>
              <FieldGroup label="Button Style">
                <StyleSelector value={fjSettings.force_join_verify_btn_style || ''} onChange={(v: string) => setFjVal('force_join_verify_btn_style', v)} />
              </FieldGroup>
              <FieldGroup label="Custom Emoji ID" hint="Numeric Telegram custom emoji ID for the verify button">
                <div className="fj-input-wrap">
                  <Icon name="emoji_symbols" size={16} className="fj-input-icon" />
                  <input type="text" className="fj-input has-icon fj-input-mono" inputMode="numeric"
                    value={fjSettings.force_join_verify_btn_emoji_id || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFjVal('force_join_verify_btn_emoji_id', e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 5368324170671202286" />
                </div>
              </FieldGroup>
            </div>
          </PremiumCard>

          <div className="fj-actions">
            <button className="fj-btn fj-btn-primary" onClick={handleSaveTexts} disabled={savingTexts}>
              <Icon name={savingTexts ? 'hourglass_empty' : 'save'} size={18} />
              {savingTexts ? 'Saving...' : 'Save Button Settings'}
            </button>
            <button className="fj-btn fj-btn-outline" onClick={handleResetTexts}>
              <Icon name="restart_alt" size={18} />
              Reset Defaults
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
