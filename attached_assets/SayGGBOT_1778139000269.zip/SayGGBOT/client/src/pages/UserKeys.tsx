import React, { useEffect, useState, useCallback, useRef } from 'react';
import cfg from '../config';

const API_BASE = cfg.apiBase;
const INTRO_MIN_MS = 1400;

async function userApi(path: string, token: string): Promise<any> {
  const res = await fetch(`${API_BASE}${path}`, { headers: { 'x-user-token': token } });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Request failed');
  }
  return res.json();
}

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  }, [value]);
  return (
    <button className={`kp-copy-btn${copied ? ' copied' : ''}`} onClick={copy} title={`Copy ${label}`}>
      {copied ? (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
      ) : (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
      )}
      <span>{copied ? 'Copied' : label}</span>
    </button>
  );
}

function Toast({ message, onDone }: { message: string; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 2000); return () => clearTimeout(t); }, [onDone]);
  return <div className="kp-toast">{message}</div>;
}

function IntroScreen({ phase }: { phase: string }) {
  return (
    <div className={`kp-intro${phase === 'exiting' ? ' exit' : ''}`}>
      <div className="kp-intro-bg" />
      <div className="kp-intro-content">
        <div className="kp-intro-shield">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <div className="kp-intro-shield-key">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
            </svg>
          </div>
        </div>
        <h1 className="kp-intro-title">Secure Keys Portal</h1>
        <p className="kp-intro-sub">Verifying your access and loading purchased keys</p>
        <div className="kp-intro-progress">
          <div className="kp-intro-progress-bar" />
        </div>
        <div className="kp-intro-dots">
          <span/><span/><span/>
        </div>
      </div>
    </div>
  );
}

function formatHumanDate(d: string | null): string {
  if (!d) return '-';
  const dt = new Date(d);
  return dt.toLocaleDateString(cfg.locale, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'Asia/Kolkata' });
}

function formatHumanTime(d: string | null): string {
  if (!d) return '';
  const dt = new Date(d);
  return dt.toLocaleTimeString(cfg.locale, { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: 'Asia/Kolkata' });
}

function formatAmount(val: any): string {
  const n = Number(val || 0);
  return n % 1 === 0 ? n.toLocaleString() : n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function UserKeys() {
  const [token, setToken] = useState('');
  const [profile, setProfile] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [recent, setRecent] = useState<any[]>([]);
  const [keysData, setKeysData] = useState<any>({ keys: [], total: 0, page: 1, totalPages: 1 });
  const [categoryStats, setCategoryStats] = useState<any[]>([]);
  const [dataReady, setDataReady] = useState(false);
  const [error, setError] = useState('');
  const [view, setView] = useState('overview');
  const [filters, setFilters] = useState<any>({ key: '', category: '', duration: '', sort: 'latest', page: 1 });
  const [toast, setToast] = useState('');
  const [introPhase, setIntroPhase] = useState('active');
  const introStart = useRef(Date.now());
  const dataReadyRef = useRef(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const t = params.get('token') || '';
    if (!t) {
      setError('No access token provided. Please use the link from the Telegram bot to access your keys.');
      finishIntro();
      return;
    }
    setToken(t);
  }, []);

  useEffect(() => {
    if (!token) return;
    Promise.all([
      userApi(`/user-keys/profile?token=${token}`, token),
      userApi(`/user-keys/summary?token=${token}`, token),
      userApi(`/user-keys/recent?token=${token}`, token),
      userApi(`/user-keys/category-stats?token=${token}`, token),
    ]).then(([p, s, r, cs]) => {
      setProfile(p); setSummary(s); setRecent(r); setCategoryStats(cs);
      dataReadyRef.current = true;
      setDataReady(true);
      finishIntro();
    }).catch((err: any) => {
      setError(err.message);
      finishIntro();
    });
  }, [token]);

  function finishIntro() {
    const elapsed = Date.now() - introStart.current;
    const remaining = Math.max(0, INTRO_MIN_MS - elapsed);
    setTimeout(() => {
      setIntroPhase('exiting');
      setTimeout(() => setIntroPhase('done'), 600);
    }, remaining);
  }

  useEffect(() => {
    if (!token || view !== 'keys') return;
    const params = new URLSearchParams();
    params.set('token', token);
    Object.entries(filters).forEach(([k, v]) => { if (v !== '') params.set(k, String(v)); });
    userApi(`/user-keys/keys?${params}`, token).then(setKeysData).catch(() => {});
  }, [token, view, filters]);

  const setFilter = (key: string, val: any) => setFilters((p: any) => ({ ...p, [key]: val, page: 1 }));

  const copyToClipboard = useCallback(async (val: string, label: string) => {
    try {
      await navigator.clipboard.writeText(val);
      setToast(`${label} copied`);
    } catch {}
  }, []);

  if (introPhase !== 'done') {
    return (
      <div className="kp-page">
        <IntroScreen phase={introPhase} />
      </div>
    );
  }

  if (error) return (
    <div className="kp-page">
      <div className="kp-error-card">
        <div className="kp-error-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 9v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <div className="kp-error-title">Access Restricted</div>
        <div className="kp-error-desc">{error}</div>
        <button className="kp-retry-btn" onClick={() => window.location.reload()}>Try Again</button>
      </div>
    </div>
  );

  return (
    <div className="kp-page kp-page-enter">
      {toast && <Toast message={toast} onDone={() => setToast('')} />}

      <header className="kp-header">
        <div className="kp-header-bg" />
        <div className="kp-header-content">
          <div className="kp-logo-mark">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
            </svg>
          </div>
          <h1 className="kp-header-title">{cfg.portalTitle}</h1>
          {profile && <p className="kp-header-sub">Welcome, <strong>{profile.displayName}</strong></p>}
          <div className="kp-secure-badge">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
            <span>Secure Access</span>
          </div>
        </div>
      </header>

      {summary && (
        <div className="kp-stats-row">
          <div className="kp-stat-card">
            <div className="kp-stat-icon accent">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
            </div>
            <div className="kp-stat-val">{summary.total_keys}</div>
            <div className="kp-stat-label">Keys</div>
          </div>
          <div className="kp-stat-card">
            <div className="kp-stat-icon emerald">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
            </div>
            <div className="kp-stat-val">{summary.total_orders}</div>
            <div className="kp-stat-label">Orders</div>
          </div>
          <div className="kp-stat-card">
            <div className="kp-stat-icon sky">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
            </div>
            <div className="kp-stat-val">{cfg.currency}{formatAmount(summary.total_amount)}</div>
            <div className="kp-stat-label">Total Spent</div>
          </div>
        </div>
      )}

      <div className="kp-body">
        <div className="kp-tab-bar">
          <button className={`kp-tab${view === 'overview' ? ' active' : ''}`} onClick={() => setView('overview')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            Overview
          </button>
          <button className={`kp-tab${view === 'keys' ? ' active' : ''}`} onClick={() => setView('keys')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
            All Keys
          </button>
        </div>

        {view === 'overview' ? (
          <>
            {categoryStats.length > 0 && (
              <section className="kp-section">
                <div className="kp-section-head">
                  <h2 className="kp-section-title">Categories</h2>
                  <span className="kp-section-count">{categoryStats.length}</span>
                </div>
                <div className="kp-cat-grid">
                  {categoryStats.map((cs: any, i: number) => (
                    <div key={i} className="kp-cat-card">
                      <div className="kp-cat-name">{cs.displayName}</div>
                      <div className="kp-cat-meta">
                        <span className="kp-chip accent">{cs.total_keys} key{cs.total_keys !== 1 ? 's' : ''}</span>
                        <span className="kp-chip emerald">{cfg.currency}{formatAmount(cs.total_amount)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {recent.length > 0 && (
              <section className="kp-section">
                <div className="kp-section-head">
                  <h2 className="kp-section-title">Recent Purchases</h2>
                  <span className="kp-section-count">{recent.length}</span>
                </div>
                <div className="kp-keys-list">
                  {recent.map((r: any) => (
                    <KeyCard key={r.id} item={r} onCopy={copyToClipboard} />
                  ))}
                </div>
              </section>
            )}

            {categoryStats.length === 0 && recent.length === 0 && (
              <div className="kp-empty">
                <div className="kp-empty-icon">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                </div>
                <div className="kp-empty-title">Your vault is empty</div>
                <div className="kp-empty-desc">Purchased keys will appear here once delivered</div>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="kp-search-bar">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" placeholder="Search keys..." value={filters.key} onChange={e => setFilter('key', e.target.value)} />
            </div>
            <div className="kp-filter-row">
              <input type="text" placeholder="Category..." value={filters.category} onChange={e => setFilter('category', e.target.value)} />
              <select value={filters.sort} onChange={e => setFilter('sort', e.target.value)}>
                <option value="latest">Latest</option>
                <option value="oldest">Oldest</option>
                <option value="amount_high">Price ↓</option>
                <option value="amount_low">Price ↑</option>
              </select>
            </div>

            {keysData.keys.length === 0 ? (
              <div className="kp-empty">
                <div className="kp-empty-icon">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </div>
                <div className="kp-empty-title">No keys found</div>
                <div className="kp-empty-desc">Adjust your search or filters</div>
              </div>
            ) : (
              <>
                <div className="kp-results-count">{keysData.total} key{keysData.total === 1 ? '' : 's'} found</div>
                <div className="kp-keys-list">
                  {keysData.keys.map((k: any) => (
                    <KeyCard key={k.id} item={k} onCopy={copyToClipboard} />
                  ))}
                </div>
                {keysData.totalPages > 1 && (
                  <div className="kp-pagination">
                    <button className="kp-page-btn" disabled={filters.page <= 1} onClick={() => setFilters((p: any) => ({...p, page: p.page - 1}))}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
                    </button>
                    <span className="kp-page-info">{keysData.page} of {keysData.totalPages}</span>
                    <button className="kp-page-btn" disabled={filters.page >= keysData.totalPages} onClick={() => setFilters((p: any) => ({...p, page: p.page + 1}))}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function KeyCard({ item, onCopy }: { item: any; onCopy: (val: string, label: string) => void }) {
  const ts = item.verified_at || item.purchased_at;
  return (
    <div className="kp-key-card">
      <div className="kp-key-card-head">
        <div className="kp-key-card-cat">
          <span className="kp-key-card-cat-name">{item.categoryDisplayName}</span>
          <span className="kp-key-card-dur">{item.durationDisplayName}</span>
        </div>
        <div className="kp-key-card-amount">{cfg.currency}{formatAmount(item.amount)}</div>
      </div>

      <div className="kp-key-box" onClick={() => onCopy(item.key_value, 'Key')}>
        <div className="kp-key-val">{item.key_value}</div>
        <CopyButton value={item.key_value} label="Copy Key" />
      </div>

      <div className="kp-key-details">
        <div className="kp-detail-row">
          <span className="kp-detail-label">Order</span>
          <span className="kp-detail-val">#{item.order_id}</span>
        </div>
        <div className="kp-detail-row">
          <span className="kp-detail-label">Date</span>
          <span className="kp-detail-val">{formatHumanDate(ts)}</span>
        </div>
        {formatHumanTime(ts) && (
          <div className="kp-detail-row">
            <span className="kp-detail-label">Time</span>
            <span className="kp-detail-val">{formatHumanTime(ts)}</span>
          </div>
        )}
        {item.txn_ref && (
          <div className="kp-detail-row">
            <span className="kp-detail-label">Reference</span>
            <span className="kp-detail-val kp-mono-val kp-copiable" onClick={e => { e.stopPropagation(); onCopy(item.txn_ref, 'Reference'); }}>
              {item.txn_ref}
            </span>
          </div>
        )}
        {item.gateway_txn_id && (
          <div className="kp-detail-row">
            <span className="kp-detail-label">UTR</span>
            <span className="kp-detail-val kp-mono-val kp-copiable" onClick={e => { e.stopPropagation(); onCopy(item.gateway_txn_id, 'UTR'); }}>
              {item.gateway_txn_id}
            </span>
          </div>
        )}
        {item.gateway_bank_txn_id && !item.gateway_txn_id && (
          <div className="kp-detail-row">
            <span className="kp-detail-label">Bank Txn</span>
            <span className="kp-detail-val kp-mono-val kp-copiable" onClick={e => { e.stopPropagation(); onCopy(item.gateway_bank_txn_id, 'Bank Txn'); }}>
              {item.gateway_bank_txn_id}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
