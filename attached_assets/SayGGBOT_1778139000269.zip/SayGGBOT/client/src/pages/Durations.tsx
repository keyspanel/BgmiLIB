import React, { useEffect, useState } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';
import cfg from '../config';

export default function Durations() {
  const [items, setItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ category_id: '', name: '', sort_order: 0, button_style: 4, price: 0, is_hidden: 0 });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (filterCat) params.set('category_id', filterCat);
    apiGet(`/durations?${params}`).then(setItems).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { apiGet('/categories').then(setCategories).catch(() => {}); }, []);
  useEffect(() => { load(); }, [search, filterCat]);

  const openAdd = () => { setEditing(null); setForm({ category_id: categories[0]?.id || '', name: '', sort_order: 0, button_style: 4, price: 0, is_hidden: 0 }); setShowForm(true); };
  const openEdit = (item: any) => { setEditing(item); setForm({ category_id: item.category_id, name: item.name, sort_order: item.sort_order, button_style: item.button_style || 4, price: item.price, is_hidden: item.is_hidden }); setShowForm(true); };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) await apiPut(`/durations/${editing.id}`, form);
      else await apiPost('/durations', form);
      setShowForm(false); setMsg(editing ? 'Duration updated' : 'Duration created'); load();
      setTimeout(() => setMsg(''), 2500);
    } catch (err: any) { setMsg(err.message); }
    setSaving(false);
  };

  const toggleVisibility = async (item: any) => {
    try { await apiPut(`/durations/${item.id}/visibility`, { is_hidden: item.is_hidden ? 0 : 1 }); load(); } catch {}
  };

  const remove = async (item: any) => {
    if (!confirm(`Delete "${item.displayName || item.name}"?`)) return;
    try { await apiDelete(`/durations/${item.id}`); load(); } catch (err: any) { setMsg(err.message); }
  };

  return (
    <div className="page">
      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search durations..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <button className="btn-primary-sm" onClick={openAdd}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add
        </button>
      </div>

      <div className="filter-row">
        <select value={filterCat} onChange={e => setFilterCat(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.displayName || c.name}</option>)}
        </select>
      </div>

      {msg && <div className="toast-msg">{msg}</div>}

      {showForm && (
        <div className="sheet-overlay" onClick={() => setShowForm(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{editing ? 'Edit Duration' : 'New Duration'}</h3>
              <p>{editing ? 'Update duration details' : 'Add a new time-based pricing plan'}</p>
            </div>
            <form onSubmit={save} className="sheet-body">
              <div className="field">
                <label>Category</label>
                <select value={form.category_id} onChange={e => setForm({...form, category_id: parseInt(e.target.value) as any})} required>
                  <option value="">Select category...</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.displayName || c.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Duration Name</label>
                <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required placeholder="e.g. 1 Month" />
              </div>
              <div className="field-row">
                <div className="field">
                  <label>Price ({cfg.currency})</label>
                  <input type="number" step="0.01" min="0" value={form.price} onChange={e => setForm({...form, price: parseFloat(e.target.value) || 0})} />
                </div>
                <div className="field">
                  <label>Sort Order</label>
                  <input type="number" value={form.sort_order} onChange={e => setForm({...form, sort_order: parseInt(e.target.value) || 0})} />
                </div>
              </div>
              <div className="field">
                <label>Button Style</label>
                <select value={form.button_style} onChange={e => setForm({...form, button_style: parseInt(e.target.value)})}>
                  <option value={1}>Style 1</option><option value={2}>Style 2</option><option value={3}>Style 3</option><option value={4}>Style 4</option>
                </select>
              </div>
              <label className="toggle-row" onClick={() => setForm({...form, is_hidden: form.is_hidden ? 0 : 1})}>
                <div className={`toggle-switch ${form.is_hidden ? 'on' : ''}`}><div className="toggle-knob" /></div>
                <span>Hide from bot menu</span>
              </label>
              <div className="sheet-actions">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary-sm" disabled={saving}>{saving ? 'Saving...' : editing ? 'Update' : 'Create'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading durations...</span></div>
      ) : items.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
          <div className="empty-title">No durations found</div>
          <div className="empty-desc">Add time-based pricing plans to your categories</div>
        </div>
      ) : (
        <div className="list">
          {items.map(item => (
            <div key={item.id} className="list-card">
              <div className="list-card-top">
                <div className="list-card-info">
                  <div className={`list-card-dot ${item.is_hidden ? 'danger' : 'success'}`} />
                  <div>
                    <div className="list-card-title">{item.displayName || item.name}</div>
                    <div className="list-card-sub">{item.categoryDisplayName || item.category_name}</div>
                  </div>
                </div>
                <div className="list-card-price">{cfg.currency}{Number(item.price).toLocaleString()}</div>
              </div>
              <div className="list-card-meta">
                {item.has_active_api_source ? (
                  <>
                    <span style={{ color: 'var(--c-sky)', fontWeight: 600 }}>API · On Demand</span>
                    {item.provider_name && <span style={{ color: 'var(--c-sky)' }}>{item.provider_name}</span>}
                    {Number(item.available_keys) > 0 && <span style={{ color: 'var(--c-emerald)' }}>+{item.available_keys} manual</span>}
                  </>
                ) : (
                  <>
                    <span style={{ color: Number(item.available_keys) > 0 ? 'var(--c-emerald)' : 'var(--c-rose)' }}>{item.available_keys || 0} available</span>
                    <span>{item.total_keys || 0} total keys</span>
                  </>
                )}
                <span>{item.is_hidden ? 'Hidden' : 'Visible'}</span>
              </div>
              <div className="list-card-actions">
                <button className="btn-ghost-sm" onClick={() => toggleVisibility(item)}>{item.is_hidden ? 'Show' : 'Hide'}</button>
                <button className="btn-ghost-sm" onClick={() => openEdit(item)}>Edit</button>
                <button className="btn-danger-sm" onClick={() => remove(item)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
