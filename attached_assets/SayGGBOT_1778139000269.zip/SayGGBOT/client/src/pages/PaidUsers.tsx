import React, { useEffect, useState } from 'react';
import { apiGet } from '../api';
import cfg from '../config';
import UserAvatar from '../components/UserAvatar';

export default function PaidUsers() {
  const [view, setView] = useState('profiles');
  const [summary, setSummary] = useState<any>(null);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [recent, setRecent] = useState<any[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<number | null>(null);
  const [profileData, setProfileData] = useState<any>(null);
  const [durationFilters, setDurationFilters] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterDuration, setFilterDuration] = useState('');
  const [filterRole, setFilterRole] = useState('');

  useEffect(() => {
    apiGet('/paid-users/summary').then(setSummary).catch(() => {});
    apiGet('/paid-users/duration-filters').then(setDurationFilters).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (filterDuration) params.set('duration_name', filterDuration);
    if (filterRole) params.set('role', filterRole);
    if (view === 'profiles') {
      apiGet(`/paid-users/profiles?${params}`).then(setProfiles).catch(() => {}).finally(() => setLoading(false));
    } else {
      apiGet(`/paid-users/recent?${params}`).then(setRecent).catch(() => {}).finally(() => setLoading(false));
    }
  }, [view, search, filterDuration, filterRole]);

  const openProfile = async (userId: number) => {
    setSelectedProfile(userId);
    try { setProfileData(await apiGet(`/paid-users/profile/${userId}`)); } catch { setProfileData(null); }
  };

  const formatDate = (d: string | null) => d ? new Date(d).toLocaleString(cfg.locale, { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }) : '-';
  const displayName = (p: any) => ((p.first_name || '') + ' ' + (p.last_name || '')).trim() || (p.username ? '@' + p.username : 'User');

  return (
    <div className="page">
      {summary && (
        <div className="inv-grid" style={{ marginBottom: 16, gridTemplateColumns: 'repeat(3, 1fr)' }}>
          <div className="inv-card"><div className="inv-val" style={{ color: 'var(--c-accent)' }}>{summary.total_paid_users}</div><div className="inv-label">Users</div></div>
          <div className="inv-card"><div className="inv-val" style={{ color: 'var(--c-emerald)' }}>{summary.total_purchases}</div><div className="inv-label">Purchases</div></div>
          <div className="inv-card"><div className="inv-val">{cfg.currency}{Number(summary.total_revenue || 0).toLocaleString()}</div><div className="inv-label">Revenue</div></div>
        </div>
      )}

      <div className="seg-control">
        <button className={view === 'profiles' ? 'active' : ''} onClick={() => setView('profiles')}>Profiles</button>
        <button className={view === 'recent' ? 'active' : ''} onClick={() => setView('recent')}>Recent Activity</button>
      </div>

      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search paid users..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>
      <div className="filter-row">
        <select value={filterDuration} onChange={e => setFilterDuration(e.target.value)}>
          <option value="">All Durations</option>
          {durationFilters.map((d: any) => <option key={d.raw} value={d.raw}>{d.display}</option>)}
        </select>
        <select value={filterRole} onChange={e => setFilterRole(e.target.value)}>
          <option value="">All Types</option>
          <option value="customer">Customer</option>
          <option value="reseller">Reseller</option>
        </select>
      </div>

      {selectedProfile && profileData && (
        <div className="sheet-overlay" onClick={() => setSelectedProfile(null)}>
          <div className="sheet sheet-lg" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{displayName(profileData.profile)}</h3>
              <p>TG: {profileData.profile.telegram_id}{profileData.profile.username ? ` · @${profileData.profile.username}` : ''}</p>
            </div>
            <div className="sheet-body">
              <div className="metric-row" style={{ marginBottom: 16 }}>
                <div className="metric-pill"><span className="metric-label">Keys</span><span className="metric-val" style={{ color: 'var(--c-accent)' }}>{profileData.profile.total_keys}</span></div>
                <div className="metric-pill"><span className="metric-label">Spent</span><span className="metric-val" style={{ color: 'var(--c-emerald)' }}>{cfg.currency}{Number(profileData.profile.total_spent || 0).toLocaleString()}</span></div>
              </div>
              <div className="section-label">Purchase History</div>
              <div className="list">
                {profileData.purchases.map((p: any) => (
                  <div key={p.id} className="compact-card">
                    <div className="compact-card-top">
                      <span className="mono-text-sm">{p.key_value}</span>
                      <span style={{ color: 'var(--c-emerald)', fontWeight: 600 }}>{cfg.currency}{Number(p.amount || 0).toLocaleString()}</span>
                    </div>
                    <div className="compact-card-bottom">
                      <span>{p.categoryDisplayName} / {p.durationDisplayName}</span>
                      <span>{formatDate(p.verified_at)}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="sheet-actions">
                <button className="btn-ghost" onClick={() => setSelectedProfile(null)}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading paid users...</span></div>
      ) : view === 'profiles' ? (
        profiles.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
            <div className="empty-title">No paid users found</div>
            <div className="empty-desc">Users who complete purchases will appear here</div>
          </div>
        ) : (
          <div className="list">
            <div className="count-label">{profiles.length} paid user{profiles.length === 1 ? '' : 's'}</div>
            {profiles.map((p: any) => (
              <div key={p.user_id} className="list-card" onClick={() => openProfile(p.user_id)} style={{ cursor: 'pointer' }}>
                <div className="list-card-top">
                  <div className="list-card-info">
                    <UserAvatar name={displayName(p)} photoUrl={p.profile_photo_url} className={p.is_reseller_purchase ? 'info' : 'accent'} />
                    <div>
                      <div className="list-card-title">{displayName(p)}</div>
                      <div className="list-card-sub">TG: {p.telegram_id}</div>
                    </div>
                  </div>
                  <div className={`badge-${p.is_reseller_purchase ? 'info' : 'accent'}`}>{p.is_reseller_purchase ? 'Reseller' : 'Customer'}</div>
                </div>
                <div className="list-card-meta">
                  <span>{p.total_keys} keys</span>
                  <span style={{ color: 'var(--c-emerald)' }}>{cfg.currency}{Number(p.total_spent || 0).toLocaleString()} spent</span>
                  <span>{formatDate(p.last_purchase_at)}</span>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        recent.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
            <div className="empty-title">No recent activity</div>
            <div className="empty-desc">Recent purchases will be listed here</div>
          </div>
        ) : (
          <div className="list">
            {recent.map((r: any) => (
              <div key={r.id} className="compact-card">
                <div className="compact-card-top">
                  <span className="mono-text-sm">{r.key_value}</span>
                  <span style={{ color: 'var(--c-emerald)', fontWeight: 600 }}>{cfg.currency}{Number(r.amount || 0).toLocaleString()}</span>
                </div>
                <div className="compact-card-bottom">
                  <span>{((r.first_name || '') + ' ' + (r.last_name || '')).trim() || (r.username ? '@' + r.username : 'User')}</span>
                  <span>{r.categoryDisplayName} / {r.durationDisplayName}</span>
                </div>
                <div className="compact-card-bottom">
                  <span>{formatDate(r.verified_at)}</span>
                </div>
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}
