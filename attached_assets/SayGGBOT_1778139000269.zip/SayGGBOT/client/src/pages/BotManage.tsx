import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { apiGet, apiPut } from '../api';

const STYLE_OPTIONS = [
  { value: '', label: 'None' },
  { value: '1', label: 'Default' },
  { value: '2', label: 'Primary' },
  { value: '3', label: 'Success' },
  { value: '4', label: 'Danger' },
];

const STYLE_COLORS: Record<string, string> = {
  '1': 'var(--text-2)',
  '2': 'var(--c-accent)',
  '3': 'var(--c-emerald)',
  '4': 'var(--c-rose)',
};

const VALID_TG_TAGS = ['b', 'i', 'u', 's', 'code', 'pre', 'a', 'em', 'strong', 'strike', 'del', 'ins', 'tg-spoiler', 'tg-emoji', 'blockquote'];

const FORMAT_EXAMPLES = [
  { label: 'Bold', syntax: '<b>text</b>', copy: '<b></b>', desc: 'Makes text bold' },
  { label: 'Italic', syntax: '<i>text</i>', copy: '<i></i>', desc: 'Makes text italic' },
  { label: 'Underline', syntax: '<u>text</u>', copy: '<u></u>', desc: 'Underlines text' },
  { label: 'Strikethrough', syntax: '<s>text</s>', copy: '<s></s>', desc: 'Strikes through text' },
  { label: 'Spoiler', syntax: '<tg-spoiler>text</tg-spoiler>', copy: '<tg-spoiler></tg-spoiler>', desc: 'Hidden until tapped' },
  { label: 'Inline Code', syntax: '<code>text</code>', copy: '<code></code>', desc: 'Monospace inline' },
  { label: 'Code Block', syntax: '<pre>text</pre>', copy: '<pre></pre>', desc: 'Monospace block' },
  { label: 'Link', syntax: '<a href="URL">text</a>', copy: '<a href=""></a>', desc: 'Clickable hyperlink' },
  { label: 'User Link', syntax: '<a href="tg://user?id=ID">name</a>', copy: '<a href="tg://user?id="></a>', desc: 'Mention by user ID' },
  { label: 'Line Break', syntax: 'New line (press Enter)', copy: '\n', desc: 'Use Enter key for new lines' },
];

const PLACEHOLDER_DEFS = [
  { name: 'brand', desc: 'Your store/brand name', used: ['welcome', 'store', 'delivery', 'verify', 'payment', 'expiry'] },
  { name: 'first_name', desc: "User's Telegram first name", used: ['welcome', 'verify', 'delivery', 'payment', 'expiry'] },
  { name: 'username', desc: "User's Telegram username", used: ['delivery', 'verify', 'payment', 'expiry'] },
  { name: 'name_link', desc: 'Clickable user mention link', used: ['welcome', 'delivery', 'verify', 'payment', 'expiry'] },
  { name: 'category', desc: 'Product category name', used: ['payment', 'delivery', 'store', 'keys', 'verify', 'expiry'] },
  { name: 'duration', desc: 'Selected duration plan', used: ['payment', 'delivery', 'keys', 'verify', 'expiry'] },
  { name: 'currency', desc: 'Currency symbol (use {currency}{amount} for formatted price)', used: ['payment', 'delivery', 'keys', 'verify', 'expiry'] },
  { name: 'amount', desc: 'Final price to pay', used: ['payment', 'delivery', 'keys', 'verify', 'expiry'] },
  { name: 'base_amount', desc: 'Original price before discount', used: ['payment', 'delivery'] },
  { name: 'order_id', desc: 'Unique order reference number', used: ['payment', 'delivery', 'keys', 'verify', 'expiry'] },
  { name: 'txn_ref', desc: 'Transaction reference code', used: ['payment', 'delivery', 'verify', 'expiry'] },
  { name: 'status', desc: 'Current order status', used: ['verify', 'expiry'] },
  { name: 'payment_method', desc: 'Payment method (e.g. UPI)', used: ['payment', 'delivery', 'verify'] },
  { name: 'created_time', desc: 'Order creation timestamp', used: ['payment'] },
  { name: 'created_at', desc: 'Order creation timestamp (alias)', used: ['payment', 'verify', 'expiry'] },
  { name: 'expiry_time', desc: 'Order expiration timestamp', used: ['payment'] },
  { name: 'expires_at', desc: 'Order expiration timestamp (alias)', used: ['payment'] },
  { name: 'upi_id', desc: 'UPI payment address', used: ['payment'] },
  { name: 'verify_btn', desc: 'Verify button label text', used: ['payment'] },
  { name: 'key', desc: 'Product key value', used: ['delivery', 'keys'] },
  { name: 'keys', desc: 'Product key value (alias)', used: ['delivery'] },
  { name: 'key_value', desc: 'Product key value (alias)', used: ['delivery'] },
  { name: 'current_time', desc: 'Delivery timestamp', used: ['delivery'] },
  { name: 'verified_title', desc: 'Payment verified heading (from setting)', used: ['delivery'] },
  { name: 'key_label', desc: 'Key label text (from setting)', used: ['delivery'] },
  { name: 'apk_notice', desc: 'APK sent notice (conditional)', used: ['delivery'] },
  { name: 'footer', desc: 'Success footer text (from setting)', used: ['delivery'] },
  { name: 'file_name', desc: 'Delivered application file ID', used: ['delivery'] },
  { name: 'category_file', desc: 'Category application file ID', used: ['delivery'] },
  { name: 'index', desc: 'Current key number', used: ['keys'] },
  { name: 'total', desc: 'Total number of keys', used: ['keys'] },
  { name: 'purchased_time', desc: 'Purchase timestamp', used: ['keys'] },
  { name: 'buyer', desc: 'Buyer name', used: ['keys'] },
  { name: 'reference_section', desc: 'Transaction reference block (conditional)', used: ['keys'] },
];

const SAMPLE_DATA: Record<string, string> = {
  brand: 'KeyStore',
  first_name: 'John',
  username: 'john_doe',
  name_link: '<a href="tg://user?id=123456">John</a>',
  category: 'BGMI Premium',
  duration: '30 Days',
  currency: String.fromCharCode(8377),
  amount: '299.00',
  base_amount: '399.00',
  total_amount: '299.00',
  order_id: '12345',
  txn_ref: 'KS2026031012345',
  status: 'paid',
  payment_method: 'UPI',
  created_time: '10 Mar 2026, 02:30 PM',
  created_at: '10 Mar 2026, 02:30 PM',
  expiry_time: '10 Mar 2026, 02:45 PM',
  expires_at: '10 Mar 2026, 02:45 PM',
  upi_id: 'merchant@upi',
  verify_btn: 'Verify Payment',
  key: 'XXXX-YYYY-ZZZZ-1234',
  keys: 'XXXX-YYYY-ZZZZ-1234',
  key_value: 'XXXX-YYYY-ZZZZ-1234',
  current_time: '10 Mar 2026, 02:31 PM',
  file_name: 'app_v2.apk',
  category_file: 'app_v2.apk',
  admin_sale_title: '\uD83D\uDD14 New Sale',
  buyer_label: '@john_doe',
  index: '1',
  total: '3',
  purchased_time: '10 Mar 2026, 02:30 PM',
  buyer: 'John Doe',
  reference_section: '\n\n<b>Reference:</b> <code>KS2026031012345</code>',
  welcome_greeting: '\u2728 <b>Hey <a href="tg://user?id=123456">John</a>!</b>',
  welcome_title: 'Welcome to KeyStore.',
  welcome_body: 'Use the menu below to browse categories and purchase keys.',
  store_title: 'KeyStore \u2014 Digital Key Store',
  store_subtitle: 'Choose a category below to browse available products.',
  categories_footer: '\uD83D\uDC47 <b>Select a category to continue</b>',
  duration_title: '\u23F1\uFE0F <b>Select Duration</b>',
  duration_sub: 'Select a duration below:',
  reseller_title: '\uD83C\uDF89 <b>Reseller Access Activated Successfully</b>',
  code: '123456',
  switched_section: '',
  expires: 'Unlimited',
  max_users: 'Unlimited',
  offer_summary: '\u2022 Global discount: <b>10.00% OFF</b>',
  reseller_footer: '\u2705 You will now see your reseller prices automatically inside the category duration buttons.',
  verified_title: '\u2705 <b>Payment Verified Successfully</b>',
  key_label: '\uD83D\uDD11 <b>Your Key:</b>',
  apk_notice: '\uD83D\uDCF2 The application file has been sent above. Install it and use your key to activate.',
  footer: 'Thank you for your purchase.',
};

const PAYMENT_PH = ['category', 'duration', 'currency', 'amount', 'base_amount', 'total_amount', 'order_id', 'txn_ref', 'created_time', 'created_at', 'expiry_time', 'expires_at', 'upi_id', 'verify_btn', 'first_name', 'username', 'name_link', 'brand', 'payment_method'];
const VERIFY_PH = ['first_name', 'username', 'name_link', 'brand', 'order_id', 'txn_ref', 'category', 'duration', 'currency', 'amount', 'status', 'payment_method', 'created_at'];
const DELIVERY_PH = ['category', 'duration', 'order_id', 'currency', 'amount', 'first_name', 'username', 'name_link', 'brand', 'key', 'keys', 'key_value', 'file_name', 'category_file'];
const DELIVERY_BODY_PH = ['category', 'duration', 'order_id', 'currency', 'amount', 'key_value', 'first_name', 'username', 'name_link', 'brand', 'txn_ref'];
const SUCCESS_BODY_PH = ['verified_title', 'category', 'duration', 'order_id', 'txn_ref', 'amount', 'base_amount', 'currency', 'key', 'keys', 'key_value', 'key_label', 'first_name', 'username', 'name_link', 'brand', 'current_time', 'apk_notice', 'footer', 'file_name', 'category_file', 'payment_method', 'status'];
const ADMIN_SALE_PH = ['admin_sale_title', 'order_id', 'buyer_label', 'category', 'duration', 'currency', 'amount', 'txn_ref', 'first_name', 'username', 'brand', 'key', 'payment_method', 'status'];
const KEYS_ITEM_PH = ['index', 'total', 'order_id', 'category', 'duration', 'currency', 'amount', 'purchased_time', 'buyer', 'key', 'reference_section'];
const WELCOME_PH = ['welcome_greeting', 'name_link', 'first_name', 'brand', 'welcome_title', 'welcome_body'];
const GREETING_PH = ['name_link', 'first_name', 'brand'];
const STORE_HEADER_PH = ['store_title', 'store_subtitle', 'categories_footer'];
const DURATION_CAPTION_PH = ['duration_title', 'category', 'duration_sub'];
const RESELLER_ACTIVATED_PH = ['reseller_title', 'code', 'switched_section', 'expires', 'max_users', 'offer_summary', 'reseller_footer'];
const RESELLER_ALREADY_ACTIVE_PH = ['reseller_title', 'code', 'expires', 'offer_summary'];

const SVG_ICONS: Record<string, string> = {
  welcome: 'M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2z',
  store: 'M6 2L3 7v11a2 2 0 002 2h14a2 2 0 002-2V7l-3-5H6z M3 7h18 M16 11a4 4 0 01-8 0',
  payment: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z M14 2v6h6 M16 13H8 M16 17H8 M10 9H8',
  verify: 'M9 11l3 3L22 4 M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11',
  delivery: 'M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4',
  keys: 'M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z M3.27 6.96L12 12.01l8.73-5.05 M12 22.08V12',
  expiry: 'M12 2a10 10 0 100 20 10 10 0 000-20z M12 6v6l4 2',
  callbacks: 'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z',
  reseller: 'M17 11h1a3 3 0 010 6h-1 M17 11H7a3 3 0 000 6h1 M12 2v4 M8 4l1 2 M16 4l-1 2',
  broadcast: 'M22 2L11 13 M22 2l-7 20-4-9-9-4 20-7z',
  keyboard: 'M20 3H4a2 2 0 00-2 2v14a2 2 0 002 2h16a2 2 0 002-2V5a2 2 0 00-2-2z M7 8h0 M12 8h0 M17 8h0 M7 12h0 M17 12h0 M8 16h8',
  buttons: 'M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4M10 17l5-5-5-5M13.8 12H3',
  howto: 'M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3 M12 17h.01',
  format: 'M12 19l7-7 3 3-7 7-3-3z M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z M2 2l7.586 7.586',
  placeholder: 'M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71 M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71',
  emoji: 'M12 2a10 10 0 100 20 10 10 0 000-20z M8 14s1.5 2 4 2 4-2 4-2 M9 9h.01 M15 9h.01',
  check: 'M20 6L9 17l-5-5',
  copy: 'M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2 M9 2h6a1 1 0 011 1v2a1 1 0 01-1 1H9a1 1 0 01-1-1V3a1 1 0 011-1z',
  reset: 'M1 4v6h6 M23 20v-6h-6 M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15',
  preview: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 9a3 3 0 100 6 3 3 0 000-6z',
};

function Svg({ name, size = 16, className = '' }: { name: string; size?: number; className?: string }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d={SVG_ICONS[name]} />
    </svg>
  );
}

function validateTgHtml(text: string): string[] {
  if (!text) return [];
  const errors: string[] = [];
  const tagRe = /<\/?([a-z][a-z0-9-]*)[^>]*>/gi;
  let m;
  while ((m = tagRe.exec(text)) !== null) {
    const tag = m[1].toLowerCase();
    if (!VALID_TG_TAGS.includes(tag)) {
      errors.push(`<${tag}> is not supported by Telegram`);
    }
  }
  for (const tag of VALID_TG_TAGS) {
    const re1 = new RegExp(`<${tag}(?:\\s[^>]*)?>`, 'gi');
    const re2 = new RegExp(`</${tag}>`, 'gi');
    const opens = (text.match(re1) || []).length;
    const closes = (text.match(re2) || []).length;
    if (opens !== closes) errors.push(`Unclosed <${tag}> tag`);
  }
  return errors;
}

function validatePlaceholders(text: string, validList: string[]): string[] {
  if (!text) return [];
  const errors: string[] = [];
  const used = [...text.matchAll(/\{(\w+)\}/g)].map(m => m[1]);
  for (const ph of used) {
    if (!validList.includes(ph)) errors.push(`{${ph}} is not valid here`);
  }
  return errors;
}

function renderPreview(template: string, sampleVals: Record<string, string>): string {
  if (!template) return '';
  let out = template;
  for (const [k, v] of Object.entries(sampleVals)) {
    out = out.replace(new RegExp(`\\{${k}\\}`, 'g'), `<span class="bm-pv-val">${v}</span>`);
  }
  out = out.replace(/<tg-spoiler>/g, '<span class="bm-pv-spoiler">').replace(/<\/tg-spoiler>/g, '</span>');
  out = out.replace(/<tg-emoji[^>]*>([^<]*)<\/tg-emoji>/g, '$1');
  out = out.replace(/\n/g, '<br>');
  return out;
}

function CopyBtn({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {}
  };
  return (
    <button type="button" className={`bm-copy-btn${copied ? ' copied' : ''}`} onClick={copy}>
      <Svg name={copied ? 'check' : 'copy'} size={12} />
      {label && <span>{copied ? 'Copied' : label}</span>}
    </button>
  );
}

function StatusBadge({ status }: { status: any }) {
  if (!status) return null;
  if (status.type === 'saving') return <span className="bm-status saving"><span className="bm-dot-pulse" /> Saving</span>;
  if (status.type === 'success') return <span className="bm-status success"><Svg name="check" size={13} /> {status.msg || 'Saved'}</span>;
  if (status.type === 'error') return <span className="bm-status error">{status.msg}</span>;
  return null;
}

function Section({ id, title, subtitle, icon, desc, children, defaultOpen, onSave, onReset, status, noSave }: any) {
  const [open, setOpen] = useState(defaultOpen || false);
  return (
    <div className={`bm-card${open ? ' open' : ''}`} id={`bm-${id}`}>
      <button type="button" className="bm-card-head" onClick={() => setOpen((o: boolean) => !o)}>
        <span className="bm-card-icon">
          <Svg name={icon} size={15} />
        </span>
        <div className="bm-card-htext">
          <span className="bm-card-title">{title}</span>
          {subtitle && !open && <span className="bm-card-subtitle">{subtitle}</span>}
        </div>
        {!open && status?.type === 'success' && (
          <span className="bm-card-saved"><Svg name="check" size={10} /></span>
        )}
        <svg className={`bm-chev${open ? ' open' : ''}`} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
      </button>
      {open && (
        <div className="bm-card-body">
          {desc && <p className="bm-card-desc">{desc}</p>}
          {children}
          {!noSave && (
            <div className="bm-card-actions">
              <button type="button" className="bm-btn-save" onClick={onSave} disabled={status?.type === 'saving'}>
                {status?.type === 'saving' ? <><span className="bm-spin" /> Saving...</> : 'Save Changes'}
              </button>
              {onReset && (
                <button type="button" className="bm-btn-reset" onClick={onReset} title="Reset to defaults">
                  <Svg name="reset" size={14} />
                </button>
              )}
              <StatusBadge status={status?.type !== 'saving' ? status : null} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, hint, error, children }: { label?: string; hint?: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="bm-field">
      {label && <label className="bm-lbl">{label}</label>}
      {children}
      {error && <span className="bm-err">{error}</span>}
      {hint && !error && <span className="bm-hint">{hint}</span>}
    </div>
  );
}

function TInput({ value, onChange, placeholder, mono, error }: { value: string; onChange: (v: string) => void; placeholder?: string; mono?: boolean; error?: boolean }) {
  return (
    <input
      type="text"
      className={`bm-inp${mono ? ' mono' : ''}${error ? ' err' : ''}`}
      value={value || ''}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
    />
  );
}

function TArea({ value, onChange, placeholder, rows = 3, mono, error }: { value: string; onChange: (v: string) => void; placeholder?: string; rows?: number; mono?: boolean; error?: boolean }) {
  return (
    <textarea
      className={`bm-inp bm-ta${mono ? ' mono' : ''}${error ? ' err' : ''}`}
      rows={rows}
      value={value || ''}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
    />
  );
}

function StylePicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="bm-style-row">
      {STYLE_OPTIONS.map(o => (
        <button
          key={o.value}
          type="button"
          className={`bm-style-opt${value === o.value ? ' active' : ''}`}
          style={o.value && value === o.value ? { borderColor: STYLE_COLORS[o.value], color: STYLE_COLORS[o.value] } : {}}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function EmojiInput({ value, onChange, error }: { value: string; onChange: (v: string) => void; error?: boolean }) {
  return (
    <input
      type="text"
      inputMode="numeric"
      className={`bm-inp mono${error ? ' err' : ''}`}
      value={value || ''}
      onChange={e => onChange(e.target.value.replace(/\D/g, ''))}
      placeholder="e.g. 5368324170671202286"
    />
  );
}

function NumInput({ value, onChange, min, max, error }: { value: string; onChange: (v: string) => void; min?: number; max?: number; error?: boolean }) {
  return (
    <input
      type="number"
      className={`bm-inp${error ? ' err' : ''}`}
      min={min}
      max={max}
      value={value || ''}
      onChange={e => onChange(e.target.value)}
    />
  );
}

function Sub({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bm-sub">
      <div className="bm-sub-title">{title}</div>
      {children}
    </div>
  );
}

function Sep() {
  return <div className="bm-sep" />;
}

function PhChips({ items, onInsert }: { items: string[]; onInsert?: (v: string) => void }) {
  return (
    <div className="bm-chips">
      {items.map(name => (
        <button key={name} type="button" className="bm-chip" onClick={() => onInsert && onInsert(`{${name}}`)}>
          <code>{`{${name}}`}</code>
        </button>
      ))}
    </div>
  );
}

function PreviewPanel({ template, sampleData, show, onToggle }: { template: string; sampleData?: Record<string, string>; show: boolean; onToggle: () => void }) {
  const html = useMemo(() => renderPreview(template, sampleData || SAMPLE_DATA), [template, sampleData]);
  return (
    <div className="bm-preview-wrap">
      <button type="button" className="bm-preview-toggle" onClick={onToggle}>
        <Svg name="preview" size={14} />
        <span>{show ? 'Hide Preview' : 'Live Preview'}</span>
      </button>
      {show && (
        <div className="bm-preview-box">
          <div
            className="bm-preview-bubble"
            dangerouslySetInnerHTML={{
              __html: html || '<span class="bm-pv-empty">Enter text above to see preview</span>',
            }}
          />
        </div>
      )}
    </div>
  );
}

function TemplateEditor({ value, onChange, placeholders, sampleData, label, hint, rows = 5, validPh }: any) {
  const [showPreview, setShowPreview] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const htmlErrors = useMemo(() => validateTgHtml(value), [value]);
  const phErrors = useMemo(() => validatePlaceholders(value, validPh || placeholders), [value, validPh, placeholders]);
  const allErrors = [...htmlErrors, ...phErrors];

  const insertPh = useCallback((ph: string) => {
    const ta = textareaRef.current;
    if (!ta) { onChange((value || '') + ph); return; }
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const before = (value || '').substring(0, start);
    const after = (value || '').substring(end);
    onChange(before + ph + after);
    setTimeout(() => {
      ta.selectionStart = ta.selectionEnd = start + ph.length;
      ta.focus();
    }, 0);
  }, [value, onChange]);

  return (
    <div className="bm-tpl-editor">
      {label && <label className="bm-lbl">{label}</label>}
      {hint && <span className="bm-hint" style={{ marginBottom: 8, display: 'block' }}>{hint}</span>}
      <PhChips items={placeholders} onInsert={insertPh} />
      <textarea
        ref={textareaRef}
        className={`bm-inp bm-ta mono${allErrors.length ? ' err' : ''}`}
        rows={rows}
        value={value || ''}
        onChange={e => onChange(e.target.value)}
      />
      {allErrors.map((e, i) => <span key={i} className="bm-err">{e}</span>)}
      <PreviewPanel
        template={value}
        sampleData={sampleData}
        show={showPreview}
        onToggle={() => setShowPreview(p => !p)}
      />
    </div>
  );
}

const LINK_BTN_STYLES = [
  { value: '', label: 'Default' },
  { value: 'primary', label: 'Blue' },
  { value: 'success', label: 'Green' },
  { value: 'danger', label: 'Red' },
];

function LinkButtonsEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  let buttons: any[] = [];
  try { buttons = value ? JSON.parse(value) : []; } catch { buttons = []; }
  if (!Array.isArray(buttons)) buttons = [];

  const update = (arr: any[]) => onChange(arr.length ? JSON.stringify(arr) : '');
  const add = () => { if (buttons.length < 4) update([...buttons, { text: '', url: '', icon_custom_emoji_id: '', style: '' }]); };
  const remove = (i: number) => update(buttons.filter((_: any, idx: number) => idx !== i));
  const change = (i: number, field: string, val: string) => {
    const copy = buttons.map((b: any, idx: number) => idx === i ? { ...b, [field]: val } : b);
    update(copy);
  };
  const moveUp = (i: number) => {
    if (i <= 0) return;
    const copy = [...buttons];
    [copy[i - 1], copy[i]] = [copy[i], copy[i - 1]];
    update(copy);
  };

  return (
    <div className="bm-link-btns">
      <div className="bm-link-btns-header">
        <span className="bm-link-btns-count">{buttons.length}/4 buttons</span>
        {buttons.length < 4 && (
          <button type="button" className="bm-link-add-btn" onClick={add}>+ Add Button</button>
        )}
      </div>
      {buttons.map((btn: any, i: number) => (
        <div key={i} className="bm-link-row-card">
          <div className="bm-link-row-top">
            <input
              className="bm-link-input"
              placeholder="Button text"
              value={btn.text || ''}
              onChange={e => change(i, 'text', e.target.value)}
            />
            <div className="bm-link-actions">
              {i > 0 && <button type="button" className="bm-link-move" onClick={() => moveUp(i)} title="Move up">{'\u2191'}</button>}
              <button type="button" className="bm-link-remove" onClick={() => remove(i)} title="Remove">{'\u00d7'}</button>
            </div>
          </div>
          <input
            className="bm-link-input bm-link-url"
            placeholder="https://..."
            value={btn.url || ''}
            onChange={e => change(i, 'url', e.target.value)}
          />
          <div className="bm-link-row-extras">
            <input
              className="bm-link-input bm-link-emoji"
              placeholder="Custom Emoji ID (optional)"
              value={btn.icon_custom_emoji_id || ''}
              onChange={e => change(i, 'icon_custom_emoji_id', e.target.value)}
            />
            <select
              className="bm-link-style-select"
              value={btn.style || ''}
              onChange={e => change(i, 'style', e.target.value)}
            >
              {LINK_BTN_STYLES.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>
      ))}
      {buttons.length === 0 && <div className="bm-link-empty">No link buttons configured. The copy-key button will be shown alone.</div>}
    </div>
  );
}

function FormatHelperSection() {
  return (
    <Section
      id="fmt_help"
      title="Formatting Guide"
      subtitle="HTML tags for Telegram"
      icon="format"
      noSave
      desc="Copy these HTML tags and paste them into any template field. Telegram supports a limited set of HTML for message formatting."
    >
      <div className="bm-fmt-grid">
        {FORMAT_EXAMPLES.map(f => (
          <div key={f.label} className="bm-fmt-item">
            <div className="bm-fmt-top">
              <span className="bm-fmt-name">{f.label}</span>
              <CopyBtn text={f.copy} label="Copy" />
            </div>
            <code className="bm-fmt-syntax">{f.syntax}</code>
            <span className="bm-fmt-desc">{f.desc}</span>
          </div>
        ))}
      </div>
      <div className="bm-info-box">
        <strong>Important Notes</strong>
        <ul>
          <li>Only the tags listed above work in Telegram messages</li>
          <li>Tags must be properly closed</li>
          <li>Nesting is supported</li>
          <li>Callback alerts (popups) do NOT support HTML</li>
          <li>Press Enter for line breaks in templates</li>
        </ul>
      </div>
    </Section>
  );
}

function PlaceholderRefSection() {
  return (
    <Section
      id="ph_ref"
      title="Placeholders & Variables"
      subtitle="Dynamic values reference"
      icon="placeholder"
      noSave
      desc="Placeholders get replaced with real data when the bot sends a message. Use curly braces like {name}."
    >
      <div className="bm-ph-grid">
        {PLACEHOLDER_DEFS.map(p => (
          <div key={p.name} className="bm-ph-item">
            <div className="bm-ph-top">
              <code className="bm-ph-code">{`{${p.name}}`}</code>
              <CopyBtn text={`{${p.name}}`} />
            </div>
            <span className="bm-ph-explain">{p.desc}</span>
            <span className="bm-ph-where">Used in: {p.used.join(', ')}</span>
          </div>
        ))}
      </div>
      <div className="bm-info-box">
        <strong>Placeholder Rules</strong>
        <ul>
          <li>Only use placeholders listed in each template editor's chip bar</li>
          <li>Payment and delivery templates support the most placeholders</li>
          <li>Some placeholders like <code>{'{apk_notice}'}</code> and <code>{'{reference_section}'}</code> are conditional and may be empty</li>
          <li>Empty placeholders collapse cleanly without leaving blank lines</li>
          <li>Missing or invalid placeholders are silently removed</li>
        </ul>
      </div>
    </Section>
  );
}

function EmojiGuideSection() {
  return (
    <Section
      id="emoji_guide"
      title="Custom Emoji Guide"
      subtitle="Premium emoji usage"
      icon="emoji"
      noSave
      desc="How emoji and custom emoji work in the bot."
    >
      <div className="bm-info-box">
        <strong>Standard Unicode Emoji</strong>
        <p>Regular emoji work everywhere in message text, button labels, and templates. Just type or paste them directly.</p>
      </div>
      <div className="bm-info-box" style={{ marginTop: 12 }}>
        <strong>Custom Emoji ID (Premium)</strong>
        <p>Telegram premium custom emoji can be used as button icons.</p>
        <ul>
          <li>Works on reply keyboard buttons</li>
          <li>The ID is a long numeric string</li>
          <li>Find IDs by sending a custom emoji to @RawDataBot</li>
          <li>Requires Telegram Bot API 9.0+</li>
        </ul>
      </div>
      <div className="bm-info-box warn" style={{ marginTop: 12 }}>
        <strong>Limitations</strong>
        <ul>
          <li>Custom emoji IDs do NOT work in plain message text</li>
          <li>Category names support emoji via special syntax (managed in Categories page)</li>
          <li>Not all Telegram clients render button styles or custom emoji</li>
          <li>Invalid emoji IDs will show buttons without icons</li>
        </ul>
      </div>
    </Section>
  );
}

const BROADCAST_PH = ['plan_name', 'description', 'pricing_examples', 'expiry_time', 'brand', 'current_time', 'first_name'];
const BROADCAST_SAMPLE: Record<string, string> = {
  plan_name: 'Sunday Discount',
  description: 'Special offer for all users',
  pricing_examples: '• Vision → Day 1\n  Normal: ₹20.00  →  ₹16.00',
  expiry_time: '15 Mar 2026, 08:00 AM',
  brand: 'KeyStore',
  current_time: '12 Mar 2026, 10:00 AM',
  first_name: 'John',
};

const BTN_STYLE_OPTIONS = [
  { value: '', label: 'Default', color: 'var(--text-2)' },
  { value: 'primary', label: 'Blue', color: 'var(--c-accent)' },
  { value: 'success', label: 'Green', color: 'var(--c-emerald)' },
  { value: 'danger', label: 'Red', color: 'var(--c-rose)' },
];

function InlineButtonEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [buttons, setButtons] = useState<any[]>([]);
  const [showJson, setShowJson] = useState(false);
  const [parseError, setParseError] = useState('');

  useEffect(() => {
    try {
      let parsed = JSON.parse(value || '[]');
      if (!Array.isArray(parsed)) parsed = [];
      const normalized = parsed
        .filter((b: any) => b && typeof b === 'object')
        .filter((b: any) => b.url || b.text)
        .map((b: any) => ({
          text: b.text || '',
          url: b.url || '',
          style: b.style || '',
          icon_custom_emoji_id: b.icon_custom_emoji_id || '',
        }));
      setButtons(normalized);
      setParseError('');
    } catch {
      setButtons([]);
      setParseError('Invalid JSON — use the editor below to fix');
    }
  }, []);

  const sync = useCallback((updated: any[]) => {
    setButtons(updated);
    const clean = updated
      .filter((b: any) => b.text.trim() && b.url.trim())
      .map((b: any) => {
        const obj: any = { text: b.text.trim(), url: b.url.trim() };
        if (b.style) obj.style = b.style;
        if (b.icon_custom_emoji_id.trim()) obj.icon_custom_emoji_id = b.icon_custom_emoji_id.trim();
        return obj;
      });
    onChange(JSON.stringify(clean));
  }, [onChange]);

  const addButton = () => sync([...buttons, { text: '', url: '', style: '', icon_custom_emoji_id: '' }]);
  const removeButton = (i: number) => sync(buttons.filter((_: any, idx: number) => idx !== i));
  const updateButton = (i: number, field: string, val: string) => {
    const updated = buttons.map((b: any, idx: number) => idx === i ? { ...b, [field]: val } : b);
    sync(updated);
  };
  const moveButton = (i: number, dir: number) => {
    const j = i + dir;
    if (j < 0 || j >= buttons.length) return;
    const updated = [...buttons];
    [updated[i], updated[j]] = [updated[j], updated[i]];
    sync(updated);
  };
  const isValidUrl = (u: string) => {
    if (!u.trim()) return true;
    try {
      const url = new URL(u.trim());
      return url.protocol === 'https:' || url.protocol === 'http:' || url.protocol === 'tg:';
    } catch { return false; }
  };

  return (
    <div className="ibe-wrap">
      {parseError && <div className="ibe-parse-error">{parseError}</div>}
      {buttons.length === 0 && (
        <div className="ibe-empty">
          <span>No buttons configured</span>
          <span className="ibe-empty-hint">Add link buttons that appear below the broadcast message</span>
        </div>
      )}
      {buttons.map((btn: any, i: number) => (
        <div key={i} className="ibe-row">
          <div className="ibe-row-head">
            <span className="ibe-row-num">Button {i + 1}</span>
            <div className="ibe-row-actions">
              {buttons.length > 1 && (
                <>
                  <button type="button" className="ibe-move" disabled={i === 0} onClick={() => moveButton(i, -1)} title="Move up">↑</button>
                  <button type="button" className="ibe-move" disabled={i === buttons.length - 1} onClick={() => moveButton(i, 1)} title="Move down">↓</button>
                </>
              )}
              <button type="button" className="ibe-remove" onClick={() => removeButton(i)} title="Remove button">×</button>
            </div>
          </div>
          <div className="ibe-fields">
            <div className="ibe-field">
              <label className="ibe-label">Text</label>
              <input type="text" className="bm-inp" value={btn.text} onChange={e => updateButton(i, 'text', e.target.value)} placeholder="e.g. Join Channel" />
            </div>
            <div className="ibe-field">
              <label className="ibe-label">URL</label>
              <input type="url" className={`bm-inp${btn.url && !isValidUrl(btn.url) ? ' err' : ''}`} value={btn.url} onChange={e => updateButton(i, 'url', e.target.value)} placeholder="https://t.me/yourchannel" />
              {btn.url && !isValidUrl(btn.url) && <span className="bm-err">Enter a valid URL</span>}
            </div>
          </div>
          <div className="ibe-extras">
            <div className="ibe-field ibe-field-style">
              <label className="ibe-label">Color</label>
              <div className="ibe-style-row">
                {BTN_STYLE_OPTIONS.map(o => (
                  <button key={o.value} type="button" className={`ibe-style-opt${btn.style === o.value ? ' active' : ''}`} style={btn.style === o.value ? { borderColor: o.color, color: o.color } : {}} onClick={() => updateButton(i, 'style', o.value)}>
                    {o.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="ibe-field ibe-field-emoji">
              <label className="ibe-label">Custom Emoji ID</label>
              <input type="text" inputMode="numeric" className="bm-inp mono" value={btn.icon_custom_emoji_id} onChange={e => updateButton(i, 'icon_custom_emoji_id', e.target.value.replace(/\D/g, ''))} placeholder="Optional" />
            </div>
          </div>
          <div className="ibe-preview-row">
            <span className="ibe-preview-label">Preview:</span>
            <span className={`ibe-preview-chip${btn.style ? ` ibe-s-${btn.style}` : ''}`}>
              {btn.text || 'Button'}{btn.url ? ' ↗' : ''}
            </span>
          </div>
        </div>
      ))}
      <div className="ibe-bottom">
        <button type="button" className="ibe-add" onClick={addButton}><span>+</span> Add Button</button>
        <button type="button" className="ibe-json-toggle" onClick={() => setShowJson(p => !p)}>{showJson ? 'Hide JSON' : 'Raw JSON'}</button>
      </div>
      {showJson && (
        <div className="ibe-json-wrap">
          <textarea
            className="bm-inp bm-ta mono"
            rows={3}
            value={value || '[]'}
            onChange={e => {
              onChange(e.target.value);
              try {
                const p = JSON.parse(e.target.value);
                if (Array.isArray(p)) {
                  setButtons(p.filter((b: any) => b && typeof b === 'object').map((b: any) => ({
                    text: b.text || '',
                    url: b.url || '',
                    style: b.style || '',
                    icon_custom_emoji_id: b.icon_custom_emoji_id || '',
                  })));
                  setParseError('');
                }
              } catch { setParseError('Invalid JSON'); }
            }}
            placeholder='[]'
          />
          <span className="bm-hint">Advanced: edit raw JSON directly. Changes sync with the visual editor.</span>
        </div>
      )}
    </div>
  );
}

interface CatOption { id: number; name: string; }

function CategoryDurationSection({ statuses, setStatus }: { statuses: Record<string, any>; setStatus: (id: string, status: any) => void }) {
  const [cats, setCats] = useState<CatOption[]>([]);
  const [selectedCat, setSelectedCat] = useState<number>(0);
  const [catSettings, setCatSettings] = useState<Record<string, string>>({});
  const [catDefaults, setCatDefaults] = useState<Record<string, string>>({});
  const [catLoading, setCatLoading] = useState(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    apiGet('/categories').then((data: any) => {
      const list = (data || []).filter((c: any) => !c.is_hidden).map((c: any) => ({ id: c.id, name: c.name.replace(/\{[0-9]+\}/g, '').trim() }));
      setCats(list);
      if (list.length > 0) setSelectedCat(list[0].id);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedCat) return;
    setCatLoading(true);
    apiGet(`/bot-settings/category-duration/${selectedCat}`).then((data: any) => {
      setCatSettings(data.settings || {});
      setCatDefaults(data.defaults || {});
    }).catch(() => {}).finally(() => setCatLoading(false));
  }, [selectedCat]);

  const setVal = useCallback((k: string, v: string) => setCatSettings(p => ({ ...p, [k]: v })), []);

  const saveCatDur = useCallback(async () => {
    if (!selectedCat) return;
    setStatus('catdur', { type: 'saving' });
    try {
      await apiPut(`/bot-settings/category-duration/${selectedCat}`, { settings: catSettings });
      setStatus('catdur', { type: 'success', msg: 'Saved' });
    } catch (err: any) {
      setStatus('catdur', { type: 'error', msg: err.message || 'Save failed' });
    }
  }, [selectedCat, catSettings, setStatus]);

  const CAT_DUR_KEYS = ['tpl_duration_caption', 'msg_select_duration_title', 'msg_select_duration_sub', 'duration_link_buttons'];

  const resetCatDur = useCallback(async () => {
    if (!selectedCat) return;
    setStatus('catdur', { type: 'saving' });
    try {
      const empty: Record<string, string> = {};
      CAT_DUR_KEYS.forEach(k => { empty[k] = ''; });
      await apiPut(`/bot-settings/category-duration/${selectedCat}`, { settings: empty });
      setCatSettings({});
      setStatus('catdur', { type: 'success', msg: 'Reset to global defaults' });
    } catch (err: any) {
      setStatus('catdur', { type: 'error', msg: err.message || 'Reset failed' });
    }
  }, [selectedCat, setStatus]);

  const catName = cats.find(c => c.id === selectedCat)?.name || '';

  if (cats.length === 0) return null;

  return (
    <Section id="catdur" title="Category Duration Messages" subtitle="Per-category duration screen"
      icon="store"
      desc="Override the global duration screen messages for individual categories. Leave fields empty to use the global defaults from the Store section above."
      status={statuses.catdur}
      onSave={saveCatDur}
      onReset={resetCatDur}>
      <Field label="Category" hint="Select a category to configure its duration screen.">
        <select className="bm-inp" value={selectedCat} onChange={e => setSelectedCat(Number(e.target.value))}>
          {cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </Field>
      {catLoading ? (
        <div style={{ padding: '16px 0', textAlign: 'center', opacity: 0.5 }}>Loading...</div>
      ) : (
        <>
          <Sep />
          <TemplateEditor label={`Duration Caption Template — ${catName}`}
            hint="Layout of the duration selection screen for this category. Leave empty to use global default."
            value={catSettings.tpl_duration_caption || ''} onChange={(v: string) => setVal('tpl_duration_caption', v)}
            placeholders={DURATION_CAPTION_PH} validPh={DURATION_CAPTION_PH} sampleData={SAMPLE_DATA} rows={3} />
          <Sep />
          <Field label="Duration Title" hint="Custom title for this category's duration screen. Leave empty for global default.">
            <TInput value={catSettings.msg_select_duration_title || ''} onChange={v => setVal('msg_select_duration_title', v)} placeholder={catDefaults.msg_select_duration_title || ''} />
          </Field>
          <Field label="Duration Subtitle" hint="Custom subtitle for this category's duration screen. Leave empty for global default.">
            <TInput value={catSettings.msg_select_duration_sub || ''} onChange={v => setVal('msg_select_duration_sub', v)} placeholder={catDefaults.msg_select_duration_sub || ''} />
          </Field>
          <Sep />
          <Field label="Duration Link Buttons" hint="Add up to 4 URL buttons below the duration list for this category.">
            <LinkButtonsEditor value={catSettings.duration_link_buttons || ''} onChange={v => setVal('duration_link_buttons', v)} />
          </Field>
          {Object.values(catSettings).some(v => v && v.trim()) && (
            <div className="bm-info-box" style={{ marginTop: 12 }}>
              <strong>Custom overrides active</strong>
              <p>This category has custom duration settings. Clear all fields and save to revert to global defaults.</p>
            </div>
          )}
        </>
      )}
    </Section>
  );
}

export default function BotManage() {
  const [s, setS] = useState<Record<string, any>>({});
  const [defaults, setDefaults] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [statuses, setStatuses] = useState<Record<string, any>>({});
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const timerRefs = useRef<Record<string, any>>({});

  const load = async () => {
    setLoading(true);
    try {
      const data = await apiGet('/bot-settings');
      setS(data.settings || {});
      setDefaults(data.defaults || {});
    } catch {
      setStatuses(p => ({ ...p, _load: { type: 'error', msg: 'Failed to load settings' } }));
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const set = useCallback((key: string, val: any) => setS(p => ({ ...p, [key]: val })), []);

  const setStatus = useCallback((id: string, status: any) => {
    setStatuses(p => ({ ...p, [id]: status }));
    if (timerRefs.current[id]) clearTimeout(timerRefs.current[id]);
    if (status?.type === 'success') {
      timerRefs.current[id] = setTimeout(() => setStatuses(p => ({ ...p, [id]: null })), 4000);
    }
  }, []);

  const saveSection = useCallback(async (id: string, keys: string[], validateFn?: (values: any) => Record<string, string>) => {
    setFieldErrors({});
    if (validateFn) {
      const errors = validateFn(s);
      if (errors && Object.keys(errors).length > 0) {
        setFieldErrors(errors);
        setStatus(id, { type: 'error', msg: 'Fix errors above before saving' });
        return;
      }
    }
    const htmlFields = keys.filter(k =>
      !k.startsWith('cb_') && !k.startsWith('reply_') && !k.startsWith('order_') &&
      !k.endsWith('_style') && !k.endsWith('_emoji_id') &&
      k !== 'currency_symbol' && k !== 'payment_label_name' &&
      k !== 'start_preview_url' && k !== 'delivery_link_buttons' && !k.startsWith('btn_') &&
      !k.endsWith('_buttons') && k !== 'discount_broadcast_send_categories'
    );
    for (const k of htmlFields) {
      const val = s[k];
      if (val) {
        const he = validateTgHtml(val);
        if (he.length > 0) {
          setFieldErrors(prev => ({ ...prev, [k]: he[0] }));
          setStatus(id, { type: 'error', msg: 'Fix formatting errors before saving' });
          return;
        }
      }
    }
    const partial: Record<string, any> = {};
    for (const k of keys) partial[k] = s[k] !== undefined ? s[k] : (defaults[k] || '');
    setStatus(id, { type: 'saving' });
    try {
      await apiPut('/bot-settings', { settings: partial });
      setStatus(id, { type: 'success', msg: 'Saved' });
    } catch (err: any) {
      setStatus(id, { type: 'error', msg: err.message || 'Save failed' });
    }
  }, [s, defaults, setStatus]);

  const resetSection = useCallback((keys: string[]) => {
    const updates: Record<string, any> = {};
    for (const k of keys) updates[k] = defaults[k] || '';
    setS(p => ({ ...p, ...updates }));
  }, [defaults]);

  const validateEmoji = useCallback((keys: string[]) => (values: any) => {
    const errors: Record<string, string> = {};
    for (const k of keys) {
      const v = values[k];
      if (v && !/^\d{5,32}$/.test(v)) errors[k] = 'Must be a 5-32 digit numeric custom emoji ID';
    }
    return errors;
  }, []);

  const validateTimeout = useCallback((values: any) => {
    const n = parseInt(values.order_timeout_minutes);
    if (isNaN(n) || n < 1 || n > 1440) return { order_timeout_minutes: 'Enter a number between 1 and 1440' };
    return {};
  }, []);

  if (loading) {
    return (
      <div className="bm-page">
        <div className="bm-loading">
          <span className="bm-spin lg" />
          <span>Loading settings...</span>
        </div>
      </div>
    );
  }

  const welcomeKeys = ['welcome_greeting', 'tpl_welcome', 'bot_welcome_msg', 'bot_welcome_instruction', 'start_preview_url', 'msg_banned'];
  const storeKeys = ['tpl_store_header', 'bot_store_title', 'bot_store_subtitle', 'msg_categories_footer', 'bot_store_empty', 'msg_store_unavailable_title', 'tpl_duration_caption', 'msg_select_duration_title', 'msg_select_duration_sub', 'msg_discount_duration_banner'];
  const paymentKeys = ['tpl_payment_caption', 'tpl_reseller_caption', 'msg_no_keys_available', 'msg_key_taken', 'msg_upi_not_configured', 'msg_payment_qr_failed', 'msg_invalid_cat_dur', 'currency_symbol', 'payment_label_name'];
  const verifyKeys = ['msg_verify_not_received', 'msg_inactive_verify_btn', 'msg_order_not_found', 'msg_order_not_yours', 'msg_already_paid', 'msg_order_expired', 'msg_order_inactive', 'msg_verify_error', 'msg_verify_failed_title', 'msg_payment_not_received_title', 'msg_verify_generic_error', 'msg_fulfillment_pending', 'msg_payment_not_found', 'msg_payment_pending', 'msg_payment_failed', 'msg_amount_mismatch', 'msg_verification_issue', 'msg_gateway_error'];
  const deliveryKeys = ['msg_payment_verified_title', 'tpl_success_body', 'tpl_delivery_body', 'msg_key_label', 'bot_payment_success', 'msg_apk_caption', 'msg_apk_notice', 'delivery_link_buttons', 'bot_admin_sale_title', 'tpl_admin_sale'];
  const keysViewerKeys = ['bot_keys_title', 'bot_keys_reseller_title', 'tpl_keys_item', 'msg_no_keys_found_title', 'bot_keys_empty', 'msg_keys_load_error', 'msg_reference_label', 'btn_prev_page', 'btn_next_page'];
  const expiryKeys = ['msg_order_expired_notice', 'order_timeout_minutes'];
  const callbackKeys = ['cb_banned', 'cb_category_unavailable', 'cb_no_durations', 'cb_category_error', 'cb_generating_qr', 'cb_unknown_action', 'cb_order_not_found', 'cb_order_not_yours', 'cb_already_paid', 'cb_order_expired', 'cb_order_inactive', 'cb_verify_error'];
  const resellerKeys = ['msg_reseller_prompt', 'msg_invalid_code_format', 'msg_reseller_cancelled', 'msg_reseller_invalid_code', 'msg_reseller_code_expired', 'msg_reseller_usage_limit', 'msg_reseller_already_active_title', 'tpl_reseller_already_active', 'msg_reseller_activation_failed', 'msg_reseller_activated_title', 'msg_reseller_activated_footer', 'msg_reseller_switched_label', 'tpl_reseller_activated'];
  const replyKbKeys = ['bot_btn_my_keys', 'reply_mykeys_style', 'reply_mykeys_emoji_id', 'bot_btn_how_to', 'reply_howto_style', 'reply_howto_emoji_id'];
  const inlineKeys = ['bot_btn_categories', 'categories_btn_style', 'categories_btn_emoji_id', 'bot_btn_verify', 'verify_btn_style', 'verify_btn_emoji_id', 'bot_btn_copy_key', 'copy_key_btn_style', 'copy_key_btn_emoji_id', 'bot_btn_manage_keys', 'manage_keys_btn_style', 'manage_keys_btn_emoji_id'];
  const howtoKeys = ['bot_how_to_text'];

  return (
    <div className="bm-page">
      {statuses._load && <div className="bm-alert-bar">{statuses._load.msg}</div>}

      <div className="bm-group-label">Bot Settings</div>

      <Section id="welcome" title="Welcome & Start Flow" subtitle="First impression" icon="welcome" defaultOpen
        desc="Controls the first message users see when they start the bot."
        status={statuses.welcome}
        onSave={() => saveSection('welcome', welcomeKeys)}
        onReset={() => resetSection(welcomeKeys)}>
        <TemplateEditor label="Welcome Greeting" hint="Greeting line at the top of the welcome message. Supports {name_link} for clickable user mention, {first_name} for plain name, {brand} for store name. Custom emojis and HTML formatting supported." value={s.welcome_greeting} onChange={(v: string) => set('welcome_greeting', v)} placeholders={GREETING_PH} validPh={GREETING_PH} sampleData={SAMPLE_DATA} rows={2} />
        <Sep />
        <TemplateEditor label="Welcome Template" hint="Full welcome message structure. {welcome_greeting} inserts the greeting above. {welcome_title} and {welcome_body} pull from the fields below." value={s.tpl_welcome} onChange={(v: string) => set('tpl_welcome', v)} placeholders={WELCOME_PH} validPh={WELCOME_PH} sampleData={SAMPLE_DATA} rows={4} />
        <Sep />
        <Sub title="Welcome Content Parts">
          <Field label="Welcome Title" hint="Inserted as {welcome_title} in the template. Use {brand} for store name."><TInput value={s.bot_welcome_msg} onChange={v => set('bot_welcome_msg', v)} placeholder={defaults.bot_welcome_msg} /></Field>
          <Field label="Welcome Body" hint="Inserted as {welcome_body} in the template."><TInput value={s.bot_welcome_instruction} onChange={v => set('bot_welcome_instruction', v)} placeholder={defaults.bot_welcome_instruction} /></Field>
        </Sub>
        <Sep />
        <Field label="Welcome Banner Image" hint="Direct image URL for the welcome banner. Leave empty for none."><TInput value={s.start_preview_url} onChange={v => set('start_preview_url', v)} placeholder="https://example.com/banner.jpg" mono /></Field>
        <Sep />
        <Field label="Banned User Message" hint="Sent when a banned user tries to use the bot."><TInput value={s.msg_banned} onChange={v => set('msg_banned', v)} placeholder={defaults.msg_banned} /></Field>
      </Section>

      <Section id="store" title="Categories & Store" subtitle="Browsing experience" icon="store" desc="Controls the store browsing experience and category/duration selection screens." status={statuses.store} onSave={() => saveSection('store', storeKeys)} onReset={() => resetSection(storeKeys)}>
        <TemplateEditor label="Store Header Template" hint="Full layout of the categories screen. {store_title}, {store_subtitle}, {categories_footer} pull from fields below." value={s.tpl_store_header} onChange={(v: string) => set('tpl_store_header', v)} placeholders={STORE_HEADER_PH} validPh={STORE_HEADER_PH} sampleData={SAMPLE_DATA} rows={4} />
        <Sep />
        <Sub title="Store Content Parts">
          <Field label="Store Title" hint="Inserted as {store_title}. Use {brand} for store name."><TInput value={s.bot_store_title} onChange={v => set('bot_store_title', v)} placeholder={defaults.bot_store_title} /></Field>
          <Field label="Store Subtitle" hint="Inserted as {store_subtitle}."><TInput value={s.bot_store_subtitle} onChange={v => set('bot_store_subtitle', v)} placeholder={defaults.bot_store_subtitle} /></Field>
          <Field label="Categories Footer" hint="Inserted as {categories_footer}. HTML supported."><TInput value={s.msg_categories_footer} onChange={v => set('msg_categories_footer', v)} placeholder={defaults.msg_categories_footer} /></Field>
        </Sub>
        <Sep />
        <Field label="Store Unavailable Title" hint="Heading when all categories are out of stock. HTML supported."><TInput value={s.msg_store_unavailable_title} onChange={v => set('msg_store_unavailable_title', v)} placeholder={defaults.msg_store_unavailable_title} /></Field>
        <Field label="Empty Store Message" hint="Body text when no categories are available."><TArea value={s.bot_store_empty} onChange={v => set('bot_store_empty', v)} placeholder={defaults.bot_store_empty} /></Field>
        <Sep />
        <Sub title="Duration Selection">
          <TemplateEditor label="Duration Caption Template" hint="Layout of the duration selection screen. {duration_title} and {duration_sub} pull from fields below." value={s.tpl_duration_caption} onChange={(v: string) => set('tpl_duration_caption', v)} placeholders={DURATION_CAPTION_PH} validPh={DURATION_CAPTION_PH} sampleData={SAMPLE_DATA} rows={3} />
          <Field label="Duration Screen Title" hint="Inserted as {duration_title}. HTML supported."><TInput value={s.msg_select_duration_title} onChange={v => set('msg_select_duration_title', v)} placeholder={defaults.msg_select_duration_title} /></Field>
          <Field label="Duration Screen Subtitle" hint="Inserted as {duration_sub}."><TInput value={s.msg_select_duration_sub} onChange={v => set('msg_select_duration_sub', v)} placeholder={defaults.msg_select_duration_sub} /></Field>
          <Field label="Discount Banner" hint="Shown below duration buttons when a discount plan is active. {plan_name} = discount plan name. HTML supported."><TInput value={s.msg_discount_duration_banner} onChange={v => set('msg_discount_duration_banner', v)} placeholder={defaults.msg_discount_duration_banner} /></Field>
        </Sub>
      </Section>

      <CategoryDurationSection statuses={statuses} setStatus={setStatus} />

      <Section id="payment" title="Payment QR & Orders" subtitle="Payment templates" icon="payment" desc="Templates for payment QR messages and order error states. Tap placeholders to insert them." status={statuses.payment} onSave={() => saveSection('payment', paymentKeys)} onReset={() => resetSection(paymentKeys)}>
        <TemplateEditor label="Customer Payment Caption" hint="Caption sent with the QR code for regular customers." value={s.tpl_payment_caption} onChange={(v: string) => set('tpl_payment_caption', v)} placeholders={PAYMENT_PH} validPh={PAYMENT_PH} sampleData={SAMPLE_DATA} rows={8} />
        <Sep />
        <TemplateEditor label="Reseller Payment Caption" hint="Caption for reseller orders. Includes base_amount for original price." value={s.tpl_reseller_caption} onChange={(v: string) => set('tpl_reseller_caption', v)} placeholders={PAYMENT_PH} validPh={PAYMENT_PH} sampleData={SAMPLE_DATA} rows={8} />
        <Sep />
        <Sub title="Payment Settings">
          <Field label="Currency Symbol" hint="Displayed next to prices."><TInput value={s.currency_symbol} onChange={v => set('currency_symbol', v)} placeholder={defaults.currency_symbol} /></Field>
          <Field label="UPI Payee Name" hint="Merchant name on UPI screens."><TInput value={s.payment_label_name} onChange={v => set('payment_label_name', v)} placeholder="e.g. My Store Payments" /></Field>
        </Sub>
        <Sep />
        <Sub title="Payment Error Messages">
          <Field label="No Keys Available" hint="When selected option has no stock."><TInput value={s.msg_no_keys_available} onChange={v => set('msg_no_keys_available', v)} placeholder={defaults.msg_no_keys_available} /></Field>
          <Field label="Key Just Taken" hint="When another user claimed the last key."><TInput value={s.msg_key_taken} onChange={v => set('msg_key_taken', v)} placeholder={defaults.msg_key_taken} /></Field>
          <Field label="UPI Not Configured" hint="When UPI ID is missing."><TInput value={s.msg_upi_not_configured} onChange={v => set('msg_upi_not_configured', v)} placeholder={defaults.msg_upi_not_configured} /></Field>
          <Field label="QR Generation Failed" hint="When QR fails to send."><TInput value={s.msg_payment_qr_failed} onChange={v => set('msg_payment_qr_failed', v)} placeholder={defaults.msg_payment_qr_failed} /></Field>
          <Field label="Invalid Selection" hint="When category or duration is invalid."><TInput value={s.msg_invalid_cat_dur} onChange={v => set('msg_invalid_cat_dur', v)} placeholder={defaults.msg_invalid_cat_dur} /></Field>
        </Sub>
      </Section>

      <Section id="verify" title="Verification & Errors" subtitle="Payment checks" icon="verify" desc="Messages during and after payment verification. HTML supported where noted." status={statuses.verify} onSave={() => saveSection('verify', verifyKeys)} onReset={() => resetSection(verifyKeys)}>
        <TemplateEditor label="Payment Not Received Alert" hint="Popup when Verify is tapped but no payment found. Supports {first_name}." value={s.msg_verify_not_received} onChange={(v: string) => set('msg_verify_not_received', v)} placeholders={VERIFY_PH} validPh={VERIFY_PH} sampleData={SAMPLE_DATA} rows={3} />
        <Field label="Inactive Verify Button" hint="Popup for old/expired verify buttons."><TInput value={s.msg_inactive_verify_btn} onChange={v => set('msg_inactive_verify_btn', v)} placeholder={defaults.msg_inactive_verify_btn} /></Field>
        <Sep />
        <Sub title="Order Status Messages" hint="All messages below support: {first_name}, {username}, {name_link}, {brand}, {order_id}, {txn_ref}, {category}, {duration}, {currency}, {amount}, {status}.">
          <Field label="Order Not Found" hint="Supports all order variables."><TArea value={s.msg_order_not_found} onChange={v => set('msg_order_not_found', v)} placeholder={defaults.msg_order_not_found} rows={2} /></Field>
          <Field label="Order Not Yours" hint="Supports all order variables."><TInput value={s.msg_order_not_yours} onChange={v => set('msg_order_not_yours', v)} placeholder={defaults.msg_order_not_yours} /></Field>
          <Field label="Already Paid" hint="Supports all order variables."><TInput value={s.msg_already_paid} onChange={v => set('msg_already_paid', v)} placeholder={defaults.msg_already_paid} /></Field>
          <Field label="Order Expired" hint="Supports all order variables."><TArea value={s.msg_order_expired} onChange={v => set('msg_order_expired', v)} placeholder={defaults.msg_order_expired} rows={2} /></Field>
          <Field label="Order Inactive" hint="Supports all order variables."><TInput value={s.msg_order_inactive} onChange={v => set('msg_order_inactive', v)} placeholder={defaults.msg_order_inactive} /></Field>
        </Sub>
        <Sep />
        <Sub title="Gateway Error Messages" hint="All messages below support: {first_name}, {username}, {name_link}, {brand}, {order_id}, {txn_ref}, {category}, {duration}, {currency}, {amount}, {status}.">
          <Field label="Verification Error" hint="Supports all order variables."><TArea value={s.msg_verify_error} onChange={v => set('msg_verify_error', v)} placeholder={defaults.msg_verify_error} rows={2} /></Field>
          <Field label="Verification Failed Title" hint="Supports all order variables including {currency}{amount}."><TInput value={s.msg_verify_failed_title} onChange={v => set('msg_verify_failed_title', v)} placeholder={defaults.msg_verify_failed_title} /></Field>
          <Field label="Payment Not Received Title" hint="Supports all order variables including {currency}{amount}."><TInput value={s.msg_payment_not_received_title} onChange={v => set('msg_payment_not_received_title', v)} placeholder={defaults.msg_payment_not_received_title} /></Field>
          <Field label="Generic Verification Error" hint="Supports all order variables."><TArea value={s.msg_verify_generic_error} onChange={v => set('msg_verify_generic_error', v)} placeholder={defaults.msg_verify_generic_error} rows={2} /></Field>
          <Field label="Fulfillment Pending" hint="Shown when payment is verified but key delivery is being processed. Supports all order variables."><TArea value={s.msg_fulfillment_pending} onChange={v => set('msg_fulfillment_pending', v)} placeholder={defaults.msg_fulfillment_pending} rows={2} /></Field>
        </Sub>
        <Sep />
        <Sub title="Verification Result Messages" hint="All messages below support: {first_name}, {username}, {name_link}, {brand}, {order_id}, {txn_ref}, {category}, {duration}, {currency}, {amount}, {status}.">
          <Field label="Payment Not Found" hint="Shown when no payment record exists. Use {currency}{amount} for formatted price."><TArea value={s.msg_payment_not_found} onChange={v => set('msg_payment_not_found', v)} placeholder={defaults.msg_payment_not_found} rows={2} /></Field>
          <Field label="Payment Pending" hint="Shown when payment is still being processed. Use {currency}{amount} for formatted price."><TArea value={s.msg_payment_pending} onChange={v => set('msg_payment_pending', v)} placeholder={defaults.msg_payment_pending} rows={2} /></Field>
          <Field label="Payment Failed" hint="Shown when payment transaction failed. Use {currency}{amount} for formatted price."><TArea value={s.msg_payment_failed} onChange={v => set('msg_payment_failed', v)} placeholder={defaults.msg_payment_failed} rows={2} /></Field>
          <Field label="Amount Mismatch" hint="Shown when paid amount does not match. Use {currency}{amount} for formatted price."><TArea value={s.msg_amount_mismatch} onChange={v => set('msg_amount_mismatch', v)} placeholder={defaults.msg_amount_mismatch} rows={2} /></Field>
          <Field label="Verification Issue" hint="Generic fallback for other failures. Use {currency}{amount} for formatted price."><TArea value={s.msg_verification_issue} onChange={v => set('msg_verification_issue', v)} placeholder={defaults.msg_verification_issue} rows={2} /></Field>
          <Field label="Gateway Error" hint="Shown when payment gateway is unreachable. Use {currency}{amount} for formatted price."><TArea value={s.msg_gateway_error} onChange={v => set('msg_gateway_error', v)} placeholder={defaults.msg_gateway_error} rows={2} /></Field>
        </Sub>
      </Section>

      <Section id="delivery" title="Success & Key Delivery" subtitle="Post-payment" icon="delivery" desc="Full template for the key delivery message sent after successful payment. The entire message is controlled by the template below." status={statuses.delivery} onSave={() => saveSection('delivery', deliveryKeys)} onReset={() => resetSection(deliveryKeys)}>
        <TemplateEditor label="Delivery Body Template" hint="Main delivery body with category, duration, order ID, and key. Supports {category}, {duration}, {order_id}, {currency}, {amount}, {key_value}." value={s.tpl_delivery_body} onChange={(v: string) => set('tpl_delivery_body', v)} placeholders={DELIVERY_BODY_PH} validPh={DELIVERY_BODY_PH} sampleData={SAMPLE_DATA} rows={5} />
        <TemplateEditor label="Legacy Full Delivery Template" hint="Full delivery message layout. {verified_title}, {key_label}, {apk_notice}, and {footer} pull from the fields below. {apk_notice} is empty when no APK is sent. Empty sections collapse automatically." value={s.tpl_success_body} onChange={(v: string) => set('tpl_success_body', v)} placeholders={SUCCESS_BODY_PH} validPh={SUCCESS_BODY_PH} sampleData={SAMPLE_DATA} rows={10} />
        <Sep />
        <Sub title="Delivery Content Parts">
          <Field label="Verified Title" hint="Inserted as {verified_title} in the template. Supports {currency}, {amount}, {category}, {duration}, {order_id}, {txn_ref}, {first_name}, {username}, {brand}. HTML supported."><TInput value={s.msg_payment_verified_title} onChange={v => set('msg_payment_verified_title', v)} placeholder={defaults.msg_payment_verified_title} /></Field>
          <Field label="Key Label" hint="Inserted as {key_label} above the key code. Supports {currency}, {amount}, {category}, {duration}, {order_id}, {brand}. HTML supported."><TInput value={s.msg_key_label} onChange={v => set('msg_key_label', v)} placeholder={defaults.msg_key_label} /></Field>
          <Field label="Success Footer" hint="Inserted as {footer} at the bottom. Supports {currency}, {amount}, {category}, {duration}, {brand}, {first_name}."><TInput value={s.bot_payment_success} onChange={v => set('bot_payment_success', v)} placeholder={defaults.bot_payment_success} /></Field>
        </Sub>
        <Sep />
        <Sub title="Inline Link Buttons">
          <Field label="Delivery Buttons" hint="Add up to 4 link buttons below the copy-key button. Each button supports text, URL, custom emoji icon, and style (Default/Blue/Green/Red)."><LinkButtonsEditor value={s.delivery_link_buttons} onChange={v => set('delivery_link_buttons', v)} /></Field>
        </Sub>
        <Sep />
        <Sub title="APK Delivery">
          <TemplateEditor label="APK File Caption" hint="Caption sent with the application file (separate from key message). Supports {category}." value={s.msg_apk_caption} onChange={(v: string) => set('msg_apk_caption', v)} placeholders={DELIVERY_PH} validPh={DELIVERY_PH} sampleData={SAMPLE_DATA} rows={2} />
          <Field label="APK Sent Notice" hint="Inserted as {apk_notice} in the delivery template when an APK is sent. Supports {category}, {duration}, {currency}, {amount}, {brand}. Leave empty to show nothing."><TInput value={s.msg_apk_notice} onChange={v => set('msg_apk_notice', v)} placeholder={defaults.msg_apk_notice} /></Field>
        </Sub>
        <Sep />
        <Sub title="Admin Sale Notification">
          <Field label="Sale Title" hint="Title label for admin sale messages."><TInput value={s.bot_admin_sale_title} onChange={v => set('bot_admin_sale_title', v)} placeholder={defaults.bot_admin_sale_title} /></Field>
          <TemplateEditor label="Admin Sale Template" hint="Full template for admin sale notification. {admin_sale_title} is the title above. {buyer_label} is the user's name/username." value={s.tpl_admin_sale} onChange={(v: string) => set('tpl_admin_sale', v)} placeholders={ADMIN_SALE_PH} validPh={ADMIN_SALE_PH} sampleData={SAMPLE_DATA} rows={5} />
        </Sub>
      </Section>

      <Section id="keys" title="Purchased Keys Viewer" subtitle="User keys screen" icon="keys" desc="Controls the My Purchased Keys screen including the full key card layout." status={statuses.keys} onSave={() => saveSection('keys', keysViewerKeys)} onReset={() => resetSection(keysViewerKeys)}>
        <Field label="Keys Section Title" hint="Heading for regular users. HTML supported."><TInput value={s.bot_keys_title} onChange={v => set('bot_keys_title', v)} placeholder={defaults.bot_keys_title} /></Field>
        <Field label="Reseller Keys Title" hint="Heading for resellers. HTML supported."><TInput value={s.bot_keys_reseller_title} onChange={v => set('bot_keys_reseller_title', v)} placeholder={defaults.bot_keys_reseller_title} /></Field>
        <Sep />
        <TemplateEditor label="Key Item Body Template" hint="Full layout of each purchased key card. {reference_section} appears only when a transaction reference exists. All other placeholders are always available." value={s.tpl_keys_item} onChange={(v: string) => set('tpl_keys_item', v)} placeholders={KEYS_ITEM_PH} validPh={KEYS_ITEM_PH} sampleData={SAMPLE_DATA} rows={10} />
        <Sep />
        <Sub title="Labels"><Field label="Reference Label" hint="Label for the transaction reference line in each key card (e.g. Reference)."><TInput value={s.msg_reference_label} onChange={v => set('msg_reference_label', v)} placeholder={defaults.msg_reference_label} /></Field></Sub>
        <Sep />
        <Sub title="Empty State">
          <Field label="No Keys Found Title" hint="When user has no purchases."><TInput value={s.msg_no_keys_found_title} onChange={v => set('msg_no_keys_found_title', v)} placeholder={defaults.msg_no_keys_found_title} /></Field>
          <Field label="No Keys Body" hint="Body text below the heading."><TInput value={s.bot_keys_empty} onChange={v => set('bot_keys_empty', v)} placeholder={defaults.bot_keys_empty} /></Field>
          <Field label="Keys Load Error" hint="Shown when keys data cannot be loaded."><TInput value={s.msg_keys_load_error} onChange={v => set('msg_keys_load_error', v)} placeholder={defaults.msg_keys_load_error} /></Field>
        </Sub>
        <Sep />
        <Sub title="Pagination Buttons">
          <Field label="Previous Page"><TInput value={s.btn_prev_page} onChange={v => set('btn_prev_page', v)} placeholder={defaults.btn_prev_page} /></Field>
          <Field label="Next Page"><TInput value={s.btn_next_page} onChange={v => set('btn_next_page', v)} placeholder={defaults.btn_next_page} /></Field>
        </Sub>
      </Section>

      <Section id="expiry" title="Order Expiry" subtitle="Timeout settings" icon="expiry" desc="Expiry notice sent when a pending order times out." status={statuses.expiry} onSave={() => saveSection('expiry', expiryKeys, validateTimeout)} onReset={() => resetSection(expiryKeys)}>
        <Field label="Order Expiry Notice" hint="Message when order expires. Supports {first_name}, {username}, {name_link}, {brand}, {order_id}, {txn_ref}, {category}, {duration}, {currency}, {amount}. HTML supported."><TArea value={s.msg_order_expired_notice} onChange={v => set('msg_order_expired_notice', v)} placeholder={defaults.msg_order_expired_notice} rows={4} /></Field>
        <Field label="Expiry Timeout (minutes)" hint="Between 1 and 1440 (24 hours)." error={fieldErrors.order_timeout_minutes}><NumInput value={s.order_timeout_minutes} onChange={v => set('order_timeout_minutes', v)} min={1} max={1440} error={!!fieldErrors.order_timeout_minutes} /></Field>
      </Section>

      <Section id="callbacks" title="Callback Alerts" subtitle="Popup notifications" icon="callbacks" desc="Small popup notifications when users tap buttons. Limited to 200 characters, no HTML." status={statuses.callbacks} onSave={() => saveSection('callbacks', callbackKeys)} onReset={() => resetSection(callbackKeys)}>
        <Sub title="Browsing Alerts">
          <Field label="User Banned"><TInput value={s.cb_banned} onChange={v => set('cb_banned', v)} placeholder={defaults.cb_banned} /></Field>
          <Field label="Category Unavailable"><TInput value={s.cb_category_unavailable} onChange={v => set('cb_category_unavailable', v)} placeholder={defaults.cb_category_unavailable} /></Field>
          <Field label="No Durations"><TInput value={s.cb_no_durations} onChange={v => set('cb_no_durations', v)} placeholder={defaults.cb_no_durations} /></Field>
          <Field label="Category Error"><TInput value={s.cb_category_error} onChange={v => set('cb_category_error', v)} placeholder={defaults.cb_category_error} /></Field>
          <Field label="Generating QR"><TInput value={s.cb_generating_qr} onChange={v => set('cb_generating_qr', v)} placeholder={defaults.cb_generating_qr} /></Field>
          <Field label="Unknown Action"><TInput value={s.cb_unknown_action} onChange={v => set('cb_unknown_action', v)} placeholder={defaults.cb_unknown_action} /></Field>
        </Sub>
        <Sub title="Verification Alerts">
          <Field label="Order Not Found"><TInput value={s.cb_order_not_found} onChange={v => set('cb_order_not_found', v)} placeholder={defaults.cb_order_not_found} /></Field>
          <Field label="Order Not Yours"><TInput value={s.cb_order_not_yours} onChange={v => set('cb_order_not_yours', v)} placeholder={defaults.cb_order_not_yours} /></Field>
          <Field label="Already Paid"><TInput value={s.cb_already_paid} onChange={v => set('cb_already_paid', v)} placeholder={defaults.cb_already_paid} /></Field>
          <Field label="Order Expired"><TInput value={s.cb_order_expired} onChange={v => set('cb_order_expired', v)} placeholder={defaults.cb_order_expired} /></Field>
          <Field label="Order Inactive"><TInput value={s.cb_order_inactive} onChange={v => set('cb_order_inactive', v)} placeholder={defaults.cb_order_inactive} /></Field>
          <Field label="Verification Error"><TInput value={s.cb_verify_error} onChange={v => set('cb_verify_error', v)} placeholder={defaults.cb_verify_error} /></Field>
        </Sub>
      </Section>

      <Section id="reseller" title="Reseller Messages" subtitle="Activation flow" icon="reseller" desc="Messages for the reseller activation flow." status={statuses.reseller} onSave={() => saveSection('reseller', resellerKeys)} onReset={() => resetSection(resellerKeys)}>
        <Field label="Reseller Activation Prompt" hint="Shown when user sends /level. HTML supported."><TArea value={s.msg_reseller_prompt} onChange={v => set('msg_reseller_prompt', v)} placeholder={defaults.msg_reseller_prompt} rows={4} /></Field>
        <Field label="Invalid Code Format" hint="For incorrect code format. HTML supported."><TArea value={s.msg_invalid_code_format} onChange={v => set('msg_invalid_code_format', v)} placeholder={defaults.msg_invalid_code_format} rows={2} /></Field>
        <Field label="Activation Cancelled" hint="Shown when user sends /cancel during code entry."><TInput value={s.msg_reseller_cancelled} onChange={v => set('msg_reseller_cancelled', v)} placeholder={defaults.msg_reseller_cancelled} /></Field>
        <Sep />
        <Sub title="Error Messages">
          <Field label="Invalid Reseller Code" hint="When the entered code does not exist."><TArea value={s.msg_reseller_invalid_code} onChange={v => set('msg_reseller_invalid_code', v)} placeholder={defaults.msg_reseller_invalid_code} rows={2} /></Field>
          <Field label="Code Expired" hint="When the reseller code has expired."><TArea value={s.msg_reseller_code_expired} onChange={v => set('msg_reseller_code_expired', v)} placeholder={defaults.msg_reseller_code_expired} rows={2} /></Field>
          <Field label="Usage Limit Reached" hint="When the code has reached its maximum allowed users."><TArea value={s.msg_reseller_usage_limit} onChange={v => set('msg_reseller_usage_limit', v)} placeholder={defaults.msg_reseller_usage_limit} rows={2} /></Field>
          <Field label="Activation Failed" hint="When activation encounters a database error."><TArea value={s.msg_reseller_activation_failed} onChange={v => set('msg_reseller_activation_failed', v)} placeholder={defaults.msg_reseller_activation_failed} rows={2} /></Field>
        </Sub>
        <Sep />
        <Sub title="Already Active Message">
          <Field label="Already Active Title" hint="Title when user already has this code active. Inserted as {reseller_title} in the template below."><TInput value={s.msg_reseller_already_active_title} onChange={v => set('msg_reseller_already_active_title', v)} placeholder={defaults.msg_reseller_already_active_title} /></Field>
          <TemplateEditor label="Already Active Body Template" hint="Full body when the user already has this reseller code. {reseller_title} pulls from the title above. {offer_summary} is auto-generated from pricing rules." value={s.tpl_reseller_already_active} onChange={(v: string) => set('tpl_reseller_already_active', v)} placeholders={RESELLER_ALREADY_ACTIVE_PH} validPh={RESELLER_ALREADY_ACTIVE_PH} sampleData={SAMPLE_DATA} rows={5} />
        </Sub>
        <Sep />
        <Sub title="Activation Success Message">
          <Field label="Activation Success Title" hint="Title when reseller code is activated. Inserted as {reseller_title}."><TInput value={s.msg_reseller_activated_title} onChange={v => set('msg_reseller_activated_title', v)} placeholder={defaults.msg_reseller_activated_title} /></Field>
          <Field label="Activation Success Footer" hint="Inserted as {reseller_footer}."><TInput value={s.msg_reseller_activated_footer} onChange={v => set('msg_reseller_activated_footer', v)} placeholder={defaults.msg_reseller_activated_footer} /></Field>
          <Field label="Code Switched Label" hint="Label shown when user had a previous code that was replaced (e.g. Previous Code Replaced)."><TInput value={s.msg_reseller_switched_label} onChange={v => set('msg_reseller_switched_label', v)} placeholder={defaults.msg_reseller_switched_label} /></Field>
          <TemplateEditor label="Activation Success Body Template" hint="Full body for successful activation. {switched_section} shows previous code if replaced. {offer_summary} is auto-generated from pricing rules." value={s.tpl_reseller_activated} onChange={(v: string) => set('tpl_reseller_activated', v)} placeholders={RESELLER_ACTIVATED_PH} validPh={RESELLER_ACTIVATED_PH} sampleData={SAMPLE_DATA} rows={8} />
        </Sub>
      </Section>

      <Section id="reply_kb" title="Reply Keyboard" subtitle="Persistent buttons" icon="keyboard" desc="Persistent buttons at the bottom of the chat. Style and emoji require Bot API 9.0+." status={statuses.reply_kb} onSave={() => saveSection('reply_kb', replyKbKeys, validateEmoji(['reply_mykeys_emoji_id', 'reply_howto_emoji_id']))} onReset={() => resetSection(replyKbKeys)}>
        <Sub title="My Purchased Keys Button">
          <Field label="Button Text"><TInput value={s.bot_btn_my_keys} onChange={v => set('bot_btn_my_keys', v)} placeholder={defaults.bot_btn_my_keys} /></Field>
          <Field label="Button Style"><StylePicker value={s.reply_mykeys_style || ''} onChange={v => set('reply_mykeys_style', v)} /></Field>
          <Field label="Custom Emoji ID" hint="5-32 digit numeric ID." error={fieldErrors.reply_mykeys_emoji_id}><EmojiInput value={s.reply_mykeys_emoji_id} onChange={v => set('reply_mykeys_emoji_id', v)} error={!!fieldErrors.reply_mykeys_emoji_id} /></Field>
        </Sub>
        <Sub title="How to Purchase Button">
          <Field label="Button Text"><TInput value={s.bot_btn_how_to} onChange={v => set('bot_btn_how_to', v)} placeholder={defaults.bot_btn_how_to} /></Field>
          <Field label="Button Style"><StylePicker value={s.reply_howto_style || ''} onChange={v => set('reply_howto_style', v)} /></Field>
          <Field label="Custom Emoji ID" error={fieldErrors.reply_howto_emoji_id}><EmojiInput value={s.reply_howto_emoji_id} onChange={v => set('reply_howto_emoji_id', v)} error={!!fieldErrors.reply_howto_emoji_id} /></Field>
        </Sub>
      </Section>

      <Section id="inline" title="Inline Buttons" subtitle="In-message buttons" icon="buttons" desc="Inline buttons inside chat messages. Each button supports text, style, and custom emoji icon." status={statuses.inline} onSave={() => saveSection('inline', inlineKeys, validateEmoji(['categories_btn_emoji_id', 'verify_btn_emoji_id', 'copy_key_btn_emoji_id', 'manage_keys_btn_emoji_id']))} onReset={() => resetSection(inlineKeys)}>
        <Sub title="Categories Menu Button">
          <Field label="Button Text" hint="Back-to-categories navigation button."><TInput value={s.bot_btn_categories} onChange={v => set('bot_btn_categories', v)} placeholder={defaults.bot_btn_categories} /></Field>
          <Field label="Button Style"><StylePicker value={s.categories_btn_style || ''} onChange={v => set('categories_btn_style', v)} /></Field>
          <Field label="Custom Emoji ID" error={fieldErrors.categories_btn_emoji_id}><EmojiInput value={s.categories_btn_emoji_id} onChange={v => set('categories_btn_emoji_id', v)} error={!!fieldErrors.categories_btn_emoji_id} /></Field>
        </Sub>
        <Sub title="Verify Payment Button">
          <Field label="Button Text" hint="Button on the payment QR message."><TInput value={s.bot_btn_verify} onChange={v => set('bot_btn_verify', v)} placeholder={defaults.bot_btn_verify} /></Field>
          <Field label="Button Style"><StylePicker value={s.verify_btn_style || ''} onChange={v => set('verify_btn_style', v)} /></Field>
          <Field label="Custom Emoji ID" error={fieldErrors.verify_btn_emoji_id}><EmojiInput value={s.verify_btn_emoji_id} onChange={v => set('verify_btn_emoji_id', v)} error={!!fieldErrors.verify_btn_emoji_id} /></Field>
        </Sub>
        <Sub title="Copy Key Button">
          <Field label="Button Text" hint="Copies the product key to clipboard."><TInput value={s.bot_btn_copy_key} onChange={v => set('bot_btn_copy_key', v)} placeholder={defaults.bot_btn_copy_key} /></Field>
          <Field label="Button Style"><StylePicker value={s.copy_key_btn_style || ''} onChange={v => set('copy_key_btn_style', v)} /></Field>
          <Field label="Custom Emoji ID" error={fieldErrors.copy_key_btn_emoji_id}><EmojiInput value={s.copy_key_btn_emoji_id} onChange={v => set('copy_key_btn_emoji_id', v)} error={!!fieldErrors.copy_key_btn_emoji_id} /></Field>
        </Sub>
        <Sub title="Manage Keys Button">
          <Field label="Button Text" hint="Opens the keys portal."><TInput value={s.bot_btn_manage_keys} onChange={v => set('bot_btn_manage_keys', v)} placeholder={defaults.bot_btn_manage_keys} /></Field>
          <Field label="Button Style"><StylePicker value={s.manage_keys_btn_style || ''} onChange={v => set('manage_keys_btn_style', v)} /></Field>
          <Field label="Custom Emoji ID" error={fieldErrors.manage_keys_btn_emoji_id}><EmojiInput value={s.manage_keys_btn_emoji_id} onChange={v => set('manage_keys_btn_emoji_id', v)} error={!!fieldErrors.manage_keys_btn_emoji_id} /></Field>
        </Sub>
      </Section>

      <Section id="howto" title="How to Purchase" subtitle="Guide message" icon="howto" desc="Complete guide shown when users tap How to Purchase." status={statuses.howto} onSave={() => saveSection('howto', howtoKeys)} onReset={() => resetSection(howtoKeys)}>
        <Field label="How to Purchase Text" hint="Step-by-step guide. HTML tags supported."><TArea value={s.bot_how_to_text} onChange={v => set('bot_how_to_text', v)} placeholder={defaults.bot_how_to_text} rows={8} /></Field>
      </Section>

      <div className="bm-ref-divider">
        <span>Reference & Help</span>
      </div>

      <FormatHelperSection />
      <PlaceholderRefSection />
      <EmojiGuideSection />
    </div>
  );
}
