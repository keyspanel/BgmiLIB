import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';

interface Provider {
  id: number;
  name: string;
  base_url: string;
  token: string | null;
  is_active: boolean;
  created_at: string;
  rules_count: number;
  fulfillments_7d: number;
  failures_7d: number;
  last_tested_at: string | null;
  last_test_ok: boolean | null;
}

interface Rule {
  id: number;
  category_id: number;
  duration_id: number;
  source_type: string;
  api_provider_id: number | null;
  api_game_value: string;
  api_duration_value: string;
  api_device_value: string;
  api_currency_value: string;
  is_active: boolean;
  last_test_result: string | null;
  last_test_success: boolean | null;
  last_test_at: string | null;
  created_at: string;
  updated_at: string;
  category_name: string;
  duration_name: string;
  provider_name: string | null;
  provider_base_url: string | null;
}

interface Stats {
  total_rules: number;
  active_rules: number;
  manual_rules: number;
  api_rules: number;
  hybrid_rules: number;
  total_providers: number;
  active_providers: number;
  fulfilled_24h: number;
  failed_24h: number;
  fallback_24h: number;
  total_24h: number;
  success_rate_7d: number;
  pending_review: number;
  open_issues: number;
  recovered_today: number;
  failed_sends: number;
  avg_recovery_min: number | null;
}

interface Issue {
  id: number;
  order_id: number;
  user_id: number;
  category_id: number;
  duration_id: number;
  source_rule_id: number | null;
  provider_id: number | null;
  source_type: string;
  failure_reason: string;
  failure_code: string | null;
  payload_snapshot: any;
  status: string;
  recovery_key: string | null;
  recovery_note: string | null;
  created_at: string;
  updated_at: string;
  resolved_at: string | null;
  resolved_by: string | null;
  send_attempts: number;
  last_send_error: string | null;
  txn_ref: string | null;
  order_amount: number;
  order_status: string;
  category_name: string;
  duration_name: string;
  delivered_at: string | null;
  telegram_id: string;
  username: string;
  first_name: string;
  last_name: string;
  profile_photo_url: string | null;
  provider_name: string | null;
}

type Tab = 'rules' | 'providers' | 'test' | 'fulfillment' | 'audit' | 'issues';

const cleanName = (raw: string) => (raw || '').replace(/\{\d{5,32}\}/g, '').trim();
const fmtTime = (iso: string | null) => {
  if (!iso) return null;
  const d = new Date(iso);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`;
  return d.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
};
const fmtDate = (iso: string | null) => iso ? new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) : '';

const sourceLabel = (t: string) => t === 'manual' ? 'Manual' : t === 'api' ? 'API' : t === 'api_and_manual' ? 'Hybrid' : t;
const sourceClass = (t: string) => t === 'manual' ? 'manual' : t === 'api' ? 'api' : 'hybrid';

const SvgPlus = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
const SvgPlay = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const SvgEdit = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>;
const SvgTrash = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>;
const SvgCopy = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>;
const SvgChevron = ({ open }: { open: boolean }) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}><polyline points="6 9 12 15 18 9"/></svg>;
const SvgRefresh = () => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>;
const SvgSearch = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
const SvgX = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;
const SvgServer = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r="1" fill="currentColor"/><circle cx="6" cy="18" r="1" fill="currentColor"/></svg>;
const SvgShield = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>;
const SvgActivity = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>;
const SvgClock = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>;
const SvgBox = () => <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>;
const SvgAlert = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>;
const SvgSend = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>;

function copyText(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

export default function SourceConfig() {
  const [tab, setTab] = useState<Tab>('rules');
  const [rules, setRules] = useState<Rule[]>([]);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [durations, setDurations] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [logsTotal, setLogsTotal] = useState(0);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [auditTotal, setAuditTotal] = useState(0);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [showRuleForm, setShowRuleForm] = useState(false);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [ruleForm, setRuleForm] = useState({
    category_id: '', duration_id: '', source_type: 'manual',
    api_provider_id: '', api_game_value: '', api_duration_value: '',
    api_device_value: '', api_currency_value: '', is_active: true,
  });
  const [catDurations, setCatDurations] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);

  const [showProvForm, setShowProvForm] = useState(false);
  const [editingProv, setEditingProv] = useState<Provider | null>(null);
  const [provForm, setProvForm] = useState({ name: '', base_url: '', token: '', is_active: true });

  const [testResult, setTestResult] = useState<any>(null);
  const [testing, setTesting] = useState(false);
  const [testForm, setTestForm] = useState({
    provider_id: '', api_game_value: '', api_duration_value: '',
    api_device_value: '', api_currency_value: '',
  });

  const [expandedRule, setExpandedRule] = useState<number | null>(null);
  const [expandedLog, setExpandedLog] = useState<number | null>(null);
  const [expandedAudit, setExpandedAudit] = useState<number | null>(null);
  const [rulesSearch, setRulesSearch] = useState('');
  const [rulesFilterType, setRulesFilterType] = useState('');
  const [rulesFilterStatus, setRulesFilterStatus] = useState('');
  const [logsFilter, setLogsFilter] = useState({ source_type: '', result: '', provider_id: '' });
  const [auditFilter, setAuditFilter] = useState({ action_type: '', target_type: '' });
  const [rawExpanded, setRawExpanded] = useState(false);

  const [issues, setIssues] = useState<Issue[]>([]);
  const [issuesTotal, setIssuesTotal] = useState(0);
  const [issuesFilter, setIssuesFilter] = useState({ status: 'open' });
  const [expandedIssue, setExpandedIssue] = useState<number | null>(null);
  const [sendingIssue, setSendingIssue] = useState<number | null>(null);
  const [issueKeyInputs, setIssueKeyInputs] = useState<Record<number, string>>({});
  const [issueNoteInputs, setIssueNoteInputs] = useState<Record<number, string>>({});

  const [sseStatus, setSseStatus] = useState<'connecting' | 'live' | 'offline'>('offline');
  const [lastSseEvent, setLastSseEvent] = useState<string | null>(null);
  const sseRef = useRef<EventSource | null>(null);

  const [loadError, setLoadError] = useState('');
  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(''), 3500); };

  const loadRules = useCallback(() => apiGet('/source-rules/rules').then(setRules).catch(() => { setLoadError('Failed to load rules'); }), []);
  const loadProviders = useCallback(() => apiGet('/source-rules/providers').then(setProviders).catch(() => { setLoadError('Failed to load providers'); }), []);
  const loadCategories = useCallback(() => apiGet('/categories').then(setCategories).catch(() => {}), []);
  const loadDurations = useCallback(() => apiGet('/durations').then(setDurations).catch(() => {}), []);
  const loadStats = useCallback(() => apiGet('/source-rules/stats').then(setStats).catch(() => {}), []);
  const loadLogs = useCallback((filters?: any) => {
    const p = new URLSearchParams({ limit: '100' });
    const f = filters || logsFilter;
    if (f.source_type) p.set('source_type', f.source_type);
    if (f.result) p.set('result', f.result);
    if (f.provider_id) p.set('provider_id', f.provider_id);
    apiGet(`/source-rules/logs?${p}`).then(d => { setLogs(d.logs || []); setLogsTotal(d.total || 0); }).catch(() => {});
  }, [logsFilter]);
  const loadAudit = useCallback((filters?: any) => {
    const p = new URLSearchParams({ limit: '100' });
    const f = filters || auditFilter;
    if (f.action_type) p.set('action_type', f.action_type);
    if (f.target_type) p.set('target_type', f.target_type);
    apiGet(`/source-rules/audit?${p}`).then(d => { setAuditLogs(d.logs || []); setAuditTotal(d.total || 0); }).catch(() => {});
  }, [auditFilter]);
  const loadIssues = useCallback((filters?: any) => {
    const p = new URLSearchParams({ limit: '100' });
    const f = filters || issuesFilter;
    if (f.status) p.set('status', f.status);
    apiGet(`/source-rules/issues?${p}`).then(d => { setIssues(d.issues || []); setIssuesTotal(d.total || 0); }).catch(() => {});
  }, [issuesFilter]);

  const sendRecoveryKey = async (issue: Issue) => {
    const key = (issueKeyInputs[issue.id] || '').trim();
    if (!key) { flash('Enter a key to send'); return; }
    setSendingIssue(issue.id);
    try {
      await apiPost(`/source-rules/issues/${issue.id}/send`, { key, note: issueNoteInputs[issue.id] || '' });
      flash('Key sent to customer via Telegram');
      setIssueKeyInputs(prev => { const n = { ...prev }; delete n[issue.id]; return n; });
      setIssueNoteInputs(prev => { const n = { ...prev }; delete n[issue.id]; return n; });
      loadIssues(); loadStats();
    } catch (err: any) { flash(err.message || 'Send failed'); }
    setSendingIssue(null);
  };

  const closeIssue = async (issue: Issue) => {
    if (!confirm(`Close issue #${issue.id} for order #${issue.order_id} without sending a key?`)) return;
    try {
      await apiPost(`/source-rules/issues/${issue.id}/close`, { note: 'Manually closed by admin' });
      flash('Issue closed');
      loadIssues(); loadStats();
    } catch (err: any) { flash(err.message || 'Close failed'); }
  };

  useEffect(() => {
    setLoading(true);
    Promise.all([loadRules(), loadProviders(), loadCategories(), loadDurations(), loadLogs(), loadAudit(), loadStats(), loadIssues()])
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    let mounted = true;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let eventResetTimer: ReturnType<typeof setTimeout> | null = null;
    const baseUrl = window.location.origin;
    const connect = () => {
      if (!mounted) return;
      setSseStatus('connecting');
      const es = new EventSource(`${baseUrl}/api/source-rules/events`);
      sseRef.current = es;
      es.onopen = () => { if (mounted) setSseStatus('live'); };
      es.onerror = () => {
        if (!mounted) return;
        setSseStatus('offline');
        es.close();
        reconnectTimer = setTimeout(connect, 5000);
      };
      es.onmessage = (ev) => {
        if (!mounted) return;
        try {
          const data = JSON.parse(ev.data);
          const type = data.type || '';
          if (type === 'connected') { setSseStatus('live'); return; }
          setLastSseEvent(type);
          if (eventResetTimer) clearTimeout(eventResetTimer);
          eventResetTimer = setTimeout(() => { if (mounted) setLastSseEvent(null); }, 2000);
          if (type === 'rule_changed') { loadRules(); loadStats(); }
          else if (type === 'provider_changed') { loadProviders(); loadStats(); }
          else if (type === 'test_result') { loadRules(); loadStats(); loadAudit(); }
          else if (type === 'audit_added') { loadAudit(); }
          else if (type === 'issue_changed') { loadIssues(); loadStats(); }
          else if (type === 'fulfillment_changed') { loadLogs(); loadStats(); }
        } catch {}
      };
    };
    connect();
    return () => {
      mounted = false;
      sseRef.current?.close();
      if (reconnectTimer) clearTimeout(reconnectTimer);
      if (eventResetTimer) clearTimeout(eventResetTimer);
    };
  }, [loadRules, loadProviders, loadStats, loadAudit, loadLogs, loadIssues]);

  useEffect(() => {
    if (ruleForm.category_id) {
      setCatDurations(durations.filter((d: any) => String(d.category_id) === String(ruleForm.category_id)));
    } else { setCatDurations([]); }
  }, [ruleForm.category_id, durations]);

  const filteredRules = useMemo(() => {
    let r = [...rules];
    if (rulesSearch) {
      const s = rulesSearch.toLowerCase();
      r = r.filter(x => cleanName(x.category_name).toLowerCase().includes(s) || cleanName(x.duration_name).toLowerCase().includes(s) || (x.provider_name || '').toLowerCase().includes(s));
    }
    if (rulesFilterType) r = r.filter(x => x.source_type === rulesFilterType);
    if (rulesFilterStatus === 'active') r = r.filter(x => x.is_active);
    else if (rulesFilterStatus === 'inactive') r = r.filter(x => !x.is_active);
    else if (rulesFilterStatus === 'failing') r = r.filter(x => x.last_test_success === false);
    return r;
  }, [rules, rulesSearch, rulesFilterType, rulesFilterStatus]);

  const openAddRule = () => {
    setEditingRule(null);
    setRuleForm({ category_id: '', duration_id: '', source_type: 'manual', api_provider_id: '', api_game_value: '', api_duration_value: '', api_device_value: '', api_currency_value: '', is_active: true });
    setShowRuleForm(true);
  };

  const openEditRule = (r: Rule) => {
    setEditingRule(r);
    setRuleForm({
      category_id: String(r.category_id), duration_id: String(r.duration_id),
      source_type: r.source_type, api_provider_id: r.api_provider_id ? String(r.api_provider_id) : '',
      api_game_value: r.api_game_value || '', api_duration_value: r.api_duration_value || '',
      api_device_value: r.api_device_value || '', api_currency_value: r.api_currency_value || '',
      is_active: r.is_active,
    });
    setShowRuleForm(true);
  };

  const saveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const body = {
        ...ruleForm,
        category_id: parseInt(ruleForm.category_id),
        duration_id: parseInt(ruleForm.duration_id),
        api_provider_id: ruleForm.api_provider_id ? parseInt(ruleForm.api_provider_id) : null,
      };
      if (editingRule) await apiPut(`/source-rules/rules/${editingRule.id}`, body);
      else await apiPost('/source-rules/rules', body);
      setShowRuleForm(false);
      flash(editingRule ? 'Rule updated' : 'Rule created');
      loadRules(); loadStats(); loadAudit();
    } catch (err: any) { flash(err.message); }
    setSaving(false);
  };

  const deleteRule = async (r: Rule) => {
    if (!confirm(`Delete source rule for "${cleanName(r.category_name)} / ${cleanName(r.duration_name)}"?`)) return;
    try { await apiDelete(`/source-rules/rules/${r.id}`); flash('Rule deleted'); loadRules(); loadStats(); loadAudit(); } catch (err: any) { flash(err.message); }
  };

  const toggleRule = async (r: Rule) => {
    try {
      await apiPut(`/source-rules/rules/${r.id}`, { ...r, is_active: !r.is_active, api_provider_id: r.api_provider_id });
      flash(r.is_active ? 'Rule disabled' : 'Rule enabled');
      loadRules(); loadStats(); loadAudit();
    } catch (err: any) { flash(err.message); }
  };

  const testRule = async (r: Rule) => {
    setTesting(true);
    try {
      const res = await apiPost(`/source-rules/rules/${r.id}/test`);
      setTestResult({ ...res, rule_name: `${cleanName(r.category_name)} / ${cleanName(r.duration_name)}` });
      setTab('test');
      loadRules(); loadStats(); loadAudit();
    } catch (err: any) { flash(err.message); }
    setTesting(false);
  };

  const openAddProv = () => { setEditingProv(null); setProvForm({ name: '', base_url: '', token: '', is_active: true }); setShowProvForm(true); };
  const openEditProv = (p: Provider) => { setEditingProv(p); setProvForm({ name: p.name, base_url: p.base_url, token: p.token || '', is_active: p.is_active }); setShowProvForm(true); };

  const saveProv = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingProv) await apiPut(`/source-rules/providers/${editingProv.id}`, provForm);
      else await apiPost('/source-rules/providers', provForm);
      setShowProvForm(false);
      flash(editingProv ? 'Provider updated' : 'Provider created');
      loadProviders(); loadStats(); loadAudit();
    } catch (err: any) { flash(err.message); }
    setSaving(false);
  };

  const deleteProv = async (p: Provider) => {
    if (!confirm(`Delete provider "${p.name}"?`)) return;
    try { await apiDelete(`/source-rules/providers/${p.id}`); flash('Provider deleted'); loadProviders(); loadStats(); loadAudit(); } catch (err: any) { flash(err.message); }
  };

  const runFreeTest = async () => {
    setTesting(true);
    setRawExpanded(false);
    try {
      const body = {
        provider_id: testForm.provider_id ? parseInt(testForm.provider_id) : null,
        api_game_value: testForm.api_game_value || null,
        api_duration_value: testForm.api_duration_value || null,
        api_device_value: testForm.api_device_value || null,
        api_currency_value: testForm.api_currency_value || null,
      };
      const res = await apiPost('/source-rules/test', body);
      setTestResult({ ...res, rule_name: 'Free Test' });
      loadAudit();
    } catch (err: any) { flash(err.message); }
    setTesting(false);
  };

  const providerHealth = (p: Provider) => {
    if (!p.is_active) return { label: 'Offline', cls: 'offline' };
    if (p.last_test_ok === false) return { label: 'Failed', cls: 'error' };
    if (p.failures_7d > 0 && p.fulfillments_7d > 0 && p.failures_7d / p.fulfillments_7d > 0.3) return { label: 'Degraded', cls: 'warning' };
    if (p.last_test_ok === true && p.failures_7d > 0) return { label: 'Degraded', cls: 'warning' };
    if (p.last_test_ok === true) return { label: 'Healthy', cls: 'healthy' };
    return { label: 'Untested', cls: 'unknown' };
  };

  const fulfillmentBadge = (l: any) => {
    if (l.delivery_success && l.fallback_used) return { label: 'Fallback', cls: 'fallback' };
    if (l.delivery_success && l.delivered_source === 'api') return { label: 'API', cls: 'api-ok' };
    if (l.delivery_success) return { label: 'Delivered', cls: 'delivered' };
    if (l.failure_reason?.includes('No stock')) return { label: 'No Stock', cls: 'no-stock' };
    if (l.failure_reason?.includes('API')) return { label: 'API Fail', cls: 'api-fail' };
    if (!l.resolution_success) return { label: 'Failed', cls: 'failed' };
    return { label: 'Pending', cls: 'pending' };
  };

  const auditIcon = (action: string) => {
    if (action === 'created') return '+';
    if (action === 'updated') return '~';
    if (action === 'deleted') return '-';
    if (action === 'test_run') return '>';
    return '*';
  };

  if (loading) return <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading...</span></div>;

  const tabs: { key: Tab; label: string; shortLabel: string; icon: React.ReactNode; badge?: number }[] = [
    { key: 'rules', label: 'Source Rules', shortLabel: 'Rules', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> },
    { key: 'providers', label: 'API Providers', shortLabel: 'Providers', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r="1" fill="currentColor"/><circle cx="6" cy="18" r="1" fill="currentColor"/></svg> },
    { key: 'test', label: 'Test Console', shortLabel: 'Test', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg> },
    { key: 'fulfillment', label: 'Fulfillment', shortLabel: 'Fulfill', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>, badge: (stats?.failed_24h || 0) },
    { key: 'issues', label: 'Issues', shortLabel: 'Issues', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>, badge: stats?.open_issues || 0 },
    { key: 'audit', label: 'Audit Log', shortLabel: 'Audit', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> },
  ];

  return (
    <div className="page sc-page">
      {msg && <div className="toast-msg">{msg}</div>}
      {loadError && <div className="toast-msg" style={{background:'rgba(251,113,133,.15)',color:'var(--c-rose)',borderColor:'rgba(251,113,133,.2)'}}>{loadError}</div>}

      <div className="sc-header">
        <div className="sc-header-left">
          <h1 className="sc-title">Source Config</h1>
          <p className="sc-subtitle">Control API and manual fulfillment logic with real-time monitoring</p>
        </div>
        <div className="sc-header-actions">
          <span className={`sc-live-indicator sc-live-${sseStatus}`}>
            <span className="sc-live-dot" />
            {sseStatus === 'live' ? (lastSseEvent ? 'Syncing...' : 'Live') : sseStatus === 'connecting' ? 'Connecting...' : 'Offline'}
          </span>
          <button className="sc-btn sc-btn-primary" onClick={openAddRule}><SvgPlus /> Add Rule</button>
          <button className="sc-btn sc-btn-secondary" onClick={openAddProv}><SvgPlus /> Add Provider</button>
        </div>
      </div>

      {stats && (
        <div className="sc-kpi-rows">
          <div className="sc-kpi-row sc-kpi-row-4">
            <div className="sc-stat-card sc-stat-default">
              <div className="sc-stat-value">{stats.total_rules}</div>
              <div className="sc-stat-label">Total Rules</div>
            </div>
            <div className="sc-stat-card sc-stat-default">
              <div className="sc-stat-value">{stats.active_providers}</div>
              <div className="sc-stat-label">Active Providers</div>
            </div>
            <div className="sc-stat-card sc-stat-accent">
              <div className="sc-stat-value">{stats.api_rules}</div>
              <div className="sc-stat-label">API Rules</div>
            </div>
            <div className="sc-stat-card sc-stat-amber">
              <div className="sc-stat-value">{stats.hybrid_rules}</div>
              <div className="sc-stat-label">Hybrid Rules</div>
            </div>
          </div>
          <div className="sc-kpi-row sc-kpi-row-3">
            <div className="sc-stat-card sc-stat-success">
              <div className="sc-stat-value">{stats.success_rate_7d}%</div>
              <div className="sc-stat-label">7d Success</div>
            </div>
            <div className="sc-stat-card sc-stat-danger">
              <div className="sc-stat-value">{stats.failed_24h}</div>
              <div className="sc-stat-label">Failed 24h</div>
            </div>
            <div className="sc-stat-card sc-stat-warn">
              <div className="sc-stat-value">{stats.pending_review}</div>
              <div className="sc-stat-label">Needs Review</div>
            </div>
          </div>
        </div>
      )}

      <div className="sc-tabs-wrap">
        <nav className="sc-tabs-nav">
          {tabs.map(t => (
            <button
              key={t.key}
              className={`sc-tab-btn${tab === t.key ? ' active' : ''}`}
              onClick={() => setTab(t.key)}
            >
              <span className="sc-tab-icon">{t.icon}</span>
              <span className="sc-tab-label">{t.label}</span>
              <span className="sc-tab-label-short">{t.shortLabel}</span>
              {t.badge != null && t.badge > 0 && <span className="sc-tab-badge">{t.badge}</span>}
            </button>
          ))}
        </nav>
      </div>

      {tab === 'rules' && (
        <div className="sc-panel">
          <div className="sc-panel-toolbar">
            <div className="sc-search-wrap">
              <SvgSearch />
              <input className="sc-search-input" placeholder="Search rules..." value={rulesSearch} onChange={e => setRulesSearch(e.target.value)} />
            </div>
            <div className="sc-filters">
              <select className="sc-filter-select" value={rulesFilterType} onChange={e => setRulesFilterType(e.target.value)}>
                <option value="">All Types</option>
                <option value="manual">Manual</option>
                <option value="api">API</option>
                <option value="api_and_manual">Hybrid</option>
              </select>
              <select className="sc-filter-select" value={rulesFilterStatus} onChange={e => setRulesFilterStatus(e.target.value)}>
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="failing">Failing Tests</option>
              </select>
            </div>
          </div>

          {filteredRules.length === 0 ? (
            <div className="sc-empty">
              <div className="sc-empty-icon"><SvgBox /></div>
              <h3>No source rules found</h3>
              <p>{rules.length === 0 ? 'Add a rule to define how keys are sourced for each category + duration pair.' : 'No rules match your current filters.'}</p>
              {rules.length === 0 && <button className="sc-btn sc-btn-primary" onClick={openAddRule}><SvgPlus /> Create First Rule</button>}
            </div>
          ) : (
            <>
              <div className="sc-table-shell sc-table-scroll">
                <table className="sc-dtable">
                    <thead>
                      <tr>
                        <th>Category</th>
                        <th>Duration</th>
                        <th>Source</th>
                        <th>Provider</th>
                        <th>Status</th>
                        <th>Last Test</th>
                        <th>Updated</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRules.map(r => (
                        <React.Fragment key={r.id}>
                          <tr className={`sc-drow${expandedRule === r.id ? ' expanded' : ''}`} onClick={() => setExpandedRule(expandedRule === r.id ? null : r.id)}>
                            <td><span className="sc-cat-name">{cleanName(r.category_name)}</span></td>
                            <td>{cleanName(r.duration_name)}</td>
                            <td><span className={`sc-pill sc-pill-${sourceClass(r.source_type)}`}>{sourceLabel(r.source_type)}</span></td>
                            <td className="sc-meta-text">{r.provider_name || <span className="sc-dim">--</span>}</td>
                            <td>
                              <span className={`sc-status-chip ${r.is_active ? 'active' : 'inactive'}`}>
                                <span className="sc-status-dot-inner" />
                                {r.is_active ? 'Active' : 'Inactive'}
                              </span>
                            </td>
                            <td>
                              {r.last_test_at ? (
                                <span className={`sc-test-pill ${r.last_test_success ? 'pass' : 'fail'}`}>
                                  {r.last_test_success ? 'Pass' : 'Fail'}
                                </span>
                              ) : <span className="sc-dim">--</span>}
                            </td>
                            <td className="sc-meta-text">{fmtTime(r.updated_at)}</td>
                            <td>
                              <div className="sc-action-rail" onClick={e => e.stopPropagation()}>
                                <button className="sc-icon-btn sc-icon-play" onClick={() => testRule(r)} disabled={testing} title="Test"><SvgPlay /></button>
                                <button className="sc-icon-btn sc-icon-edit" onClick={() => openEditRule(r)} title="Edit"><SvgEdit /></button>
                                <button className="sc-icon-btn sc-icon-toggle" onClick={() => toggleRule(r)} title={r.is_active ? 'Disable' : 'Enable'}>
                                  {r.is_active ? <span style={{fontSize:11}}>Off</span> : <span style={{fontSize:11}}>On</span>}
                                </button>
                                <button className="sc-icon-btn sc-icon-del" onClick={() => deleteRule(r)} title="Delete"><SvgTrash /></button>
                              </div>
                            </td>
                          </tr>
                          {expandedRule === r.id && (
                            <tr className="sc-detail-row">
                              <td colSpan={8}>
                                <div className="sc-detail-grid">
                                  <div className="sc-detail-item"><span className="sc-detail-label">Source Type</span><span>{sourceLabel(r.source_type)}</span></div>
                                  <div className="sc-detail-item"><span className="sc-detail-label">Provider</span><span>{r.provider_name || 'None'}</span></div>
                                  {r.provider_base_url && <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Base URL</span><span className="sc-mono-sm">{r.provider_base_url}</span></div>}
                                  {r.api_game_value && <div className="sc-detail-item"><span className="sc-detail-label">Game</span><span className="sc-mono-sm">{r.api_game_value}</span></div>}
                                  {r.api_duration_value && <div className="sc-detail-item"><span className="sc-detail-label">Duration Map</span><span className="sc-mono-sm">{r.api_duration_value}</span></div>}
                                  {r.api_device_value && <div className="sc-detail-item"><span className="sc-detail-label">Max Devices</span><span className="sc-mono-sm">{r.api_device_value}</span></div>}
                                  {r.api_currency_value && <div className="sc-detail-item"><span className="sc-detail-label">Currency</span><span className="sc-mono-sm">{r.api_currency_value}</span></div>}
                                  <div className="sc-detail-item"><span className="sc-detail-label">Created</span><span>{fmtDate(r.created_at)}</span></div>
                                  <div className="sc-detail-item"><span className="sc-detail-label">Updated</span><span>{fmtDate(r.updated_at)}</span></div>
                                  {r.last_test_at && <div className="sc-detail-item"><span className="sc-detail-label">Last Test</span><span>{fmtDate(r.last_test_at)}</span></div>}
                                  {r.last_test_result && <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Test Result</span><span className="sc-mono-sm">{r.last_test_result}</span></div>}
                                  <div className="sc-detail-item sc-detail-wide">
                                    <span className="sc-detail-label">Fulfillment Logic</span>
                                    <span className="sc-logic-text">
                                      {r.source_type === 'manual' ? 'Uses manually-stocked keys only. No API fallback.'
                                        : r.source_type === 'api' ? 'Fetches key from API after payment. No manual fallback.'
                                        : 'Tries API first after payment, falls back to manual stock from same category+duration if API fails.'}
                                    </span>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
              </div>
            </>
          )}
        </div>
      )}

      {tab === 'providers' && (
        <div className="sc-panel">
          {providers.length === 0 ? (
            <div className="sc-empty">
              <div className="sc-empty-icon"><SvgServer /></div>
              <h3>No API providers</h3>
              <p>Add an API provider to start sourcing keys from external services.</p>
              <button className="sc-btn sc-btn-primary" onClick={openAddProv}><SvgPlus /> Add Provider</button>
            </div>
          ) : (
            <div className="sc-table-shell sc-table-scroll">
              <table className="sc-dtable">
                <thead>
                  <tr>
                    <th>Provider</th>
                    <th>Health</th>
                    <th>Rules</th>
                    <th>7D Fills</th>
                    <th>7D Fails</th>
                    <th>Last Tested</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {providers.map(p => {
                    const health = providerHealth(p);
                    return (
                      <React.Fragment key={p.id}>
                        <tr className={`sc-drow${expandedRule === -p.id ? ' expanded' : ''}`} onClick={() => setExpandedRule(expandedRule === -p.id ? null : -p.id)}>
                          <td>
                            <div className="sc-prov-cell">
                              <span className="sc-cat-name">{p.name}</span>
                              <span className="sc-prov-url-inline">{p.base_url}</span>
                            </div>
                          </td>
                          <td><span className={`sc-health-chip sc-health-${health.cls}`}>{health.label}</span></td>
                          <td>{p.rules_count}</td>
                          <td>{p.fulfillments_7d}</td>
                          <td className={p.failures_7d > 0 ? 'sc-text-rose' : ''}>{p.failures_7d}</td>
                          <td className="sc-meta-text">{p.last_tested_at ? fmtTime(p.last_tested_at) : <span className="sc-dim">--</span>}</td>
                          <td className="sc-meta-text">{fmtTime(p.created_at)}</td>
                          <td>
                            <div className="sc-action-rail" onClick={e => e.stopPropagation()}>
                              <button className="sc-icon-btn sc-icon-edit" onClick={() => openEditProv(p)} title="Edit"><SvgEdit /></button>
                              <button className="sc-icon-btn sc-icon-del" onClick={() => deleteProv(p)} title="Delete"><SvgTrash /></button>
                            </div>
                          </td>
                        </tr>
                        {expandedRule === -p.id && (
                          <tr className="sc-detail-row">
                            <td colSpan={8}>
                              <div className="sc-detail-grid">
                                <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Base URL</span><span className="sc-mono-sm">{p.base_url}</span></div>
                                <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Token</span><span className="sc-mono-sm">{p.token || 'No token'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Status</span><span className={p.is_active ? 'sc-text-emerald' : 'sc-text-rose'}>{p.is_active ? 'Active' : 'Inactive'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Rules Count</span><span>{p.rules_count}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">7d Fulfillments</span><span>{p.fulfillments_7d}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">7d Failures</span><span className="sc-text-rose">{p.failures_7d}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Last Tested</span><span>{p.last_tested_at ? fmtDate(p.last_tested_at) : '--'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Created</span><span>{fmtDate(p.created_at)}</span></div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === 'test' && (
        <div className="sc-panel">
          <div className="sc-test-console">
            <div className="sc-test-form-card">
              <div className="sc-test-form-header">
                <SvgActivity />
                <div>
                  <h3>API Test Console</h3>
                  <p>Test provider API with custom mapping values</p>
                </div>
              </div>
              <div className="sc-test-fields">
                <div className="sc-field">
                  <label>Provider</label>
                  <select value={testForm.provider_id} onChange={e => setTestForm({...testForm, provider_id: e.target.value})}>
                    <option value="">Select provider...</option>
                    {providers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                <div className="sc-test-params">
                  <div className="sc-field">
                    <label>Game</label>
                    <input value={testForm.api_game_value} onChange={e => setTestForm({...testForm, api_game_value: e.target.value})} placeholder="PUBG" />
                  </div>
                  <div className="sc-field">
                    <label>Duration</label>
                    <input value={testForm.api_duration_value} onChange={e => setTestForm({...testForm, api_duration_value: e.target.value})} placeholder="1d" />
                  </div>
                  <div className="sc-field">
                    <label>Max Devices</label>
                    <input value={testForm.api_device_value} onChange={e => setTestForm({...testForm, api_device_value: e.target.value})} placeholder="1" />
                  </div>
                  <div className="sc-field">
                    <label>Currency</label>
                    <input value={testForm.api_currency_value} onChange={e => setTestForm({...testForm, api_currency_value: e.target.value})} placeholder="INR" />
                  </div>
                </div>
                <button className="sc-btn sc-btn-primary sc-btn-run" onClick={runFreeTest} disabled={testing || !testForm.provider_id}>
                  {testing ? 'Running...' : 'Run Test'}
                </button>
              </div>
            </div>

            {testResult && (
              <div className="sc-test-results">
                <div className="sc-result-header-card">
                  <div className={`sc-result-badge-lg ${testResult.success ? 'pass' : 'fail'}`}>
                    {testResult.success ? 'PASS' : 'FAIL'}
                  </div>
                  <div className="sc-result-summary">
                    <div className="sc-result-title">{testResult.rule_name || 'Test'}</div>
                    <div className="sc-result-chips">
                      {testResult.http_status != null && <span className="sc-result-chip">HTTP {testResult.http_status}</span>}
                      {testResult.latency_ms != null && <span className="sc-result-chip">{testResult.latency_ms}ms</span>}
                      {testResult.keys_found != null && <span className="sc-result-chip">{testResult.keys_found} key{testResult.keys_found !== 1 ? 's' : ''}</span>}
                      {testResult.stock_count != null && <span className="sc-result-chip">{testResult.stock_count} in stock</span>}
                    </div>
                  </div>
                </div>

                {testResult.request_url && (
                  <div className="sc-result-section">
                    <div className="sc-result-section-header">
                      <span>Request URL</span>
                      <button className="sc-icon-btn-xs" onClick={() => copyText(testResult.request_url)} title="Copy"><SvgCopy /></button>
                    </div>
                    <code className="sc-code">{testResult.request_url}</code>
                  </div>
                )}

                {testResult.extracted_user_key && (
                  <div className="sc-result-section">
                    <div className="sc-result-section-header">
                      <span>Extracted Key</span>
                      <button className="sc-icon-btn-xs" onClick={() => copyText(testResult.extracted_user_key)} title="Copy"><SvgCopy /></button>
                    </div>
                    <code className="sc-code sc-code-key">{testResult.extracted_user_key}</code>
                  </div>
                )}

                {testResult.message && (
                  <div className="sc-result-section">
                    <div className="sc-result-section-header"><span>Message</span></div>
                    <div className="sc-result-text">{testResult.message}</div>
                  </div>
                )}

                {testResult.sample_key_object && typeof testResult.sample_key_object === 'object' && (
                  <div className="sc-result-section">
                    <div className="sc-result-section-header"><span>Key Object</span></div>
                    <pre className="sc-pre">{JSON.stringify(testResult.sample_key_object, null, 2)}</pre>
                  </div>
                )}

                {testResult.raw_response && (
                  <div className="sc-result-section">
                    <div className="sc-result-section-header">
                      <span>Raw Response</span>
                      <div className="sc-result-section-actions">
                        <button className="sc-icon-btn-xs" onClick={() => copyText(typeof testResult.raw_response === 'string' ? testResult.raw_response : JSON.stringify(testResult.raw_response))} title="Copy"><SvgCopy /></button>
                        <button className="sc-icon-btn-xs" onClick={() => setRawExpanded(!rawExpanded)}><SvgChevron open={rawExpanded} /></button>
                      </div>
                    </div>
                    {rawExpanded && (
                      <pre className="sc-pre sc-pre-raw">{typeof testResult.raw_response === 'string' ? testResult.raw_response : JSON.stringify(testResult.raw_response, null, 2)}</pre>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'fulfillment' && (
        <div className="sc-panel">
          {stats && (
            <div className="sc-fulfill-kpis">
              <div className="sc-kpi"><span className="sc-kpi-val">{stats.total_24h}</span><span className="sc-kpi-label">Total 24h</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val sc-text-emerald">{stats.fulfilled_24h}</span><span className="sc-kpi-label">Delivered</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val sc-text-rose">{stats.failed_24h}</span><span className="sc-kpi-label">Failed</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val sc-text-amber">{stats.fallback_24h}</span><span className="sc-kpi-label">Fallback</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val">{stats.success_rate_7d}%</span><span className="sc-kpi-label">7d Rate</span></div>
            </div>
          )}

          <div className="sc-panel-toolbar">
            <div className="sc-filters">
              <select className="sc-filter-select" value={logsFilter.source_type} onChange={e => { const f = {...logsFilter, source_type: e.target.value}; setLogsFilter(f); loadLogs(f); }}>
                <option value="">All Sources</option>
                <option value="manual">Manual</option>
                <option value="api">API</option>
                <option value="api_and_manual">Hybrid</option>
              </select>
              <select className="sc-filter-select" value={logsFilter.result} onChange={e => { const f = {...logsFilter, result: e.target.value}; setLogsFilter(f); loadLogs(f); }}>
                <option value="">All Results</option>
                <option value="delivered">Delivered</option>
                <option value="failed">Failed</option>
                <option value="fallback">Fallback</option>
              </select>
              <select className="sc-filter-select" value={logsFilter.provider_id} onChange={e => { const f = {...logsFilter, provider_id: e.target.value}; setLogsFilter(f); loadLogs(f); }}>
                <option value="">All Providers</option>
                {providers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <button className="sc-btn sc-btn-ghost" onClick={() => loadLogs()}><SvgRefresh /> Refresh</button>
          </div>

          {logs.length === 0 ? (
            <div className="sc-empty">
              <div className="sc-empty-icon"><SvgActivity /></div>
              <h3>No fulfillment logs</h3>
              <p>Logs appear here when orders are processed through the source system.</p>
            </div>
          ) : (
            <div className="sc-table-shell sc-table-scroll">
              <table className="sc-dtable">
                <thead>
                  <tr>
                    <th>Time</th>
                    <th>Order</th>
                    <th>Buyer</th>
                    <th>Category</th>
                    <th>Duration</th>
                    <th>Source</th>
                    <th>Provider</th>
                    <th>Result</th>
                    <th>Delivered</th>
                    <th>Latency</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((l: any) => {
                    const badge = fulfillmentBadge(l);
                    return (
                      <React.Fragment key={l.id}>
                        <tr className={`sc-drow${expandedLog === l.id ? ' expanded' : ''}`} onClick={() => setExpandedLog(expandedLog === l.id ? null : l.id)}>
                          <td className="sc-meta-text sc-nowrap">{fmtTime(l.created_at)}</td>
                          <td>{l.order_id ? <span className="sc-mono-sm">#{l.order_id}</span> : <span className="sc-dim">--</span>}</td>
                          <td className="sc-meta-text">{l.user_display_name || l.order_username || l.user_tg_username || (l.telegram_user_id ? `ID:${l.telegram_user_id}` : '--')}</td>
                          <td>{cleanName(l.category_name) || <span className="sc-dim">--</span>}</td>
                          <td>{cleanName(l.duration_name) || <span className="sc-dim">--</span>}</td>
                          <td>{l.source_type ? <span className={`sc-pill sc-pill-${sourceClass(l.source_type)}`}>{sourceLabel(l.source_type)}</span> : <span className="sc-dim">--</span>}</td>
                          <td className="sc-meta-text">{l.provider_name || <span className="sc-dim">--</span>}</td>
                          <td><span className={`sc-fulfill-badge sc-fb-${badge.cls}`}>{badge.label}</span></td>
                          <td><span className={l.delivery_success ? 'sc-text-emerald' : 'sc-text-rose'}>{l.delivery_success ? 'Yes' : 'No'}</span></td>
                          <td className="sc-meta-text">{l.response_time_ms != null ? `${l.response_time_ms}ms` : <span className="sc-dim">--</span>}</td>
                          <td>
                            <button className="sc-icon-btn" onClick={e => { e.stopPropagation(); setExpandedLog(expandedLog === l.id ? null : l.id); }}>
                              <SvgChevron open={expandedLog === l.id} />
                            </button>
                          </td>
                        </tr>
                        {expandedLog === l.id && (
                          <tr className="sc-detail-row">
                            <td colSpan={11}>
                              <div className="sc-detail-grid">
                                <div className="sc-detail-item"><span className="sc-detail-label">Order ID</span><span>{l.order_id || '--'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Provider</span><span>{l.provider_name || '--'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Source Type</span><span>{sourceLabel(l.source_type || '')}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Delivered Source</span><span>{l.delivered_source || '--'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Resolved</span><span className={l.resolution_success ? 'sc-text-emerald' : 'sc-text-rose'}>{l.resolution_success ? 'Yes' : 'No'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Delivered</span><span className={l.delivery_success ? 'sc-text-emerald' : 'sc-text-rose'}>{l.delivery_success ? 'Yes' : 'No'}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Fallback</span><span>{l.fallback_used ? 'Yes' : 'No'}</span></div>
                                {l.response_time_ms != null && <div className="sc-detail-item"><span className="sc-detail-label">Latency</span><span>{l.response_time_ms}ms</span></div>}
                                {l.http_status != null && <div className="sc-detail-item"><span className="sc-detail-label">HTTP</span><span>{l.http_status}</span></div>}
                                <div className="sc-detail-item"><span className="sc-detail-label">Time</span><span>{fmtDate(l.created_at)}</span></div>
                                {l.failure_reason && <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Failure Reason</span><span className="sc-text-rose">{l.failure_reason}</span></div>}
                                {l.key_value && <div className="sc-detail-item sc-detail-wide">
                                  <span className="sc-detail-label">Key Delivered</span>
                                  <span className="sc-mono-sm">{l.key_value.substring(0, 30)}...</span>
                                  <button className="sc-icon-btn-xs" onClick={() => copyText(l.key_value)}><SvgCopy /></button>
                                </div>}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
          <div className="sc-log-count">{logsTotal} total entries</div>
        </div>
      )}

      {tab === 'issues' && (
        <div className="sc-panel">
          {stats && (
            <div className="sc-fulfill-kpis">
              <div className="sc-kpi"><span className="sc-kpi-val sc-text-rose">{stats.open_issues}</span><span className="sc-kpi-label">Open Issues</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val sc-text-emerald">{stats.recovered_today}</span><span className="sc-kpi-label">Recovered Today</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val sc-text-amber">{stats.failed_sends}</span><span className="sc-kpi-label">Failed Sends</span></div>
              <div className="sc-kpi"><span className="sc-kpi-val">{stats.avg_recovery_min != null ? `${stats.avg_recovery_min}m` : '--'}</span><span className="sc-kpi-label">Avg Recovery</span></div>
            </div>
          )}

          <div className="sc-panel-toolbar">
            <div className="sc-filters">
              <select className="sc-filter-select" value={issuesFilter.status} onChange={e => { const f = { status: e.target.value }; setIssuesFilter(f); loadIssues(f); }}>
                <option value="">All Statuses</option>
                <option value="open">Open</option>
                <option value="sending">Sending</option>
                <option value="sent">Sent</option>
                <option value="failed">Failed</option>
                <option value="closed">Closed</option>
              </select>
            </div>
            <button className="sc-btn sc-btn-ghost" onClick={() => loadIssues()}><SvgRefresh /> Refresh</button>
          </div>

          {issues.length === 0 ? (
            <div className="sc-empty">
              <div className="sc-empty-icon"><SvgAlert /></div>
              <h3>No issues found</h3>
              <p>{issuesFilter.status === 'open' ? 'No open fulfillment issues. All deliveries are on track.' : 'No issues match the current filter.'}</p>
            </div>
          ) : (
            <div className="sc-issues-list">
              {issues.map((iss) => {
                const isOpen = iss.status === 'open' || iss.status === 'failed';
                const isExpanded = expandedIssue === iss.id;
                const isSending = sendingIssue === iss.id;
                return (
                  <div key={iss.id} className={`sc-issue-card sc-issue-${iss.status}`}>
                    <div className="sc-issue-header" onClick={() => setExpandedIssue(isExpanded ? null : iss.id)}>
                      <div className="sc-issue-left">
                        <span className={`sc-issue-status-dot sc-isd-${iss.status}`} />
                        <div className="sc-issue-info">
                          <div className="sc-issue-title">
                            Order <span className="sc-mono-sm">#{iss.order_id}</span>
                            <span className="sc-issue-sep">&middot;</span>
                            <span className="sc-issue-cat">{cleanName(iss.category_name)}</span>
                            <span className="sc-issue-sep">&middot;</span>
                            <span className="sc-issue-dur">{cleanName(iss.duration_name)}</span>
                          </div>
                          <div className="sc-issue-meta">
                            {iss.first_name || iss.username || `TG:${iss.telegram_id}`}
                            <span className="sc-issue-sep">&middot;</span>
                            {fmtTime(iss.created_at)}
                            {iss.send_attempts > 0 && <><span className="sc-issue-sep">&middot;</span><span className="sc-text-amber">{iss.send_attempts} attempt{iss.send_attempts !== 1 ? 's' : ''}</span></>}
                          </div>
                        </div>
                      </div>
                      <div className="sc-issue-right">
                        <span className={`sc-issue-badge sc-ib-${iss.status}`}>{iss.status}</span>
                        <SvgChevron open={isExpanded} />
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="sc-issue-body">
                        <div className="sc-issue-detail-grid">
                          <div className="sc-detail-item"><span className="sc-detail-label">Issue ID</span><span>#{iss.id}</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">Order ID</span><span>#{iss.order_id}</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">Order Status</span><span>{iss.order_status}</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">Amount</span><span>{iss.order_amount}</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">TXN Ref</span><span className="sc-mono-sm">{iss.txn_ref || '--'}</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">Source Type</span><span>{sourceLabel(iss.source_type)}</span></div>
                          {iss.provider_name && <div className="sc-detail-item"><span className="sc-detail-label">Provider</span><span>{iss.provider_name}</span></div>}
                          <div className="sc-detail-item"><span className="sc-detail-label">Customer</span><span>{iss.first_name} {iss.last_name} (@{iss.username || '--'})</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">Telegram ID</span><span className="sc-mono-sm">{iss.telegram_id}</span></div>
                          <div className="sc-detail-item"><span className="sc-detail-label">Created</span><span>{fmtDate(iss.created_at)}</span></div>
                          {iss.resolved_at && <div className="sc-detail-item"><span className="sc-detail-label">Resolved</span><span>{fmtDate(iss.resolved_at)}</span></div>}
                          <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Failure Reason</span><span className="sc-text-rose">{iss.failure_reason}</span></div>
                          {iss.last_send_error && <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Last Send Error</span><span className="sc-text-rose">{iss.last_send_error}</span></div>}
                          {iss.recovery_key && <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Recovery Key Sent</span><span className="sc-mono-sm">{iss.recovery_key}</span></div>}
                          {iss.recovery_note && <div className="sc-detail-item sc-detail-wide"><span className="sc-detail-label">Recovery Note</span><span>{iss.recovery_note}</span></div>}
                        </div>

                        {isOpen && (
                          <div className="sc-issue-send-form">
                            <div className="sc-issue-send-header">Manual Recovery — Send Key via Telegram</div>
                            <div className="sc-issue-send-fields">
                              <div className="sc-field sc-field-grow">
                                <label>Key to deliver</label>
                                <input
                                  placeholder="Paste the product key here..."
                                  value={issueKeyInputs[iss.id] || ''}
                                  onChange={e => setIssueKeyInputs(prev => ({ ...prev, [iss.id]: e.target.value }))}
                                  disabled={isSending}
                                  className="sc-issue-key-input"
                                />
                              </div>
                              <div className="sc-field">
                                <label>Note (optional)</label>
                                <input
                                  placeholder="Internal note..."
                                  value={issueNoteInputs[iss.id] || ''}
                                  onChange={e => setIssueNoteInputs(prev => ({ ...prev, [iss.id]: e.target.value }))}
                                  disabled={isSending}
                                />
                              </div>
                            </div>
                            <div className="sc-issue-send-actions">
                              <button
                                className="sc-btn sc-btn-primary sc-btn-send"
                                onClick={() => sendRecoveryKey(iss)}
                                disabled={isSending || !(issueKeyInputs[iss.id] || '').trim()}
                              >
                                {isSending ? 'Sending...' : <><SvgSend /> Send Key via Telegram</>}
                              </button>
                              <button className="sc-btn sc-btn-ghost" onClick={() => closeIssue(iss)} disabled={isSending}>Close Without Sending</button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <div className="sc-log-count">{issuesTotal} total issues</div>
        </div>
      )}

      {tab === 'audit' && (
        <div className="sc-panel">
          <div className="sc-panel-toolbar">
            <div className="sc-filters">
              <select className="sc-filter-select" value={auditFilter.action_type} onChange={e => { const f = {...auditFilter, action_type: e.target.value}; setAuditFilter(f); loadAudit(f); }}>
                <option value="">All Actions</option>
                <option value="created">Created</option>
                <option value="updated">Updated</option>
                <option value="deleted">Deleted</option>
                <option value="test_run">Test Run</option>
              </select>
              <select className="sc-filter-select" value={auditFilter.target_type} onChange={e => { const f = {...auditFilter, target_type: e.target.value}; setAuditFilter(f); loadAudit(f); }}>
                <option value="">All Targets</option>
                <option value="rule">Rules</option>
                <option value="provider">Providers</option>
              </select>
            </div>
            <button className="sc-btn sc-btn-ghost" onClick={() => loadAudit()}><SvgRefresh /> Refresh</button>
          </div>

          {auditLogs.length === 0 ? (
            <div className="sc-empty">
              <div className="sc-empty-icon"><SvgShield /></div>
              <h3>No audit events</h3>
              <p>Configuration changes and test runs will be logged here automatically.</p>
            </div>
          ) : (
            <div className="sc-table-shell sc-table-scroll">
              <table className="sc-dtable">
                <thead>
                  <tr>
                    <th>Time</th>
                    <th>Actor</th>
                    <th>Action</th>
                    <th>Target Type</th>
                    <th>Target Name</th>
                    <th>Summary</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {auditLogs.map((a: any) => {
                    const changeSummary = a.changes && Object.keys(a.changes).length > 0
                      ? Object.keys(a.changes).join(', ')
                      : a.action_type === 'test_run' ? 'test executed' : '--';
                    return (
                      <React.Fragment key={a.id}>
                        <tr className={`sc-drow${expandedAudit === a.id ? ' expanded' : ''}`} onClick={() => setExpandedAudit(expandedAudit === a.id ? null : a.id)}>
                          <td className="sc-meta-text sc-nowrap">{fmtTime(a.created_at)}</td>
                          <td className="sc-meta-text">{a.actor}</td>
                          <td>
                            <span className={`sc-audit-action sc-aa-${a.action_type}`}>
                              <span className="sc-audit-icon">{auditIcon(a.action_type)}</span>
                              {a.action_type}
                            </span>
                          </td>
                          <td><span className="sc-audit-target">{a.target_type}</span></td>
                          <td className="sc-cat-name">{a.target_name || '--'}</td>
                          <td className="sc-meta-text sc-summary-cell">{changeSummary}</td>
                          <td>
                            <button className="sc-icon-btn" onClick={e => { e.stopPropagation(); setExpandedAudit(expandedAudit === a.id ? null : a.id); }}>
                              <SvgChevron open={expandedAudit === a.id} />
                            </button>
                          </td>
                        </tr>
                        {expandedAudit === a.id && (
                          <tr className="sc-detail-row">
                            <td colSpan={7}>
                              <div className="sc-audit-detail">
                                <div className="sc-detail-item"><span className="sc-detail-label">Time</span><span>{fmtDate(a.created_at)}</span></div>
                                <div className="sc-detail-item"><span className="sc-detail-label">Target ID</span><span>{a.target_id || '--'}</span></div>
                                {a.changes && Object.keys(a.changes).length > 0 && (
                                  <div className="sc-audit-changes">
                                    <div className="sc-detail-label" style={{marginBottom:6}}>Changes</div>
                                    {Object.entries(a.changes).map(([k, v]: [string, any]) => (
                                      <div key={k} className="sc-audit-diff">
                                        <span className="sc-audit-field">{k}</span>
                                        {v && typeof v === 'object' && 'before' in v ? (
                                          <div className="sc-audit-before-after">
                                            <span className="sc-diff-before">{String(v.before ?? 'null')}</span>
                                            <span className="sc-diff-arrow">&rarr;</span>
                                            <span className="sc-diff-after">{String(v.after ?? 'null')}</span>
                                          </div>
                                        ) : (
                                          <span className="sc-diff-after">{String(v)}</span>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                )}
                                {a.metadata && Object.keys(a.metadata).length > 0 && (
                                  <div className="sc-result-section" style={{marginTop:8}}>
                                    <div className="sc-result-section-header">
                                      <span>Metadata</span>
                                      <button className="sc-icon-btn-xs" onClick={() => copyText(JSON.stringify(a.metadata, null, 2))}><SvgCopy /></button>
                                    </div>
                                    <pre className="sc-pre">{JSON.stringify(a.metadata, null, 2)}</pre>
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
          <div className="sc-log-count">{auditTotal} total events</div>
        </div>
      )}

      {showRuleForm && (
        <div className="sheet-overlay" onClick={() => setShowRuleForm(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{editingRule ? 'Edit Source Rule' : 'New Source Rule'}</h3>
              <p>{editingRule ? 'Modify source configuration for this category + duration' : 'Define how keys are sourced for a category + duration pair'}</p>
            </div>
            <form onSubmit={saveRule} className="sheet-body">
              {!editingRule && (
                <>
                  <div className="field">
                    <label>Category</label>
                    <select required value={ruleForm.category_id} onChange={e => setRuleForm({...ruleForm, category_id: e.target.value, duration_id: ''})}>
                      <option value="">Select category...</option>
                      {categories.map((c: any) => <option key={c.id} value={c.id}>{cleanName(c.name)}</option>)}
                    </select>
                  </div>
                  <div className="field">
                    <label>Duration</label>
                    <select required value={ruleForm.duration_id} onChange={e => setRuleForm({...ruleForm, duration_id: e.target.value})} disabled={!ruleForm.category_id}>
                      <option value="">Select duration...</option>
                      {catDurations.map((d: any) => <option key={d.id} value={d.id}>{cleanName(d.name)}</option>)}
                    </select>
                  </div>
                </>
              )}

              <div className="field">
                <label>Source Type</label>
                <select value={ruleForm.source_type} onChange={e => setRuleForm({...ruleForm, source_type: e.target.value})}>
                  <option value="manual">Manual Only</option>
                  <option value="api">API Only</option>
                  <option value="api_and_manual">API & Manual (Hybrid)</option>
                </select>
                <span className="field-hint">
                  {ruleForm.source_type === 'manual'
                    ? 'Use only manually stocked keys'
                    : ruleForm.source_type === 'api'
                    ? 'Fetch key only after successful payment'
                    : 'Try API after payment, fallback to manual if API fails'}
                </span>
              </div>

              {(ruleForm.source_type === 'api' || ruleForm.source_type === 'api_and_manual') && (
                <>
                  <div className="field">
                    <label>API Provider</label>
                    <select required value={ruleForm.api_provider_id} onChange={e => setRuleForm({...ruleForm, api_provider_id: e.target.value})}>
                      <option value="">Select provider...</option>
                      {providers.filter(p => p.is_active).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div className="sc-mapping-grid">
                    <div className="field">
                      <label>Game Value</label>
                      <input value={ruleForm.api_game_value} onChange={e => setRuleForm({...ruleForm, api_game_value: e.target.value})} placeholder="e.g. PUBG" />
                    </div>
                    <div className="field">
                      <label>Duration Value</label>
                      <input value={ruleForm.api_duration_value} onChange={e => setRuleForm({...ruleForm, api_duration_value: e.target.value})} placeholder="e.g. 1d" />
                    </div>
                    <div className="field">
                      <label>Max Devices</label>
                      <input value={ruleForm.api_device_value} onChange={e => setRuleForm({...ruleForm, api_device_value: e.target.value})} placeholder="e.g. 1" />
                    </div>
                    <div className="field">
                      <label>Currency</label>
                      <input value={ruleForm.api_currency_value} onChange={e => setRuleForm({...ruleForm, api_currency_value: e.target.value})} placeholder="optional" />
                    </div>
                  </div>
                </>
              )}

              <div className="sc-toggle-field">
                <div className="sc-toggle-row">
                  <div className="sc-toggle-info">
                    <span className="sc-toggle-label">Active</span>
                    <span className="sc-toggle-hint">Enable this rule immediately after saving</span>
                  </div>
                  <button type="button" className={`sc-switch${ruleForm.is_active ? ' on' : ''}`} onClick={() => setRuleForm({...ruleForm, is_active: !ruleForm.is_active})} role="switch" aria-checked={ruleForm.is_active}>
                    <span className="sc-switch-thumb" />
                  </button>
                </div>
              </div>

              <div className="sheet-actions">
                <button type="button" className="btn-ghost" onClick={() => setShowRuleForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary-sm" disabled={saving}>{saving ? 'Saving...' : editingRule ? 'Update Rule' : 'Create Rule'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showProvForm && (
        <div className="sheet-overlay" onClick={() => setShowProvForm(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{editingProv ? 'Edit Provider' : 'New API Provider'}</h3>
              <p>{editingProv ? 'Update provider details' : 'Add an external API key provider'}</p>
            </div>
            <form onSubmit={saveProv} className="sheet-body">
              <div className="field">
                <label>Provider Name</label>
                <input required value={provForm.name} onChange={e => setProvForm({...provForm, name: e.target.value})} placeholder="e.g. Nova ESP Server" />
              </div>
              <div className="field">
                <label>Base URL</label>
                <input required value={provForm.base_url} onChange={e => setProvForm({...provForm, base_url: e.target.value})} placeholder="e.g. http://example.com/api.php?game=&duration=&max_devices=&currency=" />
                <span className="field-hint">Full URL template with query parameters. The mapping values replace the parameter values.</span>
              </div>
              <div className="field">
                <label>Token</label>
                <input value={provForm.token} onChange={e => setProvForm({...provForm, token: e.target.value})} placeholder="optional token" />
                <span className="field-hint">Optional. If provided, this token will be sent as token= in the request.</span>
              </div>
              <div className="sc-toggle-field">
                <div className="sc-toggle-row">
                  <div className="sc-toggle-info">
                    <span className="sc-toggle-label">Active</span>
                    <span className="sc-toggle-hint">Enable this provider immediately after saving</span>
                  </div>
                  <button type="button" className={`sc-switch${provForm.is_active ? ' on' : ''}`} onClick={() => setProvForm({...provForm, is_active: !provForm.is_active})} role="switch" aria-checked={provForm.is_active}>
                    <span className="sc-switch-thumb" />
                  </button>
                </div>
              </div>
              <div className="sheet-actions">
                <button type="button" className="btn-ghost" onClick={() => setShowProvForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary-sm" disabled={saving}>{saving ? 'Saving...' : editingProv ? 'Update' : 'Create'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
