import React, { useEffect, useState } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';
import cfg from '../config';

export default function Resellers() {
  const [resellers, setResellers] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [durations, setDurations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ expires_at: '', max_users: '', apply_scope: 'all_categories', rule_mode: 'percent', category_id: '', rule_value: 0, duration_prices: {}, category_rules: {}, selected_categories: [], category_duration_prices: {} });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const load = () => {
    setLoading(true);
    apiGet(`/resellers?search=${encodeURIComponent(search)}`).then(setResellers).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => {
    apiGet('/resellers/categories').then(setCategories).catch(() => {});
    apiGet('/resellers/durations').then(setDurations).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [search]);

  const openAdd = () => {
    setEditing(null);
    setForm({ expires_at: '', max_users: '', apply_scope: 'all_categories', rule_mode: 'percent', category_id: '', rule_value: 0, duration_prices: {}, category_rules: {}, selected_categories: [], category_duration_prices: {} });
    setShowForm(true);
  };

  const openEdit = (item: any) => {
    setEditing(item);
    let scope = 'all_categories', mode = 'percent', catId: any = '', ruleVal = 0, durPrices: any = {}, catRules: any = {}, selCats: any[] = [], catDurPrices: any = {};
    const rules = item.rules || [];

    const hasDurationRules = rules.some((r: any) => r.duration_id !== null && r.duration_id !== undefined);
    const hasCategoryRules = rules.some((r: any) => r.category_id !== null && r.category_id !== undefined);
    const allHaveDuration = rules.length > 0 && rules.every((r: any) => r.duration_id !== null && r.duration_id !== undefined);
    const distinctCats = [...new Set(rules.filter((r: any) => r.category_id).map((r: any) => r.category_id))];

    if (allHaveDuration && distinctCats.length === 1) {
      scope = 'one_category'; mode = 'custom_prices'; catId = distinctCats[0];
      rules.forEach((r: any) => { if (r.duration_id) durPrices[r.duration_id] = r.price; });
    } else if (allHaveDuration && distinctCats.length > 1) {
      scope = 'per_categories'; mode = 'custom_prices';
      selCats = distinctCats;
      rules.forEach((r: any) => {
        if (r.category_id && r.duration_id) {
          if (!catDurPrices[r.category_id]) catDurPrices[r.category_id] = {};
          catDurPrices[r.category_id][r.duration_id] = r.price;
        }
      });
    } else if (hasCategoryRules && !hasDurationRules && rules.length > 1) {
      scope = 'per_categories';
      const r0 = rules[0];
      mode = r0.price !== null ? 'price' : r0.discount_type === 'percent' ? 'percent' : 'fixed';
      rules.forEach((r: any) => { catRules[r.category_id] = r.price !== null ? r.price : r.discount_value; });
    } else if (rules.length === 1) {
      const r = rules[0];
      if (r.category_id) { scope = 'one_category'; catId = r.category_id; }
      mode = r.price !== null ? 'price' : r.discount_type === 'percent' ? 'percent' : 'fixed';
      ruleVal = r.price !== null ? r.price : r.discount_value || 0;
    }
    setForm({ expires_at: item.expires_at ? item.expires_at.slice(0, 16) : '', max_users: item.max_users ?? '', apply_scope: scope, rule_mode: mode, category_id: catId, rule_value: ruleVal, duration_prices: durPrices, category_rules: catRules, selected_categories: selCats, category_duration_prices: catDurPrices });
    setShowForm(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) await apiPut(`/resellers/${editing.id}`, form);
      else await apiPost('/resellers', form);
      setShowForm(false); setMsg(editing ? 'Reseller updated' : 'Reseller created'); load();
      setTimeout(() => setMsg(''), 2500);
    } catch (err: any) { setMsg(err.message); }
    setSaving(false);
  };

  const remove = async (item: any) => {
    if (!confirm(`Delete reseller code "${item.code}"? This cannot be undone.`)) return;
    try { await apiDelete(`/resellers/${item.id}`); load(); } catch (err: any) { setMsg(err.message); }
  };

  const toggleSelectedCategory = (catId: number) => {
    const sel = form.selected_categories || [];
    const next = sel.includes(catId) ? sel.filter((id: number) => id !== catId) : [...sel, catId];
    setForm({ ...form, selected_categories: next });
  };

  const catDurations = durations.filter(d => d.category_id === parseInt(form.category_id));
  const formatDate = (d: string | null) => d ? new Date(d).toLocaleString(cfg.locale, { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }) : 'No expiry';
  const ruleDescription = (r: any) => {
    if (r.price !== null) return `Fixed ${cfg.currency}${r.price}`;
    if (r.discount_type === 'percent') return `${r.discount_value}% off`;
    if (r.discount_type === 'fixed') return `${cfg.currency}${r.discount_value} off`;
    return '-';
  };
  const activeCount = resellers.filter(r => !r.expires_at || new Date(r.expires_at) > new Date()).length;

  const isPerCatCustom = form.apply_scope === 'per_categories' && form.rule_mode === 'custom_prices';

  return (
    <div className="page">
      {resellers.length > 0 && (
        <div className="metric-row" style={{ marginBottom: 16 }}>
          <div className="metric-pill"><span className="metric-label">Total</span><span className="metric-val">{resellers.length}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-emerald)' }} /><span className="metric-label">Active</span><span className="metric-val">{activeCount}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-accent)' }} /><span className="metric-label">Users</span><span className="metric-val">{resellers.reduce((s: number, r: any) => s + (r.used_count || 0), 0)}</span></div>
        </div>
      )}

      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search reseller codes..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <button className="btn-primary-sm" onClick={openAdd}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add
        </button>
      </div>

      {msg && <div className="toast-msg">{msg}</div>}

      {showForm && (
        <div className="sheet-overlay" onClick={() => setShowForm(false)}>
          <div className="sheet sheet-lg" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{editing ? 'Edit Reseller' : 'Create Reseller Code'}</h3>
              <p>{editing ? 'Update reseller configuration' : 'Set up pricing rules and limits for a new reseller'}</p>
            </div>
            <form onSubmit={save} className="sheet-body">
              <div className="section-label">Access Settings</div>
              <div className="field-row">
                <div className="field">
                  <label>Expiry Date</label>
                  <input type="datetime-local" value={form.expires_at} onChange={e => setForm({...form, expires_at: e.target.value})} />
                  <span className="field-hint">Leave empty for no expiry</span>
                </div>
                <div className="field">
                  <label>Max Users</label>
                  <input type="number" min="1" value={form.max_users} onChange={e => setForm({...form, max_users: e.target.value})} placeholder="Unlimited" />
                </div>
              </div>

              <div className="section-label" style={{ marginTop: 16 }}>Pricing Rules</div>
              <div className="field">
                <label>Pricing Scope</label>
                <select value={form.apply_scope} onChange={e => setForm({...form, apply_scope: e.target.value, rule_mode: 'percent', selected_categories: [], category_duration_prices: {}, category_rules: {}})}>
                  <option value="all_categories">All Categories (Global Rule)</option>
                  <option value="one_category">Single Category</option>
                  <option value="per_categories">Per Category Rules</option>
                </select>
                <span className="field-hint">
                  {form.apply_scope === 'all_categories' && 'One rule applied across all product categories'}
                  {form.apply_scope === 'one_category' && 'Rule applies to a specific category only'}
                  {form.apply_scope === 'per_categories' && 'Set individual rules for each category'}
                </span>
              </div>

              {form.apply_scope === 'one_category' && (
                <div className="field">
                  <label>Category</label>
                  <select value={form.category_id} onChange={e => setForm({...form, category_id: parseInt(e.target.value) || ''})}>
                    <option value="">Select category...</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.displayName}</option>)}
                  </select>
                </div>
              )}

              <div className="field">
                <label>Discount Type</label>
                <select value={form.rule_mode} onChange={e => setForm({...form, rule_mode: e.target.value})}>
                  <option value="percent">Percentage Discount (%)</option>
                  <option value="fixed">Fixed Amount Discount ({cfg.currency})</option>
                  <option value="price">Override with Fixed Price ({cfg.currency})</option>
                  {(form.apply_scope === 'one_category' || form.apply_scope === 'per_categories') && <option value="custom_prices">Custom Per-Duration Prices</option>}
                </select>
              </div>

              {form.rule_mode === 'custom_prices' && form.apply_scope === 'one_category' && form.category_id ? (
                <div className="field">
                  <label>Duration-specific Prices</label>
                  {catDurations.length === 0 ? (
                    <span className="field-hint">No durations found for this category</span>
                  ) : catDurations.map(d => (
                    <div key={d.id} className="inline-field">
                      <span className="inline-field-label">{d.displayName} <span className="field-hint">base: {cfg.currency}{d.price}</span></span>
                      <input type="number" step="0.01" min="0" value={form.duration_prices[d.id] ?? ''} onChange={e => setForm({...form, duration_prices: {...form.duration_prices, [d.id]: e.target.value}})} placeholder={cfg.currency} />
                    </div>
                  ))}
                </div>
              ) : isPerCatCustom ? (
                <div className="field">
                  <label>Select Categories</label>
                  <div className="cat-select-grid">
                    {categories.map(c => {
                      const isSelected = (form.selected_categories || []).includes(c.id);
                      return (
                        <button key={c.id} type="button" className={`cat-select-chip${isSelected ? ' active' : ''}`} onClick={() => toggleSelectedCategory(c.id)}>
                          {c.displayName}
                        </button>
                      );
                    })}
                  </div>
                  {(form.selected_categories || []).length > 0 && (
                    <div className="per-cat-dur-section">
                      {(form.selected_categories || []).map((catId: number) => {
                        const cat = categories.find(c => c.id === catId);
                        if (!cat) return null;
                        const cDurs = durations.filter(d => d.category_id === catId);
                        const prices = (form.category_duration_prices || {})[catId] || {};
                        return (
                          <div key={catId} className="per-cat-dur-block">
                            <div className="per-cat-dur-title">{cat.displayName}</div>
                            {cDurs.length === 0 ? (
                              <span className="field-hint">No durations</span>
                            ) : cDurs.map(d => (
                              <div key={d.id} className="inline-field">
                                <span className="inline-field-label">{d.displayName} <span className="field-hint">base: {cfg.currency}{d.price}</span></span>
                                <input type="number" step="0.01" min="0" value={prices[d.id] ?? ''} onChange={e => {
                                  const updated = { ...(form.category_duration_prices || {}) };
                                  if (!updated[catId]) updated[catId] = {};
                                  updated[catId] = { ...updated[catId], [d.id]: e.target.value };
                                  setForm({ ...form, category_duration_prices: updated });
                                }} placeholder={cfg.currency} />
                              </div>
                            ))}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ) : form.apply_scope === 'per_categories' ? (
                <div className="field">
                  <label>{form.rule_mode === 'percent' ? 'Discount per category (%)' : form.rule_mode === 'fixed' ? `Discount per category (${cfg.currency})` : `Fixed price per category (${cfg.currency})`}</label>
                  {categories.map(c => (
                    <div key={c.id} className="inline-field">
                      <span className="inline-field-label">{c.displayName}</span>
                      <input type="number" step="0.01" min="0" value={form.category_rules[c.id] ?? ''} onChange={e => setForm({...form, category_rules: {...form.category_rules, [c.id]: e.target.value}})} placeholder={form.rule_mode === 'percent' ? '%' : cfg.currency} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="field">
                  <label>{form.rule_mode === 'percent' ? 'Discount Percentage' : form.rule_mode === 'fixed' ? `Discount Amount (${cfg.currency})` : `Fixed Price (${cfg.currency})`}</label>
                  <input type="number" step="0.01" min="0" value={form.rule_value} onChange={e => setForm({...form, rule_value: parseFloat(e.target.value) || 0})} />
                  <span className="field-hint">
                    {form.rule_mode === 'percent' && 'Percentage off the base price for all durations'}
                    {form.rule_mode === 'fixed' && 'Fixed amount deducted from the base price'}
                    {form.rule_mode === 'price' && 'This price replaces the base price entirely'}
                  </span>
                </div>
              )}

              <div className="sheet-actions">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary-sm" disabled={saving}>{saving ? 'Saving...' : editing ? 'Update' : 'Create'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading resellers...</span></div>
      ) : resellers.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg></div>
          <div className="empty-title">No resellers configured</div>
          <div className="empty-desc">Create reseller codes with custom pricing rules for your partners</div>
        </div>
      ) : (
        <div className="list">
          {resellers.map((item: any) => {
            const isExpired = item.expires_at && new Date(item.expires_at) < new Date();
            const isExpanded = expandedId === item.id;
            return (
              <div key={item.id} className="list-card">
                <div className="list-card-top">
                  <div className="list-card-info">
                    <div className={`avatar ${isExpired ? 'danger' : 'accent'}`}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                    </div>
                    <div>
                      <div className="mono-value" style={{ fontSize: 13 }}>{item.code}</div>
                      <div className="list-card-sub">{item.used_count || 0} / {item.max_users || '\u221E'} users</div>
                    </div>
                  </div>
                  <div className={`badge-${isExpired ? 'danger' : 'success'}`}>{isExpired ? 'Expired' : 'Active'}</div>
                </div>

                <div className="list-card-meta">
                  <span>Expires: {formatDate(item.expires_at)}</span>
                </div>

                {item.rules?.length > 0 && (
                  <div className="reseller-rules">
                    <button className="rules-toggle" onClick={() => setExpandedId(isExpanded ? null : item.id)}>
                      <span>{item.rules.length} pricing rule{item.rules.length > 1 ? 's' : ''}</span>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: isExpanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    {isExpanded && (
                      <div className="rules-list">
                        {item.rules.map((r: any, i: number) => (
                          <div key={i} className="rule-row">
                            <span>{r.categoryDisplayName || 'All Categories'}{r.durationDisplayName ? ` / ${r.durationDisplayName}` : ''}</span>
                            <span className="rule-val">{ruleDescription(r)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {item.users?.length > 0 && (
                  <div className="reseller-users">
                    <span className="list-card-sub" style={{ marginBottom: 4, display: 'block' }}>Assigned Users</span>
                    <div className="user-chips">
                      {item.users.slice(0, 5).map((u: any, i: number) => (
                        <span key={i} className="chip">{((u.first_name || '') + ' ' + (u.last_name || '')).trim() || (u.username ? `@${u.username}` : u.telegram_id)}</span>
                      ))}
                      {item.users.length > 5 && <span className="chip">+{item.users.length - 5} more</span>}
                    </div>
                  </div>
                )}

                <div className="list-card-actions">
                  <button className="btn-ghost-sm" onClick={() => openEdit(item)}>Edit</button>
                  <button className="btn-danger-sm" onClick={() => remove(item)}>Delete</button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
