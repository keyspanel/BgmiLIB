import React, { useState, useEffect, useCallback, useRef } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';

type HomeTab = 'campaigns' | 'templates' | 'apk-captions' | 'keys' | 'logs' | 'analytics';
type Nav =
  | { screen: 'home' }
  | { screen: 'campaign-form'; campaign: TrialCampaign | null }
  | { screen: 'template-form'; template: TrialTemplate | null }
  | { screen: 'detail'; campaignId: number };

interface TrialCampaign {
  id: number; name: string; description: string; status: string;
  category_ids_json: string; category_names_snapshot_json: string | null;
  trial_duration_hours: number; max_devices: number | null;
  repeat_mode: string; timezone: string; start_at: string; expire_at: string;
  next_run_at: string; next_expire_at: string; is_enabled: boolean;
  start_template_id: number | null; expire_template_id: number | null;
  start_template_name: string | null; expire_template_name: string | null;
  send_to_users: boolean; send_to_channels: boolean; channel_targets_json: string;
  reveal_keys_in_channels: boolean; linked_promo_campaign_id: number | null;
  linked_promo_name: string | null; target_audience: string; total_runs: number;
  apk_delivery_config_json: string | null;
  delivery_mode: string;
  created_at: string;
}

interface ApkDeliveryFileConfig { send_enabled: boolean; }
interface ApkDeliveryCatConfig { send_enabled: boolean; files: Record<string, ApkDeliveryFileConfig>; }
interface ApkDeliveryConfig { send_apks_enabled: boolean; categories: Record<string, ApkDeliveryCatConfig>; }
interface CategoryWithMedia { id: number; name: string; has_apk: boolean; file_id: string | null; }

interface TrialTemplate {
  id: number; name: string; template_type: string; body_text: string; parse_mode: string;
  inline_buttons_json: string | null; media_type: string | null; media_url: string | null;
  apk_captions_json: string | null; start_delivery_config_json: string | null;
  is_active: boolean; created_at: string; updated_at: string;
}

interface TrialKey {
  id: number; category_id: number; category_name: string; categoryDisplayName: string;
  duration_hours: number; max_devices: number; key_value: string; status: string;
  used_in_trial_campaign_run_id: number | null; used_at: string | null; created_at: string;
  is_orphaned?: boolean;
}

interface KeyStat {
  category_id: number; categoryDisplayName: string; duration_hours: number;
  max_devices: number; total_keys: number; available_keys: number;
  used_keys: number; disabled_keys: number;
  is_orphaned?: boolean;
}

interface Run {
  id: number; campaign_id: number; campaign_name: string; run_type: string; status: string;
  total_targets: number; total_sent: number; total_failed: number;
  channels_targeted: number; channels_sent: number; channels_failed: number;
  error_text: string | null; started_at: string; completed_at: string | null;
  run_keys: { category_id: number; key_value_snapshot: string; duration_hours: number; max_devices: number; categoryDisplayName: string }[];
}

interface DeliveryLog {
  id: number; run_id: number; campaign_id: number; campaign_name: string;
  telegram_id: string; target_type: string; delivery_status: string;
  error_text: string | null; first_name: string; username: string; created_at: string;
}

interface UsageEntry {
  id: number; run_id: number; campaign_id: number; campaign_name: string;
  category_id: number; categoryDisplayName: string; key_value_snapshot: string;
  duration_hours: number; max_devices: number; run_type: string;
  run_started_at: string; created_at: string;
}

interface Category { id: number; name: string; }
interface Channel { id: number; name: string; channel_name?: string; channel_username?: string; is_validated?: boolean; is_enabled?: boolean; }
interface PromoCampaign { id: number; name: string; }

const STATUS_MAP: Record<string, { color: string; bg: string; label: string }> = {
  draft:     { color: 'var(--text-2)',          bg: 'var(--bg-4)',              label: 'Draft' },
  scheduled: { color: 'var(--c-accent-bright)', bg: 'var(--c-accent-surface)', label: 'Scheduled' },
  active:    { color: 'var(--c-emerald)',       bg: 'var(--c-emerald-surface)', label: 'Active' },
  paused:    { color: 'var(--c-amber)',         bg: 'var(--c-amber-surface)',   label: 'Paused' },
  expired:   { color: 'var(--text-3)',          bg: 'var(--bg-4)',              label: 'Expired' },
  disabled:  { color: 'var(--text-3)',          bg: 'var(--bg-4)',              label: 'Disabled' },
  completed: { color: 'var(--c-emerald)',       bg: 'var(--c-emerald-surface)', label: 'Completed' },
  failed:    { color: 'var(--c-red)',           bg: 'var(--c-red-surface)',     label: 'Failed' },
  running:   { color: 'var(--c-accent-bright)', bg: 'var(--c-accent-surface)', label: 'Running' },
};
const REPEAT_MAP: Record<string, string> = { once: 'Once', daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly' };
const AUDIENCE_MAP: Record<string, { label: string; desc: string; icon: string }> = {
  all_users:    { label: 'All Users',    desc: 'Send to all eligible bot users',      icon: 'users' },
  paid_users:   { label: 'Paid Users',   desc: 'Users with completed payments',       icon: 'key' },
  resellers:    { label: 'Resellers',    desc: 'Reseller accounts only',              icon: 'send' },
  active_users: { label: 'Active Users', desc: 'Users active in the last 30 days',    icon: 'clock' },
  purchasers:   { label: 'Purchasers',   desc: 'Users with delivered order history',  icon: 'check' },
  channels:     { label: 'Channels Only',desc: 'Send to selected channels only',      icon: 'send' },
};

const TRIAL_VARS_START = [
  { key: '{campaign_name}', desc: 'Campaign name' },
  { key: '{user_name}', desc: "User's first name" },
  { key: '{bot_name}', desc: 'Bot display name' },
  { key: '{trial_duration}', desc: 'Duration in hours' },
  { key: '{trial_devices}', desc: 'Max devices allowed' },
  { key: '{expire_time}', desc: 'When trial expires' },
  { key: '{start_time}', desc: 'When trial started' },
  { key: '{categories}', desc: 'Comma-separated category names' },
  { key: '{TrialCategoryBlocks}', desc: 'Formatted key blocks per category' },
  { key: '{TrialCategoryNames}', desc: 'Comma-separated names' },
  { key: '{TrialCategoryCount}', desc: 'Number of categories' },
  { key: '{trial_key}', desc: 'First category key (single-cat)' },
  { key: '{category_name}', desc: 'First category name (single-cat)' },
];
const TRIAL_VARS_EXPIRE = [
  { key: '{campaign_name}', desc: 'Campaign name' },
  { key: '{user_name}', desc: "User's first name" },
  { key: '{bot_name}', desc: 'Bot display name' },
  { key: '{expire_time}', desc: 'When trial expired' },
  { key: '{categories}', desc: 'Comma-separated category names' },
  { key: '{TrialCategoryNames}', desc: 'Comma-separated names' },
  { key: '{TrialCategoryCount}', desc: 'Number of categories' },
];
const TRIAL_VARS_DYNAMIC_HINT = 'Per-category keys: {TrialKey<Name>} e.g. {TrialKeyNovaEsp}, {TrialKeySayGG}';

const APK_CAPTION_VARS = [
  { key: '{category_name}', desc: 'Category name' },
  { key: '{trial_key}', desc: "That category's trial key" },
  { key: '{category_key}', desc: "Alias for trial_key" },
  { key: '{category_file_name}', desc: 'Category display name' },
  { key: '{trial_duration}', desc: 'Duration in hours' },
  { key: '{trial_devices}', desc: 'Max devices' },
  { key: '{expire_time}', desc: 'When trial expires' },
  { key: '{start_time}', desc: 'When trial started' },
  { key: '{bot_name}', desc: 'Bot display name' },
  { key: '{campaign_name}', desc: 'Campaign name' },
  { key: '{user_name}', desc: "User's first name" },
  { key: '{categories}', desc: 'All category names' },
  { key: '{TrialCategoryCount}', desc: 'Number of categories' },
];

const TG_VALID_STYLES = new Set(['primary', 'success', 'danger']);
const CB_STYLE_OPTIONS = [
  { value: '',        label: 'Default', color: 'var(--text-3)' },
  { value: 'primary', label: 'Blue',    color: 'var(--c-accent)' },
  { value: 'success', label: 'Green',   color: 'var(--c-emerald)' },
  { value: 'danger',  label: 'Red',     color: 'var(--c-rose)' },
];

const normalizeTcBtn = (b: any): any => {
  const rawStyle = (b.style || '').trim().toLowerCase();
  return {
    id: b.id || `btn_${Math.random().toString(36).slice(2, 8)}`,
    type: b.type || 'url',
    text: b.text || '',
    url: b.url || 'https://',
    style: TG_VALID_STYLES.has(rawStyle) ? rawStyle : '',
    icon_custom_emoji_id: b.icon_custom_emoji_id || '',
    row: b.row || 1,
    enabled: b.enabled !== false,
  };
};

const tcBtnStyleClass = (style: string) => {
  if (style === 'primary') return ' ibe-s-primary';
  if (style === 'success') return ' ibe-s-success';
  if (style === 'danger')  return ' ibe-s-danger';
  return '';
};

const SAFE_TAGS = new Set(['b', 'i', 'u', 's', 'em', 'strong', 'code', 'pre', 'a', 'br']);
const sanitizeTcHtml = (html: string): string =>
  html.replace(/<\/?([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>/g, (match, tag) => {
    const t = tag.toLowerCase();
    if (SAFE_TAGS.has(t)) return match.startsWith('</') ? `</${t}>` : match;
    return '';
  });

const TZ = 'Asia/Kolkata';

const cleanName = (n: string) => (n || '').replace(/\{\d{5,32}\}/, '').trim();

function resolveCatName(catId: number, categories: Category[], snapshots?: {id: number; name: string}[] | null): { name: string; isOrphaned: boolean } {
  const cat = categories.find(c => c.id === catId);
  if (cat) return { name: cleanName(cat.name), isOrphaned: false };
  if (snapshots) {
    const snap = snapshots.find(s => s.id === catId);
    if (snap) return { name: cleanName(snap.name), isOrphaned: true };
  }
  return { name: `Deleted Category (ID ${catId})`, isOrphaned: true };
}

const OrphanBadge = () => <span className="tc-badge-orphan">Deleted</span>;

const fmtDate = (d: string | null, tz?: string) => {
  if (!d) return '—';
  try { return new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: tz || TZ }); }
  catch { return new Date(d).toLocaleString(); }
};

const toLocalInput = (utc: string, tz: string): string => {
  if (!utc) return '';
  try {
    const d = new Date(utc);
    const parts = new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false, timeZone: tz }).formatToParts(d);
    const g = (t: string) => parts.find(p => p.type === t)?.value || '00';
    return `${g('year')}-${g('month')}-${g('day')}T${g('hour')}:${g('minute')}`;
  } catch { return new Date(utc).toISOString().slice(0, 16); }
};

const fromLocalInput = (local: string, tz: string): string => {
  if (!local) return '';
  try {
    const iso = local.length === 16 ? local + ':00' : local;
    const formatter = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'longOffset' });
    const now = new Date();
    const offsetStr = formatter.formatToParts(now).find(p => p.type === 'timeZoneName')?.value || '+00:00';
    const offset = offsetStr.replace('GMT', '') || '+00:00';
    return new Date(iso + offset).toISOString();
  } catch { return local; }
};

const Icon = ({ name, size = 14 }: { name: string; size?: number }) => {
  const s = size;
  const icons: Record<string, React.ReactNode> = {
    flag:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
    file:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
    chart:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
    list:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
    plus:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    edit:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
    trash:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>,
    play:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>,
    stop:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg>,
    eye:     <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
    key:     <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>,
    copy:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>,
    back:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>,
    clock:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
    users:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>,
    send:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
    dots:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>,
    target:  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
    x:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    refresh: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>,
    check:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>,
    hash:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>,
    link:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>,
    shield:  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
    download:<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
    warning: <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
  };
  return <span className="cp-icon">{icons[name] || null}</span>;
};

const StatusBadge = ({ status }: { status: string }) => {
  const s = STATUS_MAP[status] || STATUS_MAP.draft;
  return <span className="cp-status-badge" style={{ color: s.color, background: s.bg }}><span className="cp-status-dot" style={{ background: s.color }} />{s.label}</span>;
};

const EmptyState = ({ icon, title, sub, action }: { icon: string; title: string; sub?: string; action?: React.ReactNode }) => (
  <div className="cp-empty">
    <div className="cp-empty-icon"><Icon name={icon} /></div>
    <p>{title}</p>
    {sub && <span>{sub}</span>}
    {action}
  </div>
);

const BackButton = ({ onBack, label = 'Back' }: { onBack: () => void; label?: string }) => (
  <button className="cp-back-btn" onClick={onBack}><Icon name="back" size={16} />{label}</button>
);

const SectionCard = ({ title, icon, children, accent }: { title: string; icon: string; children: React.ReactNode; accent?: string }) => (
  <div className="tc-section">
    <div className="tc-section-hdr">
      <span className="tc-section-icon" style={accent ? { color: accent } : {}}><Icon name={icon} size={15} /></span>
      <h4 className="tc-section-title">{title}</h4>
    </div>
    <div className="tc-section-body">{children}</div>
  </div>
);

const FieldLabel = ({ text, helper }: { text: string; helper?: string }) => (
  <div className="tc-field-label">
    <span>{text}</span>
    {helper && <span className="tc-field-helper">{helper}</span>}
  </div>
);

export default function TrialCampaigns() {
  const [nav, setNav] = useState<Nav>({ screen: 'home' });
  const [homeTab, setHomeTab] = useState<HomeTab>('campaigns');
  const [flash, setFlash] = useState('');
  const [campaigns, setCampaigns] = useState<TrialCampaign[]>([]);
  const [templates, setTemplates] = useState<TrialTemplate[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [promoCampaigns, setPromoCampaigns] = useState<PromoCampaign[]>([]);

  const onFlash = (msg: string) => { setFlash(msg); setTimeout(() => setFlash(''), 3000); };

  const load = useCallback(async () => {
    try {
      const [camps, cats, chans, promos] = await Promise.all([
        apiGet('/trial-campaigns'),
        apiGet('/categories'),
        apiGet('/channels').catch(() => []),
        apiGet('/campaigns').catch(() => []),
      ]);
      setCampaigns(camps);
      setCategories(cats);
      setChannels(Array.isArray(chans) ? chans : (chans.channels || []));
      setPromoCampaigns(Array.isArray(promos) ? promos : []);
    } catch {}
  }, []);

  const loadTemplates = useCallback(async () => {
    try {
      const data = await apiGet('/campaigns/templates?type=trial');
      setTemplates(data);
    } catch {}
  }, []);

  useEffect(() => {
    load();
    loadTemplates();
    apiPost('/trial-campaigns/seed-defaults', {}).catch(() => {});
  }, []);

  const stats = {
    total: campaigns.length,
    active: campaigns.filter(c => c.status === 'active').length,
    scheduled: campaigns.filter(c => c.status === 'scheduled').length,
    enabled: campaigns.filter(c => c.is_enabled).length,
    totalRuns: campaigns.reduce((s, c) => s + (Number(c.total_runs) || 0), 0),
    startTpls: templates.filter(t => t.template_type === 'trial_start').length,
    expireTpls: templates.filter(t => t.template_type === 'trial_expire').length,
    totalTpls: templates.length,
  };

  if (nav.screen === 'campaign-form') {
    return <CampaignFormScreen nav={nav} setNav={setNav} categories={categories} templates={templates}
      channels={channels} promoCampaigns={promoCampaigns} onFlash={onFlash} load={load} flash={flash} />;
  }

  if (nav.screen === 'template-form') {
    return <TemplateFormScreen nav={nav} setNav={setNav} onFlash={onFlash} loadTemplates={loadTemplates} flash={flash} />;
  }

  if (nav.screen === 'detail') {
    return <CampaignDetailScreen campaignId={nav.campaignId} setNav={setNav} categories={categories}
      templates={templates} channels={channels} onFlash={onFlash} load={load} flash={flash} />;
  }

  const catNameMap = Object.fromEntries(categories.map(c => [c.id, cleanName(c.name)]));

  return (
    <div className="cp-screen">
      {flash && <div className="toast-msg" style={{ position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)', zIndex: 999 }}>{flash}</div>}

      <div className="cp-home-hdr">
        <h2 className="cp-home-title">Trial Campaigns</h2>
        <p className="cp-home-sub">One key per category per run — trial campaigns, templates, keys & logs</p>
        <div className="cp-home-ctas">
          <button className="btn-primary-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: null })}>
            <Icon name="plus" /> New Campaign
          </button>
          <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'template-form', template: null })}>
            <Icon name="file" /> New Template
          </button>
        </div>
      </div>

      <div className="cp-stat-grid cp-stat-grid--4col" style={{ padding: '0 20px', marginBottom: 12 }}>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.total}</span><span className="cp-stat-card-l">Campaigns</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: 'var(--c-emerald)' }}>{stats.active}</span><span className="cp-stat-card-l">Active</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.scheduled}</span><span className="cp-stat-card-l">Scheduled</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.totalRuns}</span><span className="cp-stat-card-l">Total Runs</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.totalTpls}</span><span className="cp-stat-card-l">Templates</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: 'var(--c-emerald)' }}>{stats.startTpls}</span><span className="cp-stat-card-l">Start Tpls</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: '#f97316' }}>{stats.expireTpls}</span><span className="cp-stat-card-l">Expire Tpls</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.enabled}</span><span className="cp-stat-card-l">Enabled</span></div>
      </div>

      <div className="cp-tab-bar">
        {(['campaigns', 'templates', 'apk-captions', 'keys', 'logs', 'analytics'] as HomeTab[]).map(t => (
          <button key={t} className={`cp-tab-btn${homeTab === t ? ' active' : ''}`} onClick={() => setHomeTab(t)}>
            <Icon name={t === 'campaigns' ? 'flag' : t === 'templates' ? 'file' : t === 'apk-captions' ? 'send' : t === 'keys' ? 'key' : t === 'logs' ? 'list' : 'chart'} size={13} />
            {t === 'campaigns' ? `Campaigns (${campaigns.length})` :
             t === 'templates' ? `Templates (${templates.length})` :
             t === 'apk-captions' ? 'APK Captions' :
             t === 'keys' ? 'Keys' : t === 'logs' ? 'Runs & Logs' : 'Analytics'}
          </button>
        ))}
      </div>

      <div className="cp-tab-content">
        {homeTab === 'campaigns' && (
          <div className="cp-card-list" style={{ padding: '14px 20px 60px' }}>
            {campaigns.length === 0
              ? <EmptyState icon="flag" title="No trial campaigns yet" sub="Create your first trial campaign"
                  action={<button className="btn-primary-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: null })} style={{ marginTop: 12 }}><Icon name="plus" /> Create Campaign</button>} />
              : campaigns.map(c => (
                <TrialCampaignCard key={c.id} c={c} catNameMap={catNameMap} categories={categories} setNav={setNav} onFlash={onFlash} load={load} />
              ))
            }
          </div>
        )}

        {homeTab === 'templates' && (
          <div className="cp-card-list" style={{ padding: '14px 20px 60px' }}>
            {templates.length === 0
              ? <EmptyState icon="file" title="No trial templates yet" sub="Create start/expire message templates"
                  action={<button className="btn-primary-sm" onClick={() => setNav({ screen: 'template-form', template: null })} style={{ marginTop: 12 }}><Icon name="plus" /> Create Template</button>} />
              : templates.map(t => (
                <TrialTemplateCard key={t.id} t={t} setNav={setNav} onFlash={onFlash} loadTemplates={loadTemplates} />
              ))
            }
          </div>
        )}

        {homeTab === 'apk-captions' && (
          <div style={{ padding: '14px 20px 60px' }}>
            <ApkCaptionsPanel categories={categories} onFlash={onFlash} />
          </div>
        )}

        {homeTab === 'keys' && (
          <div style={{ padding: '14px 20px 60px' }}>
            <KeysPanel categories={categories} onFlash={onFlash} />
          </div>
        )}

        {homeTab === 'logs' && (
          <div style={{ padding: '14px 20px 60px' }}>
            <LogsPanel campaigns={campaigns} onFlash={onFlash} />
          </div>
        )}

        {homeTab === 'analytics' && (
          <div style={{ padding: '14px 20px 60px' }}>
            <AnalyticsPanel campaigns={campaigns} stats={stats} />
          </div>
        )}
      </div>
    </div>
  );
}

function TrialCampaignActionMenu({ c, onEdit, onToggle, onDelete, onDetail }: any) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);
  const act = (fn: () => void) => { setOpen(false); fn(); };
  return (
    <div className="cp-menu-wrap" ref={ref}>
      <button className="cp-menu-btn" onClick={() => setOpen(o => !o)} title="More actions"><Icon name="dots" size={16} /></button>
      {open && (
        <div className="cp-menu-dd">
          <button className="cp-menu-item" onClick={() => act(onDetail)}><Icon name="eye" size={13} /> Details</button>
          <button className="cp-menu-item" onClick={() => act(onEdit)}><Icon name="edit" size={13} /> Edit</button>
          <button className="cp-menu-item" onClick={() => act(onToggle)}>
            <Icon name={c.is_enabled ? 'stop' : 'play'} size={13} /> {c.is_enabled ? 'Disable' : 'Enable'}
          </button>
          <div className="cp-menu-sep" />
          <button className="cp-menu-item danger" onClick={() => act(onDelete)}><Icon name="trash" size={13} /> Delete</button>
        </div>
      )}
    </div>
  );
}

function TrialCampaignCard({ c, catNameMap, categories, setNav, onFlash, load }: any) {
  let catIds: number[] = [];
  try { catIds = JSON.parse(c.category_ids_json || '[]'); } catch {}
  let campCatSnaps: {id: number; name: string}[] | null = null;
  try { campCatSnaps = JSON.parse(c.category_names_snapshot_json || 'null'); } catch {}
  const scopeLabel = catIds.length ? catIds.map((id: number) => {
    const r = resolveCatName(id, categories, campCatSnaps);
    return r.name + (r.isOrphaned ? ' ⚠' : '');
  }).join(', ') : 'All categories';
  const audienceInfo = AUDIENCE_MAP[c.target_audience] || { label: c.target_audience, icon: 'users' };

  const handleToggle = async () => {
    try {
      const newEnabled = !c.is_enabled;
      const updates: any = { is_enabled: newEnabled };
      if (newEnabled && (c.status === 'draft' || c.status === 'expired')) updates.status = 'scheduled';
      await apiPut(`/trial-campaigns/${c.id}`, updates);
      onFlash(newEnabled ? 'Campaign enabled' : 'Campaign disabled');
      load();
    } catch (e: any) { onFlash(e?.message || 'Failed'); }
  };

  const handleDelete = () => {
    if (!confirm('Delete this trial campaign?')) return;
    apiDelete(`/trial-campaigns/${c.id}`).then(() => { onFlash('Campaign deleted'); load(); }).catch((e: any) => onFlash(e?.message || 'Failed'));
  };

  return (
    <div className={`cp-camp-card2${c.status === 'active' ? ' is-active' : ''}`}>
      <div className="cp-camp-card2-top">
        <div style={{ minWidth: 0, flex: 1 }}>
          <h4 className="cp-camp-card2-name">{c.name}</h4>
          <div className="cp-camp-card2-tags">
            <StatusBadge status={c.status} />
            <span className="cp-tag"><Icon name={audienceInfo.icon} size={10} /> {audienceInfo.label}</span>
            <span className="cp-tag">{REPEAT_MAP[c.repeat_mode] || c.repeat_mode}</span>
            {c.send_to_users && <span className="cp-tag" style={{ color: 'var(--c-emerald)', background: 'var(--c-emerald-surface)' }}>Users</span>}
            {c.send_to_channels && <span className="cp-tag" style={{ color: 'var(--c-accent-bright)', background: 'var(--c-accent-surface)' }}>Channels</span>}
          </div>
        </div>
        <TrialCampaignActionMenu c={c}
          onEdit={() => setNav({ screen: 'campaign-form', campaign: c })}
          onToggle={handleToggle}
          onDelete={handleDelete}
          onDetail={() => setNav({ screen: 'detail', campaignId: c.id })} />
      </div>

      <div className="cp-camp-card2-perf">
        <div className="cp-camp-perf-stat">
          <span className="cp-camp-perf-v">{c.trial_duration_hours}h</span>
          <span className="cp-camp-perf-l">Duration</span>
        </div>
        <div className="cp-camp-perf-stat">
          <span className="cp-camp-perf-v">{catIds.length}</span>
          <span className="cp-camp-perf-l">Categories</span>
        </div>
        <div className="cp-camp-perf-stat">
          <span className="cp-camp-perf-v accent">{c.total_runs || 0}</span>
          <span className="cp-camp-perf-l">Runs</span>
        </div>
      </div>

      <div className="cp-camp-card2-meta">
        <div className="cp-camp-meta-item">Start <span>{fmtDate(c.start_at, c.timezone)}</span></div>
        <div className="cp-camp-meta-item">Expire <span>{fmtDate(c.expire_at, c.timezone)}</span></div>
        {c.next_run_at && <div className="cp-camp-meta-item">Next run <span>{fmtDate(c.next_run_at, c.timezone)}</span></div>}
        <div className="cp-camp-meta-item">Scope <span>{scopeLabel}</span></div>
      </div>

      {(c.start_template_name || c.expire_template_name) && (
        <div className="cp-camp-tpl" style={{ marginTop: 8 }}>
          <Icon name="file" />
          {c.start_template_name && <span>Start: {c.start_template_name}</span>}
          {c.expire_template_name && <><span className="cp-camp-tpl-sep">·</span><span>Expire: {c.expire_template_name}</span></>}
        </div>
      )}

      {c.linked_promo_name && (
        <div style={{ fontSize: '.72rem', color: 'var(--c-accent-bright)', marginTop: 6 }}>
          <Icon name="link" size={11} /> Linked promo: {c.linked_promo_name}
        </div>
      )}

      <div className="cp-camp-card2-acts">
        <button className="btn-primary-sm" onClick={() => setNav({ screen: 'detail', campaignId: c.id })} style={{ flex: 1 }}><Icon name="eye" /> Details</button>
        <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: c })}><Icon name="edit" /></button>
      </div>
    </div>
  );
}

function TrialTemplateCard({ t, setNav, onFlash, loadTemplates }: any) {
  const varCount = (t.body_text?.match(/\{[^}]+\}/g) || []).length;
  const btnCount = (() => { try { return t.inline_buttons_json ? JSON.parse(t.inline_buttons_json).length : 0; } catch { return 0; } })();

  const handleDelete = async () => {
    if (!confirm('Delete this template?')) return;
    try { await apiDelete(`/campaigns/templates/${t.id}`); onFlash('Template deleted'); loadTemplates(); }
    catch (e: any) { onFlash(e?.message || 'Failed'); }
  };

  const handleDuplicate = () => {
    setNav({ screen: 'template-form', template: { ...t, id: 0, name: `${t.name} (copy)` } });
  };

  return (
    <div className="cp-tpl-card2">
      <div className="cp-tpl-card2-top">
        <div style={{ flex: 1, minWidth: 0 }}>
          <h4 className="cp-tpl-name">{t.name}</h4>
          <div style={{ display: 'flex', gap: 6, marginTop: 4, alignItems: 'center', flexWrap: 'wrap' }}>
            <span className={`cp-type-badge ${t.template_type === 'trial_start' ? 'cp-type-start' : 'cp-type-expiry'}`}>
              {t.template_type === 'trial_start' ? 'trial start' : 'trial expire'}
            </span>
            {!t.is_active && <span style={{ fontSize: '.65rem', padding: '1px 6px', borderRadius: 4, background: 'var(--c-red-surface)', color: 'var(--c-red)' }}>Inactive</span>}
            <span className="cp-tpl-date">{fmtDate(t.updated_at || t.created_at)}</span>
          </div>
        </div>
        <div className="cp-tpl-acts">
          <button className="btn-ghost-sm" onClick={handleDuplicate} title="Duplicate"><Icon name="copy" /></button>
          <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'template-form', template: t })}><Icon name="edit" /></button>
          <button className="btn-danger-sm" onClick={handleDelete}><Icon name="trash" /></button>
        </div>
      </div>
      <div className="cp-tpl-preview">{t.body_text?.substring(0, 120)}{(t.body_text?.length || 0) > 120 ? '…' : ''}</div>
      <div style={{ display: 'flex', gap: 8, marginTop: 6, fontSize: '.7rem', color: 'var(--text-3)', flexWrap: 'wrap', alignItems: 'center' }}>
        <span>{varCount} variable{varCount !== 1 ? 's' : ''}</span>
        {btnCount > 0 && <span>· {btnCount} button{btnCount !== 1 ? 's' : ''}</span>}
        {t.edited_via && <span>· {t.edited_via === 'bot' ? '🤖' : '🌐'} {t.edited_via}</span>}
      </div>
    </div>
  );
}

function CampaignFormScreen({ nav, setNav, categories, templates, channels, promoCampaigns, onFlash, load, flash }: any) {
  const existing = nav.campaign as TrialCampaign | null;
  const isEdit = !!(existing?.id);
  const tz = existing?.timezone || TZ;

  let initCatIds: number[] = [];
  let initChTargets: number[] = [];
  let initApkCfg: ApkDeliveryConfig = { send_apks_enabled: true, categories: {} };
  let existingCatSnaps: {id: number; name: string}[] | null = null;
  if (existing) {
    try { initCatIds = JSON.parse(existing.category_ids_json || '[]'); } catch {}
    try { initChTargets = JSON.parse(existing.channel_targets_json || '[]'); } catch {}
    if (existing.apk_delivery_config_json) {
      try { initApkCfg = JSON.parse(existing.apk_delivery_config_json); } catch {}
    }
    try { existingCatSnaps = JSON.parse(existing.category_names_snapshot_json || 'null'); } catch {}
  }

  const [form, setForm] = useState({
    name: existing?.name || '',
    description: existing?.description || '',
    category_ids: initCatIds,
    trial_duration_hours: existing?.trial_duration_hours || 5,
    max_devices: existing?.max_devices || null as number | null,
    repeat_mode: existing?.repeat_mode || 'once',
    timezone: tz,
    start_at: existing?.start_at ? toLocalInput(existing.start_at, tz) : '',
    expire_at: existing?.expire_at ? toLocalInput(existing.expire_at, tz) : '',
    start_template_id: existing?.start_template_id || null as number | null,
    expire_template_id: existing?.expire_template_id || null as number | null,
    send_to_users: existing?.send_to_users ?? true,
    send_to_channels: existing?.send_to_channels ?? false,
    channel_targets_json: initChTargets,
    reveal_keys_in_channels: existing?.reveal_keys_in_channels ?? false,
    linked_promo_campaign_id: existing?.linked_promo_campaign_id || null as number | null,
    target_audience: existing?.target_audience || 'all_users',
    delivery_mode: existing?.delivery_mode || 'mode_1_separate',
    is_enabled: existing?.is_enabled ?? false,
    status: existing?.status || 'draft',
  });

  const [apkCfg, setApkCfg] = useState<ApkDeliveryConfig>(initApkCfg);
  const [catMedia, setCatMedia] = useState<CategoryWithMedia[]>([]);
  const [expandedCats, setExpandedCats] = useState<Set<number>>(new Set());

  const [inventory, setInventory] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [estimate, setEstimate] = useState<{ users: number; channels: number } | null>(null);
  const [activeSection, setActiveSection] = useState(0);

  useEffect(() => {
    apiGet('/trial-campaigns/categories-with-media').then(setCatMedia).catch(() => {});
  }, []);

  const startTpls = templates.filter((t: TrialTemplate) => t.template_type === 'trial_start');
  const expireTpls = templates.filter((t: TrialTemplate) => t.template_type === 'trial_expire');
  const validatedChannels = channels.filter((ch: Channel) => ch.is_validated && ch.is_enabled);

  const checkInventory = async (catIds: number[], durationHours: number) => {
    if (!catIds.length || !durationHours) return;
    try {
      const data = await apiGet(`/trial-campaigns/inventory-check?category_ids=${catIds.join(',')}&duration_hours=${durationHours}`);
      setInventory(data);
    } catch {}
  };

  const fetchEstimate = useCallback(async () => {
    try {
      const chIds = form.send_to_channels ? form.channel_targets_json.join(',') : '';
      const data = await apiGet(`/trial-campaigns/estimate-recipients?target_audience=${form.target_audience}&channel_ids=${chIds}`);
      setEstimate(data);
    } catch {}
  }, [form.target_audience, form.send_to_channels, form.channel_targets_json]);

  useEffect(() => {
    if (initCatIds.length && (existing?.trial_duration_hours || form.trial_duration_hours)) {
      checkInventory(initCatIds, existing?.trial_duration_hours || form.trial_duration_hours);
    }
    fetchEstimate();
  }, []);

  useEffect(() => { fetchEstimate(); }, [form.target_audience, form.send_to_channels, form.channel_targets_json.length]);

  const toggleCategory = (catId: number) => {
    const ids = form.category_ids.includes(catId) ? form.category_ids.filter(id => id !== catId) : [...form.category_ids, catId];
    setForm({ ...form, category_ids: ids });
    checkInventory(ids, form.trial_duration_hours);
  };

  const toggleChannel = (chId: number) => {
    const ids = form.channel_targets_json.includes(chId) ? form.channel_targets_json.filter(id => id !== chId) : [...form.channel_targets_json, chId];
    setForm({ ...form, channel_targets_json: ids });
  };

  const hasLowStock = inventory.some(inv => inv.available === 0);

  const startISO = form.start_at ? fromLocalInput(form.start_at, form.timezone) : '';
  const expireISO = form.expire_at ? fromLocalInput(form.expire_at, form.timezone) : '';

  const handleSave = async () => {
    if (!form.name) return onFlash('Campaign name is required');
    if (!form.category_ids.length) return onFlash('Select at least one category');
    if (!form.start_at) return onFlash('Start time is required');
    if (!form.expire_at) return onFlash('Expire time is required');
    if (expireISO && startISO && new Date(expireISO) <= new Date(startISO)) return onFlash('Expire time must be after start time');
    if (form.send_to_channels && form.channel_targets_json.length === 0) return onFlash('Select at least one channel or disable channel delivery');
    if (form.target_audience === 'channels' && !form.send_to_channels) return onFlash('Enable channel delivery for Channels Only audience');
    setSaving(true);
    try {
      const body: any = { ...form, start_at: startISO, expire_at: expireISO, apk_delivery_config_json: apkCfg };
      if (isEdit) {
        await apiPut(`/trial-campaigns/${existing!.id}`, body);
        onFlash('Campaign updated');
      } else {
        await apiPost('/trial-campaigns', body);
        onFlash('Campaign created');
      }
      load();
      setNav({ screen: 'home' });
    } catch (e: any) { onFlash(e?.message || 'Save failed'); }
    setSaving(false);
  };

  const audienceInfo = AUDIENCE_MAP[form.target_audience] || AUDIENCE_MAP.all_users;
  const startTplName = startTpls.find((t: TrialTemplate) => t.id === form.start_template_id)?.name || 'Default';
  const expireTplName = expireTpls.find((t: TrialTemplate) => t.id === form.expire_template_id)?.name || 'Default';

  const sections = ['Basic Info', 'Trial Rules', 'Schedule', 'Audience', 'Delivery', 'APK Delivery', 'Delivery Mode', 'Templates', 'Linked Promo', 'Review'];

  const getCatConfig = (catId: number): ApkDeliveryCatConfig => {
    return apkCfg.categories[String(catId)] || { send_enabled: true, files: {} };
  };
  const setCatConfig = (catId: number, update: Partial<ApkDeliveryCatConfig>) => {
    setApkCfg(prev => ({
      ...prev,
      categories: { ...prev.categories, [String(catId)]: { ...getCatConfig(catId), ...update } },
    }));
  };
  const getFileConfig = (catId: number, fileId: string): ApkDeliveryFileConfig => {
    const cat = getCatConfig(catId);
    return cat.files[fileId] || { send_enabled: true };
  };
  const setFileConfig = (catId: number, fileId: string, enabled: boolean) => {
    const cat = getCatConfig(catId);
    setApkCfg(prev => ({
      ...prev,
      categories: {
        ...prev.categories,
        [String(catId)]: { ...cat, files: { ...cat.files, [fileId]: { send_enabled: enabled } } },
      },
    }));
  };

  const selectedCatMedia = catMedia.filter(c => form.category_ids.includes(c.id));
  const enabledCatCount = selectedCatMedia.filter(c => getCatConfig(c.id).send_enabled).length;
  const totalFilesCount = selectedCatMedia.filter(c => c.has_apk).length;
  const enabledFilesCount = selectedCatMedia.filter(c => c.has_apk && getCatConfig(c.id).send_enabled && (c.file_id ? getFileConfig(c.id, c.file_id).send_enabled : true)).length;

  const bulkSetCategories = (enabled: boolean) => {
    const cats = { ...apkCfg.categories };
    selectedCatMedia.forEach(c => {
      cats[String(c.id)] = { ...getCatConfig(c.id), send_enabled: enabled };
    });
    setApkCfg(prev => ({ ...prev, categories: cats }));
  };
  const bulkSetFiles = (enabled: boolean) => {
    const cats = { ...apkCfg.categories };
    selectedCatMedia.forEach(c => {
      if (c.has_apk && c.file_id) {
        const cc = getCatConfig(c.id);
        cats[String(c.id)] = { ...cc, files: { ...cc.files, [c.file_id]: { send_enabled: enabled } } };
      }
    });
    setApkCfg(prev => ({ ...prev, categories: cats }));
  };
  const bulkSetCatFiles = (catId: number, enabled: boolean) => {
    const cm = catMedia.find(c => c.id === catId);
    if (cm?.file_id) setFileConfig(catId, cm.file_id, enabled);
  };
  const resetApkDefaults = () => {
    setApkCfg({ send_apks_enabled: true, categories: {} });
  };

  return (
    <div className="cp-screen">
      {flash && <div className="toast-msg" style={{ position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)', zIndex: 999 }}>{flash}</div>}
      <div className="cp-screen-hdr">
        <BackButton onBack={() => setNav({ screen: 'home' })} />
        <h3 className="cp-screen-title" style={{ margin: 0 }}>{isEdit ? 'Edit' : 'Create'} Trial Campaign</h3>
      </div>

      <div className="tc-form-nav">
        {sections.map((s, i) => (
          <button key={s} className={`tc-form-nav-btn${activeSection === i ? ' active' : ''}`} onClick={() => setActiveSection(i)}>
            <span className="tc-form-nav-num">{i + 1}</span>{s}
          </button>
        ))}
      </div>

      <div className="tc-form-body">
        {activeSection === 0 && (
          <SectionCard title="Basic Info" icon="flag" accent="var(--c-accent-bright)">
            <FieldLabel text="Campaign Name" helper="A descriptive name for this trial campaign" />
            <input className="tc-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Weekend Trial Drop" />
            <FieldLabel text="Description" helper="Optional internal notes" />
            <textarea className="tc-input tc-textarea" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Internal campaign description..." />
          </SectionCard>
        )}

        {activeSection === 1 && (
          <SectionCard title="Trial Rules" icon="shield" accent="var(--c-emerald)">
            <FieldLabel text="Categories" helper="One trial key consumed per category per run" />
            <div className="tc-chip-grid">
              {categories.map((c: Category) => (
                <button key={c.id} className={`tc-chip${form.category_ids.includes(c.id) ? ' selected' : ''}`} onClick={() => toggleCategory(c.id)}>
                  {form.category_ids.includes(c.id) && <Icon name="check" size={12} />}
                  {cleanName(c.name)}
                </button>
              ))}
              {form.category_ids.filter(id => !categories.find(c => c.id === id)).map(id => (
                <button key={`orphan-${id}`} className="tc-chip selected tc-chip--orphan" onClick={() => toggleCategory(id)}>
                  <Icon name="check" size={12} />
                  {resolveCatName(id, categories, existingCatSnaps).name}
                  <OrphanBadge />
                </button>
              ))}
            </div>

            {inventory.length > 0 && (
              <div className={`tc-inventory-box${hasLowStock ? ' tc-inventory-warn' : ''}`}>
                <div className="tc-inventory-hdr">
                  <Icon name="key" size={13} />
                  Inventory ({form.trial_duration_hours}h keys)
                  {hasLowStock && <span className="tc-inventory-alert">Low stock!</span>}
                </div>
                {inventory.map((inv: any, i: number) => (
                  <div key={i} className="tc-inventory-row">
                    <span>{inv.categoryDisplayName}</span>
                    <span className={`tc-inventory-count ${inv.available === 0 ? 'danger' : inv.available <= 3 ? 'warn' : 'ok'}`}>
                      {inv.available} available{inv.available === 0 ? ' — OUT OF STOCK' : inv.available <= 3 ? ' — LOW' : ''}
                    </span>
                  </div>
                ))}
              </div>
            )}

            <div className="tc-row-2">
              <div>
                <FieldLabel text="Trial Duration" helper="Hours the trial key is valid" />
                <input className="tc-input" type="number" value={form.trial_duration_hours}
                  onChange={e => { const v = parseInt(e.target.value) || 1; setForm({ ...form, trial_duration_hours: v }); checkInventory(form.category_ids, v); }} />
              </div>
              <div>
                <FieldLabel text="Max Devices" helper="Optional device limit" />
                <input className="tc-input" type="number" value={form.max_devices || ''} onChange={e => setForm({ ...form, max_devices: parseInt(e.target.value) || null })} placeholder="Unlimited" />
              </div>
            </div>
          </SectionCard>
        )}

        {activeSection === 2 && (
          <SectionCard title="Schedule" icon="clock" accent="#f97316">
            <div className="tc-row-2">
              <div>
                <FieldLabel text="Start Time" helper={`Timezone: ${form.timezone}`} />
                <input className="tc-input" type="datetime-local" value={form.start_at} onChange={e => setForm({ ...form, start_at: e.target.value })} />
              </div>
              <div>
                <FieldLabel text="Expire Time" helper={`Timezone: ${form.timezone}`} />
                <input className="tc-input" type="datetime-local" value={form.expire_at} onChange={e => setForm({ ...form, expire_at: e.target.value })} />
              </div>
            </div>

            <FieldLabel text="Repeat Mode" />
            <div className="tc-chip-grid">
              {(['once', 'daily', 'weekly', 'monthly'] as const).map(m => (
                <button key={m} className={`tc-chip${form.repeat_mode === m ? ' selected' : ''}`} onClick={() => setForm({ ...form, repeat_mode: m })}>
                  {form.repeat_mode === m && <Icon name="check" size={12} />}
                  {REPEAT_MAP[m]}
                </button>
              ))}
            </div>

            {(form.start_at || form.expire_at) && (
              <div className="tc-schedule-preview">
                <div className="tc-schedule-preview-hdr"><Icon name="clock" size={13} /> Schedule Preview</div>
                <div className="tc-schedule-preview-row"><span>Start:</span><b>{form.start_at ? fmtDate(fromLocalInput(form.start_at, form.timezone), form.timezone) : '—'}</b></div>
                <div className="tc-schedule-preview-row"><span>Expire:</span><b>{form.expire_at ? fmtDate(fromLocalInput(form.expire_at, form.timezone), form.timezone) : '—'}</b></div>
                <div className="tc-schedule-preview-row"><span>Timezone:</span><b>{form.timezone}</b></div>
                <div className="tc-schedule-preview-row"><span>Repeat:</span><b>{REPEAT_MAP[form.repeat_mode]}</b></div>
                {form.start_at && <div className="tc-schedule-preview-row"><span>Next Run:</span><b>{fmtDate(fromLocalInput(form.start_at, form.timezone), form.timezone)}</b></div>}
                {form.expire_at && <div className="tc-schedule-preview-row"><span>Next Expire:</span><b>{fmtDate(fromLocalInput(form.expire_at, form.timezone), form.timezone)}</b></div>}
              </div>
            )}
          </SectionCard>
        )}

        {activeSection === 3 && (
          <SectionCard title="Audience Target" icon="target" accent="var(--c-accent-bright)">
            <FieldLabel text="Target Audience" helper="Who should receive this trial" />
            <div className="tc-audience-grid">
              {Object.entries(AUDIENCE_MAP).map(([key, info]) => (
                <button key={key} className={`tc-audience-card${form.target_audience === key ? ' selected' : ''}`}
                  onClick={() => {
                    const updates: any = { target_audience: key };
                    if (key === 'channels') { updates.send_to_channels = true; updates.send_to_users = false; }
                    setForm({ ...form, ...updates });
                  }}>
                  <div className="tc-audience-card-icon"><Icon name={info.icon} size={18} /></div>
                  <div className="tc-audience-card-label">{info.label}</div>
                  <div className="tc-audience-card-desc">{info.desc}</div>
                  {form.target_audience === key && <div className="tc-audience-card-check"><Icon name="check" size={14} /></div>}
                </button>
              ))}
            </div>

            {estimate && (
              <div className="tc-estimate-bar">
                <Icon name="users" size={13} />
                <span>Estimated: <b>{form.send_to_users ? `${estimate.users} users` : '0 users'}</b></span>
                {form.send_to_channels && <span>+ <b>{estimate.channels} channels</b></span>}
              </div>
            )}
          </SectionCard>
        )}

        {activeSection === 4 && (
          <SectionCard title="Delivery Options" icon="send" accent="var(--c-emerald)">
            <div className="tc-toggle-row">
              <label className="tc-toggle">
                <input type="checkbox" checked={form.send_to_users} onChange={e => setForm({ ...form, send_to_users: e.target.checked })} />
                <span className="tc-toggle-slider" />
              </label>
              <div>
                <div className="tc-toggle-label">Send to Users</div>
                <div className="tc-toggle-desc">Deliver trial messages to individual users via bot DM</div>
              </div>
            </div>

            <div className="tc-toggle-row">
              <label className="tc-toggle">
                <input type="checkbox" checked={form.send_to_channels} onChange={e => setForm({ ...form, send_to_channels: e.target.checked })} />
                <span className="tc-toggle-slider" />
              </label>
              <div>
                <div className="tc-toggle-label">Send to Channels</div>
                <div className="tc-toggle-desc">Post trial announcement to selected Telegram channels</div>
              </div>
            </div>

            {form.send_to_channels && (
              <>
                <div className="tc-toggle-row" style={{ paddingLeft: 8, borderLeft: '2px solid var(--c-accent)' }}>
                  <label className="tc-toggle">
                    <input type="checkbox" checked={form.reveal_keys_in_channels} onChange={e => setForm({ ...form, reveal_keys_in_channels: e.target.checked })} />
                    <span className="tc-toggle-slider" />
                  </label>
                  <div>
                    <div className="tc-toggle-label">Reveal Keys in Channels</div>
                    <div className="tc-toggle-desc">Show actual key values in channel messages (otherwise directs users to bot)</div>
                  </div>
                </div>

                <FieldLabel text="Select Channels" helper={`${validatedChannels.length} validated channels available`} />
                {validatedChannels.length === 0 ? (
                  <div className="tc-empty-hint">No validated channels. Add and validate channels in Channel Configuration first.</div>
                ) : (
                  <div className="tc-channel-grid">
                    {validatedChannels.map((ch: Channel) => {
                      const selected = form.channel_targets_json.includes(ch.id);
                      return (
                        <button key={ch.id} className={`tc-channel-chip${selected ? ' selected' : ''}`} onClick={() => toggleChannel(ch.id)}>
                          <div className="tc-channel-chip-icon">{selected ? <Icon name="check" size={14} /> : <Icon name="hash" size={14} />}</div>
                          <div className="tc-channel-chip-info">
                            <span className="tc-channel-chip-name">{ch.name || ch.channel_name || `Channel #${ch.id}`}</span>
                            {ch.channel_username && <span className="tc-channel-chip-user">@{ch.channel_username}</span>}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
                {form.send_to_channels && form.channel_targets_json.length === 0 && validatedChannels.length > 0 && (
                  <div className="tc-validation-msg">Select at least one channel for channel delivery</div>
                )}
              </>
            )}
          </SectionCard>
        )}

        {activeSection === 5 && (
          <SectionCard title="APK Delivery Controls" icon="download" accent="#f43f5e">
            <div className="tc-toggle-row">
              <label className="tc-toggle">
                <input type="checkbox" checked={apkCfg.send_apks_enabled}
                  onChange={e => setApkCfg(prev => ({ ...prev, send_apks_enabled: e.target.checked }))} />
                <span className="tc-toggle-slider" />
              </label>
              <div>
                <div className="tc-toggle-label">Send APK / Documents</div>
                <div className="tc-toggle-desc">Controls whether category APK/document files are sent before the trial summary message.</div>
              </div>
            </div>

            {apkCfg.send_apks_enabled && (
              <>
                <div className="tc-apk-summary-bar">
                  <span>{enabledCatCount}/{selectedCatMedia.length} categories enabled</span>
                  <span className="tc-apk-summary-sep">|</span>
                  <span>{enabledFilesCount}/{totalFilesCount} files will send</span>
                </div>

                <div className="tc-apk-bulk-row">
                  <button type="button" className="btn-ghost-xs" onClick={() => bulkSetCategories(true)}>Enable All Categories</button>
                  <button type="button" className="btn-ghost-xs" onClick={() => bulkSetCategories(false)}>Disable All Categories</button>
                  <button type="button" className="btn-ghost-xs" onClick={() => bulkSetFiles(true)}>Enable All Files</button>
                  <button type="button" className="btn-ghost-xs" onClick={() => bulkSetFiles(false)}>Disable All Files</button>
                  <button type="button" className="btn-ghost-xs tc-btn-reset" onClick={resetApkDefaults}>Reset to Default</button>
                </div>

                {selectedCatMedia.length === 0 ? (
                  <div className="tc-empty-hint">No categories selected. Go to Trial Rules to select categories.</div>
                ) : (
                  <div className="tc-apk-cat-list">
                    {selectedCatMedia.map(cm => {
                      const cc = getCatConfig(cm.id);
                      const isExpanded = expandedCats.has(cm.id);
                      const fileEnabled = cm.file_id ? getFileConfig(cm.id, cm.file_id).send_enabled : false;
                      const fileCt = cm.has_apk ? 1 : 0;
                      const enabledFCt = (cm.has_apk && cc.send_enabled && fileEnabled) ? 1 : 0;
                      return (
                        <div key={cm.id} className={`tc-apk-cat-card${!cc.send_enabled || !apkCfg.send_apks_enabled ? ' disabled' : ''}`}>
                          <div className="tc-apk-cat-header">
                            <label className="tc-toggle tc-toggle-sm">
                              <input type="checkbox" checked={cc.send_enabled}
                                onChange={e => setCatConfig(cm.id, { send_enabled: e.target.checked })} />
                              <span className="tc-toggle-slider" />
                            </label>
                            <div className="tc-apk-cat-info">
                              <span className="tc-apk-cat-name">{cm.name}</span>
                              <span className={`tc-apk-badge ${cm.has_apk ? 'tc-apk-badge-file' : 'tc-apk-badge-nofile'}`}>
                                {cm.has_apk ? 'Has File' : 'No File'}
                              </span>
                              {cm.has_apk && (
                                <span className="tc-apk-file-count">{enabledFCt}/{fileCt} file{fileCt !== 1 ? 's' : ''} enabled</span>
                              )}
                            </div>
                            {cm.has_apk && cc.send_enabled && (
                              <button type="button" className="btn-ghost-xs tc-apk-expand-btn"
                                onClick={() => setExpandedCats(prev => {
                                  const next = new Set(prev);
                                  next.has(cm.id) ? next.delete(cm.id) : next.add(cm.id);
                                  return next;
                                })}>
                                {isExpanded ? 'Collapse' : 'Manage Files'}
                              </button>
                            )}
                          </div>

                          {!cm.has_apk && cc.send_enabled && (
                            <div className="tc-apk-no-file-hint">No file configured for this category. File delivery will be skipped.</div>
                          )}

                          {isExpanded && cm.has_apk && cm.file_id && cc.send_enabled && (
                            <div className="tc-apk-file-list">
                              <div className="tc-apk-file-bulk">
                                <button type="button" className="btn-ghost-xs" onClick={() => bulkSetCatFiles(cm.id, true)}>Enable All</button>
                                <button type="button" className="btn-ghost-xs" onClick={() => bulkSetCatFiles(cm.id, false)}>Disable All</button>
                              </div>
                              <div className={`tc-apk-file-row${!fileEnabled ? ' disabled' : ''}`}>
                                <label className="tc-toggle tc-toggle-sm">
                                  <input type="checkbox" checked={fileEnabled}
                                    onChange={e => setFileConfig(cm.id, cm.file_id!, e.target.checked)} />
                                  <span className="tc-toggle-slider" />
                                </label>
                                <div className="tc-apk-file-info">
                                  <span className="tc-apk-file-name">{cm.name}</span>
                                  <span className="tc-apk-badge tc-apk-badge-type">APK</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}

            {!apkCfg.send_apks_enabled && (
              <div className="tc-apk-disabled-notice">
                <Icon name="warning" size={16} />
                <span>All APK/document file delivery is disabled. Only the summary trial start message will be sent.</span>
              </div>
            )}
          </SectionCard>
        )}

        {activeSection === 6 && (
          <SectionCard title="Delivery Mode" icon="send" accent="#8b5cf6">
            <div className="tc-toggle-desc" style={{ marginBottom: 16 }}>Choose how trial start messages and APK files are delivered to users. Only one mode can be active at a time.</div>
            {([
              { value: 'mode_1_separate', label: 'Separate Files + Separate Summary', desc: 'Sends every APK/document as its own message with caption and buttons, then sends the trial summary message as a separate final message.', msgs: form.category_ids.length > 0 ? form.category_ids.length + 1 : 1, preview: [...(form.category_ids.length > 0 ? form.category_ids.map((_, i) => `APK ${i + 1} + caption + buttons`) : []), 'Trial Summary + buttons'] },
              { value: 'mode_2_single_combined', label: 'Single Combined Delivery', desc: 'Sends all APK/document files as a Telegram media group, then sends one follow-up summary message with all merged inline buttons.', msgs: 2, preview: ['Media group: all APK/doc files with captions', 'Summary + all merged buttons'] },
              { value: 'mode_3_combined_plus_summary', label: 'Combined File Block + Separate Summary', desc: 'Sends all APK/document files as a Telegram media group with APK buttons attached, then sends a separate trial summary message with summary buttons.', msgs: 2, preview: ['Media group: all APK/doc files + APK buttons', 'Trial Summary + summary buttons'] },
            ] as const).map(mode => {
              const isActive = form.delivery_mode === mode.value;
              return (
                <button key={mode.value} type="button" className={`tc-dm-card${isActive ? ' active' : ''}`}
                  onClick={() => setForm({ ...form, delivery_mode: mode.value })}>
                  <div className="tc-dm-card-header">
                    <div className={`tc-dm-radio${isActive ? ' checked' : ''}`}>
                      {isActive && <div className="tc-dm-radio-dot" />}
                    </div>
                    <div className="tc-dm-card-title">{mode.label}</div>
                    <span className="tc-dm-badge">{mode.msgs} msg{mode.msgs !== 1 ? 's' : ''}</span>
                  </div>
                  <div className="tc-dm-card-desc">{mode.desc}</div>
                  {isActive && (
                    <div className="tc-dm-preview">
                      <div className="tc-dm-preview-title">Message Preview</div>
                      {mode.preview.map((line, idx) => (
                        <div key={idx} className="tc-dm-preview-msg">
                          <span className="tc-dm-preview-num">{idx + 1}</span>
                          <span>{line}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </button>
              );
            })}
            {form.delivery_mode !== 'mode_1_separate' && (
              <div className="tc-dm-note">
                <Icon name="warning" size={14} />
                <span>Combined delivery uses Telegram media groups for APK/doc files where supported. If buttons or summary content must be separate, the system sends a follow-up summary message.</span>
              </div>
            )}
          </SectionCard>
        )}

        {activeSection === 7 && (
          <SectionCard title="Templates" icon="file" accent="var(--c-accent-bright)">
            <div className="tc-row-2">
              <div>
                <FieldLabel text="Start Template" helper="Sent when trial begins" />
                <select className="tc-input tc-select" value={form.start_template_id || ''} onChange={e => setForm({ ...form, start_template_id: parseInt(e.target.value) || null })}>
                  <option value="">Default Template</option>
                  {startTpls.map((t: TrialTemplate) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
              <div>
                <FieldLabel text="Expire Template" helper="Sent when trial expires" />
                <select className="tc-input tc-select" value={form.expire_template_id || ''} onChange={e => setForm({ ...form, expire_template_id: parseInt(e.target.value) || null })}>
                  <option value="">Default Template</option>
                  {expireTpls.map((t: TrialTemplate) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            </div>
            {startTpls.length === 0 && expireTpls.length === 0 && (
              <div className="tc-empty-hint">No trial templates found. Default templates will be used. Create custom templates from the Templates tab.</div>
            )}
          </SectionCard>
        )}

        {activeSection === 8 && (
          <SectionCard title="Linked Promo Campaign" icon="link" accent="#f97316">
            <FieldLabel text="Linked Promo" helper="Automatically triggers after trial expires" />
            <select className="tc-input tc-select" value={form.linked_promo_campaign_id || ''} onChange={e => setForm({ ...form, linked_promo_campaign_id: parseInt(e.target.value) || null })}>
              <option value="">None — no linked promo</option>
              {promoCampaigns.map((pc: any) => <option key={pc.id} value={pc.id}>{pc.name}</option>)}
            </select>
            {form.linked_promo_campaign_id && (
              <div className="tc-linked-preview">
                <Icon name="check" size={13} /> After trial expires, promo campaign will be triggered automatically
              </div>
            )}
          </SectionCard>
        )}

        {activeSection === 9 && (
          <SectionCard title="Review & Save" icon="check" accent="var(--c-emerald)">
            <div className="tc-review-grid">
              <div className="tc-review-item"><span className="tc-review-label">Name</span><span className="tc-review-value">{form.name || '—'}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Categories</span><span className="tc-review-value">{form.category_ids.length ? form.category_ids.map(id => { const r = resolveCatName(id, categories, existingCatSnaps); return r.name + (r.isOrphaned ? ' (Deleted)' : ''); }).join(', ') : '—'}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Duration</span><span className="tc-review-value">{form.trial_duration_hours}h</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Max Devices</span><span className="tc-review-value">{form.max_devices || 'Unlimited'}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Audience</span><span className="tc-review-value">{audienceInfo.label}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Repeat</span><span className="tc-review-value">{REPEAT_MAP[form.repeat_mode]}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Start Template</span><span className="tc-review-value">{startTplName}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Expire Template</span><span className="tc-review-value">{expireTplName}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Send to Users</span><span className="tc-review-value">{form.send_to_users ? 'Yes' : 'No'}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Send to Channels</span><span className="tc-review-value">{form.send_to_channels ? `Yes (${form.channel_targets_json.length} selected)` : 'No'}</span></div>
              {form.linked_promo_campaign_id && <div className="tc-review-item"><span className="tc-review-label">Linked Promo</span><span className="tc-review-value">{promoCampaigns.find((p: any) => p.id === form.linked_promo_campaign_id)?.name || '—'}</span></div>}
              <div className="tc-review-item"><span className="tc-review-label">APK Delivery</span><span className="tc-review-value">{apkCfg.send_apks_enabled ? `ON (${enabledFilesCount}/${totalFilesCount} files)` : 'OFF'}</span></div>
              <div className="tc-review-item"><span className="tc-review-label">Delivery Mode</span><span className="tc-review-value">{form.delivery_mode === 'mode_1_separate' ? 'Separate Files + Summary' : form.delivery_mode === 'mode_2_single_combined' ? 'Single Combined' : 'Combined Files + Summary'}</span></div>
            </div>

            <div className="tc-schedule-preview" style={{ marginTop: 16 }}>
              <div className="tc-schedule-preview-hdr"><Icon name="clock" size={13} /> Schedule Confirmation</div>
              <div className="tc-schedule-preview-row"><span>Start:</span><b>{form.start_at ? fmtDate(fromLocalInput(form.start_at, form.timezone), form.timezone) : '—'}</b></div>
              <div className="tc-schedule-preview-row"><span>Expire:</span><b>{form.expire_at ? fmtDate(fromLocalInput(form.expire_at, form.timezone), form.timezone) : '—'}</b></div>
              <div className="tc-schedule-preview-row"><span>Timezone:</span><b>{form.timezone}</b></div>
              <div className="tc-schedule-preview-row"><span>Next Run:</span><b>{form.start_at ? fmtDate(fromLocalInput(form.start_at, form.timezone), form.timezone) : '—'}</b></div>
              <div className="tc-schedule-preview-row"><span>Next Expire:</span><b>{form.expire_at ? fmtDate(fromLocalInput(form.expire_at, form.timezone), form.timezone) : '—'}</b></div>
            </div>

            {estimate && (
              <div className="tc-estimate-bar" style={{ marginTop: 12 }}>
                <Icon name="users" size={13} />
                <span>Delivery: <b>{form.send_to_users ? `${estimate.users} users` : '0 users'}</b></span>
                {form.send_to_channels && <span>+ <b>{estimate.channels} channels</b></span>}
              </div>
            )}

            {hasLowStock && (
              <div className="tc-validation-msg" style={{ marginTop: 12 }}>
                Warning: Some categories have no available stock. The run will fail for those categories.
              </div>
            )}
          </SectionCard>
        )}

        <div className="tc-form-actions">
          <div className="tc-form-actions-nav">
            {activeSection > 0 && <button className="btn-ghost-sm" onClick={() => setActiveSection(s => s - 1)}><Icon name="back" size={14} /> Previous</button>}
            {activeSection < sections.length - 1 && (
              <button className="btn-primary-sm" onClick={() => setActiveSection(s => s + 1)} style={{ marginLeft: 'auto' }}>
                Next <span style={{ display: 'inline-block', transform: 'rotate(180deg)' }}><Icon name="back" size={14} /></span>
              </button>
            )}
          </div>
          <div className="tc-form-actions-save">
            <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'home' })}>Cancel</button>
            <button className="btn-primary-sm" onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : isEdit ? 'Update Campaign' : 'Create Campaign'}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function TcButtonBuilder({ buttons, setButtons, emptyHint }: { buttons: any[]; setButtons: (fn: (b: any[]) => any[]) => void; emptyHint?: string }) {
  const [advOpen, setAdvOpen] = useState<Record<string, boolean>>({});
  const add = () => setButtons(b => [...b, normalizeTcBtn({ text: '', url: 'https://', style: 'primary', icon_custom_emoji_id: '', row: 1, enabled: true })]);
  const upd = (i: number, k: string, v: any) => setButtons(b => { const nb = [...b]; nb[i] = { ...nb[i], [k]: v }; return nb; });
  const rm = (i: number) => setButtons(b => b.filter((_, j) => j !== i));
  const mv = (i: number, dir: -1 | 1) => setButtons(b => { const nb = [...b]; const j = i + dir; if (j < 0 || j >= nb.length) return nb; [nb[i], nb[j]] = [nb[j], nb[i]]; return nb; });
  return (
    <div className="ibe-wrap">
      {buttons.length === 0 && (
        <div className="ibe-empty">
          <span>No buttons configured</span>
          <span className="ibe-empty-hint">{emptyHint || 'Add link buttons that appear below the message'}</span>
        </div>
      )}
      {buttons.map((b, i) => {
        const isAdv = !!advOpen[b.id];
        const urlBad = b.url && !b.url.startsWith('http') && !b.url.startsWith('tg://');
        return (
          <div key={b.id || i} className={`ibe-row${b.enabled === false ? ' cp-btn-off' : ''}`}>
            <div className="ibe-row-head">
              <span className="ibe-row-num">Button {i + 1}</span>
              <div className="ibe-row-actions">
                {buttons.length > 1 && (<>
                  <button type="button" className="ibe-move" disabled={i === 0} onClick={() => mv(i, -1)}>↑</button>
                  <button type="button" className="ibe-move" disabled={i === buttons.length - 1} onClick={() => mv(i, 1)}>↓</button>
                </>)}
                <label className="cp-btn-on-lbl" title="Enable/disable">
                  <input type="checkbox" checked={b.enabled !== false} onChange={e => upd(i, 'enabled', e.target.checked)} />
                  <span>On</span>
                </label>
                <button type="button" className="ibe-remove" onClick={() => rm(i)}>×</button>
              </div>
            </div>
            <div className="ibe-fields">
              <div className="ibe-field">
                <label className="ibe-label">Name</label>
                <input className="tc-input" value={b.text} onChange={e => upd(i, 'text', e.target.value)} placeholder="Get Full Version" />
              </div>
              <div className="ibe-field">
                <label className="ibe-label">URL</label>
                <input className={`tc-input${urlBad ? ' err' : ''}`} value={b.url || ''} onChange={e => upd(i, 'url', e.target.value)} placeholder="https://..." />
                {urlBad && <span style={{ fontSize: '.7rem', color: 'var(--c-red)' }}>Must start with https:// or tg://</span>}
              </div>
            </div>
            <div className="ibe-extras">
              <div className="ibe-field ibe-field-style">
                <label className="ibe-label">Color</label>
                <div className="ibe-style-row">
                  {CB_STYLE_OPTIONS.map(o => (
                    <button key={o.value} type="button"
                      className={`ibe-style-opt${b.style === o.value ? ' active' : ''}`}
                      style={b.style === o.value ? { borderColor: o.color, color: o.color } : {}}
                      onClick={() => upd(i, 'style', o.value)}>{o.label}</button>
                  ))}
                </div>
              </div>
              <div className="ibe-field ibe-field-emoji">
                <label className="ibe-label">Button Icon</label>
                <input className="tc-input" inputMode="numeric" value={b.icon_custom_emoji_id || ''}
                  onChange={e => upd(i, 'icon_custom_emoji_id', e.target.value.replace(/\D/g, ''))}
                  placeholder="Custom Emoji ID (optional)" style={{ fontFamily: 'var(--font-mono, monospace)', fontSize: '.75rem' }} />
              </div>
            </div>
            <div className="ibe-preview-row">
              <span className="ibe-preview-label">Delivery:</span>
              <span className={`ibe-preview-chip${tcBtnStyleClass(b.style)}`}>{(b.text || 'Button').trim() || 'Button'} ↗</span>
              {b.icon_custom_emoji_id && <span className="cp-emoji-id-badge" title={`icon_custom_emoji_id: ${b.icon_custom_emoji_id}`}>icon·{b.icon_custom_emoji_id.slice(0, 8)}</span>}
              {b.style && <span className="cp-style-badge" style={{ color: CB_STYLE_OPTIONS.find(o => o.value === b.style)?.color }}>{b.style}</span>}
              <button type="button" className="cp-adv-toggle" onClick={() => setAdvOpen(o => ({ ...o, [b.id]: !o[b.id] }))}>Advanced {isAdv ? '▲' : '▼'}</button>
            </div>
            {isAdv && (
              <div className="cp-btn-adv"><div className="cp-adv-grid"><div className="ibe-field">
                <label className="ibe-label">Row <span style={{ fontSize: '.65rem', color: 'var(--text-3)' }}>same row = side-by-side</span></label>
                <input type="number" className="tc-input" min={1} max={10} value={b.row || 1}
                  onChange={e => upd(i, 'row', Math.max(1, parseInt(e.target.value) || 1))} style={{ width: 64 }} />
              </div></div></div>
            )}
          </div>
        );
      })}
      <div className="ibe-bottom"><button type="button" className="ibe-add" onClick={add}>+ Add Button</button></div>
    </div>
  );
}

function TcButtonPreview({ buttons }: { buttons: any[] }) {
  const active = buttons.filter(b => b.enabled !== false);
  const rowMap: Record<number, any[]> = {};
  active.forEach(b => { const r = b.row || 1; (rowMap[r] = rowMap[r] || []).push(b); });
  if (!active.length) return null;
  return (
    <div className="cp-phone-buttons">
      {Object.entries(rowMap).sort(([a],[z]) => +a - +z).map(([rn, row]) => (
        <div key={rn} className="cp-phone-btn-row">
          {row.map((b, i) => (
            <div key={i} className={`cp-phone-btn${b.style === 'primary' ? ' s-primary' : b.style === 'success' ? ' s-success' : b.style === 'danger' ? ' s-danger' : ' s-none'}`}>
              {(b.text || 'Button').trim() || 'Button'}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

const SAMPLE_VARS: Record<string, string> = {
  '{campaign_name}': 'Weekend Trial Drop', '{user_name}': 'John', '{bot_name}': 'KeyStore',
  '{trial_duration}': '5', '{trial_devices}': '1000',
  '{expire_time}': '29 Mar 2026, 06:20 PM IST', '{start_time}': '29 Mar 2026, 01:20 PM IST',
  '{categories}': 'NovaEsp, SayGG', '{TrialCategoryNames}': 'NovaEsp, SayGG', '{TrialCategoryCount}': '2',
  '{trial_key}': 'TRIAL-ABC-123', '{category_key}': 'TRIAL-ABC-123',
  '{category_name}': 'NovaEsp', '{category_file_name}': 'NovaEsp',
  '{TrialCategoryBlocks}': '• <b>NovaEsp</b>\n  Key: <code>Vzhshsuajqw</code>\n• <b>SayGG</b>\n  Key: <code>KEYDGHAUWNW</code>',
  '{TrialKeyNovaEsp}': 'Vzhshsuajqw', '{TrialKeySayGG}': 'KEYDGHAUWNW',
};
const resolveSample = (text: string) => { let t = text; Object.entries(SAMPLE_VARS).forEach(([k, v]) => { t = t.split(k).join(v); }); return t; };

interface ApkConfig { enabled: boolean; caption: string; buttons: any[]; }
interface StartDeliveryConfig { send_media: boolean; send_summary: boolean; apk_configs: Record<string, ApkConfig>; }

function _loadStartConfig(existing: TrialTemplate | null): StartDeliveryConfig {
  if (existing?.start_delivery_config_json) {
    try {
      const c = JSON.parse(existing.start_delivery_config_json);
      return {
        send_media: c.send_media !== false,
        send_summary: c.send_summary !== false,
        apk_configs: c.apk_configs || {},
      };
    } catch {}
  }
  if (existing?.apk_captions_json) {
    try {
      const old = JSON.parse(existing.apk_captions_json);
      const configs: Record<string, ApkConfig> = {};
      for (const [catId, cap] of Object.entries(old)) {
        configs[catId] = { enabled: true, caption: (cap as string) || '', buttons: [] };
      }
      return { send_media: true, send_summary: true, apk_configs: configs };
    } catch {}
  }
  return { send_media: true, send_summary: true, apk_configs: {} };
}

function TemplateFormScreen({ nav, setNav, onFlash, loadTemplates, flash }: any) {
  const existing = nav.template as TrialTemplate | null;
  const isEdit = !!(existing?.id);

  const [form, setForm] = useState({
    name: existing?.name || '',
    template_type: existing?.template_type || 'trial_start',
    body_text: existing?.body_text || '',
    is_active: existing?.is_active ?? true,
  });
  const [saving, setSaving] = useState(false);

  const [summaryButtons, setSummaryButtons] = useState<any[]>(() => {
    try { const p = JSON.parse(existing?.inline_buttons_json || '[]'); return Array.isArray(p) ? p.map(normalizeTcBtn) : []; } catch { return []; }
  });

  const bodyRef = useRef<HTMLTextAreaElement>(null);

  const isStart = form.template_type === 'trial_start';

  const insertVar = (v: string) => {
    const el = bodyRef.current;
    if (!el) { setForm(f => ({ ...f, body_text: f.body_text + v })); return; }
    const s = el.selectionStart; const e = el.selectionEnd;
    const newText = form.body_text.substring(0, s) + v + form.body_text.substring(e);
    setForm(f => ({ ...f, body_text: newText }));
    setTimeout(() => { el.focus(); el.setSelectionRange(s + v.length, s + v.length); }, 10);
  };

  const handleSave = async () => {
    if (!form.name) return onFlash('Name required');
    if (!form.body_text) return onFlash('Body text required');
    setSaving(true);
    try {
      const body: any = {
        name: form.name,
        template_type: form.template_type,
        body_text: form.body_text,
        parse_mode: 'HTML',
        is_active: form.is_active,
        inline_buttons_json: summaryButtons.length ? JSON.stringify(summaryButtons) : null,
      };

      if (isStart) {
        const existingConfig = _loadStartConfig(existing);
        const configToSave: StartDeliveryConfig = {
          send_media: existingConfig.send_media,
          send_summary: true,
          apk_configs: {},
        };
        body.start_delivery_config_json = JSON.stringify(configToSave);
      }

      if (isEdit) {
        await apiPut(`/campaigns/templates/${existing!.id}`, body);
        onFlash('Template updated');
      } else {
        await apiPost('/campaigns/templates', body);
        onFlash('Template created');
      }
      loadTemplates();
      setNav({ screen: 'home' });
    } catch (e: any) { onFlash(e?.message || 'Save failed'); }
    setSaving(false);
  };

  const varsToShow = isStart ? TRIAL_VARS_START : TRIAL_VARS_EXPIRE;

  return (
    <div className="cp-screen">
      {flash && <div className="toast-msg" style={{ position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)', zIndex: 999 }}>{flash}</div>}
      <div className="cp-screen-hdr">
        <BackButton onBack={() => setNav({ screen: 'home' })} />
        <h3 className="cp-screen-title" style={{ margin: 0 }}>{isEdit ? 'Edit' : 'Create'} Trial Template</h3>
      </div>
      <div className="tc-form-body">

        <SectionCard title="Template Details" icon="file" accent="var(--c-accent-bright)">
          <div className="tc-row-2">
            <div>
              <FieldLabel text="Template Name" />
              <input className="tc-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <FieldLabel text="Template Type" />
              <select className="tc-input tc-select" value={form.template_type} onChange={e => setForm({ ...form, template_type: e.target.value })}>
                <option value="trial_start">Trial Start</option>
                <option value="trial_expire">Trial Expire</option>
              </select>
            </div>
          </div>
          <div className="tc-toggle-row">
            <label className="tc-toggle">
              <input type="checkbox" checked={form.is_active} onChange={e => setForm({ ...form, is_active: e.target.checked })} />
              <span className="tc-toggle-slider" />
            </label>
            <div><div className="tc-toggle-label">Active</div></div>
          </div>
        </SectionCard>

        <SectionCard title={isStart ? 'Summary Message' : 'Message Body'} icon="send" accent="var(--c-accent-bright)">
          <FieldLabel text="Variables" helper="Tap to insert" />
          <div className="tc-chip-grid">
            {varsToShow.map(v => (
              <button key={v.key} className="tc-var-chip" onClick={() => insertVar(v.key)} title={v.desc}>{v.key}</button>
            ))}
          </div>
          <div className="tc-field-helper" style={{ marginTop: 6, fontStyle: 'italic' }}>{TRIAL_VARS_DYNAMIC_HINT}</div>

          <FieldLabel text="Body Text (HTML)" />
          <textarea ref={bodyRef} className="tc-input tc-textarea" value={form.body_text}
            onChange={e => setForm({ ...form, body_text: e.target.value })}
            style={{ height: 160, fontFamily: 'var(--font-mono, monospace)', fontSize: '.8rem' }}
            placeholder={isStart ? 'Enter summary message body...' : 'Enter expire message body...'} />

          {isStart && (
            <div className="tc-info-box tc-info-muted" style={{ marginTop: 10, fontSize: '.72rem' }}>
              APK/document delivery settings are managed separately in the APK Captions tab.
            </div>
          )}
        </SectionCard>

        <SectionCard title="Inline Buttons" icon="link" accent="var(--c-accent-bright)">
          <TcButtonBuilder buttons={summaryButtons} setButtons={setSummaryButtons} emptyHint={isStart ? 'Add buttons below the summary message' : 'Add buttons below the expire message'} />
        </SectionCard>

        <SectionCard title="Live Preview" icon="eye">
          <div className="cp-phone-preview">
            <div className="cp-phone-bubble">
              <div className="cp-phone-bubble-text" style={{ whiteSpace: 'pre-wrap', fontSize: '.85rem', lineHeight: 1.5 }}
                dangerouslySetInnerHTML={{ __html: sanitizeTcHtml(resolveSample(form.body_text)).replace(/\n/g, '<br/>') || '<span style="color:var(--text-3)">Empty template — add body text above</span>' }} />
            </div>
            <TcButtonPreview buttons={summaryButtons} />
          </div>
        </SectionCard>

        <div className="tc-form-actions">
          <div className="tc-form-actions-save">
            <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'home' })}>Cancel</button>
            <button className="btn-primary-sm" onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : isEdit ? 'Update' : 'Create'}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function CampaignDetailScreen({ campaignId, setNav, categories, templates, channels, onFlash, load, flash }: any) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [runs, setRuns] = useState<Run[]>([]);
  const [inventory, setInventory] = useState<any[]>([]);
  const [detailTab, setDetailTab] = useState<'overview' | 'runs' | 'deliveries'>('overview');
  const [deliveryLogs, setDeliveryLogs] = useState<DeliveryLog[]>([]);
  const [dlPage, setDlPage] = useState(1);
  const [dlTotal, setDlTotal] = useState(0);
  const [dlTotalPages, setDlTotalPages] = useState(1);
  const [dlTargetType, setDlTargetType] = useState('');
  const [dlStatusFilter, setDlStatusFilter] = useState('');

  useEffect(() => {
    setLoading(true);
    Promise.all([
      apiGet(`/trial-campaigns/${campaignId}`),
      apiGet(`/trial-campaigns/${campaignId}/runs`),
    ]).then(([detail, runsData]) => {
      setData(detail);
      setRuns(runsData);
      let catIds: number[] = [];
      try { catIds = JSON.parse(detail.category_ids_json || '[]'); } catch {}
      if (catIds.length && detail.trial_duration_hours) {
        apiGet(`/trial-campaigns/inventory-check?category_ids=${catIds.join(',')}&duration_hours=${detail.trial_duration_hours}`)
          .then(inv => setInventory(inv)).catch(() => {});
      }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [campaignId]);

  const loadDeliveryLogs = useCallback(async () => {
    try {
      const params = new URLSearchParams({ page: String(dlPage), limit: '50', campaign_id: String(campaignId) });
      if (dlTargetType) params.set('target_type', dlTargetType);
      if (dlStatusFilter) params.set('delivery_status', dlStatusFilter);
      const d = await apiGet(`/trial-campaigns/delivery-logs?${params}`);
      setDeliveryLogs(d.logs); setDlTotal(d.total); setDlTotalPages(d.totalPages);
    } catch (e: any) { onFlash(e.message); }
  }, [dlPage, campaignId, dlTargetType, dlStatusFilter]);

  useEffect(() => { if (detailTab === 'deliveries') loadDeliveryLogs(); }, [detailTab, loadDeliveryLogs]);
  useEffect(() => { setDlPage(1); }, [dlTargetType, dlStatusFilter]);

  if (loading) return <div className="cp-screen"><div className="page-loader"><div className="loader-spinner" /></div></div>;
  if (!data) return <div className="cp-screen"><div className="cp-screen-hdr"><BackButton onBack={() => setNav({ screen: 'home' })} /></div><EmptyState icon="flag" title="Campaign not found" /></div>;

  let catIds: number[] = [];
  try { catIds = JSON.parse(data.category_ids_json || '[]'); } catch {}
  let catSnapshots: {id: number; name: string}[] | null = null;
  try { catSnapshots = JSON.parse(data.category_names_snapshot_json || 'null'); } catch {}
  const resolvedCats = catIds.map((id: number) => resolveCatName(id, categories, catSnapshots));
  const catNames = resolvedCats.map(r => r.name + (r.isOrphaned ? ' (Deleted)' : '')).join(', ');
  const tz = data.timezone || TZ;
  const audienceInfo = AUDIENCE_MAP[data.target_audience] || { label: data.target_audience, icon: 'users' };

  let channelTargets: number[] = [];
  try { channelTargets = JSON.parse(data.channel_targets_json || '[]'); } catch {}
  const channelNames = channelTargets.map((id: number) => {
    const ch = (channels || []).find((c: Channel) => c.id === id);
    return ch ? (ch.name || ch.channel_name || `#${id}`) : `#${id}`;
  });

  const handleToggle = async () => {
    try {
      const newEnabled = !data.is_enabled;
      const updates: any = { is_enabled: newEnabled };
      if (newEnabled && (data.status === 'draft' || data.status === 'expired')) updates.status = 'scheduled';
      await apiPut(`/trial-campaigns/${data.id}`, updates);
      onFlash(newEnabled ? 'Campaign enabled' : 'Campaign disabled');
      const d = await apiGet(`/trial-campaigns/${campaignId}`);
      setData(d);
      load();
    } catch (e: any) { onFlash(e?.message || 'Failed'); }
  };

  return (
    <div className="cp-screen">
      {flash && <div className="toast-msg" style={{ position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)', zIndex: 999 }}>{flash}</div>}
      <div className="cp-screen-hdr">
        <BackButton onBack={() => setNav({ screen: 'home' })} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h3 className="cp-screen-title" style={{ margin: 0 }}>{data.name}</h3>
        </div>
        <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: data })}><Icon name="edit" /> Edit</button>
      </div>

      <div className="cp-detail-hdr">
        {data.description && <p className="cp-detail-desc">{data.description}</p>}
        <div className="cp-detail-badges">
          <StatusBadge status={data.status} />
          <span className="cp-tag"><Icon name={audienceInfo.icon} size={10} /> {audienceInfo.label}</span>
          <span className="cp-tag">{REPEAT_MAP[data.repeat_mode] || data.repeat_mode}</span>
          {data.is_enabled && <span className="cp-tag" style={{ color: 'var(--c-emerald)', background: 'var(--c-emerald-surface)' }}>Enabled</span>}
          {data.send_to_users && <span className="cp-tag" style={{ color: 'var(--c-emerald)', background: 'var(--c-emerald-surface)' }}>Users</span>}
          {data.send_to_channels && <span className="cp-tag" style={{ color: 'var(--c-accent-bright)', background: 'var(--c-accent-surface)' }}>Channels</span>}
        </div>
      </div>

      <div className="cp-tab-bar" style={{ margin: '12px 20px 0' }}>
        {(['overview', 'runs', 'deliveries'] as const).map(t => (
          <button key={t} className={`cp-tab-btn${detailTab === t ? ' active' : ''}`} onClick={() => setDetailTab(t)}>
            <Icon name={t === 'overview' ? 'eye' : t === 'runs' ? 'list' : 'send'} size={13} />
            {t === 'overview' ? 'Overview' : t === 'runs' ? `Runs (${runs.length})` : 'Delivery Logs'}
          </button>
        ))}
      </div>

      <div className="cp-detail-body">
        {detailTab === 'overview' && (
          <>
            <div className="tc-detail-grid">
              <div className="tc-detail-kv"><span>Categories</span><b>{catNames || 'All'}</b></div>
              <div className="tc-detail-kv"><span>Duration</span><b>{data.trial_duration_hours}h</b></div>
              <div className="tc-detail-kv"><span>Max Devices</span><b>{data.max_devices || 'Unlimited'}</b></div>
              <div className="tc-detail-kv"><span>Total Runs</span><b>{data.total_runs || 0}</b></div>
              <div className="tc-detail-kv"><span>Start</span><b>{fmtDate(data.start_at, tz)}</b></div>
              <div className="tc-detail-kv"><span>Expire</span><b>{fmtDate(data.expire_at, tz)}</b></div>
              <div className="tc-detail-kv"><span>Next Run</span><b>{fmtDate(data.next_run_at, tz)}</b></div>
              <div className="tc-detail-kv"><span>Next Expire</span><b>{fmtDate(data.next_expire_at, tz)}</b></div>
              <div className="tc-detail-kv"><span>Timezone</span><b>{tz}</b></div>
              <div className="tc-detail-kv"><span>Schedule</span><b>{REPEAT_MAP[data.repeat_mode] || data.repeat_mode}</b></div>
              <div className="tc-detail-kv"><span>Start Template</span><b>{data.start_template_name || 'Default'}</b></div>
              <div className="tc-detail-kv"><span>Expire Template</span><b>{data.expire_template_name || 'Default'}</b></div>
              <div className="tc-detail-kv"><span>Audience</span><b>{audienceInfo.label}</b></div>
              <div className="tc-detail-kv"><span>Send to Users</span><b>{data.send_to_users ? 'Yes' : 'No'}</b></div>
              <div className="tc-detail-kv"><span>Send to Channels</span><b>{data.send_to_channels ? 'Yes' : 'No'}</b></div>
              {data.reveal_keys_in_channels && <div className="tc-detail-kv"><span>Keys in Channels</span><b>Visible</b></div>}
            </div>

            {data.send_to_channels && channelNames.length > 0 && (
              <div style={{ marginTop: 16 }}>
                <div style={{ fontSize: '.75rem', fontWeight: 600, marginBottom: 8 }}>Channel Targets</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {channelNames.map((name: string, i: number) => (
                    <span key={i} className="cp-tag" style={{ color: 'var(--c-accent-bright)', background: 'var(--c-accent-surface)' }}><Icon name="hash" size={10} /> {name}</span>
                  ))}
                </div>
              </div>
            )}

            {data.linked_promo_name && (
              <div className="tc-linked-preview" style={{ marginTop: 16 }}>
                <Icon name="link" size={13} /> Linked Promo: <b>{data.linked_promo_name}</b>
                <div style={{ fontSize: '.7rem', color: 'var(--text-3)', marginTop: 2 }}>Auto-triggers after trial expires</div>
              </div>
            )}

            <div style={{ display: 'flex', gap: 8, margin: '20px 0' }}>
              <button className="btn-primary-sm" onClick={handleToggle}>
                <Icon name={data.is_enabled ? 'stop' : 'play'} /> {data.is_enabled ? 'Disable' : 'Enable'}
              </button>
              <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: data })}>
                <Icon name="edit" /> Edit
              </button>
            </div>

            {inventory.length > 0 && (
              <div style={{ marginBottom: 20 }}>
                <h4 style={{ margin: '0 0 8px', fontSize: '.85rem', fontWeight: 600 }}>Inventory Stock</h4>
                <div className="cp-stat-grid cp-stat-grid--4col">
                  {inventory.map((inv: any, i: number) => (
                    <div key={i} className="cp-stat-card" style={{ borderLeft: inv.available === 0 ? '3px solid var(--c-red)' : inv.available <= 3 ? '3px solid #f97316' : '3px solid var(--c-emerald)' }}>
                      <span className="cp-stat-card-v" style={{ color: inv.available === 0 ? 'var(--c-red)' : inv.available <= 3 ? '#f97316' : 'var(--c-emerald)' }}>{inv.available}</span>
                      <span className="cp-stat-card-l">{inv.categoryDisplayName}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {detailTab === 'runs' && (
          <>
            {runs.length === 0 && <EmptyState icon="list" title="No runs yet" sub="Campaign hasn't been executed" />}
            {runs.map((r: Run) => (
              <div key={r.id} style={{ background: 'var(--bg-3)', borderRadius: 8, padding: 14, marginBottom: 10, border: '1px solid var(--border-2)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, flexWrap: 'wrap', gap: 6 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontWeight: 600, fontSize: '.85rem' }}>Run #{r.id}</span>
                    <span className={`cp-type-badge ${r.run_type === 'trial_start' ? 'cp-type-start' : 'cp-type-expiry'}`}>
                      {r.run_type === 'trial_start' ? 'START' : 'EXPIRE'}
                    </span>
                    <StatusBadge status={r.status} />
                  </div>
                  <span style={{ fontSize: '.75rem', color: 'var(--text-3)' }}>{fmtDate(r.started_at, tz)}</span>
                </div>
                <div style={{ fontSize: '.8rem', color: 'var(--text-2)' }}>
                  Sent: {r.total_sent}/{r.total_targets} | Failed: {r.total_failed}
                  {r.channels_targeted > 0 && ` | Channels: ${r.channels_sent}/${r.channels_targeted}`}
                </div>
                {r.error_text && <div style={{ fontSize: '.75rem', color: 'var(--c-red)', marginTop: 4 }}>{r.error_text}</div>}
                {r.run_keys && r.run_keys.length > 0 && (
                  <div style={{ background: 'var(--bg-2)', borderRadius: 6, padding: 10, marginTop: 8 }}>
                    <div style={{ fontSize: '.72rem', fontWeight: 600, marginBottom: 6 }}>Keys Used (1 per category)</div>
                    {r.run_keys.map((rk: any, i: number) => (
                      <div key={i} style={{ fontSize: '.8rem', marginBottom: 3 }}>
                        <b>{rk.categoryDisplayName}</b>: <code style={{ fontSize: '.75rem' }}>{rk.key_value_snapshot}</code>
                        <span style={{ color: 'var(--text-3)', marginLeft: 8 }}>{rk.duration_hours}h / {rk.max_devices} devices</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </>
        )}

        {detailTab === 'deliveries' && (
          <>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
              <select className="tc-input tc-select" value={dlTargetType} onChange={e => setDlTargetType(e.target.value)} style={{ width: 120, fontSize: '.8rem' }}>
                <option value="">All Targets</option>
                <option value="user">Users</option>
                <option value="channel">Channels</option>
              </select>
              <select className="tc-input tc-select" value={dlStatusFilter} onChange={e => setDlStatusFilter(e.target.value)} style={{ width: 120, fontSize: '.8rem' }}>
                <option value="">All Status</option>
                <option value="sent">Sent</option>
                <option value="failed">Failed</option>
              </select>
              <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>{dlTotal} deliveries</span>
            </div>

            {deliveryLogs.length === 0 ? <EmptyState icon="send" title="No delivery logs" sub="No deliveries recorded for this campaign" /> : (
              <div style={{ display: 'grid', gap: 8 }}>
                {deliveryLogs.map(l => (
                  <div key={l.id} style={{ background: 'var(--bg-3)', borderRadius: 8, padding: 12, border: '1px solid var(--border-2)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, flexWrap: 'wrap', gap: 4 }}>
                      <span style={{ fontWeight: 500, fontSize: '.85rem' }}>{l.first_name || l.username || l.telegram_id}</span>
                      <StatusBadge status={l.delivery_status === 'sent' ? 'completed' : 'failed'} />
                    </div>
                    <div style={{ fontSize: '.8rem', color: 'var(--text-2)', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      <span>Run #{l.run_id}</span>
                      <span className={`cp-type-badge ${l.target_type === 'user' ? 'cp-type-start' : 'cp-type-expiry'}`} style={{ fontSize: '.65rem' }}>{l.target_type}</span>
                      <span style={{ color: 'var(--text-3)' }}>{fmtDate(l.created_at, tz)}</span>
                    </div>
                    {l.error_text && <div style={{ fontSize: '.75rem', color: 'var(--c-red)', marginTop: 4 }}>{l.error_text}</div>}
                  </div>
                ))}
              </div>
            )}

            {dlTotalPages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 16 }}>
                <button className="btn-ghost-sm" disabled={dlPage <= 1} onClick={() => setDlPage(p => p - 1)}>Prev</button>
                <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>Page {dlPage} of {dlTotalPages}</span>
                <button className="btn-ghost-sm" disabled={dlPage >= dlTotalPages} onClick={() => setDlPage(p => p + 1)}>Next</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

interface ApkCaptionTemplate {
  id: number; name: string; category_id: number; category_display_name: string | null;
  category_name_snapshot: string | null; is_orphaned?: boolean;
  body_text: string; inline_buttons_json: string | null; is_active: boolean;
  edited_via: string | null; updated_by: string | null; updated_at: string;
}

function ApkCaptionsPanel({ categories, onFlash }: { categories: Category[]; onFlash: (m: string) => void }) {
  const [captions, setCaptions] = useState<ApkCaptionTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [editId, setEditId] = useState<number | null>(null);
  const [editBody, setEditBody] = useState('');
  const [editButtons, setEditButtons] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);

  const loadCaptions = useCallback(async () => {
    try {
      const data = await apiGet('/trial-campaigns/apk-caption-templates');
      setCaptions(data);
    } catch (e: any) { onFlash(e.message); }
    setLoading(false);
  }, []);

  useEffect(() => { loadCaptions(); }, [loadCaptions]);

  const handleSeedDefaults = async () => {
    setSeeding(true);
    try {
      const res = await apiPost('/trial-campaigns/seed-apk-caption-defaults', {});
      onFlash(res.message || `Seeded ${res.seeded} templates`);
      loadCaptions();
    } catch (e: any) { onFlash(e.message); }
    setSeeding(false);
  };

  const handleEdit = (cap: ApkCaptionTemplate) => {
    setEditId(cap.id);
    setEditBody(cap.body_text);
    try { setEditButtons(JSON.parse(cap.inline_buttons_json || '[]').map(normalizeTcBtn)); } catch { setEditButtons([]); }
  };

  const handleSave = async () => {
    if (!editId) return;
    setSaving(true);
    try {
      await apiPut(`/trial-campaigns/apk-caption-templates/${editId}`, {
        body_text: editBody,
        inline_buttons_json: editButtons.length ? JSON.stringify(editButtons) : null,
      });
      onFlash('APK caption saved');
      setEditId(null);
      loadCaptions();
    } catch (e: any) { onFlash(e.message); }
    setSaving(false);
  };

  if (loading) return <div className="page-loader"><div className="loader-spinner" /></div>;

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
        <span style={{ fontSize: '.85rem', fontWeight: 600 }}>APK Caption Templates</span>
        <button className="btn-primary-sm" onClick={handleSeedDefaults} disabled={seeding}>
          {seeding ? 'Seeding...' : 'Seed Defaults'}
        </button>
      </div>

      <div className="tc-info-box tc-info-muted" style={{ marginBottom: 16 }}>
        Per-category caption templates for APK/document delivery. These are used when sending trial APK files to users. Each category can have its own caption and buttons.
      </div>

      {captions.length === 0 ? (
        <EmptyState icon="send" title="No APK caption templates" sub="Click 'Seed Defaults' to create templates for all categories" />
      ) : (
        <div style={{ display: 'grid', gap: 12 }}>
          {captions.map(cap => {
            const isEditing = editId === cap.id;
            const catName = cap.category_display_name ? cleanName(cap.category_display_name) : cleanName(cap.category_name_snapshot || `Deleted Category (ID ${cap.category_id})`);
            const isOrphan = !!cap.is_orphaned;
            const viaIcon = cap.edited_via === 'bot' ? '🤖' : '🌐';
            return (
              <div key={cap.id} className={`tc-apk-card${isOrphan ? ' tc-apk-card--orphan' : ''}`}>
                <div className="tc-apk-card-hdr">
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <span className="tc-apk-cat-name">{catName}</span>
                      {isOrphan ? <OrphanBadge /> : <span className="tc-badge-active">Active Category</span>}
                      <span className="tc-apk-badge tc-apk-badge-ok">APK Caption</span>
                      <span style={{ fontSize: '.65rem', color: 'var(--text-3)' }}>
                        {viaIcon} {cap.edited_via || 'web'}
                      </span>
                    </div>
                    {isOrphan && (
                      <div className="tc-orphan-warning">This category was removed from main store categories. Trial config is still preserved until you delete it manually.</div>
                    )}
                  </div>
                  <div style={{ display: 'flex', gap: 4, alignItems: 'center', flexShrink: 0 }}>
                    {!isEditing && (
                      <button className="btn-ghost-sm" onClick={() => handleEdit(cap)} style={{ padding: '2px 8px', fontSize: '.75rem' }}>
                        <Icon name="edit" size={12} /> Edit
                      </button>
                    )}
                    <button className="btn-ghost-sm tc-btn-danger" onClick={async () => {
                      if (!confirm(`Delete APK caption for "${catName}"?`)) return;
                      try {
                        await apiDelete(`/trial-campaigns/apk-caption-templates/${cap.id}`);
                        setCaptions(prev => prev.filter(c => c.id !== cap.id));
                        onFlash('APK caption deleted');
                      } catch { onFlash('Failed to delete'); }
                    }} style={{ padding: '2px 8px', fontSize: '.75rem' }}>
                      <Icon name="trash" size={12} /> Delete
                    </button>
                  </div>
                </div>

                {isEditing ? (
                  <div style={{ marginTop: 10 }}>
                    <FieldLabel text="Caption Body (HTML)" />
                    <div className="tc-chip-grid" style={{ marginBottom: 6 }}>
                      {APK_CAPTION_VARS.map(v => (
                        <button key={v.key} className="tc-var-chip" onClick={() => setEditBody(b => b + v.key)} title={v.desc} style={{ fontSize: '.62rem', padding: '2px 5px' }}>
                          {v.key}
                        </button>
                      ))}
                    </div>
                    <textarea className="tc-input tc-textarea" value={editBody}
                      onChange={e => setEditBody(e.target.value)}
                      style={{ height: 80, fontFamily: 'var(--font-mono, monospace)', fontSize: '.75rem' }} />

                    {editBody && (
                      <div style={{ marginTop: 6 }}>
                        <div style={{ fontSize: '.72rem', fontWeight: 600, color: 'var(--text-2)', marginBottom: 4 }}>Preview</div>
                        <div className="cp-phone-preview">
                          <div className="cp-phone-bubble">
                            <div className="cp-phone-bubble-text" style={{ whiteSpace: 'pre-wrap', fontSize: '.82rem', lineHeight: 1.4 }}
                              dangerouslySetInnerHTML={{ __html: sanitizeTcHtml(resolveSample(editBody)) || '—' }} />
                          </div>
                          <TcButtonPreview buttons={editButtons} />
                        </div>
                      </div>
                    )}

                    <div style={{ marginTop: 10 }}>
                      <FieldLabel text="Inline Buttons" />
                      <TcButtonBuilder buttons={editButtons} setButtons={setEditButtons} emptyHint="Add buttons below this APK document" />
                    </div>

                    <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 12 }}>
                      <button className="btn-ghost-sm" onClick={() => setEditId(null)}>Cancel</button>
                      <button className="btn-primary-sm" onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
                    </div>
                  </div>
                ) : (
                  <div style={{ marginTop: 8 }}>
                    <div style={{ fontSize: '.75rem', color: 'var(--text-2)', fontFamily: 'var(--font-mono, monospace)', whiteSpace: 'pre-wrap', maxHeight: 60, overflow: 'hidden' }}>
                      {cap.body_text || '(empty)'}
                    </div>
                    <div style={{ fontSize: '.65rem', color: 'var(--text-3)', marginTop: 4 }}>
                      Updated: {fmtDate(cap.updated_at)}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

function KeysPanel({ categories, onFlash }: { categories: Category[]; onFlash: (m: string) => void }) {
  const [keys, setKeys] = useState<TrialKey[]>([]);
  const [stats, setStats] = useState<KeyStat[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filterCat, setFilterCat] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterDuration, setFilterDuration] = useState('');
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [addMode, setAddMode] = useState<'single' | 'bulk'>('single');
  const [formCat, setFormCat] = useState('');
  const [formDuration, setFormDuration] = useState('5');
  const [formDevices, setFormDevices] = useState('1000');
  const [formKey, setFormKey] = useState('');
  const [formBulk, setFormBulk] = useState('');

  const loadKeys = useCallback(async () => {
    try {
      const params = new URLSearchParams({ page: String(page), limit: '50' });
      if (filterCat) params.set('filter_category_id', filterCat);
      if (filterStatus) params.set('filter_status', filterStatus);
      if (filterDuration) params.set('filter_duration_hours', filterDuration);
      if (search) params.set('search', search);
      const data = await apiGet(`/trial-keys?${params}`);
      setKeys(data.keys);
      setTotal(data.total);
      setTotalPages(data.totalPages);
    } catch (e: any) { onFlash(e.message); }
  }, [page, filterCat, filterStatus, filterDuration, search]);

  const loadStats = async () => {
    try { const data = await apiGet('/trial-keys/stats'); setStats(data); } catch {}
  };

  useEffect(() => { loadKeys(); }, [loadKeys]);
  useEffect(() => { loadStats(); }, []);

  const handleAdd = async () => {
    try {
      if (!formCat) return onFlash('Select a category');
      const body: any = { category_id: parseInt(formCat), duration_hours: parseInt(formDuration) || 5, max_devices: parseInt(formDevices) || 1000 };
      if (addMode === 'bulk') { body.keys_bulk = formBulk; } else { body.key_value = formKey; }
      const res = await apiPost('/trial-keys', body);
      if (res.inserted !== undefined) { onFlash(`Added ${res.inserted} keys (${res.duplicates} duplicates)`); }
      else { onFlash('Key added'); }
      setShowAdd(false); setFormKey(''); setFormBulk(''); loadKeys(); loadStats();
    } catch (e: any) { onFlash(e.message); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this trial key?')) return;
    try { await apiDelete(`/trial-keys/${id}`); onFlash('Key deleted'); loadKeys(); loadStats(); }
    catch (e: any) { onFlash(e.message); }
  };

  const handleStatusChange = async (id: number, newStatus: string) => {
    try { await apiPut(`/trial-keys/${id}`, { status: newStatus }); onFlash(`Status: ${newStatus}`); loadKeys(); loadStats(); }
    catch (e: any) { onFlash(e.message); }
  };

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
        <span style={{ fontSize: '.85rem', fontWeight: 600 }}>Trial Keys Inventory</span>
        <button className="btn-primary-sm" onClick={() => setShowAdd(true)}><Icon name="plus" /> Add Keys</button>
      </div>

      {stats.length > 0 && (
        <div className="cp-stat-grid cp-stat-grid--4col" style={{ marginBottom: 16 }}>
          {stats.map((s, i) => (
            <div key={i} className={`cp-stat-card${s.is_orphaned ? ' cp-stat-card--orphan' : ''}`}>
              <span className="cp-stat-card-v" style={{ fontSize: '.85rem' }}>
                {s.categoryDisplayName}
                {s.is_orphaned && <OrphanBadge />}
              </span>
              <span className="cp-stat-card-l" style={{ fontSize: '.65rem' }}>
                {s.available_keys} avail · {s.used_keys} used · {s.total_keys} total
              </span>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <select value={filterCat} onChange={e => { setFilterCat(e.target.value); setPage(1); }} className="tc-input tc-select" style={{ width: 150, fontSize: '.8rem' }}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{cleanName(c.name)}</option>)}
          {stats.filter(s => s.is_orphaned).reduce((acc: {id: number; name: string}[], s) => {
            if (!acc.find(x => x.id === s.category_id)) acc.push({ id: s.category_id, name: s.categoryDisplayName });
            return acc;
          }, []).map(oc => <option key={`orphan-${oc.id}`} value={oc.id}>{oc.name} (Deleted)</option>)}
        </select>
        <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value); setPage(1); }} className="tc-input tc-select" style={{ width: 130, fontSize: '.8rem' }}>
          <option value="">All Status</option>
          <option value="available">Available</option>
          <option value="used">Used</option>
          <option value="disabled">Disabled</option>
        </select>
        <input placeholder="Duration hrs" value={filterDuration} onChange={e => { setFilterDuration(e.target.value); setPage(1); }} className="tc-input" style={{ width: 100, fontSize: '.8rem' }} />
        <input placeholder="Search key..." value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} className="tc-input" style={{ flex: 1, minWidth: 120, fontSize: '.8rem' }} />
      </div>

      {keys.length === 0 ? (
        <EmptyState icon="key" title="No trial keys found" sub="Add keys to your inventory" />
      ) : (
        <div style={{ display: 'grid', gap: 8 }}>
          {keys.map(k => (
            <div key={k.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', background: 'var(--bg-3)', borderRadius: 8, border: k.is_orphaned ? '1px solid var(--c-amber, #f59e0b)' : '1px solid var(--border-2)', gap: 8, flexWrap: 'wrap' }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: '.8rem', fontWeight: 500 }}>
                  {k.categoryDisplayName}
                  {k.is_orphaned && <OrphanBadge />}
                  <span style={{ color: 'var(--text-3)' }}> · {k.duration_hours}h · {k.max_devices} dev</span>
                </div>
                <code style={{ fontSize: '.75rem', color: 'var(--text-2)', wordBreak: 'break-all' }}>{k.key_value}</code>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <StatusBadge status={k.status} />
                {k.used_in_trial_campaign_run_id && <span style={{ fontSize: '.7rem', color: 'var(--text-3)' }}>Run #{k.used_in_trial_campaign_run_id}</span>}
                {k.status === 'available' && <button className="btn-ghost-sm" onClick={() => handleStatusChange(k.id, 'disabled')} style={{ padding: '2px 6px', fontSize: '.7rem' }}>Disable</button>}
                {k.status === 'disabled' && <button className="btn-ghost-sm" onClick={() => handleStatusChange(k.id, 'available')} style={{ padding: '2px 6px', fontSize: '.7rem' }}>Enable</button>}
                <button className="btn-danger-sm" onClick={() => handleDelete(k.id)} style={{ padding: '2px 6px' }}><Icon name="trash" size={12} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 16 }}>
          <button className="btn-ghost-sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</button>
          <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>Page {page} of {totalPages} ({total} total)</span>
          <button className="btn-ghost-sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
        </div>
      )}

      {showAdd && (
        <div className="modal-overlay" onClick={() => setShowAdd(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: 480 }}>
            <h3 style={{ margin: '0 0 16px', fontSize: '.95rem' }}>Add Trial Keys</h3>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
              <button className={`tc-chip${addMode === 'single' ? ' selected' : ''}`} onClick={() => setAddMode('single')}>Single</button>
              <button className={`tc-chip${addMode === 'bulk' ? ' selected' : ''}`} onClick={() => setAddMode('bulk')}>Bulk</button>
            </div>
            <FieldLabel text="Category" />
            <select value={formCat} onChange={e => setFormCat(e.target.value)} className="tc-input tc-select" style={{ marginBottom: 10 }}>
              <option value="">Select category...</option>
              {categories.map(c => <option key={c.id} value={c.id}>{cleanName(c.name)}</option>)}
            </select>
            <FieldLabel text="Trial Duration (hours)" />
            <input value={formDuration} onChange={e => setFormDuration(e.target.value)} className="tc-input" style={{ marginBottom: 10 }} type="number" />
            <FieldLabel text="Max Devices" />
            <input value={formDevices} onChange={e => setFormDevices(e.target.value)} className="tc-input" style={{ marginBottom: 10 }} type="number" />
            {addMode === 'single' ? (
              <>
                <FieldLabel text="Key Value" />
                <input value={formKey} onChange={e => setFormKey(e.target.value)} className="tc-input" style={{ marginBottom: 12 }} placeholder="Enter trial key..." />
              </>
            ) : (
              <>
                <FieldLabel text="Keys (one per line)" />
                <textarea value={formBulk} onChange={e => setFormBulk(e.target.value)} className="tc-input tc-textarea" style={{ height: 120, marginBottom: 12 }} placeholder={'KEY_001\nKEY_002\nKEY_003'} />
              </>
            )}
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button className="btn-ghost-sm" onClick={() => setShowAdd(false)}>Cancel</button>
              <button className="btn-primary-sm" onClick={handleAdd}>Add</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function LogsPanel({ campaigns, onFlash }: { campaigns: TrialCampaign[]; onFlash: (m: string) => void }) {
  const [logsTab, setLogsTab] = useState<'runs' | 'deliveries' | 'usage'>('runs');
  const [filterCampaign, setFilterCampaign] = useState('');

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
        <div className="cp-tab-bar" style={{ margin: 0, padding: 0, border: 'none', borderBottom: 'none' }}>
          {(['runs', 'deliveries', 'usage'] as const).map(t => (
            <button key={t} className={`cp-tab-btn${logsTab === t ? ' active' : ''}`} onClick={() => setLogsTab(t)} style={{ fontSize: '.75rem' }}>
              {t === 'runs' ? 'Runs' : t === 'deliveries' ? 'Deliveries' : 'Inventory Usage'}
            </button>
          ))}
        </div>
        <select className="tc-input tc-select" value={filterCampaign} onChange={e => setFilterCampaign(e.target.value)} style={{ width: 180, fontSize: '.8rem' }}>
          <option value="">All Campaigns</option>
          {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {logsTab === 'runs' && <RunsSubPanel campaignId={filterCampaign} onFlash={onFlash} />}
      {logsTab === 'deliveries' && <DeliveriesSubPanel campaignId={filterCampaign} onFlash={onFlash} />}
      {logsTab === 'usage' && <UsageSubPanel campaignId={filterCampaign} onFlash={onFlash} />}
    </>
  );
}

function RunsSubPanel({ campaignId, onFlash }: { campaignId: string; onFlash: (m: string) => void }) {
  const [runs, setRuns] = useState<Run[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [expandedRun, setExpandedRun] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams({ page: String(page), limit: '30' });
      if (campaignId) params.set('campaign_id', campaignId);
      if (statusFilter) params.set('status', statusFilter);
      const data = await apiGet(`/trial-campaigns/runs/all?${params}`);
      setRuns(data.runs); setTotal(data.total); setTotalPages(data.totalPages);
    } catch (e: any) { onFlash(e.message); }
  }, [page, campaignId, statusFilter]);

  useEffect(() => { setPage(1); }, [campaignId, statusFilter]);
  useEffect(() => { load(); }, [load]);

  return (
    <>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <select className="tc-input tc-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={{ width: 130, fontSize: '.8rem' }}>
          <option value="">All Status</option>
          <option value="completed">Completed</option>
          <option value="failed">Failed</option>
          <option value="running">Running</option>
        </select>
        <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>{total} runs</span>
      </div>

      {runs.length === 0 ? <EmptyState icon="list" title="No runs found" /> : runs.map(r => (
        <div key={r.id} style={{ background: 'var(--bg-3)', borderRadius: 8, padding: 14, marginBottom: 10, border: '1px solid var(--border-2)', cursor: 'pointer' }}
          onClick={() => setExpandedRun(expandedRun === r.id ? null : r.id)}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4, flexWrap: 'wrap', gap: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontWeight: 600, fontSize: '.85rem' }}>Run #{r.id}</span>
              <StatusBadge status={r.status} />
              <span className={`cp-type-badge ${r.run_type === 'trial_start' ? 'cp-type-start' : 'cp-type-expiry'}`}>
                {r.run_type === 'trial_start' ? 'START' : 'EXPIRE'}
              </span>
            </div>
            <span style={{ fontSize: '.75rem', color: 'var(--text-3)' }}>{fmtDate(r.started_at)}</span>
          </div>
          <div style={{ fontSize: '.8rem', color: 'var(--text-2)' }}>
            {r.campaign_name || `Campaign #${r.campaign_id}`} | Sent: {r.total_sent}/{r.total_targets} | Failed: {r.total_failed}
            {r.channels_targeted > 0 && ` | Ch: ${r.channels_sent}/${r.channels_targeted}`}
          </div>
          {r.error_text && <div style={{ fontSize: '.75rem', color: 'var(--c-red)', marginTop: 4 }}>{r.error_text}</div>}
          {expandedRun === r.id && r.run_keys && r.run_keys.length > 0 && (
            <div style={{ background: 'var(--bg-2)', borderRadius: 6, padding: 10, marginTop: 8 }}>
              <div style={{ fontSize: '.72rem', fontWeight: 600, marginBottom: 6 }}>Keys Used (1 per category)</div>
              {r.run_keys.map((rk: any, i: number) => (
                <div key={i} style={{ fontSize: '.8rem', marginBottom: 3 }}>
                  <b>{rk.categoryDisplayName}</b>: <code style={{ fontSize: '.75rem' }}>{rk.key_value_snapshot}</code>
                  <span style={{ color: 'var(--text-3)', marginLeft: 8 }}>{rk.duration_hours}h / {rk.max_devices} dev</span>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 16 }}>
          <button className="btn-ghost-sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</button>
          <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>Page {page} of {totalPages}</span>
          <button className="btn-ghost-sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
        </div>
      )}
    </>
  );
}

function DeliveriesSubPanel({ campaignId, onFlash }: { campaignId: string; onFlash: (m: string) => void }) {
  const [logs, setLogs] = useState<DeliveryLog[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [targetType, setTargetType] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams({ page: String(page), limit: '50' });
      if (campaignId) params.set('campaign_id', campaignId);
      if (targetType) params.set('target_type', targetType);
      if (statusFilter) params.set('delivery_status', statusFilter);
      const data = await apiGet(`/trial-campaigns/delivery-logs?${params}`);
      setLogs(data.logs); setTotal(data.total); setTotalPages(data.totalPages);
    } catch (e: any) { onFlash(e.message); }
  }, [page, campaignId, targetType, statusFilter]);

  useEffect(() => { setPage(1); }, [campaignId, targetType, statusFilter]);
  useEffect(() => { load(); }, [load]);

  return (
    <>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <select className="tc-input tc-select" value={targetType} onChange={e => setTargetType(e.target.value)} style={{ width: 120, fontSize: '.8rem' }}>
          <option value="">All Targets</option>
          <option value="user">Users</option>
          <option value="channel">Channels</option>
        </select>
        <select className="tc-input tc-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={{ width: 120, fontSize: '.8rem' }}>
          <option value="">All Status</option>
          <option value="sent">Sent</option>
          <option value="failed">Failed</option>
        </select>
        <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>{total} deliveries</span>
      </div>

      {logs.length === 0 ? <EmptyState icon="send" title="No delivery logs" /> : (
        <div style={{ display: 'grid', gap: 8 }}>
          {logs.map(l => (
            <div key={l.id} style={{ background: 'var(--bg-3)', borderRadius: 8, padding: 12, border: '1px solid var(--border-2)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, flexWrap: 'wrap', gap: 4 }}>
                <span style={{ fontWeight: 500, fontSize: '.85rem' }}>{l.first_name || l.username || l.telegram_id}</span>
                <StatusBadge status={l.delivery_status === 'sent' ? 'completed' : 'failed'} />
              </div>
              <div style={{ fontSize: '.8rem', color: 'var(--text-2)', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <span>{l.campaign_name || `#${l.campaign_id}`}</span>
                <span>· Run #{l.run_id}</span>
                <span className={`cp-type-badge ${l.target_type === 'user' ? 'cp-type-start' : 'cp-type-expiry'}`} style={{ fontSize: '.65rem' }}>{l.target_type}</span>
                <span style={{ color: 'var(--text-3)' }}>{fmtDate(l.created_at)}</span>
              </div>
              {l.error_text && <div style={{ fontSize: '.75rem', color: 'var(--c-red)', marginTop: 4 }}>{l.error_text}</div>}
            </div>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 16 }}>
          <button className="btn-ghost-sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</button>
          <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>Page {page} of {totalPages}</span>
          <button className="btn-ghost-sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
        </div>
      )}
    </>
  );
}

function UsageSubPanel({ campaignId, onFlash }: { campaignId: string; onFlash: (m: string) => void }) {
  const [usage, setUsage] = useState<UsageEntry[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams({ page: String(page), limit: '50' });
      if (campaignId) params.set('campaign_id', campaignId);
      const data = await apiGet(`/trial-campaigns/inventory-usage?${params}`);
      setUsage(data.usage); setTotal(data.total); setTotalPages(data.totalPages);
    } catch (e: any) { onFlash(e.message); }
  }, [page, campaignId]);

  useEffect(() => { setPage(1); }, [campaignId]);
  useEffect(() => { load(); }, [load]);

  return (
    <>
      <div style={{ marginBottom: 12 }}>
        <span style={{ fontSize: '.8rem', color: 'var(--text-3)' }}>{total} keys used in runs</span>
      </div>

      {usage.length === 0 ? <EmptyState icon="key" title="No inventory usage" sub="No keys consumed in runs yet" /> : (
        <div style={{ display: 'grid', gap: 8 }}>
          {usage.map(u => (
            <div key={u.id} style={{ background: 'var(--bg-3)', borderRadius: 8, padding: 12, border: '1px solid var(--border-2)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, flexWrap: 'wrap', gap: 4 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontWeight: 500, fontSize: '.85rem' }}>{u.categoryDisplayName}</span>
                  <span className={`cp-type-badge ${u.run_type === 'trial_start' ? 'cp-type-start' : 'cp-type-expiry'}`}>
                    {u.run_type === 'trial_start' ? 'START' : 'EXPIRE'}
                  </span>
                </div>
                <span style={{ fontSize: '.75rem', color: 'var(--text-3)' }}>{fmtDate(u.run_started_at || u.created_at)}</span>
              </div>
              <div style={{ fontSize: '.8rem', color: 'var(--text-2)' }}>
                <code style={{ fontSize: '.75rem' }}>{u.key_value_snapshot}</code>
                <span style={{ marginLeft: 8 }}>{u.campaign_name || `#${u.campaign_id}`} · Run #{u.run_id} · {u.duration_hours}h · {u.max_devices} dev</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 16 }}>
          <button className="btn-ghost-sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</button>
          <span style={{ fontSize: '.8rem', padding: '6px 0', color: 'var(--text-3)' }}>Page {page} of {totalPages}</span>
          <button className="btn-ghost-sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
        </div>
      )}
    </>
  );
}

function AnalyticsPanel({ campaigns, stats }: { campaigns: TrialCampaign[]; stats: any }) {
  const activeCamps = campaigns.filter(c => c.status === 'active');
  const scheduledCamps = campaigns.filter(c => c.status === 'scheduled');
  const expiredCamps = campaigns.filter(c => c.status === 'expired' || c.status === 'completed');

  return (
    <>
      <h4 style={{ margin: '0 0 12px', fontSize: '.85rem', fontWeight: 600 }}>Campaign Overview</h4>
      <div className="cp-stat-grid cp-stat-grid--4col" style={{ marginBottom: 20 }}>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.total}</span><span className="cp-stat-card-l">Total Campaigns</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: 'var(--c-emerald)' }}>{stats.active}</span><span className="cp-stat-card-l">Active</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: 'var(--c-accent-bright)' }}>{stats.scheduled}</span><span className="cp-stat-card-l">Scheduled</span></div>
        <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.totalRuns}</span><span className="cp-stat-card-l">Total Runs</span></div>
      </div>

      {activeCamps.length > 0 && (
        <>
          <h4 style={{ margin: '0 0 8px', fontSize: '.85rem', fontWeight: 600, color: 'var(--c-emerald)' }}>Active Campaigns</h4>
          <div style={{ display: 'grid', gap: 8, marginBottom: 20 }}>
            {activeCamps.map(c => (
              <div key={c.id} style={{ background: 'var(--c-emerald-surface)', borderRadius: 8, padding: 12, border: '1px solid var(--c-emerald)' }}>
                <div style={{ fontWeight: 600, fontSize: '.85rem' }}>{c.name}</div>
                <div style={{ fontSize: '.8rem', color: 'var(--text-2)', marginTop: 4 }}>
                  {c.trial_duration_hours}h trial · {c.total_runs} runs · Next: {fmtDate(c.next_run_at, c.timezone)}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {scheduledCamps.length > 0 && (
        <>
          <h4 style={{ margin: '0 0 8px', fontSize: '.85rem', fontWeight: 600, color: 'var(--c-accent-bright)' }}>Scheduled Campaigns</h4>
          <div style={{ display: 'grid', gap: 8, marginBottom: 20 }}>
            {scheduledCamps.map(c => (
              <div key={c.id} style={{ background: 'var(--c-accent-surface)', borderRadius: 8, padding: 12, border: '1px solid var(--c-accent-bright)' }}>
                <div style={{ fontWeight: 600, fontSize: '.85rem' }}>{c.name}</div>
                <div style={{ fontSize: '.8rem', color: 'var(--text-2)', marginTop: 4 }}>
                  Starts: {fmtDate(c.start_at, c.timezone)} · {c.repeat_mode}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {expiredCamps.length > 0 && (
        <>
          <h4 style={{ margin: '0 0 8px', fontSize: '.85rem', fontWeight: 600, color: 'var(--text-3)' }}>Past Campaigns</h4>
          <div style={{ display: 'grid', gap: 8 }}>
            {expiredCamps.map(c => (
              <div key={c.id} style={{ background: 'var(--bg-3)', borderRadius: 8, padding: 12, border: '1px solid var(--border-2)' }}>
                <div style={{ fontWeight: 600, fontSize: '.85rem' }}>{c.name}</div>
                <div style={{ fontSize: '.8rem', color: 'var(--text-3)', marginTop: 4 }}>
                  {c.total_runs} runs · Expired: {fmtDate(c.expire_at, c.timezone)}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {campaigns.length === 0 && <EmptyState icon="chart" title="No analytics data" sub="Create campaigns to see analytics" />}
    </>
  );
}
