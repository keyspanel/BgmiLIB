import React, { useEffect, useState } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';

export default function Categories() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ name: '', sort_order: 0, is_hidden: 0, button_style: 4, file_id: '' });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    apiGet(`/categories?search=${encodeURIComponent(search)}`).then(setItems).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [search]);

  const openAdd = () => { setEditing(null); setForm({ name: '', sort_order: 0, is_hidden: 0, button_style: 4, file_id: '' }); setShowForm(true); };
  const openEdit = (item: any) => { setEditing(item); setForm({ name: item.name, sort_order: item.sort_order, is_hidden: item.is_hidden, button_style: item.button_style || 4, file_id: item.file_id || '' }); setShowForm(true); };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) await apiPut(`/categories/${editing.id}`, form);
      else await apiPost('/categories', form);
      setShowForm(false); setMsg(editing ? 'Category updated' : 'Category created'); load();
      setTimeout(() => setMsg(''), 2500);
    } catch (err: any) { setMsg(err.message); }
    setSaving(false);
  };

  const toggleVisibility = async (item: any) => {
    try { await apiPut(`/categories/${item.id}/visibility`, { is_hidden: item.is_hidden ? 0 : 1 }); load(); } catch {}
  };

  const remove = async (item: any) => {
    if (!confirm(`Delete "${item.displayName || item.name}"? This may affect related durations and keys.`)) return;
    try { await apiDelete(`/categories/${item.id}`); load(); } catch (err: any) { setMsg(err.message); }
  };

  const visibleCount = items.filter(i => !i.is_hidden).length;
  const hiddenCount = items.filter(i => i.is_hidden).length;

  return (
    <div className="page">
      {items.length > 0 && (
        <div className="metric-row" style={{ marginBottom: 16 }}>
          <div className="metric-pill"><span className="metric-label">Total</span><span className="metric-val">{items.length}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-emerald)' }} /><span className="metric-label">Visible</span><span className="metric-val">{visibleCount}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-rose)' }} /><span className="metric-label">Hidden</span><span className="metric-val">{hiddenCount}</span></div>
        </div>
      )}

      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search categories..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <button className="btn-primary-sm" onClick={openAdd}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add
        </button>
      </div>

      {msg && <div className="toast-msg">{msg}</div>}

      {showForm && (
        <div className="sheet-overlay" onClick={() => setShowForm(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{editing ? 'Edit Category' : 'New Category'}</h3>
              <p>{editing ? 'Update category details below' : 'Create a new product category'}</p>
            </div>
            <form onSubmit={save} className="sheet-body">
              <div className="field">
                <label>Category Name</label>
                <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required autoFocus placeholder="e.g. Game Pass, VPN, Streaming" />
              </div>
              <div className="field-row">
                <div className="field">
                  <label>Sort Order</label>
                  <input type="number" value={form.sort_order} onChange={e => setForm({...form, sort_order: parseInt(e.target.value) || 0})} />
                </div>
                <div className="field">
                  <label>Button Style</label>
                  <select value={form.button_style} onChange={e => setForm({...form, button_style: parseInt(e.target.value)})}>
                    <option value={1}>Style 1</option><option value={2}>Style 2</option><option value={3}>Style 3</option><option value={4}>Style 4</option>
                  </select>
                </div>
              </div>
              <div className="field">
                <label>Telegram File ID</label>
                <input value={form.file_id} onChange={e => setForm({...form, file_id: e.target.value})} placeholder="Optional - for bot media" />
                <span className="field-hint">Used by the Telegram bot to display media</span>
              </div>
              <label className="toggle-row" onClick={() => setForm({...form, is_hidden: form.is_hidden ? 0 : 1})}>
                <div className={`toggle-switch ${form.is_hidden ? 'on' : ''}`}><div className="toggle-knob" /></div>
                <span>Hide from bot menu</span>
              </label>
              <div className="sheet-actions">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary-sm" disabled={saving}>{saving ? 'Saving...' : editing ? 'Update' : 'Create'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading categories...</span></div>
      ) : items.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
          </div>
          <div className="empty-title">No categories found</div>
          <div className="empty-desc">Create your first product category to organize your inventory</div>
        </div>
      ) : (
        <div className="list">
          {items.map(item => (
            <div key={item.id} className="list-card">
              <div className="list-card-top">
                <div className="list-card-info">
                  <div className={`list-card-dot ${item.is_hidden ? 'danger' : 'success'}`} />
                  <div>
                    <div className="list-card-title">{item.displayName || item.name}</div>
                    <div className="list-card-sub">Order: {item.sort_order} · {item.is_hidden ? 'Hidden' : 'Visible'}</div>
                  </div>
                </div>
                <div className="list-card-stats">
                  {Number(item.api_backed_durations) > 0 ? (
                    <>
                      <span className="stat-mini" style={{ color: 'var(--c-sky)' }}>API</span>
                      {Number(item.available_keys) > 0 && <span className="stat-mini success">+{item.available_keys} manual</span>}
                    </>
                  ) : (
                    <>
                      <span className="stat-mini success">{item.available_keys || 0} avail</span>
                      <span className="stat-mini">{item.total_keys || 0} total</span>
                    </>
                  )}
                </div>
              </div>
              <div className="list-card-meta">
                <span>{item.total_durations || 0} durations</span>
                {(item.reserved_keys > 0 || item.sold_keys > 0) && <span>{item.reserved_keys || 0} rsv / {item.sold_keys || 0} sold</span>}
              </div>
              <div className="list-card-actions">
                <button className="btn-ghost-sm" onClick={() => toggleVisibility(item)}>{item.is_hidden ? 'Show' : 'Hide'}</button>
                <button className="btn-ghost-sm" onClick={() => openEdit(item)}>Edit</button>
                <button className="btn-danger-sm" onClick={() => remove(item)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
