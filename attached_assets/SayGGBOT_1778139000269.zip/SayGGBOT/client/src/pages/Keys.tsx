import React, { useEffect, useState } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';
import cfg from '../config';

const statusLabels: Record<number, string> = { 0: 'Available', 1: 'Sold', 2: 'Reserved' };
const statusClass: Record<number, string> = { 0: 'success', 1: 'danger', 2: 'warning' };

export default function Keys() {
  const [data, setData] = useState<any>({ keys: [], total: 0, page: 1, totalPages: 1 });
  const [stats, setStats] = useState<any>(null);
  const [categories, setCategories] = useState<any[]>([]);
  const [durations, setDurations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<any>({ filter_category_id: '', filter_duration_id: '', filter_status: '', search: '', page: 1 });
  const [filterDurations, setFilterDurations] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formMode, setFormMode] = useState('single');
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ category_id: '', duration_id: '', key_value: '', keys_bulk: '', is_sold: 0 });
  const [formDurations, setFormDurations] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [duplicates, setDuplicates] = useState<string[]>([]);

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => { if (v !== '') params.set(k, String(v)); });
    apiGet(`/keys?${params}`).then(setData).catch(() => {}).finally(() => setLoading(false));
    apiGet('/keys/stats').then(setStats).catch(() => {});
  };

  useEffect(() => { apiGet('/categories').then(setCategories).catch(() => {}); }, []);
  useEffect(() => { load(); }, [filters]);
  useEffect(() => {
    if (filters.filter_category_id) {
      apiGet(`/durations/by-category/${filters.filter_category_id}`).then(setFilterDurations).catch(() => setFilterDurations([]));
    } else { setFilterDurations([]); }
  }, [filters.filter_category_id]);

  const loadFormDurations = (catId: any) => {
    if (!catId) { setFormDurations([]); return; }
    apiGet(`/durations/by-category/${catId}`).then(setFormDurations).catch(() => setFormDurations([]));
  };

  const openAdd = (mode: string) => {
    setEditing(null); setFormMode(mode); setDuplicates([]);
    setForm({ category_id: '', duration_id: '', key_value: '', keys_bulk: '', is_sold: 0 });
    setFormDurations([]); setShowForm(true);
  };

  const openEdit = (item: any) => {
    setEditing(item); setFormMode('single'); setDuplicates([]);
    setForm({ category_id: item.category_id, duration_id: item.duration_id, key_value: item.key_value, keys_bulk: '', is_sold: item.is_sold });
    loadFormDurations(item.category_id); setShowForm(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true); setDuplicates([]);
    try {
      if (editing) {
        await apiPut(`/keys/${editing.id}`, form);
        setMsg('Key updated'); setShowForm(false);
      } else {
        const body: any = { category_id: form.category_id, duration_id: form.duration_id };
        if (formMode === 'bulk') body.keys_bulk = form.keys_bulk;
        else body.key_value = form.key_value;
        const result = await apiPost('/keys', body);
        setMsg(result.message);
        if (result.duplicates?.length > 0) setDuplicates(result.duplicates);
        else setShowForm(false);
      }
      load();
      setTimeout(() => setMsg(''), 3000);
    } catch (err: any) { setMsg(err.message); }
    setSaving(false);
  };

  const changeStatus = async (item: any, newStatus: number) => {
    try { await apiPut(`/keys/${item.id}/status`, { is_sold: newStatus }); load(); } catch {}
  };

  const remove = async (item: any) => {
    if (!confirm('Delete this key permanently?')) return;
    try { await apiDelete(`/keys/${item.id}`); load(); } catch (err: any) { setMsg(err.message); }
  };

  const setFilter = (key: string, val: any) => setFilters((p: any) => ({ ...p, [key]: val, page: 1 }));

  return (
    <div className="page">
      {stats && (
        <div className="inv-grid" style={{ marginBottom: 16 }}>
          <div className="inv-card"><div className="inv-val">{stats.total_keys}</div><div className="inv-label">Total</div></div>
          <div className="inv-card"><div className="inv-val" style={{ color: 'var(--c-emerald)' }}>{stats.available_keys}</div><div className="inv-label">Available</div></div>
          <div className="inv-card"><div className="inv-val" style={{ color: 'var(--c-amber)' }}>{stats.reserved_keys}</div><div className="inv-label">Reserved</div></div>
          <div className="inv-card"><div className="inv-val" style={{ color: 'var(--c-rose)' }}>{stats.sold_keys}</div><div className="inv-label">Sold</div></div>
        </div>
      )}

      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search keys..." value={filters.search} onChange={e => setFilter('search', e.target.value)} />
        </div>
        <button className="btn-primary-sm" onClick={() => openAdd('single')}>+ Key</button>
        <button className="btn-outline-sm" onClick={() => openAdd('bulk')}>+ Bulk</button>
      </div>

      <div className="filter-row">
        <select value={filters.filter_category_id} onChange={e => { setFilters((p: any) => ({...p, filter_category_id: e.target.value, filter_duration_id: '', page: 1})); }}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.displayName || c.name}</option>)}
        </select>
        <select value={filters.filter_status} onChange={e => setFilter('filter_status', e.target.value)}>
          <option value="">All Status</option>
          <option value="available">Available</option>
          <option value="reserved">Reserved</option>
          <option value="sold">Sold</option>
        </select>
      </div>
      {filterDurations.length > 0 && (
        <div className="filter-row">
          <select value={filters.filter_duration_id} onChange={e => setFilter('filter_duration_id', e.target.value)}>
            <option value="">All Durations</option>
            {filterDurations.map(d => <option key={d.id} value={d.id}>{d.displayName || d.name}</option>)}
          </select>
        </div>
      )}

      {msg && <div className="toast-msg">{msg}</div>}

      {showForm && (
        <div className="sheet-overlay" onClick={() => setShowForm(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="sheet-header">
              <h3>{editing ? 'Edit Key' : formMode === 'bulk' ? 'Bulk Import' : 'Add Key'}</h3>
              <p>{editing ? 'Modify key details' : formMode === 'bulk' ? 'Paste multiple keys, one per line' : 'Add a new product key to inventory'}</p>
            </div>
            <form onSubmit={save} className="sheet-body">
              <div className="field">
                <label>Category</label>
                <select value={form.category_id} onChange={e => { const v = parseInt(e.target.value); setForm({...form, category_id: v, duration_id: ''}); loadFormDurations(v); }} required>
                  <option value="">Select category...</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.displayName || c.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Duration</label>
                <select value={form.duration_id} onChange={e => setForm({...form, duration_id: parseInt(e.target.value)})} required>
                  <option value="">Select duration...</option>
                  {formDurations.map(d => <option key={d.id} value={d.id}>{d.displayName || d.name} ({cfg.currency}{d.price})</option>)}
                </select>
              </div>
              {formMode === 'bulk' && !editing ? (
                <div className="field">
                  <label>Keys (one per line)</label>
                  <textarea rows={6} value={form.keys_bulk} onChange={e => setForm({...form, keys_bulk: e.target.value})} required placeholder={"KEY-001\nKEY-002\nKEY-003"} />
                  <span className="field-hint">Each line will be added as a separate key</span>
                </div>
              ) : (
                <div className="field">
                  <label>Key Value</label>
                  <input className="mono-input" value={form.key_value} onChange={e => setForm({...form, key_value: e.target.value})} required placeholder="Enter key value" />
                </div>
              )}
              {editing && (
                <div className="field">
                  <label>Status</label>
                  <select value={form.is_sold} onChange={e => setForm({...form, is_sold: parseInt(e.target.value)})}>
                    <option value={0}>Available</option><option value={2}>Reserved</option><option value={1}>Sold</option>
                  </select>
                </div>
              )}
              {duplicates.length > 0 && (
                <div className="alert-card alert-warning">
                  <strong>Duplicate keys skipped:</strong>
                  {duplicates.map((d, i) => <div key={i} className="mono-text">{d}</div>)}
                </div>
              )}
              <div className="sheet-actions">
                <button type="button" className="btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn-primary-sm" disabled={saving}>{saving ? 'Saving...' : editing ? 'Update' : formMode === 'bulk' ? 'Import All' : 'Add Key'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading keys...</span></div>
      ) : data.keys.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg></div>
          <div className="empty-title">No keys found</div>
          <div className="empty-desc">Add product keys individually or import in bulk</div>
        </div>
      ) : (
        <>
          <div className="count-label">{data.total} key{data.total === 1 ? '' : 's'} total</div>
          <div className="list">
            {data.keys.map((item: any) => (
              <div key={item.id} className="list-card">
                <div className="list-card-top">
                  <div className="list-card-info" style={{ flex: 1 }}>
                    <div className={`list-card-dot ${statusClass[item.is_sold]}`} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="mono-value">{item.key_value}</div>
                      <div className="list-card-sub">{item.categoryDisplayName} / {item.durationDisplayName}</div>
                    </div>
                  </div>
                  <div className={`badge-${statusClass[item.is_sold]}`}>{statusLabels[item.is_sold]}</div>
                </div>
                <div className="list-card-meta">
                  <span>Price: {cfg.currency}{Number(item.duration_price || 0).toLocaleString()}</span>
                </div>
                <div className="list-card-actions">
                  {item.is_sold !== 0 && <button className="btn-ghost-sm" onClick={() => changeStatus(item, 0)}>Available</button>}
                  {item.is_sold !== 2 && <button className="btn-ghost-sm" onClick={() => changeStatus(item, 2)}>Reserve</button>}
                  <button className="btn-ghost-sm" onClick={() => openEdit(item)}>Edit</button>
                  <button className="btn-danger-sm" onClick={() => remove(item)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
          {data.totalPages > 1 && (
            <div className="pagination">
              <button className="pg-btn" disabled={filters.page <= 1} onClick={() => setFilters((p: any) => ({...p, page: p.page - 1}))}>Previous</button>
              <span className="pg-info">{filters.page} / {data.totalPages}</span>
              <button className="pg-btn" disabled={filters.page >= data.totalPages} onClick={() => setFilters((p: any) => ({...p, page: p.page + 1}))}>Next</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
