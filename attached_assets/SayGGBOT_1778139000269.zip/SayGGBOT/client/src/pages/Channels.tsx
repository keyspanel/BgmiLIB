import React, { useEffect, useState, useCallback } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  return <span className="material-symbols-rounded" style={{ fontSize: size, lineHeight: 1 }}>{name}</span>;
}

interface Channel {
  id: number;
  label: string;
  original_input: string;
  normalized_input: string;
  resolved_chat_id: number | null;
  resolved_username: string | null;
  resolved_title: string | null;
  chat_type: string | null;
  is_validated: boolean;
  bot_is_member: boolean;
  bot_is_admin: boolean;
  can_post_messages: boolean;
  is_enabled: boolean;
  last_validated_at: string | null;
  last_validation_status: string;
  last_validation_error: string | null;
  notes: string;
  created_at: string;
  updated_at: string;
}

interface ValidationResult {
  ok: boolean;
  resolved_chat_id: number | null;
  resolved_username: string | null;
  resolved_title: string | null;
  chat_type: string | null;
  bot_is_member: boolean;
  bot_is_admin: boolean;
  can_post_messages: boolean;
  error: string | null;
  detail: string;
  normalized: string;
  input_type: string;
  display: string;
}

interface AuditEntry {
  id: number;
  action: string;
  actor: string;
  channel_id: number | null;
  channel_label: string | null;
  normalized_input: string | null;
  resolved_chat_id: number | null;
  result: string | null;
  error_reason: string | null;
  metadata: any;
  created_at: string;
}

const STATUS_CONFIG: Record<string, { color: string; bg: string; label: string; icon: string }> = {
  valid:            { color: 'var(--c-emerald)', bg: 'var(--c-emerald-surface)', label: 'Valid',            icon: 'check_circle' },
  pending:          { color: 'var(--text-4)',    bg: 'var(--bg-3)',              label: 'Pending',          icon: 'hourglass_empty' },
  needs_validation: { color: 'var(--c-amber)',   bg: 'var(--c-amber-surface)',   label: 'Needs Validation', icon: 'warning' },
  invalid:          { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'Invalid',          icon: 'cancel' },
  permission_lost:  { color: 'var(--c-rose)',    bg: 'var(--c-rose-surface)',     label: 'Permission Lost',  icon: 'lock' },
};

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.pending;
  return (
    <span className="ch-status-badge" style={{ color: cfg.color, background: cfg.bg }}>
      <Icon name={cfg.icon} size={13} />
      {cfg.label}
    </span>
  );
}

function fmtDate(d: string | null) {
  if (!d) return '—';
  return new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: '2-digit', hour: '2-digit', minute: '2-digit' });
}

const TABS = [
  { key: 'channels', label: 'Channels', icon: 'cell_tower' },
  { key: 'audit', label: 'Activity Log', icon: 'history' },
];

const AUDIT_LABELS: Record<string, { label: string; color: string }> = {
  channel_validation_passed: { label: 'Validation Passed', color: 'var(--c-emerald)' },
  channel_validation_failed: { label: 'Validation Failed', color: 'var(--c-rose)' },
  channel_created:           { label: 'Channel Created',   color: 'var(--c-accent-bright)' },
  channel_updated:           { label: 'Channel Updated',   color: 'var(--c-amber)' },
  channel_deleted:           { label: 'Channel Deleted',   color: 'var(--c-rose)' },
  channel_enabled:           { label: 'Channel Enabled',   color: 'var(--c-emerald)' },
  channel_disabled:          { label: 'Channel Disabled',  color: 'var(--text-3)' },
};

export default function Channels() {
  const [tab, setTab] = useState('channels');
  const [channels, setChannels] = useState<Channel[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const [formMode, setFormMode] = useState<'add' | 'edit' | null>(null);
  const [editId, setEditId] = useState<number | null>(null);
  const [formLabel, setFormLabel] = useState('');
  const [formInput, setFormInput] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const [validating, setValidating] = useState(false);
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');
  const [revalidatingId, setRevalidatingId] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const [originalInput, setOriginalInput] = useState('');
  const [lastValidatedInput, setLastValidatedInput] = useState('');

  const loadChannels = useCallback(async () => {
    try {
      const data = await apiGet('/channels');
      setChannels(data.channels || []);
    } catch (e) {
      console.error(e);
    }
  }, []);

  const loadAudit = useCallback(async () => {
    try {
      const data = await apiGet('/channels/audit');
      setAuditLogs(data.logs || []);
    } catch (e) {
      console.error(e);
    }
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await loadChannels();
      setLoading(false);
    })();
  }, [loadChannels]);

  useEffect(() => {
    if (tab === 'audit') loadAudit();
  }, [tab, loadAudit]);

  const resetForm = () => {
    setFormMode(null);
    setEditId(null);
    setFormLabel('');
    setFormInput('');
    setFormNotes('');
    setValidation(null);
    setSaveMsg('');
    setOriginalInput('');
    setLastValidatedInput('');
  };

  const openAdd = () => {
    resetForm();
    setFormMode('add');
  };

  const openEdit = (ch: Channel) => {
    resetForm();
    setFormMode('edit');
    setEditId(ch.id);
    setFormLabel(ch.label);
    setFormInput(ch.original_input);
    setFormNotes(ch.notes);
    setOriginalInput(ch.original_input);
    setLastValidatedInput(ch.original_input);
  };

  const handleInputChange = (val: string) => {
    setFormInput(val);
    if (val.trim() !== lastValidatedInput.trim()) {
      setValidation(null);
      setSaveMsg('');
    }
  };

  const doValidate = async () => {
    if (!formInput.trim()) return;
    setValidating(true);
    setValidation(null);
    setSaveMsg('');
    try {
      const result = await apiPost('/channels/validate', { input: formInput.trim() });
      setValidation(result);
      setLastValidatedInput(formInput.trim());
    } catch (e: any) {
      setValidation({
        ok: false, resolved_chat_id: null, resolved_username: null, resolved_title: null,
        chat_type: null, bot_is_member: false, bot_is_admin: false, can_post_messages: false,
        error: e.message || 'Validation failed', detail: e.message || 'Validation failed',
        normalized: '', input_type: 'invalid', display: '',
      });
    }
    setValidating(false);
  };

  const doSave = async () => {
    if (!validation?.ok) return;
    setSaving(true);
    setSaveMsg('');
    try {
      if (formMode === 'add') {
        await apiPost('/channels', {
          label: formLabel.trim(),
          input: formInput.trim(),
          notes: formNotes.trim(),
          validation,
        });
        setSaveMsg('Channel saved successfully');
      } else if (formMode === 'edit' && editId) {
        await apiPut(`/channels/${editId}`, {
          label: formLabel.trim(),
          input: formInput.trim(),
          notes: formNotes.trim(),
          validation: formInput.trim() !== originalInput.trim() ? validation : undefined,
        });
        setSaveMsg('Channel updated successfully');
      }
      await loadChannels();
      setTimeout(() => resetForm(), 1200);
    } catch (e: any) {
      setSaveMsg(e.message || 'Save failed');
    }
    setSaving(false);
  };

  const doRevalidate = async (ch: Channel) => {
    setRevalidatingId(ch.id);
    try {
      await apiPost(`/channels/${ch.id}/revalidate`);
      await loadChannels();
    } catch (e) {
      console.error(e);
    }
    setRevalidatingId(null);
  };

  const doToggle = async (ch: Channel) => {
    try {
      await apiPost(`/channels/${ch.id}/toggle`);
      await loadChannels();
    } catch (e) {
      console.error(e);
    }
  };

  const doDelete = async (id: number) => {
    try {
      await apiDelete(`/channels/${id}`);
      await loadChannels();
      setDeleteConfirm(null);
    } catch (e) {
      console.error(e);
    }
  };

  const inputChanged = formInput.trim() !== originalInput.trim();
  const canSave = formMode === 'edit'
    ? (inputChanged ? validation?.ok === true : true)
    : validation?.ok === true;

  const needsRevalidation = formMode === 'edit' && inputChanged && !validation;

  if (loading) {
    return <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading…</span></div>;
  }

  return (
    <div className="ch-page">
      <div className="ch-tab-bar">
        {TABS.map(t => (
          <button key={t.key} className={`ch-tab-btn${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
            <Icon name={t.icon} size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'channels' && (
        <>
          <div className="ch-toolbar">
            <span className="ch-toolbar-count">{channels.length} channel{channels.length !== 1 ? 's' : ''} configured</span>
            {!formMode && (
              <button className="ch-btn ch-btn--primary" onClick={openAdd}>
                <Icon name="add" size={15} /> Add Channel
              </button>
            )}
          </div>

          {formMode && (
            <div className="ch-form-card">
              <div className="ch-form-hdr">
                <span className="ch-form-title">{formMode === 'add' ? 'Add New Channel' : 'Edit Channel'}</span>
                <button className="ch-btn ch-btn--ghost" onClick={resetForm}><Icon name="close" size={16} /></button>
              </div>

              <div className="ch-form-body">
                <div className="ch-form-row">
                  <label className="ch-form-label">Display Label</label>
                  <input className="ch-form-input" placeholder="e.g. Main Updates Channel" value={formLabel} onChange={e => setFormLabel(e.target.value)} />
                </div>

                <div className="ch-form-row">
                  <label className="ch-form-label">Channel ID / Username / Link <span style={{ color: 'var(--c-rose)' }}>*</span></label>
                  <input className="ch-form-input" placeholder="@channel, -1001234567890, or https://t.me/channel" value={formInput} onChange={e => handleInputChange(e.target.value)} />
                  {needsRevalidation && (
                    <span className="ch-form-hint" style={{ color: 'var(--c-amber)' }}>Target changed — validation required before saving</span>
                  )}
                </div>

                <div className="ch-form-row">
                  <label className="ch-form-label">Notes</label>
                  <input className="ch-form-input" placeholder="Optional notes" value={formNotes} onChange={e => setFormNotes(e.target.value)} />
                </div>

                <div className="ch-form-actions">
                  <button className="ch-btn ch-btn--accent" onClick={doValidate} disabled={!formInput.trim() || validating}>
                    {validating ? <><Icon name="sync" size={14} /> Validating…</> : <><Icon name="verified" size={14} /> Validate</>}
                  </button>
                  <button className="ch-btn ch-btn--primary" onClick={doSave} disabled={!canSave || saving}>
                    {saving ? 'Saving…' : formMode === 'add' ? 'Save Channel' : 'Update Channel'}
                  </button>
                  <button className="ch-btn ch-btn--ghost" onClick={resetForm}>Cancel</button>
                </div>

                {saveMsg && (
                  <div className={`ch-msg ${saveMsg.includes('success') ? 'ch-msg--ok' : 'ch-msg--err'}`}>{saveMsg}</div>
                )}
              </div>

              {validation && (
                <div className={`ch-validation-card ${validation.ok ? 'ch-validation--ok' : 'ch-validation--fail'}`}>
                  <div className="ch-val-hdr">
                    <Icon name={validation.ok ? 'check_circle' : 'cancel'} size={20} />
                    <span className="ch-val-title">{validation.ok ? 'Validation Passed' : 'Validation Failed'}</span>
                  </div>

                  {validation.error && (
                    <div className="ch-val-error">{validation.error}</div>
                  )}

                  <div className="ch-val-grid">
                    {validation.resolved_title && (
                      <div className="ch-val-field"><span className="ch-val-fl">Channel Title</span><span className="ch-val-fv">{validation.resolved_title}</span></div>
                    )}
                    {validation.resolved_chat_id && (
                      <div className="ch-val-field"><span className="ch-val-fl">Chat ID</span><span className="ch-val-fv mono">{validation.resolved_chat_id}</span></div>
                    )}
                    {validation.resolved_username && (
                      <div className="ch-val-field"><span className="ch-val-fl">Username</span><span className="ch-val-fv">@{validation.resolved_username}</span></div>
                    )}
                    {validation.chat_type && (
                      <div className="ch-val-field"><span className="ch-val-fl">Chat Type</span><span className="ch-val-fv">{validation.chat_type}</span></div>
                    )}
                    <div className="ch-val-field">
                      <span className="ch-val-fl">Bot Member</span>
                      <span className={`ch-val-fv ${validation.bot_is_member ? 'ok' : 'fail'}`}>{validation.bot_is_member ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="ch-val-field">
                      <span className="ch-val-fl">Bot Admin</span>
                      <span className={`ch-val-fv ${validation.bot_is_admin ? 'ok' : 'fail'}`}>{validation.bot_is_admin ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="ch-val-field">
                      <span className="ch-val-fl">Can Post</span>
                      <span className={`ch-val-fv ${validation.can_post_messages ? 'ok' : 'fail'}`}>{validation.can_post_messages ? 'Yes' : 'No'}</span>
                    </div>
                    {validation.normalized && (
                      <div className="ch-val-field"><span className="ch-val-fl">Normalized</span><span className="ch-val-fv mono">{validation.normalized}</span></div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {channels.length === 0 && !formMode && (
            <div className="empty-state">
              <Icon name="cell_tower" size={40} />
              <h3>No channels configured</h3>
              <p>Add a Telegram channel to use for campaign delivery</p>
            </div>
          )}

          {channels.length > 0 && (
            <>
              <div className="ch-tbl-wrap has-cards">
                <table className="ch-tbl">
                  <thead>
                    <tr>
                      <th>Label</th><th>Channel</th><th>Chat ID</th><th>Type</th>
                      <th>Status</th><th>Admin</th><th>Post</th><th>Last Validated</th><th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {channels.map(ch => (
                      <tr key={ch.id} className={!ch.is_enabled ? 'ch-row-disabled' : ''}>
                        <td style={{ fontWeight: 600 }}>{ch.label || <span style={{ color: 'var(--text-4)' }}>—</span>}</td>
                        <td>
                          <div style={{ fontSize: '.78rem' }}>
                            {ch.resolved_title && <div style={{ fontWeight: 500 }}>{ch.resolved_title}</div>}
                            <div className="mono" style={{ color: 'var(--c-accent-bright)', fontSize: '.72rem' }}>{ch.normalized_input}</div>
                          </div>
                        </td>
                        <td className="mono" style={{ fontSize: '.72rem' }}>{ch.resolved_chat_id || '—'}</td>
                        <td style={{ fontSize: '.72rem' }}>{ch.chat_type || '—'}</td>
                        <td><StatusBadge status={ch.last_validation_status} /></td>
                        <td style={{ textAlign: 'center' }}>{ch.bot_is_admin ? <Icon name="check" size={15} /> : <Icon name="close" size={15} />}</td>
                        <td style={{ textAlign: 'center' }}>{ch.can_post_messages ? <Icon name="check" size={15} /> : <Icon name="close" size={15} />}</td>
                        <td style={{ fontSize: '.72rem', whiteSpace: 'nowrap' }}>{fmtDate(ch.last_validated_at)}</td>
                        <td>
                          <div className="ch-actions">
                            <button className="ch-btn ch-btn--sm" onClick={() => doRevalidate(ch)} disabled={revalidatingId === ch.id} title="Revalidate">
                              {revalidatingId === ch.id ? <Icon name="sync" size={13} /> : <Icon name="refresh" size={13} />}
                            </button>
                            <button className="ch-btn ch-btn--sm" onClick={() => openEdit(ch)} title="Edit"><Icon name="edit" size={13} /></button>
                            <button className="ch-btn ch-btn--sm" onClick={() => doToggle(ch)} title={ch.is_enabled ? 'Disable' : 'Enable'}>
                              <Icon name={ch.is_enabled ? 'toggle_on' : 'toggle_off'} size={13} />
                            </button>
                            {deleteConfirm === ch.id ? (
                              <>
                                <button className="ch-btn ch-btn--sm ch-btn--danger" onClick={() => doDelete(ch.id)}>Confirm</button>
                                <button className="ch-btn ch-btn--sm" onClick={() => setDeleteConfirm(null)}>Cancel</button>
                              </>
                            ) : (
                              <button className="ch-btn ch-btn--sm" onClick={() => setDeleteConfirm(ch.id)} title="Delete"><Icon name="delete" size={13} /></button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="ch-cards">
                {channels.map(ch => (
                  <div key={ch.id} className={`ch-card ${!ch.is_enabled ? 'ch-card--disabled' : ''}`}>
                    <div className="ch-card-top">
                      <div className="ch-card-title-area">
                        <span className="ch-card-name">{ch.label || ch.resolved_title || ch.normalized_input}</span>
                        {ch.resolved_title && ch.label && (
                          <span className="ch-card-sub">{ch.resolved_title}</span>
                        )}
                      </div>
                      <StatusBadge status={ch.last_validation_status} />
                    </div>

                    <div className="ch-card-grid">
                      <div className="ch-card-field"><span className="ch-card-fl">Target</span><span className="ch-card-fv mono">{ch.normalized_input}</span></div>
                      <div className="ch-card-field"><span className="ch-card-fl">Chat ID</span><span className="ch-card-fv mono">{ch.resolved_chat_id || '—'}</span></div>
                      <div className="ch-card-field"><span className="ch-card-fl">Type</span><span className="ch-card-fv">{ch.chat_type || '—'}</span></div>
                      <div className="ch-card-field"><span className="ch-card-fl">Admin</span><span className={`ch-card-fv ${ch.bot_is_admin ? 'ok' : 'fail'}`}>{ch.bot_is_admin ? 'Yes' : 'No'}</span></div>
                      <div className="ch-card-field"><span className="ch-card-fl">Can Post</span><span className={`ch-card-fv ${ch.can_post_messages ? 'ok' : 'fail'}`}>{ch.can_post_messages ? 'Yes' : 'No'}</span></div>
                      <div className="ch-card-field"><span className="ch-card-fl">Validated</span><span className="ch-card-fv">{fmtDate(ch.last_validated_at)}</span></div>
                    </div>

                    {ch.last_validation_error && (
                      <div className="ch-card-error">{ch.last_validation_error}</div>
                    )}

                    <div className="ch-card-actions">
                      <button className="ch-btn ch-btn--sm" onClick={() => doRevalidate(ch)} disabled={revalidatingId === ch.id}>
                        {revalidatingId === ch.id ? <><Icon name="sync" size={12} /> Checking…</> : <><Icon name="refresh" size={12} /> Revalidate</>}
                      </button>
                      <button className="ch-btn ch-btn--sm" onClick={() => openEdit(ch)}><Icon name="edit" size={12} /> Edit</button>
                      <button className="ch-btn ch-btn--sm" onClick={() => doToggle(ch)}>
                        <Icon name={ch.is_enabled ? 'toggle_on' : 'toggle_off'} size={12} /> {ch.is_enabled ? 'Disable' : 'Enable'}
                      </button>
                      {deleteConfirm === ch.id ? (
                        <>
                          <button className="ch-btn ch-btn--sm ch-btn--danger" onClick={() => doDelete(ch.id)}>Confirm Delete</button>
                          <button className="ch-btn ch-btn--sm" onClick={() => setDeleteConfirm(null)}>Cancel</button>
                        </>
                      ) : (
                        <button className="ch-btn ch-btn--sm" onClick={() => setDeleteConfirm(ch.id)}><Icon name="delete" size={12} /> Delete</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}

      {tab === 'audit' && (
        <div className="ch-audit-section">
          {auditLogs.length === 0 ? (
            <div className="empty-state">
              <Icon name="history" size={40} />
              <h3>No activity yet</h3>
              <p>Channel configuration actions will appear here</p>
            </div>
          ) : (
            <>
              <div className="ch-tbl-wrap has-cards">
                <table className="ch-tbl">
                  <thead>
                    <tr><th>Action</th><th>Channel</th><th>Target</th><th>Result</th><th>Error</th><th>Time</th></tr>
                  </thead>
                  <tbody>
                    {auditLogs.map(log => {
                      const cfg = AUDIT_LABELS[log.action] || { label: log.action, color: 'var(--text-3)' };
                      return (
                        <tr key={log.id}>
                          <td><span className="ch-audit-action" style={{ color: cfg.color }}>{cfg.label}</span></td>
                          <td style={{ fontSize: '.78rem' }}>{log.channel_label || '—'}</td>
                          <td className="mono" style={{ fontSize: '.72rem' }}>{log.normalized_input || '—'}</td>
                          <td style={{ fontSize: '.72rem' }}>{log.result || '—'}</td>
                          <td style={{ fontSize: '.72rem', color: 'var(--c-rose)', maxWidth: 200, whiteSpace: 'normal' }}>{log.error_reason || '—'}</td>
                          <td style={{ fontSize: '.72rem', whiteSpace: 'nowrap' }}>{fmtDate(log.created_at)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="ch-cards">
                {auditLogs.map(log => {
                  const acfg = AUDIT_LABELS[log.action] || { label: log.action, color: 'var(--text-3)' };
                  return (
                    <div key={log.id} className="ch-card">
                      <div className="ch-card-top">
                        <span className="ch-audit-action" style={{ color: acfg.color, fontSize: '.8rem', fontWeight: 600 }}>{acfg.label}</span>
                        <span style={{ fontSize: '.68rem', color: 'var(--text-3)' }}>{fmtDate(log.created_at)}</span>
                      </div>
                      <div className="ch-card-grid">
                        {log.channel_label && <div className="ch-card-field"><span className="ch-card-fl">Channel</span><span className="ch-card-fv">{log.channel_label}</span></div>}
                        {log.normalized_input && <div className="ch-card-field"><span className="ch-card-fl">Target</span><span className="ch-card-fv mono">{log.normalized_input}</span></div>}
                        {log.result && <div className="ch-card-field"><span className="ch-card-fl">Result</span><span className="ch-card-fv">{log.result}</span></div>}
                        {log.error_reason && <div className="ch-card-field"><span className="ch-card-fl">Error</span><span className="ch-card-fv" style={{ color: 'var(--c-rose)' }}>{log.error_reason}</span></div>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
