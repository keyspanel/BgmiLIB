import React, { useEffect, useState } from 'react';
import { apiGet, apiPut } from '../api';
import UserAvatar from '../components/UserAvatar';

export default function Users() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    apiGet(`/users?search=${encodeURIComponent(search)}`).then(setUsers).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [search]);

  const toggleBan = async (user: any) => {
    const action = user.is_banned ? 'unban' : 'ban';
    if (!confirm(`${action === 'ban' ? 'Ban' : 'Unban'} this user? ${action === 'ban' ? 'They will lose access to the bot.' : 'They will regain bot access.'}`)) return;
    try {
      await apiPut(`/users/${user.id}/${action}`);
      setMsg(`User ${action === 'ban' ? 'banned' : 'unbanned'}`);
      load();
      setTimeout(() => setMsg(''), 2500);
    } catch (err: any) { setMsg(err.message); }
  };

  const displayName = (u: any) => {
    let name = ((u.first_name || '') + ' ' + (u.last_name || '')).trim();
    if (!name) name = u.username ? '@' + u.username : 'Unknown';
    return name;
  };

  const getInitials = (u: any) => displayName(u).substring(0, 2).toUpperCase();
  const activeCount = users.filter(u => !u.is_banned).length;
  const bannedCount = users.filter(u => u.is_banned).length;

  return (
    <div className="page">
      {users.length > 0 && (
        <div className="metric-row" style={{ marginBottom: 16 }}>
          <div className="metric-pill"><span className="metric-label">Total</span><span className="metric-val">{users.length}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-emerald)' }} /><span className="metric-label">Active</span><span className="metric-val">{activeCount}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-rose)' }} /><span className="metric-label">Banned</span><span className="metric-val">{bannedCount}</span></div>
        </div>
      )}

      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search by name, username, Telegram ID..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      {msg && <div className="toast-msg">{msg}</div>}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading users...</span></div>
      ) : users.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
          <div className="empty-title">No users found</div>
          <div className="empty-desc">Users who interact with the Telegram bot will appear here</div>
        </div>
      ) : (
        <div className="list">
          {users.map(user => (
            <div key={user.id} className="list-card">
              <div className="list-card-top">
                <div className="list-card-info">
                  <UserAvatar name={displayName(user)} photoUrl={user.profile_photo_url} className={user.is_banned ? 'danger' : 'accent'} />
                  <div>
                    <div className="list-card-title">{displayName(user)}</div>
                    <div className="list-card-sub">{user.username && `@${user.username} · `}TG: {user.telegram_id}</div>
                  </div>
                </div>
                <div className={`badge-${user.is_banned ? 'danger' : 'success'}`}>{user.is_banned ? 'Banned' : 'Active'}</div>
              </div>
              <div className="list-card-actions">
                <button className={user.is_banned ? 'btn-primary-sm' : 'btn-danger-sm'} onClick={() => toggleBan(user)}>
                  {user.is_banned ? 'Unban User' : 'Ban User'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
