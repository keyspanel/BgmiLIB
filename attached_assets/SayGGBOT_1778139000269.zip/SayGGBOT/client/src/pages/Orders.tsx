import React, { useEffect, useState } from 'react';
import { apiGet, apiPut } from '../api';
import cfg from '../config';
import UserAvatar from '../components/UserAvatar';

const statusOptions = ['pending', 'awaiting_payment', 'paid', 'cancelled'];
const statusClass: Record<string, string> = { pending: 'warning', awaiting_payment: 'info', paid: 'success', cancelled: 'danger' };

export default function Orders() {
  const [data, setData] = useState<any>({ orders: [], total: 0, page: 1, totalPages: 1 });
  const [stats, setStats] = useState<any>(null);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<any>({ search: '', status: '', category_id: '', page: 1 });
  const [editingTxn, setEditingTxn] = useState<number | null>(null);
  const [txnValue, setTxnValue] = useState('');
  const [msg, setMsg] = useState('');
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => { if (v !== '') params.set(k, String(v)); });
    apiGet(`/orders?${params}`).then(setData).catch(() => {}).finally(() => setLoading(false));
    apiGet('/orders/stats').then(setStats).catch(() => {});
  };

  useEffect(() => { apiGet('/categories').then(setCategories).catch(() => {}); }, []);
  useEffect(() => { load(); }, [filters]);

  const changeStatus = async (order: any, newStatus: string) => {
    try { await apiPut(`/orders/${order.id}/status`, { status: newStatus }); load(); setMsg('Status updated'); setTimeout(() => setMsg(''), 2000); } catch {}
  };

  const saveTxn = async (orderId: number) => {
    try { await apiPut(`/orders/${orderId}/txn`, { txn_ref: txnValue }); setEditingTxn(null); load(); } catch {}
  };

  const setFilter = (key: string, val: any) => setFilters((p: any) => ({ ...p, [key]: val, page: 1 }));
  const formatDate = (d: string | null) => d ? new Date(d).toLocaleString(cfg.locale, { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }) : '-';

  return (
    <div className="page">
      {stats && (
        <div className="metric-row" style={{ marginBottom: 16 }}>
          <div className="metric-pill"><span className="metric-label">Total</span><span className="metric-val">{stats.total_orders}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-amber)' }} /><span className="metric-label">Pending</span><span className="metric-val">{stats.pending_orders}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-emerald)' }} /><span className="metric-label">Paid</span><span className="metric-val">{stats.paid_orders}</span></div>
          <div className="metric-pill"><span className="metric-dot" style={{ background: 'var(--c-rose)' }} /><span className="metric-label">Cancelled</span><span className="metric-val">{stats.cancelled_orders || 0}</span></div>
        </div>
      )}

      <div className="toolbar">
        <div className="search-wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Search by user, order ID..." value={filters.search} onChange={e => setFilter('search', e.target.value)} />
        </div>
      </div>

      <div className="filter-row">
        <select value={filters.status} onChange={e => setFilter('status', e.target.value)}>
          <option value="">All Status</option>
          {statusOptions.map(s => <option key={s} value={s}>{s.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</option>)}
        </select>
        <select value={filters.category_id} onChange={e => setFilter('category_id', e.target.value)}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.displayName || c.name}</option>)}
        </select>
      </div>

      {msg && <div className="toast-msg">{msg}</div>}

      {loading ? (
        <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading orders...</span></div>
      ) : data.orders.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg></div>
          <div className="empty-title">No orders found</div>
          <div className="empty-desc">Orders from the Telegram bot will appear here</div>
        </div>
      ) : (
        <>
          <div className="count-label">{data.total} order{data.total === 1 ? '' : 's'}</div>
          <div className="list">
            {data.orders.map((order: any) => {
              const sc = statusClass[order.status] || 'warning';
              const isExpanded = expandedOrder === order.id;
              return (
                <div key={order.id} className="list-card" onClick={() => setExpandedOrder(isExpanded ? null : order.id)}>
                  <div className="list-card-top">
                    <div className="list-card-info">
                      <UserAvatar name={order.displayUser} photoUrl={order.profile_photo_url} className="accent" size="sm" />
                      <div>
                        <div className="list-card-title"><span className="order-id" style={{ marginRight: 6 }}>#{order.id}</span>{order.displayUser}</div>
                        <div className="list-card-sub">{formatDate(order.created_at)}</div>
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div className="list-card-price">{cfg.currency}{Number(order.amount || 0).toLocaleString()}</div>
                      <div className={`badge-${sc}`}>{order.status.replace('_', ' ')}</div>
                    </div>
                  </div>
                  <div className="list-card-meta">
                    <span>{order.displayCategory} / {order.displayDuration}</span>
                    {order.key_value && <span className="mono-text-sm">{order.key_value.substring(0, 20)}{order.key_value.length > 20 ? '...' : ''}</span>}
                  </div>
                  <div className="list-card-meta">
                    <span>Ref: {editingTxn === order.id ? '' : (order.txn_ref || '-')}</span>
                    {editingTxn === order.id ? (
                      <div className="inline-edit" onClick={e => e.stopPropagation()}>
                        <input value={txnValue} onChange={e => setTxnValue(e.target.value)} placeholder="TXN ref" />
                        <button className="btn-primary-sm" onClick={() => saveTxn(order.id)}>Save</button>
                        <button className="btn-ghost-sm" onClick={() => setEditingTxn(null)}>X</button>
                      </div>
                    ) : (
                      <button className="btn-ghost-sm" onClick={(e) => { e.stopPropagation(); setEditingTxn(order.id); setTxnValue(order.txn_ref || ''); }}>Edit Ref</button>
                    )}
                  </div>
                  {isExpanded && (
                    <div className="list-card-actions" onClick={e => e.stopPropagation()}>
                      {statusOptions.filter(s => s !== order.status).map(s => (
                        <button key={s} className={`btn-${statusClass[s]}-sm`} onClick={() => changeStatus(order, s)}>
                          {s.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {data.totalPages > 1 && (
            <div className="pagination">
              <button className="pg-btn" disabled={filters.page <= 1} onClick={() => setFilters((p: any) => ({...p, page: p.page - 1}))}>Previous</button>
              <span className="pg-info">{filters.page} / {data.totalPages}</span>
              <button className="pg-btn" disabled={filters.page >= data.totalPages} onClick={() => setFilters((p: any) => ({...p, page: p.page + 1}))}>Next</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
