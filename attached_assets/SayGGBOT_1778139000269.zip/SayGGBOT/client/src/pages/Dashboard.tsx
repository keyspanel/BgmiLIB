import React, { useEffect, useState, useMemo } from 'react';
import { apiGet } from '../api';
import { useNavigate } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import cfg from '../config';
import UserAvatar from '../components/UserAvatar';

const fmt = (v: any) => `${cfg.currency}${Number(v || 0).toLocaleString(cfg.locale)}`;
const fmtCompact = (v: any) => {
  if (v >= 10000000) return `${cfg.currency}${(v / 10000000).toFixed(1)}Cr`;
  if (v >= 100000) return `${cfg.currency}${(v / 100000).toFixed(1)}L`;
  if (v >= 1000) return `${cfg.currency}${(v / 1000).toFixed(1)}K`;
  return fmt(v);
};

const timeAgo = (d: string | null) => {
  if (!d) return '';
  const diff = (Date.now() - new Date(d).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(d).toLocaleDateString(cfg.locale, { day: 'numeric', month: 'short', timeZone: 'Asia/Kolkata' });
};

const statusIcon: Record<string, { color: string; bg: string; label: string }> = {
  paid: { color: 'var(--d-green)', bg: 'var(--d-green-soft)', label: 'Paid' },
  pending: { color: 'var(--d-amber)', bg: 'var(--d-amber-soft)', label: 'Pending' },
  awaiting_payment: { color: 'var(--d-amber)', bg: 'var(--d-amber-soft)', label: 'Awaiting' },
  cancelled: { color: 'var(--d-rose)', bg: 'var(--d-rose-soft)', label: 'Cancelled' },
};

function ChartTooltipContent({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="d-tooltip">
      <span className="d-tooltip-date">{label}</span>
      <span className="d-tooltip-rev">{fmt(payload[0]?.value)}</span>
      <span className="d-tooltip-ord">{payload[1]?.value || 0} orders</span>
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    apiGet('/dashboard').then(setData).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const chart = useMemo(() => {
    if (!data?.chart) return [];
    return data.chart.map((d: any) => ({
      ...d,
      label: new Date(d.date).toLocaleDateString(cfg.locale, { day: 'numeric', month: 'short', timeZone: 'Asia/Kolkata' }),
    }));
  }, [data?.chart]);

  const peakDay = useMemo(() => {
    if (!chart.length) return null;
    return chart.reduce((best: any, d: any) => d.revenue > (best?.revenue || 0) ? d : best, chart[0]);
  }, [chart]);

  const chartTotal = useMemo(() => {
    if (!chart.length) return { revenue: 0, orders: 0 };
    return chart.reduce((acc: any, d: any) => ({ revenue: acc.revenue + d.revenue, orders: acc.orders + d.orders }), { revenue: 0, orders: 0 });
  }, [chart]);

  if (loading) return (
    <div className="d-loader">
      <div className="d-loader-ring" />
      <span className="d-loader-text">Loading dashboard...</span>
    </div>
  );

  if (!data) return (
    <div className="d-page">
      <div className="d-error-card">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
        <span>Unable to load dashboard data. Please try again.</span>
      </div>
    </div>
  );

  const s = data.sales || {};
  const o = data.orders || {};
  const k = data.keys || {};

  const todayDelta = s.yesterday?.revenue > 0
    ? Math.round(((s.today?.revenue - s.yesterday?.revenue) / s.yesterday?.revenue) * 100)
    : null;

  const conversionRate = o.paid_orders ? Math.round((o.paid_orders / Math.max(o.total_orders, 1)) * 100) : 0;

  return (
    <div className="d-page">

      <section className="d-hero">
        <div className="d-hero-accent" />
        <div className="d-hero-inner">
          <div className="d-hero-main">
            <div className="d-hero-eyebrow">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
              Today's Revenue
            </div>
            <div className="d-hero-value">{fmt(s.today?.revenue)}</div>
            <div className="d-hero-meta">
              <span className="d-hero-orders">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                {s.today?.orders || 0} orders today
              </span>
              {todayDelta !== null && (
                <span className={`d-hero-delta ${todayDelta >= 0 ? 'up' : 'down'}`}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    {todayDelta >= 0
                      ? <polyline points="18 15 12 9 6 15" />
                      : <polyline points="6 9 12 15 18 9" />}
                  </svg>
                  {Math.abs(todayDelta)}%
                </span>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="d-kpi-row">
        <div className="d-kpi-card">
          <div className="d-kpi-icon" style={{ background: 'var(--d-green-soft)', color: 'var(--d-green)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
          </div>
          <div className="d-kpi-body">
            <div className="d-kpi-value">{fmt(s.yesterday?.revenue)}</div>
            <div className="d-kpi-label">Yesterday</div>
          </div>
          <div className="d-kpi-sub">{s.yesterday?.orders || 0} orders</div>
        </div>
        <div className="d-kpi-card">
          <div className="d-kpi-icon" style={{ background: 'var(--c-accent-surface)', color: 'var(--c-accent)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          </div>
          <div className="d-kpi-body">
            <div className="d-kpi-value">{fmt(s.weekly?.revenue)}</div>
            <div className="d-kpi-label">This Week</div>
          </div>
          <div className="d-kpi-sub">{s.weekly?.orders || 0} orders</div>
        </div>
        <div className="d-kpi-card">
          <div className="d-kpi-icon" style={{ background: 'var(--c-sky-surface)', color: 'var(--c-sky)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          </div>
          <div className="d-kpi-body">
            <div className="d-kpi-value">{fmt(s.monthly?.revenue)}</div>
            <div className="d-kpi-label">This Month</div>
          </div>
          <div className="d-kpi-sub">{s.monthly?.orders || 0} orders</div>
        </div>
      </section>

      <section className="d-module">
        <div className="d-module-head">
          <div className="d-module-icon" style={{ background: 'var(--d-green-soft)', color: 'var(--d-green)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z"/></svg>
          </div>
          <div className="d-module-title-group">
            <h3 className="d-module-title">Lifetime Revenue</h3>
            <span className="d-module-badge green">{o.paid_orders || 0} paid orders</span>
          </div>
        </div>
        <div className="d-lifetime-body">
          <div className="d-lifetime-val">{fmt(o.total_revenue)}</div>
          <div className="d-lifetime-bar-wrap">
            <div className="d-lifetime-bar">
              <div className="d-lifetime-fill" style={{ width: `${Math.min(100, (o.paid_orders / Math.max(o.total_orders, 1)) * 100)}%` }} />
            </div>
            <div className="d-lifetime-foot">
              <span>{o.total_orders || 0} total</span>
              <span className="d-lifetime-conv">{conversionRate}% conversion</span>
            </div>
          </div>
        </div>
      </section>

      {chart.length > 0 && (
        <section className="d-module">
          <div className="d-module-head">
            <div className="d-module-icon" style={{ background: 'var(--c-accent-surface)', color: 'var(--c-accent)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </div>
            <div className="d-module-title-group">
              <h3 className="d-module-title">Revenue Trend</h3>
              <span className="d-module-subtitle">Last 30 days</span>
            </div>
            <div className="d-module-stat">{fmtCompact(chartTotal.revenue)}</div>
          </div>
          <div className="d-chart-container">
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={chart} margin={{ top: 8, right: 4, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="dRevGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--d-green)" stopOpacity={0.2} />
                    <stop offset="100%" stopColor="var(--d-green)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: 'var(--text-4)' }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 10, fill: 'var(--text-4)' }} axisLine={false} tickLine={false} tickFormatter={fmtCompact} />
                <Tooltip content={<ChartTooltipContent />} />
                <Area type="monotone" dataKey="revenue" stroke="var(--d-green)" strokeWidth={2} fill="url(#dRevGrad)" dot={false} activeDot={{ r: 5, fill: 'var(--d-green)', stroke: '#0a0a12', strokeWidth: 2 }} />
                <Area type="monotone" dataKey="orders" stroke="var(--text-4)" strokeWidth={1} strokeDasharray="4 4" fill="none" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
            {peakDay && (
              <div className="d-chart-peak">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="var(--d-green)" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                <span>Peak: <strong>{peakDay.label}</strong> — {fmt(peakDay.revenue)}</span>
              </div>
            )}
          </div>
        </section>
      )}

      <section className="d-module">
        <div className="d-module-head">
          <div className="d-module-icon" style={{ background: 'var(--d-amber-soft)', color: 'var(--d-amber)' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div className="d-module-title-group">
            <h3 className="d-module-title">Order Pipeline</h3>
            <span className="d-module-subtitle">{o.total_orders || 0} total orders</span>
          </div>
        </div>
        <div className="d-pipeline-grid">
          <div className="d-pipeline-card paid" onClick={() => navigate('/orders')}>
            <div className="d-pipeline-card-icon paid">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <div className="d-pipeline-card-value">{o.paid_orders || 0}</div>
            <div className="d-pipeline-card-label">Paid</div>
          </div>
          <div className="d-pipeline-card pending" onClick={() => navigate('/orders')}>
            <div className="d-pipeline-card-icon pending">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <div className="d-pipeline-card-value">{o.pending_orders || 0}</div>
            <div className="d-pipeline-card-label">Pending</div>
          </div>
          <div className="d-pipeline-card cancelled" onClick={() => navigate('/orders')}>
            <div className="d-pipeline-card-icon cancelled">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            </div>
            <div className="d-pipeline-card-value">{o.cancelled_orders || 0}</div>
            <div className="d-pipeline-card-label">Cancelled</div>
          </div>
        </div>
      </section>

      <div className="d-split-row">
        <section className="d-module d-module-half">
          <div className="d-module-head">
            <div className="d-module-icon" style={{ background: 'var(--c-sky-surface)', color: 'var(--c-sky)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
            </div>
            <div className="d-module-title-group">
              <h3 className="d-module-title">Inventory</h3>
            </div>
            <div className="d-module-stat">{k.total_keys || 0}</div>
          </div>
          <div className="d-inv-list">
            <div className="d-inv-item" onClick={() => navigate('/keys')}>
              <div className="d-inv-marker avail" />
              <span className="d-inv-name">Available</span>
              <span className="d-inv-val avail">{k.available_keys || 0}</span>
            </div>
            <div className="d-inv-item" onClick={() => navigate('/keys')}>
              <div className="d-inv-marker reserved" />
              <span className="d-inv-name">Reserved</span>
              <span className="d-inv-val reserved">{k.reserved_keys || 0}</span>
            </div>
            <div className="d-inv-item" onClick={() => navigate('/keys')}>
              <div className="d-inv-marker sold" />
              <span className="d-inv-name">Sold</span>
              <span className="d-inv-val sold">{k.sold_keys || 0}</span>
            </div>
          </div>
        </section>

        <section className="d-module d-module-half">
          <div className="d-module-head">
            <div className="d-module-icon" style={{ background: 'var(--c-emerald-surface)', color: 'var(--c-emerald)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
            </div>
            <div className="d-module-title-group">
              <h3 className="d-module-title">Network</h3>
            </div>
          </div>
          <div className="d-network-list">
            <div className="d-network-item" onClick={() => navigate('/resellers')}>
              <div className="d-network-item-info">
                <span className="d-network-item-val">{data.resellers || 0}</span>
                <span className="d-network-item-label">Resellers</span>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
            <div className="d-network-item" onClick={() => navigate('/paid-users')}>
              <div className="d-network-item-info">
                <span className="d-network-item-val">{data.paidUsers || 0}</span>
                <span className="d-network-item-label">Paid Users</span>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          </div>
        </section>
      </div>

      <section className="d-actions-section">
        <div className="d-section-label">Quick Actions</div>
        <div className="d-actions-grid">
          <button className="d-action-btn" onClick={() => navigate('/keys')}>
            <div className="d-action-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </div>
            <div className="d-action-text">
              <span className="d-action-title">Add Keys</span>
              <span className="d-action-desc">Upload new inventory</span>
            </div>
          </button>
          <button className="d-action-btn" onClick={() => navigate('/orders')}>
            <div className="d-action-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            </div>
            <div className="d-action-text">
              <span className="d-action-title">View Orders</span>
              <span className="d-action-desc">Manage transactions</span>
            </div>
          </button>
          <button className="d-action-btn" onClick={() => navigate('/categories')}>
            <div className="d-action-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            </div>
            <div className="d-action-text">
              <span className="d-action-title">Categories</span>
              <span className="d-action-desc">Manage products</span>
            </div>
          </button>
          <button className="d-action-btn" onClick={() => navigate('/bot-manage')}>
            <div className="d-action-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 010 14.14M4.93 4.93a10 10 0 000 14.14M12 2v2m0 16v2M2 12h2m16 0h2"/></svg>
            </div>
            <div className="d-action-text">
              <span className="d-action-title">Bot Settings</span>
              <span className="d-action-desc">Configure bot</span>
            </div>
          </button>
        </div>
      </section>

      {data.recentActivity && data.recentActivity.length > 0 && (
        <section className="d-module">
          <div className="d-module-head">
            <div className="d-module-icon" style={{ background: 'var(--bg-3)', color: 'var(--text-2)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </div>
            <div className="d-module-title-group">
              <h3 className="d-module-title">Recent Activity</h3>
              <span className="d-module-subtitle">{data.recentActivity.length} latest</span>
            </div>
          </div>
          <div className="d-feed-list">
            {data.recentActivity.map((a: any) => {
              const si = statusIcon[a.status] || statusIcon.pending;
              return (
                <div key={a.id} className="d-feed-item" onClick={() => navigate('/orders')}>
                  {a.profile_photo_url ? (
                    <div className="d-feed-avatar" style={{ background: si.bg, color: si.color, overflow: 'hidden', padding: 0 }}>
                      <img src={a.profile_photo_url} alt="" className="avatar-img" onError={(e) => { const t = e.currentTarget.parentElement!; t.style.padding = ''; t.textContent = (a.first_name || a.username || 'U').charAt(0).toUpperCase(); (e.currentTarget as HTMLImageElement).remove(); }} />
                    </div>
                  ) : (
                    <div className="d-feed-avatar" style={{ background: si.bg, color: si.color }}>
                      {(a.first_name || a.username || 'U').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="d-feed-body">
                    <div className="d-feed-name">{a.first_name || a.username || 'User'}</div>
                    <div className="d-feed-detail">
                      {a.category_name}{a.duration_name ? ` · ${a.duration_name}` : ''}
                    </div>
                  </div>
                  <div className="d-feed-right">
                    <div className="d-feed-amount">{fmt(a.amount)}</div>
                    <div className="d-feed-time">{timeAgo(a.created_at)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

    </div>
  );
}
