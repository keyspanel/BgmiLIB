import React, { useEffect, useState, useCallback, useRef } from 'react';
import { apiGet, apiPost, apiPut, apiDelete } from '../api';
import cfg from '../config';
import UserAvatar from '../components/UserAvatar';

// ── TYPES ──────────────────────────────────────────────────────────────────

type ScopeType = 'all_products' | 'selected_categories' | 'selected_pairs';
type HomeTab = 'campaigns' | 'templates' | 'settings';
type LogsTab = 'runs' | 'deliveries' | 'failures';
type Nav =
  | { screen: 'home' }
  | { screen: 'analytics'; campaignId?: number; campaignName?: string }
  | { screen: 'logs'; campaignId?: number; campaignName?: string }
  | { screen: 'detail'; campaignId: number }
  | { screen: 'deep-link-detail'; linkId: number; campaignName?: string; fromCampaignId?: number }
  | { screen: 'campaign-form'; campaign: Campaign | null }
  | { screen: 'template-form'; template: Template | null };

interface Campaign {
  id: number; name: string; description: string; status: string;
  campaign_mode: string; linked_discount_plan_id: number | null;
  category_scope_json: string; duration_scope_json: string;
  repeat_mode: string; timezone: string; start_at: string; expire_at: string;
  next_run_at: string | null; next_expire_at: string | null;
  is_enabled: boolean; promo_template_id: number | null; expiry_template_id: number | null;
  send_to_users: boolean; send_to_channels: boolean;
  total_runs?: number; total_opens?: number; total_purchases?: number; total_revenue?: number;
  created_at: string; discount_rules?: any[]; targets?: any[]; deep_links?: any[]; deep_link_code?: string;
}
interface Template {
  id: number; name: string; template_type: string; body_text: string; parse_mode: string;
  inline_buttons_json: string | null; custom_emoji_json: string | null; is_active: boolean;
  created_at: string; updated_at?: string; updated_by?: string; edited_via?: string; version_count?: number;
}
interface Stats {
  total_campaigns: number; active_campaigns: number; scheduled_campaigns: number;
  runs_24h: number; total_opens: number; total_purchases: number; total_revenue: number; unique_users: number;
}

// ── CONSTANTS ──────────────────────────────────────────────────────────────

const STATUS_MAP: Record<string, { color: string; bg: string; label: string }> = {
  draft:     { color: 'var(--text-2)',        bg: 'var(--bg-4)',              label: 'Draft' },
  scheduled: { color: 'var(--c-accent-bright)', bg: 'var(--c-accent-surface)', label: 'Scheduled' },
  active:    { color: 'var(--c-emerald)',     bg: 'var(--c-emerald-surface)', label: 'Active' },
  expiring:  { color: 'var(--c-amber)',       bg: 'var(--c-amber-surface)',   label: 'Expiring' },
  paused:    { color: 'var(--c-amber)',       bg: 'var(--c-amber-surface)',   label: 'Paused' },
  expired:   { color: 'var(--text-3)',        bg: 'var(--bg-4)',              label: 'Expired' },
  disabled:  { color: 'var(--text-3)',        bg: 'var(--bg-4)',              label: 'Disabled' },
  completed: { color: 'var(--c-emerald)',     bg: 'var(--c-emerald-surface)', label: 'Completed' },
  failed:    { color: 'var(--c-red)',         bg: 'var(--c-red-surface)',     label: 'Failed' },
  running:   { color: 'var(--c-accent-bright)', bg: 'var(--c-accent-surface)', label: 'Running' },
};
const MODE_MAP: Record<string, string> = { fixed_plan: 'Fixed Plan', random_discount: 'Random %', message_only: 'Msg Only' };
const REPEAT_MAP: Record<string, string> = { once: 'Once', daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly' };
const TARGET_MAP: Record<string, string> = {
  all_users: 'All Users', paid_users: 'Paid', resellers: 'Resellers',
  active_users: 'Active', clicked_users: 'Clicked', purchased_users: 'Purchasers', channels: 'Channels',
};

const VARS = [
  { key: '{campaign_name}' }, { key: '{discount_percent}' }, { key: '{original_price}' },
  { key: '{discounted_price}' }, { key: '{current_price}' }, { key: '{expires_at}' },
  { key: '{starts_at}' }, { key: '{deep_link}' }, { key: '{category_name}' },
  { key: '{duration_name}' }, { key: '{user_name}' },
  { key: '{product_discount_lines}' }, { key: '{product_expiry_lines}' },
];

const SAMPLE_DATA: Record<string, Record<string, string>> = {
  promo_start: {
    '{campaign_name}': 'Sunday Discount', '{user_name}': 'SayGG → Admin',
    '{discount_percent}': '20', '{original_price}': `${cfg.currency}10.00`,
    '{discounted_price}': `${cfg.currency}8.00`, '{current_price}': `${cfg.currency}8.00`,
    '{expires_at}': '28 Mar 2026, 05:12 AM', '{starts_at}': '27 Mar 2026, 10:00 PM',
    '{deep_link}': 'https://t.me/example_bot?start=promo_demo',
    '{category_name}': 'NovaEsp', '{duration_name}': 'Month',
    '{product_discount_lines}': `• <b>NovaEsp · Day</b>\n   <s>Original: ₹10.00</s>\n   <b>Now: ₹8.00</b>   (You save ₹2.00)\n\n• <b>NovaEsp · Month</b>\n   <s>Original: ₹20.00</s>\n   <b>Now: ₹16.00</b>   (You save ₹4.00)`,
    '{product_expiry_lines}': '(not used in Promo Start)',
  },
  promo_expiry: {
    '{campaign_name}': 'Sunday Discount', '{user_name}': 'SayGG → Admin',
    '{discount_percent}': '20', '{original_price}': `${cfg.currency}10.00`,
    '{discounted_price}': `${cfg.currency}8.00`, '{current_price}': `${cfg.currency}10.00`,
    '{expires_at}': '28 Mar 2026, 05:12 AM', '{starts_at}': '27 Mar 2026, 10:00 PM',
    '{deep_link}': 'https://t.me/example_bot?start=promo_demo',
    '{category_name}': 'NovaEsp', '{duration_name}': 'Month',
    '{product_discount_lines}': '(not used in Promo Expiry)',
    '{product_expiry_lines}': `• <b>NovaEsp · Day</b>\n   <s>Discounted: ₹8.00</s>\n   <b>Current: ₹10.00</b>\n\n• <b>NovaEsp · Month</b>\n   <s>Discounted: ₹16.00</s>\n   <b>Current: ₹20.00</b>`,
  },
  general: {
    '{campaign_name}': 'Sunday Discount', '{user_name}': 'SayGG → Admin',
    '{discount_percent}': '20', '{original_price}': `${cfg.currency}10.00`,
    '{discounted_price}': `${cfg.currency}8.00`, '{current_price}': `${cfg.currency}10.00`,
    '{expires_at}': '28 Mar 2026, 05:12 AM', '{starts_at}': '27 Mar 2026, 10:00 PM',
    '{deep_link}': 'https://t.me/example_bot?start=promo_demo',
    '{category_name}': 'NovaEsp', '{duration_name}': 'Month',
    '{product_discount_lines}': `• NovaEsp · Month   Now: ₹8.00`,
    '{product_expiry_lines}': `• NovaEsp · Month   Current: ₹10.00`,
  },
};

const RECOMMENDED_BODIES: Record<string, { body: string; buttons: any[] }> = {
  promo_start: {
    body: `📢 <b>{campaign_name}</b> — Limited Offer\n\nHi <b>{user_name}</b> 👋\n\n💰 <b>{discount_percent}% Discounted Prices</b>\n──────────────\n{product_discount_lines}\n──────────────\n\n⏰ <b>Offer ends:</b> {expires_at}\n\nTap below to open the store and claim your deal ↓`,
    buttons: [{ id: 'btn_start_1', type: 'url', text: 'Buy Now', url: '{deep_link}', style: 'primary', icon_custom_emoji_id: '', row: 1, enabled: true }],
  },
  promo_expiry: {
    body: `⏰ <b>{campaign_name} Expired</b>\n\nHi <b>{user_name}</b> 👋\n\nThe promotional prices have ended. Current prices are now:\n\n──────────────\n{product_expiry_lines}\n──────────────\n\nCheck the store for active offers and new discounts.`,
    buttons: [{ id: 'btn_expiry_1', type: 'url', text: 'Open Store', url: '{deep_link}', style: '', icon_custom_emoji_id: '', row: 1, enabled: true }],
  },
};

// Telegram Bot API 9.4 valid style values for InlineKeyboardButton.
// Only these three are recognized by the Telegram API; others are omitted on send.
const CB_STYLE_OPTIONS = [
  { value: '',        label: 'Default', color: 'var(--text-3)' },
  { value: 'primary', label: 'Blue',    color: 'var(--c-accent)' },
  { value: 'success', label: 'Green',   color: 'var(--c-emerald)' },
  { value: 'danger',  label: 'Red',     color: 'var(--c-rose)' },
];

const COMMON_TIMEZONES = [
  'Asia/Kolkata', 'Asia/Dhaka', 'Asia/Karachi', 'Asia/Colombo', 'Asia/Kathmandu',
  'Asia/Dubai', 'Asia/Riyadh', 'Asia/Tehran', 'Asia/Baghdad',
  'Asia/Singapore', 'Asia/Hong_Kong', 'Asia/Tokyo', 'Asia/Seoul', 'Asia/Shanghai',
  'Asia/Jakarta', 'Asia/Manila', 'Asia/Bangkok',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Europe/Moscow', 'Europe/Istanbul',
  'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
  'America/Sao_Paulo', 'America/Toronto',
  'Africa/Cairo', 'Africa/Nairobi', 'Africa/Lagos',
  'Australia/Sydney', 'Australia/Melbourne', 'Pacific/Auckland', 'UTC',
];

// ── BUTTON BUILDER HELPERS ──────────────────────────────────────────────────

const TG_VALID_STYLES = new Set(['primary', 'success', 'danger']);

const normalizeBtn = (b: any): any => {
  const rawStyle = (b.style || '').trim().toLowerCase();
  return {
    id:                   b.id || `btn_${Math.random().toString(36).slice(2, 8)}`,
    type:                 b.type || 'url',
    text:                 b.text || '',
    url:                  b.url || '{deep_link}',
    style:                TG_VALID_STYLES.has(rawStyle) ? rawStyle : '',
    icon_custom_emoji_id: b.icon_custom_emoji_id || b.emoji_id || '',
    row:                  b.row || 1,
    enabled:              b.enabled !== false,
  };
};

const getButtonTelegramText = (b: any): string => {
  return (b.text || 'Button').trim() || 'Button';
};

const getButtonPreviewText = (b: any): string => getButtonTelegramText(b);

// Bot API 9.4 valid styles only; others won't be set after normalization
const btnStyleClass = (style: string) => {
  if (style === 'primary') return ' ibe-s-primary';
  if (style === 'success') return ' ibe-s-success';
  if (style === 'danger')  return ' ibe-s-danger';
  return '';
};

const phoneBtnClass = (style: string) => {
  if (style === 'primary') return ' s-primary';
  if (style === 'success') return ' s-success';
  if (style === 'danger')  return ' s-danger';
  if (!style)              return ' s-none';
  return '';
};

const SAFE_TAGS = new Set(['b', 'i', 'u', 's', 'em', 'strong', 'code', 'pre', 'a', 'br']);
const sanitizeHtml = (html: string): string =>
  html.replace(/<\/?([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>/g, (match, tag) => {
    const t = tag.toLowerCase();
    if (SAFE_TAGS.has(t)) return match.startsWith('</') ? `</${t}>` : match;
    return '';
  }).replace(/<script[\s\S]*?<\/script>/gi, '');

const EMOJI_REGEX = /\p{Emoji_Presentation}|\p{Extended_Pictographic}|\u200D|\uFE0F|\u20E3/gu;

const stripEmojisForChannel = (text: string): string => {
  let result = text.replace(/<tg-emoji[^>]*>.*?<\/tg-emoji>/gi, '');
  result = result.replace(EMOJI_REGEX, '');
  result = result.replace(/[ \t]+/g, ' ');
  const lines = result.split('\n');
  const cleaned: string[] = [];
  for (const line of lines) {
    const s = line.trim();
    if (s) {
      cleaned.push(line);
    } else if (cleaned.length > 0 && cleaned[cleaned.length - 1].trim()) {
      cleaned.push('');
    }
  }
  while (cleaned.length > 0 && !cleaned[cleaned.length - 1].trim()) cleaned.pop();
  while (cleaned.length > 0 && !cleaned[0].trim()) cleaned.shift();
  return cleaned.join('\n');
};

// ── UTILITIES ──────────────────────────────────────────────────────────────

const fmt = (v: any) =>
  `${cfg.currency}${Number(v || 0).toLocaleString(cfg.locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtDate = (d: string | null, tz?: string) => {
  if (!d) return '—';
  try {
    return new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true, timeZone: tz || 'Asia/Kolkata' });
  } catch {
    return new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true });
  }
};

const toLocalInput = (utc: string, tz: string): string => {
  if (!utc) return '';
  try {
    const d = new Date(utc);
    const parts = new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false, timeZone: tz }).formatToParts(d);
    const g = (t: string) => parts.find(p => p.type === t)?.value || '00';
    return `${g('year')}-${g('month')}-${g('day')}T${g('hour')}:${g('minute')}`;
  } catch { return new Date(utc).toISOString().slice(0, 16); }
};

const fromLocalInput = (local: string, tz: string): string => {
  if (!local) return '';
  try {
    const iso = local.length === 16 ? local + ':00' : local;
    const formatter = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'longOffset' });
    const now = new Date();
    const offsetStr = formatter.formatToParts(now).find(p => p.type === 'timeZoneName')?.value || '+00:00';
    const offset = offsetStr.replace('GMT', '') || '+00:00';
    return new Date(iso + offset).toISOString();
  } catch { return local; }
};

const avatarColor = (name: string) => {
  const colors = ['#5865f2','#3ba55c','#ed4245','#faa61a','#eb459e','#57f287','#0099ff'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) | 0;
  return colors[Math.abs(hash) % colors.length];
};

// ── ICONS ──────────────────────────────────────────────────────────────────

const Icon = ({ name, size = 14 }: { name: string; size?: number }) => {
  const s = size;
  const icons: Record<string, React.ReactNode> = {
    flag:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
    file:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
    chart:      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
    list:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
    plus:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    edit:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
    copy:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>,
    trash:      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>,
    play:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>,
    pause:      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
    stop:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg>,
    zap:        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
    eye:        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
    link:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>,
    x:          <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    clock:      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
    users:      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>,
    send:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
    info:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
    tag:        <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>,
    back:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>,
    refresh:    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>,
    dots:       <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>,
    check:      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>,
    calendar:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
    target:     <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
    settings:   <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>,
  };
  return <span className="cp-icon">{icons[name] || null}</span>;
};

// ── SHARED COMPONENTS ──────────────────────────────────────────────────────

const StatusBadge = ({ status }: { status: string }) => {
  const s = STATUS_MAP[status] || STATUS_MAP.draft;
  return (
    <span className="cp-status-badge" style={{ color: s.color, background: s.bg }}>
      <span className="cp-status-dot" style={{ background: s.color }} />{s.label}
    </span>
  );
};

const UserIdentity = ({ firstName, lastName, username, telegramId, photoUrl }: {
  firstName?: string | null; lastName?: string | null; username?: string | null;
  telegramId?: string | number | null; photoUrl?: string | null;
}) => {
  const tidStr = telegramId != null ? String(telegramId) : '';
  const fullName = [firstName, lastName].filter(Boolean).join(' ');
  const displayName = fullName || (username ? `@${username}` : '') || (tidStr ? `ID ${tidStr}` : 'Unknown');
  return (
    <div className="cp-user-chip">
      <UserAvatar name={displayName} photoUrl={photoUrl} className="accent" size="sm" />
      <div className="cp-user-info">
        <div className="cp-user-name">{fullName || (username ? `@${username}` : (tidStr ? `ID ${tidStr}` : 'Unknown'))}</div>
        <div className="cp-user-id">
          {username && `@${username}`}
          {username && tidStr && ' · '}
          {tidStr}
        </div>
      </div>
    </div>
  );
};

const EmptyState = ({ icon, title, sub, action }: { icon: string; title: string; sub?: string; action?: React.ReactNode }) => (
  <div className="cp-empty">
    <div className="cp-empty-icon"><Icon name={icon} /></div>
    <p>{title}</p>
    {sub && <span>{sub}</span>}
    {action}
  </div>
);

const BackButton = ({ onBack, label = 'Back' }: { onBack: () => void; label?: string }) => (
  <button className="cp-back-btn" onClick={onBack}><Icon name="back" size={16} />{label}</button>
);

// Mini bar chart (unchanged)
function MiniBarChart({ series, field }: { series: any[]; field: string }) {
  const vals = series.map(d => Number(d[field]) || 0);
  const max = Math.max(...vals, 1);
  return (
    <div className="cp-mini-bar-chart">
      {series.map((d, i) => {
        const pct = (vals[i] / max) * 100;
        return (
          <div key={i} className="cp-bar-col" title={`${d.day || ''}: ${vals[i]}`}>
            <div className="cp-bar" style={{ height: `${Math.max(2, pct)}%` }} />
          </div>
        );
      })}
    </div>
  );
}

function MiniDualBarChart({ series, fieldA, fieldB, colorA, colorB }: { series: any[]; fieldA: string; fieldB: string; colorA: string; colorB: string }) {
  const valsA = series.map(d => Number(d[fieldA]) || 0);
  const valsB = series.map(d => Number(d[fieldB]) || 0);
  const max = Math.max(...valsA.map((a, i) => a + valsB[i]), 1);
  return (
    <div className="cp-mini-bar-chart" style={{ alignItems: 'flex-end' }}>
      {series.map((d, i) => {
        const pctA = (valsA[i] / max) * 100;
        const pctB = (valsB[i] / max) * 100;
        return (
          <div key={i} className="cp-bar-col" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', gap: 1 }}
            title={`${d.day || ''}: valid ${valsA[i]}, late ${valsB[i]}`}>
            {valsB[i] > 0 && <div style={{ height: `${Math.max(1, pctB)}%`, background: colorB, borderRadius: '2px 2px 0 0', minHeight: 2 }} />}
            <div style={{ height: `${Math.max(2, pctA)}%`, background: colorA, borderRadius: valsB[i] > 0 ? 0 : '2px 2px 0 0', minHeight: 2 }} />
          </div>
        );
      })}
    </div>
  );
}

// ── HOME SCREEN ────────────────────────────────────────────────────────────

function CampaignActionMenu({ c, onEdit, onEnable, onDisable, onPause, onResume, onDuplicate, onDelete, onAnalytics, onLogs }: any) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);
  const act = (fn: () => void) => { setOpen(false); fn(); };
  return (
    <div className="cp-menu-wrap" ref={ref}>
      <button className="cp-menu-btn" onClick={() => setOpen(o => !o)} title="More actions">
        <Icon name="dots" size={16} />
      </button>
      {open && (
        <div className="cp-menu-dd">
          {!c.is_enabled && <button className="cp-menu-item" onClick={() => act(() => onEnable(c.id))}><Icon name="play" size={13} /> Enable</button>}
          {c.is_enabled && c.status !== 'paused' && <button className="cp-menu-item" onClick={() => act(() => onPause(c.id))}><Icon name="pause" size={13} /> Pause</button>}
          {c.status === 'paused' && <button className="cp-menu-item" onClick={() => act(() => onResume(c.id))}><Icon name="play" size={13} /> Resume</button>}
          {c.is_enabled && <button className="cp-menu-item" onClick={() => act(() => onDisable(c.id))}><Icon name="stop" size={13} /> Disable</button>}
          <div className="cp-menu-sep" />
          <button className="cp-menu-item" onClick={() => act(() => onAnalytics(c.id, c.name))}><Icon name="chart" size={13} /> Analytics</button>
          <button className="cp-menu-item" onClick={() => act(() => onLogs(c.id, c.name))}><Icon name="list" size={13} /> View Logs</button>
          <button className="cp-menu-item" onClick={() => act(() => onDuplicate(c.id))}><Icon name="copy" size={13} /> Duplicate</button>
          <div className="cp-menu-sep" />
          <button className="cp-menu-item danger" onClick={() => act(() => onDelete(c.id))}><Icon name="trash" size={13} /> Delete</button>
        </div>
      )}
    </div>
  );
}

function CampaignCard({ c, catNameMap, tplNameMap, onDetail, onEdit, onEnable, onDisable, onPause, onResume, onDuplicate, onDelete, onAnalytics, onLogs }: any) {
  const scopeLabel = () => {
    try {
      const ids: number[] = JSON.parse(c.category_scope_json || '[]');
      if (!ids.length) return 'All categories';
      return ids.map(id => catNameMap[id] || `#${id}`).join(', ');
    } catch { return 'All'; }
  };
  return (
    <div className={`cp-camp-card2${c.status === 'active' ? ' is-active' : ''}`}>
      <div className="cp-camp-card2-top">
        <div style={{ minWidth: 0, flex: 1 }}>
          <h4 className="cp-camp-card2-name">{c.name}</h4>
          <div className="cp-camp-card2-tags">
            <StatusBadge status={c.status} />
            <span className="cp-tag">{MODE_MAP[c.campaign_mode] || c.campaign_mode}</span>
            <span className="cp-tag">{REPEAT_MAP[c.repeat_mode] || c.repeat_mode}</span>
          </div>
        </div>
        <CampaignActionMenu c={c} onEdit={() => onEdit(c.id)} onEnable={onEnable} onDisable={onDisable} onPause={onPause} onResume={onResume} onDuplicate={onDuplicate} onDelete={onDelete} onAnalytics={onAnalytics} onLogs={onLogs} />
      </div>

      <div className="cp-camp-card2-perf">
        <div className="cp-camp-perf-stat">
          <span className="cp-camp-perf-v">{c.total_opens || 0}</span>
          <span className="cp-camp-perf-l">Opens</span>
        </div>
        <div className="cp-camp-perf-stat">
          <span className="cp-camp-perf-v">{c.total_purchases || 0}</span>
          <span className="cp-camp-perf-l">Orders</span>
        </div>
        <div className="cp-camp-perf-stat">
          <span className="cp-camp-perf-v accent">{fmt(c.total_revenue)}</span>
          <span className="cp-camp-perf-l">Revenue</span>
        </div>
      </div>

      <div className="cp-camp-card2-meta">
        <div className="cp-camp-meta-item">Start <span>{fmtDate(c.start_at, c.timezone)}</span></div>
        <div className="cp-camp-meta-item">Expire <span>{fmtDate(c.expire_at, c.timezone)}</span></div>
        {c.next_run_at && <div className="cp-camp-meta-item">Next run <span>{fmtDate(c.next_run_at, c.timezone)}</span></div>}
        <div className="cp-camp-meta-item">Scope <span>{scopeLabel()}</span></div>
      </div>

      {(c.promo_template_id || c.expiry_template_id) && (
        <div className="cp-camp-tpl" style={{ marginTop: 8 }}>
          <Icon name="file" />
          {c.promo_template_id && <span>Start: {tplNameMap[c.promo_template_id] || `#${c.promo_template_id}`}</span>}
          {c.expiry_template_id && <><span className="cp-camp-tpl-sep">·</span><span>Expiry: {tplNameMap[c.expiry_template_id] || `#${c.expiry_template_id}`}</span></>}
        </div>
      )}

      <div className="cp-camp-card2-acts">
        <button className="btn-primary-sm" onClick={() => onDetail(c.id)} style={{ flex: 1 }}><Icon name="eye" /> Details</button>
        <button className="btn-ghost-sm" onClick={() => onEdit(c.id)}><Icon name="edit" /></button>
      </div>
    </div>
  );
}

function TemplateCard({ t, onEdit, onDelete }: any) {
  const varCount = (t.body_text.match(/\{[^}]+\}/g) || []).length;
  const btnCount = (() => { try { return t.inline_buttons_json ? JSON.parse(t.inline_buttons_json).length : 0; } catch { return 0; } })();
  const viaBot = t.edited_via === 'bot';
  const versionCount = t.version_count ?? 0;
  return (
    <div className="cp-tpl-card2">
      <div className="cp-tpl-card2-top">
        <div style={{ flex: 1, minWidth: 0 }}>
          <h4 className="cp-tpl-name">{t.name}</h4>
          <div style={{ display: 'flex', gap: 6, marginTop: 4, alignItems: 'center', flexWrap: 'wrap' }}>
            <span className={`cp-type-badge ${t.template_type === 'promo_start' ? 'cp-type-start' : t.template_type === 'promo_expiry' ? 'cp-type-expiry' : 'cp-type-general'}`}>
              {t.template_type.replace(/_/g, ' ')}
            </span>
            {t.edited_via && (
              <span className={`cp-via-badge ${viaBot ? 'cp-via-bot' : 'cp-via-web'}`}>
                {viaBot ? '🤖 bot' : '🌐 web'}
              </span>
            )}
            <span className="cp-tpl-date">{fmtDate(t.updated_at || t.created_at)}</span>
          </div>
        </div>
        <div className="cp-tpl-acts">
          <button className="btn-ghost-sm" onClick={() => onEdit(t)}><Icon name="edit" /></button>
          <button className="btn-danger-sm" onClick={() => onDelete(t.id)}><Icon name="trash" /></button>
        </div>
      </div>
      <div className="cp-tpl-preview">{t.body_text.substring(0, 120)}{t.body_text.length > 120 ? '…' : ''}</div>
      <div style={{ display: 'flex', gap: 8, marginTop: 6, fontSize: '.7rem', color: 'var(--text-3)', flexWrap: 'wrap', alignItems: 'center' }}>
        <span>{varCount} variable{varCount !== 1 ? 's' : ''}</span>
        {btnCount > 0 && <span>· {btnCount} button{btnCount !== 1 ? 's' : ''}</span>}
        {versionCount > 0 && <span>· {versionCount} version{versionCount !== 1 ? 's' : ''}</span>}
        {t.updated_by && t.updated_by !== 'web' && (
          <span style={{ marginLeft: 'auto', fontStyle: 'italic', opacity: .7 }}>by {t.updated_by}</span>
        )}
      </div>
    </div>
  );
}

const DELIVERY_MODES = [
  {
    value: 'copy',
    label: 'Copy Message',
    description: 'Bot creates a source promo message and copies it to channels.',
    icon: 'copy',
  },
  {
    value: 'forward',
    label: 'Forward Message',
    description: 'Bot sends source promo message to owner/admin and forwards it to channels.',
    icon: 'send',
  },
  {
    value: 'direct',
    label: 'Direct Message',
    description: 'Bot sends promo message directly to channels.',
    icon: 'zap',
  },
] as const;

function ChannelDeliveryModeSelector({ onFlash }: { onFlash: (msg: string) => void }) {
  const [mode, setMode] = useState<string>('direct');
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [updatedBy, setUpdatedBy] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [pendingMode, setPendingMode] = useState<string | null>(null);

  const loadMode = useCallback(async () => {
    try {
      const data = await apiGet('/campaigns/channel-delivery-mode');
      setMode(data.mode || 'direct');
      setUpdatedAt(data.updated_at || null);
      setUpdatedBy(data.updated_by || null);
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => { loadMode(); }, [loadMode]);

  const saveMode = async (newMode: string) => {
    if (newMode === mode) return;
    setPendingMode(newMode);
    setSaving(true);
    try {
      const res = await apiPut('/campaigns/channel-delivery-mode', { mode: newMode });
      setMode(res.mode || newMode);
      setUpdatedAt(res.updated_at || new Date().toISOString());
      setUpdatedBy(res.updated_by || null);
      onFlash(`Channel delivery mode set to ${DELIVERY_MODES.find(m => m.value === newMode)?.label || newMode}`);
    } catch (e: any) {
      onFlash(e?.message || 'Failed to save delivery mode');
    }
    setSaving(false);
    setPendingMode(null);
  };

  if (loading) return <div style={{ padding: 20, color: 'var(--c-text-3)', textAlign: 'center' }}>Loading settings...</div>;

  return (
    <div className="cp-delivery-mode-panel">
      <div className="cp-delivery-mode-header">
        <h3 className="cp-delivery-mode-title"><Icon name="send" size={16} /> Channel Delivery Mode</h3>
        <p className="cp-delivery-mode-sub">
          Select how campaign promo messages are delivered to channels.
          Only one mode can be active at a time.
        </p>
      </div>
      <div className="cp-delivery-mode-options">
        {DELIVERY_MODES.map(m => {
          const isActive = mode === m.value;
          const isPending = pendingMode === m.value;
          return (
            <button
              key={m.value}
              className={`cp-delivery-mode-option${isActive ? ' active' : ''}`}
              onClick={() => saveMode(m.value)}
              disabled={saving}
            >
              <div className="cp-delivery-mode-option-top">
                <span className={`cp-delivery-mode-radio${isActive ? ' checked' : ''}`}>
                  {isActive && <span className="cp-delivery-mode-radio-dot" />}
                </span>
                <span className="cp-delivery-mode-option-icon"><Icon name={m.icon} size={15} /></span>
                <span className="cp-delivery-mode-option-label">{m.label}</span>
                {isActive && <span className="cp-delivery-mode-active-badge">Active</span>}
                {isPending && <span className="cp-delivery-mode-saving">Saving...</span>}
              </div>
              <p className="cp-delivery-mode-option-desc">{m.description}</p>
            </button>
          );
        })}
      </div>
      {(updatedAt || updatedBy) && (
        <div className="cp-delivery-mode-meta">
          {updatedBy && <span>Changed by: <b>{updatedBy}</b></span>}
          {updatedAt && <span>Last changed: <b>{new Date(updatedAt).toLocaleString()}</b></span>}
        </div>
      )}
    </div>
  );
}

function HomeScreen({ nav, setNav, campaigns, templates, stats, categories, durations, discountPlans, onAction, onFlash, load }: any) {
  const [homeTab, setHomeTab] = useState<HomeTab>('campaigns');
  const catNameMap = Object.fromEntries(categories.map((c: any) => [c.id, c.name]));
  const tplNameMap = Object.fromEntries(templates.map((t: any) => [t.id, t.name]));

  const action = async (fn: () => Promise<any>, ok: string) => {
    try { await fn(); onFlash(ok); load(); } catch (e: any) { onFlash(e?.message || 'Action failed'); }
  };

  const newCampaign: Campaign = {
    id: 0, name: '', description: '', status: 'draft', campaign_mode: 'random_discount',
    linked_discount_plan_id: null, category_scope_json: '[]', duration_scope_json: '[]',
    repeat_mode: 'once', timezone: 'Asia/Kolkata', start_at: '', expire_at: '',
    next_run_at: null, next_expire_at: null, is_enabled: false,
    promo_template_id: null, expiry_template_id: null,
    send_to_users: true, send_to_channels: false, created_at: '',
    discount_rules: [{ discount_mode: 'random_percent', min_value: 5, max_value: 30 }],
    targets: [{ target_type: 'all_users', target_value: '', message_kind: 'promo_start' }],
  };

  return (
    <div className="cp-screen">
      {/* Header */}
      <div className="cp-home-hdr">
        <h2 className="cp-home-title">Campaigns</h2>
        <p className="cp-home-sub">Promo campaigns, templates, and delivery analytics</p>
        <div className="cp-home-ctas">
          <button className="btn-primary-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: newCampaign })}>
            <Icon name="plus" /> New Campaign
          </button>
          <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'template-form', template: null })}>
            <Icon name="file" /> New Template
          </button>
          <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'analytics' })}>
            <Icon name="chart" /> Analytics
          </button>
          <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'logs' })}>
            <Icon name="list" /> Logs
          </button>
        </div>
      </div>

      {stats && (
        <div className="cp-stat-grid cp-stat-grid--4col" style={{ padding: '0 20px', marginBottom: 12 }}>
          <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.total_campaigns}</span><span className="cp-stat-card-l">Total</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: 'var(--c-emerald)' }}>{stats.active_campaigns}</span><span className="cp-stat-card-l">Active</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.scheduled_campaigns}</span><span className="cp-stat-card-l">Scheduled</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.runs_24h}</span><span className="cp-stat-card-l">Runs 24h</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.total_opens}</span><span className="cp-stat-card-l">Opens</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.total_purchases}</span><span className="cp-stat-card-l">Purchases</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v accent">{fmt(stats.total_revenue)}</span><span className="cp-stat-card-l">Revenue</span></div>
          <div className="cp-stat-card"><span className="cp-stat-card-v">{stats.unique_users}</span><span className="cp-stat-card-l">Users</span></div>
        </div>
      )}

      {/* Tab bar */}
      <div className="cp-tab-bar">
        <button className={`cp-tab-btn${homeTab === 'campaigns' ? ' active' : ''}`} onClick={() => setHomeTab('campaigns')}>
          <Icon name="flag" size={13} /> Campaigns ({campaigns.length})
        </button>
        <button className={`cp-tab-btn${homeTab === 'templates' ? ' active' : ''}`} onClick={() => setHomeTab('templates')}>
          <Icon name="file" size={13} /> Templates ({templates.length})
        </button>
        <button className={`cp-tab-btn${homeTab === 'settings' ? ' active' : ''}`} onClick={() => setHomeTab('settings')}>
          <Icon name="settings" size={13} /> Settings
        </button>
      </div>

      {/* Tab content */}
      <div className="cp-tab-content">
        {homeTab === 'campaigns' && (
          <div className="cp-card-list" style={{ padding: '14px 20px 60px' }}>
            {campaigns.length === 0
              ? <EmptyState icon="flag" title="No campaigns yet" sub="Create your first campaign to start promoting"
                  action={<button className="btn-primary-sm" onClick={() => setNav({ screen: 'campaign-form', campaign: newCampaign })} style={{ marginTop: 12 }}><Icon name="plus" /> Create Campaign</button>} />
              : campaigns.map((c: Campaign) => (
                <CampaignCard key={c.id} c={c} catNameMap={catNameMap} tplNameMap={tplNameMap}
                  onDetail={(id: number) => setNav({ screen: 'detail', campaignId: id })}
                  onEdit={async (id: number) => { const d = await apiGet(`/campaigns/${id}`); setNav({ screen: 'campaign-form', campaign: d }); }}
                  onEnable={(id: number) => action(() => apiPost(`/campaigns/${id}/enable`), 'Campaign enabled')}
                  onDisable={(id: number) => action(() => apiPost(`/campaigns/${id}/disable`), 'Campaign disabled')}
                  onPause={(id: number) => action(() => apiPost(`/campaigns/${id}/pause`), 'Campaign paused')}
                  onResume={(id: number) => action(() => apiPost(`/campaigns/${id}/resume`), 'Campaign resumed')}
                  onDuplicate={(id: number) => action(() => apiPost(`/campaigns/${id}/duplicate`), 'Campaign duplicated')}
                  onDelete={(id: number) => { if (confirm('Delete this campaign permanently?')) action(() => apiDelete(`/campaigns/${id}`), 'Campaign deleted'); }}
                  onAnalytics={(id: number, name: string) => setNav({ screen: 'analytics', campaignId: id, campaignName: name })}
                  onLogs={(id: number, name: string) => setNav({ screen: 'logs', campaignId: id, campaignName: name })}
                />
              ))
            }
          </div>
        )}
        {homeTab === 'templates' && (
          <div className="cp-card-list" style={{ padding: '14px 20px 60px' }}>
            {templates.length === 0
              ? <EmptyState icon="file" title="No promo templates yet" sub="Create message templates for your promo campaigns"
                  action={<button className="btn-primary-sm" onClick={() => setNav({ screen: 'template-form', template: null })} style={{ marginTop: 12 }}><Icon name="plus" /> Create Template</button>} />
              : templates.map((t: Template) => (
                <TemplateCard key={t.id} t={t}
                  onEdit={(tpl: Template) => setNav({ screen: 'template-form', template: tpl })}
                  onDelete={async (id: number) => { if (confirm('Delete this template?')) { try { await apiDelete(`/campaigns/templates/${id}`); onFlash('Template deleted'); load(); } catch (e: any) { onFlash(e?.message || 'Delete failed'); } } }}
                />
              ))
            }
          </div>
        )}
        {homeTab === 'settings' && (
          <div style={{ padding: '14px 20px 60px' }}>
            <ChannelDeliveryModeSelector onFlash={onFlash} />
          </div>
        )}
      </div>
    </div>
  );
}

// ── CAMPAIGN DETAIL SCREEN ────────────────────────────────────────────────

function CampaignDetailScreen({ campaignId, setNav, categories, templates, onFlash, load }: any) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [deepLinks, setDeepLinks] = useState<any[]>([]);
  const [deepLinksLoading, setDeepLinksLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  useEffect(() => {
    setLoading(true);
    apiGet(`/campaigns/${campaignId}`).then(d => { setData(d); setLoading(false); }).catch(() => setLoading(false));
  }, [campaignId]);

  useEffect(() => {
    setDeepLinksLoading(true);
    apiGet(`/campaigns/${campaignId}/deep-links`)
      .then(d => { setDeepLinks(d.deep_links || []); setDeepLinksLoading(false); })
      .catch(() => setDeepLinksLoading(false));
  }, [campaignId]);

  const action = async (fn: () => Promise<any>, ok: string) => {
    try { await fn(); onFlash(ok); const d = await apiGet(`/campaigns/${campaignId}`); setData(d); load(); }
    catch (e: any) { onFlash(e?.message || 'Action failed'); }
  };

  if (loading) return <div className="cp-screen"><div className="page-loader"><div className="loader-spinner" /></div></div>;
  if (!data) return <div className="cp-screen"><div className="cp-screen-hdr"><BackButton onBack={() => setNav({ screen: 'home' })} /></div><EmptyState icon="flag" title="Campaign not found" /></div>;

  const catNameMap = Object.fromEntries(categories.map((c: any) => [c.id, c.name]));
  const tplNameMap = Object.fromEntries(templates.map((t: any) => [t.id, t.name]));

  const scopeLabel = () => {
    try {
      const cats: number[] = JSON.parse(data.category_scope_json || '[]');
      const durs: number[] = JSON.parse(data.duration_scope_json || '[]');
      if (!cats.length && !durs.length) return 'All products';
      const catNames = cats.map((id: number) => catNameMap[id] || `#${id}`).join(', ');
      return catNames || 'All categories';
    } catch { return 'All products'; }
  };

  const discountLabel = () => {
    const rules = data.discount_rules || [];
    const r = rules[0];
    if (!r) return 'No discount';
    if (r.discount_mode === 'fixed_percent') return `${r.fixed_value}% fixed discount`;
    if (r.discount_mode === 'random_percent') return `${r.min_value}%–${r.max_value}% random discount`;
    if (r.discount_mode === 'fixed_price_override') return `Price override: ${fmt(r.fixed_value)}`;
    return r.discount_mode;
  };

  const deepLink = data.deep_links?.[0]?.code || data.deep_link_code || '';

  return (
    <div className="cp-screen">
      <div className="cp-screen-hdr">
        <BackButton onBack={() => setNav({ screen: 'home' })} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h3 className="cp-screen-title" style={{ margin: 0 }}>{data.name}</h3>
        </div>
        <button className="btn-ghost-sm" onClick={async () => { const d = await apiGet(`/campaigns/${campaignId}`); setNav({ screen: 'campaign-form', campaign: d }); }}>
          <Icon name="edit" /> Edit
        </button>
      </div>

      <div className="cp-detail-hdr">
        {data.description && <p className="cp-detail-desc">{data.description}</p>}
        <div className="cp-detail-badges">
          <StatusBadge status={data.status} />
          <span className="cp-tag">{MODE_MAP[data.campaign_mode] || data.campaign_mode}</span>
          <span className="cp-tag">{REPEAT_MAP[data.repeat_mode] || data.repeat_mode}</span>
          {data.is_enabled && <span className="cp-tag" style={{ color: 'var(--c-emerald)', background: 'var(--c-emerald-surface)' }}>Enabled</span>}
        </div>
      </div>

      <div className="cp-detail-body">

        {/* Performance summary */}
        <div className="cp-detail-section">
          <div className="cp-detail-section-hdr">Performance</div>
          <div className="cp-detail-section-body">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
              {[
                { l: 'Total Opens', v: data.total_opens || 0 },
                { l: 'Purchases', v: data.total_purchases || 0 },
                { l: 'Revenue', v: fmt(data.total_revenue), accent: true },
                { l: 'Total Runs', v: (data.runs || []).length },
              ].map((s, i) => (
                <div key={i} className="cp-detail-kv">
                  <div className="cp-detail-kv-l">{s.l}</div>
                  <div className={`cp-detail-kv-v${(s as any).accent ? ' accent' : ''}`} style={(s as any).accent ? { color: 'var(--c-accent-bright)' } : undefined}>{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Schedule */}
        <div className="cp-detail-section">
          <div className="cp-detail-section-hdr">Schedule</div>
          <div className="cp-detail-section-body">
            <div className="cp-detail-kv-grid">
              <div className="cp-detail-kv"><div className="cp-detail-kv-l">Start</div><div className="cp-detail-kv-v">{fmtDate(data.start_at, data.timezone)}</div></div>
              <div className="cp-detail-kv"><div className="cp-detail-kv-l">Expire</div><div className="cp-detail-kv-v">{fmtDate(data.expire_at, data.timezone)}</div></div>
              <div className="cp-detail-kv"><div className="cp-detail-kv-l">Next Run</div><div className="cp-detail-kv-v">{fmtDate(data.next_run_at, data.timezone)}</div></div>
              <div className="cp-detail-kv"><div className="cp-detail-kv-l">Timezone</div><div className="cp-detail-kv-v">{data.timezone}</div></div>
            </div>
          </div>
        </div>

        {/* Discount + Scope */}
        {data.campaign_mode !== 'message_only' && (
          <div className="cp-detail-section">
            <div className="cp-detail-section-hdr">Discount &amp; Scope</div>
            <div className="cp-detail-section-body">
              <div className="cp-detail-kv-grid">
                <div className="cp-detail-kv"><div className="cp-detail-kv-l">Discount</div><div className="cp-detail-kv-v">{discountLabel()}</div></div>
                <div className="cp-detail-kv"><div className="cp-detail-kv-l">Applies to</div><div className="cp-detail-kv-v">{scopeLabel()}</div></div>
              </div>
            </div>
          </div>
        )}

        {/* Templates */}
        <div className="cp-detail-section">
          <div className="cp-detail-section-hdr">Message Templates</div>
          <div className="cp-detail-section-body">
            <div className="cp-detail-kv-grid">
              <div className="cp-detail-kv"><div className="cp-detail-kv-l">Promo Start</div><div className="cp-detail-kv-v">{data.promo_template_id ? (tplNameMap[data.promo_template_id] || `#${data.promo_template_id}`) : 'Not set'}</div></div>
              <div className="cp-detail-kv"><div className="cp-detail-kv-l">Promo Expiry</div><div className="cp-detail-kv-v">{data.expiry_template_id ? (tplNameMap[data.expiry_template_id] || `#${data.expiry_template_id}`) : 'Not set'}</div></div>
            </div>
          </div>
        </div>

        {/* Targets */}
        {data.targets?.length > 0 && (
          <div className="cp-detail-section">
            <div className="cp-detail-section-hdr">Audience Targets</div>
            <div className="cp-detail-section-body">
              {data.targets.map((t: any, i: number) => (
                <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 4, fontSize: '.8rem', color: 'var(--text-1)' }}>
                  <span className="cp-tag">{TARGET_MAP[t.target_type] || t.target_type}</span>
                  <span style={{ color: 'var(--text-3)' }}>{t.message_kind?.replace(/_/g, ' ')}</span>
                  {t.target_value && <span style={{ color: 'var(--text-2)', fontFamily: 'monospace' }}>{t.target_value}</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Deep Links — per-run table */}
        <div className="cp-detail-section" style={{ overflow: 'hidden' }}>
          <div className="cp-detail-section-hdr" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span>Deep Links</span>
            {deepLinks.length > 0 && <span style={{ fontSize: '.7rem', color: 'var(--text-3)', fontWeight: 400 }}>{deepLinks.length} link{deepLinks.length > 1 ? 's' : ''}</span>}
          </div>
          {deepLinksLoading && <div style={{ padding: '16px', textAlign: 'center', color: 'var(--text-3)', fontSize: '.78rem' }}>Loading…</div>}
          {!deepLinksLoading && deepLinks.length === 0 && (
            <div style={{ padding: '14px 16px', color: 'var(--text-3)', fontSize: '.78rem' }}>
              No deep links yet. A fresh link is generated automatically when a campaign starts.
            </div>
          )}
          {!deepLinksLoading && deepLinks.length > 0 && (
            <div className="cp-tbl-wrap">
              <table className="cp-tbl">
                <thead>
                  <tr>
                    <th>Code</th>
                    <th>Status</th>
                    <th>Active from</th>
                    <th>Expired at</th>
                    <th>Opens</th>
                    <th>Buys</th>
                    <th>Revenue</th>
                    <th>Late</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {deepLinks.map((dl: any) => (
                    <tr key={dl.id}>
                      <td>
                        <code style={{ fontSize: '.72rem', color: 'var(--c-accent-bright)' }}>
                          {dl.code}
                        </code>
                      </td>
                      <td>
                        <span className={`cp-dl-badge cp-dl-badge--${dl.status}`}>
                          {dl.status}
                        </span>
                      </td>
                      <td style={{ whiteSpace: 'nowrap', fontSize: '.72rem' }}>{fmtDate(dl.activated_at || dl.created_at)}</td>
                      <td style={{ whiteSpace: 'nowrap', fontSize: '.72rem', color: dl.expired_at ? 'var(--text-2)' : 'var(--text-3)' }}>
                        {dl.expired_at ? fmtDate(dl.expired_at) : '—'}
                      </td>
                      <td>{dl.opens_count || 0}</td>
                      <td>{dl.purchases_count || 0}</td>
                      <td className="accent">{fmt(dl.revenue_total || 0)}</td>
                      <td style={{ color: 'var(--text-3)', fontSize: '.72rem' }}>
                        {Number(dl.late_purchases_count) > 0
                          ? <span title={`Late: ${dl.late_purchases_count} orders · ${fmt(dl.late_revenue_total)}`}>
                              {dl.late_purchases_count} · {fmt(dl.late_revenue_total)}
                            </span>
                          : '—'
                        }
                      </td>
                      <td style={{ whiteSpace: 'nowrap', display: 'flex', gap: 4 }}>
                        <button
                          className="cp-icon-btn"
                          title={copiedId === dl.id ? 'Copied!' : 'Copy link'}
                          onClick={() => {
                            const url = dl.full_url || dl.deep_link_url || '';
                            navigator.clipboard?.writeText(url).then(() => {
                              setCopiedId(dl.id);
                              setTimeout(() => setCopiedId(n => n === dl.id ? null : n), 1800);
                            });
                          }}
                        >
                          {copiedId === dl.id ? '✓' : <Icon name="copy" size={12} />}
                        </button>
                        <button
                          className="cp-icon-btn"
                          title="View details"
                          onClick={() => setNav({
                            screen: 'deep-link-detail',
                            linkId: dl.id,
                            campaignName: data?.name,
                            fromCampaignId: campaignId,
                          })}
                        >
                          <Icon name="chart" size={12} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Recent runs */}
        {data.runs?.length > 0 && (
          <div className="cp-detail-section" style={{ overflow: 'hidden' }}>
            <div className="cp-detail-section-hdr">Recent Runs</div>
            <div className="cp-tbl-wrap">
              <table className="cp-tbl">
                <thead><tr><th>Type</th><th>Executed</th><th>Status</th><th>Sent</th><th>Failed</th></tr></thead>
                <tbody>
                  {data.runs.slice(0, 10).map((r: any) => (
                    <tr key={r.id}>
                      <td className="mono">{r.run_type}</td>
                      <td>{fmtDate(r.executed_at)}</td>
                      <td><StatusBadge status={r.status} /></td>
                      <td>{r.total_sent || 0}</td>
                      <td className={r.total_failed > 0 ? 'danger' : ''}>{r.total_failed || 0}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* Action bar */}
      <div className="cp-detail-acts">
        <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'analytics', campaignId: data.id, campaignName: data.name })}><Icon name="chart" /> Analytics</button>
        <button className="btn-ghost-sm" onClick={() => setNav({ screen: 'logs', campaignId: data.id, campaignName: data.name })}><Icon name="list" /> Logs</button>
        <button className="btn-outline-sm" onClick={() => action(() => apiPost(`/campaigns/${campaignId}/duplicate`), 'Duplicated')}><Icon name="copy" /> Duplicate</button>
        {!data.is_enabled && <button className="btn-success-sm" onClick={() => action(() => apiPost(`/campaigns/${campaignId}/enable`), 'Enabled')}><Icon name="play" /> Enable</button>}
        {data.is_enabled && data.status !== 'paused' && <button className="btn-warning-sm" onClick={() => action(() => apiPost(`/campaigns/${campaignId}/pause`), 'Paused')}><Icon name="pause" /> Pause</button>}
        {data.status === 'paused' && <button className="btn-success-sm" onClick={() => action(() => apiPost(`/campaigns/${campaignId}/resume`), 'Resumed')}><Icon name="play" /> Resume</button>}
        {data.is_enabled && <button className="btn-danger-sm" onClick={() => action(() => apiPost(`/campaigns/${campaignId}/disable`), 'Disabled')}><Icon name="stop" /> Disable</button>}
        <button className="btn-danger-sm" onClick={() => { if (confirm('Delete this campaign?')) action(async () => { await apiDelete(`/campaigns/${campaignId}`); setNav({ screen: 'home' }); load(); }, 'Deleted'); }}>
          <Icon name="trash" /> Delete
        </button>
      </div>
    </div>
  );
}

// ── ANALYTICS SCREEN ───────────────────────────────────────────────────────

type AnaTab = 'overview' | 'runs' | 'deep-links' | 'orders' | 'funnel';
type AnaPeriod = 'today' | 'yesterday' | '7d' | '30d' | 'custom';

const PERIOD_DAYS: Record<AnaPeriod, number> = { today: 1, yesterday: 2, '7d': 7, '30d': 30, custom: 30 };

function AtrBadge({ isLate, status }: { isLate: boolean; status: string }) {
  if (status && !['paid', 'completed', 'delivered'].includes(status))
    return <span className="cp-attr-badge cp-attr-badge--excluded">Excluded</span>;
  if (isLate) return <span className="cp-attr-badge cp-attr-badge--late">Late</span>;
  return <span className="cp-attr-badge cp-attr-badge--counted">Counted</span>;
}

function AnalyticsScreen({ campaignId, campaignName, campaigns, setNav }: any) {
  const [tab,          setTab]          = useState<AnaTab>('overview');
  const [period,       setPeriod]       = useState<AnaPeriod>('30d');
  const [filterCampId, setFilterCampId] = useState<number | ''>(campaignId || '');
  const [filterRunId,  setFilterRunId]  = useState<string>('');
  const [customFrom,   setCustomFrom]   = useState('');
  const [customTo,     setCustomTo]     = useState('');
  const [dlFilter,     setDlFilter]     = useState<'all' | 'sent' | 'failed'>('all');

  const [summary,     setSummary]     = useState<any>(null);
  const [series,      setSeries]      = useState<any[]>([]);
  const [runs,        setRuns]        = useState<any[]>([]);
  const [deepLinks,   setDeepLinks]   = useState<any[]>([]);
  const [orders,      setOrders]      = useState<any[]>([]);
  const [funnel,      setFunnel]      = useState<any>(null);
  const [dispLogs,    setDispLogs]    = useState<any>(null);
  const [loading,     setLoading]     = useState(false);

  const [selectedRunId, setSelectedRunId] = useState<number | null>(null);
  const days = PERIOD_DAYS[period];

  const buildDateQ = useCallback(() => {
    const parts: string[] = [];
    if (period === 'custom') {
      if (customFrom) parts.push(`date_from=${customFrom}`);
      if (customTo)   parts.push(`date_to=${customTo}`);
    } else if (period === 'today') {
      parts.push(`date_from=${new Date().toISOString().slice(0, 10)}`);
      parts.push(`date_to=${new Date().toISOString().slice(0, 10)}`);
    } else if (period === 'yesterday') {
      const d = new Date(); d.setDate(d.getDate() - 1);
      parts.push(`date_from=${d.toISOString().slice(0, 10)}`);
      parts.push(`date_to=${d.toISOString().slice(0, 10)}`);
    } else {
      const d = new Date(); d.setDate(d.getDate() - days);
      parts.push(`date_from=${d.toISOString().slice(0, 10)}`);
    }
    return parts.join('&');
  }, [period, customFrom, customTo, days]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const dq = buildDateQ();
      const campQ  = filterCampId ? `campaign_id=${filterCampId}` : '';
      const runQ   = filterRunId  ? `run_id=${filterRunId}` : '';
      const parts  = [campQ, runQ, dq].filter(Boolean);
      const q      = parts.join('&');
      const sep    = q ? `?${q}` : '';
      const summaryParts = [campQ, dq].filter(Boolean);
      const sumQ   = summaryParts.join('&');
      const sumSep = sumQ ? `?${sumQ}` : '';
      const serParts = [campQ, dq].filter(Boolean);
      const serQ   = serParts.join('&');
      const serSep = serQ ? `?${serQ}` : '';
      const logParts = ['limit=100', campQ].filter(Boolean);
      const logQ   = logParts.join('&');

      const [sum, ser, r, dl, o, fn, logs] = await Promise.all([
        apiGet(`/campaigns/analytics/summary${sumSep}`),
        apiGet(`/campaigns/analytics/daily-series${serSep ? `?${serQ}` : ''}`),
        apiGet(`/campaigns/analytics/runs${sep}`),
        apiGet(`/campaigns/analytics/deep-links${sep}`),
        apiGet(`/campaigns/analytics/attributed-orders${sep}`),
        apiGet(`/campaigns/analytics/funnel${sep}`),
        apiGet(`/campaigns/analytics/dispatch-logs?${logQ}`),
      ]);
      setSummary(sum);
      setSeries(ser);
      setRuns(r.runs || []);
      setDeepLinks(dl.deep_links || []);
      setOrders(o.orders || []);
      setFunnel(fn);
      setDispLogs(logs);
    } catch {}
    setLoading(false);
  }, [filterCampId, filterRunId, period, customFrom, customTo, days, buildDateQ]);

  useEffect(() => { load(); }, [load]);

  const hasFilters = filterCampId !== '' || filterRunId !== '' || period !== '30d';
  const clearFilters = () => { setFilterCampId(''); setFilterRunId(''); setPeriod('30d'); setCustomFrom(''); setCustomTo(''); setSelectedRunId(null); };

  const pd = summary && (period === 'custom' && summary.period_revenue !== undefined
    ? { revenue: summary.period_revenue, purchases: summary.period_purchases, opens: summary.period_opens || summary.total_opens, late_revenue: summary.period_late_revenue, late_purchases: summary.period_late_purchases, unique_openers: summary.period_unique_openers || summary.unique_openers }
    : ({
      today:     { revenue: summary.today_revenue,     purchases: summary.today_purchases,     opens: summary.today_opens,     late_revenue: summary.today_late_revenue,      late_purchases: 0, unique_openers: summary.unique_openers },
      yesterday: { revenue: summary.yesterday_revenue, purchases: summary.yesterday_purchases, opens: summary.yesterday_opens, late_revenue: summary.yesterday_late_revenue,  late_purchases: summary.yesterday_late_purchases, unique_openers: summary.unique_openers },
      '7d':      { revenue: summary.last7d_revenue,    purchases: summary.last7d_purchases,    opens: summary.last7d_opens,    late_revenue: summary.last7d_late_revenue,     late_purchases: summary.last7d_late_purchases, unique_openers: summary.unique_openers },
      '30d':     { revenue: summary.last30d_revenue,   purchases: summary.last30d_purchases,   opens: summary.last30d_opens,   late_revenue: summary.last30d_late_revenue,    late_purchases: summary.last30d_late_purchases, unique_openers: summary.unique_openers },
      custom:    { revenue: summary.total_revenue,     purchases: summary.total_purchases,     opens: summary.total_opens,     late_revenue: summary.total_late_revenue,      late_purchases: summary.total_late_purchases, unique_openers: summary.unique_openers },
    } as any)[period]
  );

  const perCampSummary = summary?.active_campaigns || [];
  const deliveries     = dispLogs?.delivery_logs   || [];
  const filteredDl     = dlFilter === 'all' ? deliveries : deliveries.filter((l: any) => l.delivery_status === dlFilter);
  const chartSeries    = series;

  const selectedRunData = selectedRunId ? runs.find((r: any) => r.run_id === selectedRunId) : null;
  const runDeepLinks    = selectedRunId ? deepLinks.filter((dl: any) => dl.campaign_run_id === selectedRunId) : [];

  const kpis = pd && summary ? [
    { v: fmt(pd.revenue),                    l: 'Valid Revenue',     accent: true },
    { v: pd.purchases,                       l: 'Purchases' },
    { v: pd.opens,                           l: 'Opens' },
    { v: pd.unique_openers ?? summary.unique_openers ?? 0, l: 'Unique Openers' },
    { v: `${summary.conversion_rate}%`,      l: 'Conversion Rate',  accent: true },
    { v: fmt(summary.avg_order_value),       l: 'Avg Order Value' },
    { v: fmt(pd.late_revenue || 0),          l: 'Late Revenue',      danger: true },
    { v: pd.late_purchases || 0,             l: 'Late Purchases',    danger: true },
    { v: summary.active_runs  || 0,          l: 'Active Runs' },
    { v: summary.expired_runs || 0,          l: 'Expired Runs' },
  ] : [];

  const TABS: { id: AnaTab; label: string }[] = [
    { id: 'overview',    label: 'Overview' },
    { id: 'runs',        label: `Runs${runs.length > 0 ? ` (${runs.length})` : ''}` },
    { id: 'deep-links',  label: 'Deep Links' },
    { id: 'orders',      label: `Orders${orders.length > 0 ? ` (${orders.length})` : ''}` },
    { id: 'funnel',      label: 'Funnel' },
  ];

  return (
    <div className="cp-screen">
      {/* Header */}
      <div className="cp-screen-hdr">
        <BackButton onBack={() => setNav({ screen: 'home' })} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h3 className="cp-screen-title" style={{ margin: 0 }}>Analytics</h3>
          {(campaignName || filterCampId) && (
            <div className="cp-screen-sub">
              {campaignName || campaigns.find((c: any) => c.id === filterCampId)?.name || ''}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 5 }}>
          {hasFilters && (
            <button className="btn-ghost-sm" onClick={clearFilters} style={{ fontSize: '.7rem', color: 'var(--text-3)' }}>Clear</button>
          )}
          <button className="btn-ghost-sm" onClick={load} disabled={loading}><Icon name="refresh" /></button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="cp-ana-filters">
        <select
          className="cp-filter-select"
          value={filterCampId}
          onChange={e => { setFilterCampId(e.target.value ? Number(e.target.value) : ''); setFilterRunId(''); }}
        >
          <option value="">All Campaigns</option>
          {campaigns.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        {runs.length > 0 && (
          <select
            className="cp-filter-select"
            value={filterRunId}
            onChange={e => setFilterRunId(e.target.value)}
          >
            <option value="">All Runs</option>
            {runs.map((r: any) => (
              <option key={r.run_id} value={r.run_id}>
                Run #{r.run_id} {r.run_type ? `(${r.run_type})` : ''} {r.executed_at ? fmtDate(r.executed_at).slice(0, 10) : ''}
              </option>
            ))}
          </select>
        )}
        <div className="cp-ana-chips">
          {(['today', 'yesterday', '7d', '30d', 'custom'] as const).map(p => (
            <button key={p} className={`cp-filter-chip${period === p ? ' active' : ''}`} onClick={() => setPeriod(p)}>
              {p === 'today' ? 'Today' : p === 'yesterday' ? 'Yesterday' : p === '7d' ? '7d' : p === '30d' ? '30d' : 'Custom'}
            </button>
          ))}
        </div>
        {period === 'custom' && (
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <input type="date" className="cp-filter-select" style={{ padding: '4px 8px', fontSize: '.72rem' }}
              value={customFrom} onChange={e => setCustomFrom(e.target.value)} />
            <span style={{ fontSize: '.7rem', color: 'var(--text-3)' }}>→</span>
            <input type="date" className="cp-filter-select" style={{ padding: '4px 8px', fontSize: '.72rem' }}
              value={customTo} onChange={e => setCustomTo(e.target.value)} />
            <button className="btn-ghost-sm" onClick={load} style={{ fontSize: '.7rem' }}>Apply</button>
          </div>
        )}
      </div>

      {/* Main tabs */}
      <div className="cp-sub-tabs">
        {TABS.map(t => (
          <button key={t.id} className={`cp-sub-tab${tab === t.id ? ' active' : ''}`} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {loading && (
        <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-3)' }}>Loading analytics…</div>
      )}

      {!loading && (
        <div className="cp-ana-body">

          {/* ── OVERVIEW ── */}
          {tab === 'overview' && (
            <>
              {kpis.length > 0 && (
                <div className="cp-stat-grid cp-stat-grid--5col">
                  {kpis.map((k, i) => (
                    <div key={i} className="cp-stat-card">
                      <span className="cp-stat-card-v" style={(k as any).accent ? { color: 'var(--c-accent-bright)' } : (k as any).danger ? { color: 'var(--c-rose)' } : undefined}>
                        {k.v}
                      </span>
                      <span className="cp-stat-card-l">{k.l}</span>
                    </div>
                  ))}
                </div>
              )}

              {chartSeries.length > 0 && (
                <div className="cp-detail-section" style={{ overflow: 'hidden' }}>
                  <div className="cp-detail-section-hdr" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span>Revenue Trend</span>
                    <div style={{ display: 'flex', gap: 10, fontSize: '.68rem', color: 'var(--text-3)' }}>
                      <span style={{ color: 'var(--c-accent-bright)' }}>■ Valid</span>
                      <span style={{ color: 'var(--c-rose)' }}>■ Late</span>
                    </div>
                  </div>
                  <div style={{ padding: '10px 14px 6px' }}>
                    <MiniDualBarChart
                      series={chartSeries}
                      fieldA="revenue" fieldB="late_revenue"
                      colorA="var(--c-accent-bright)" colorB="var(--c-rose)"
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3, fontSize: '.65rem', color: 'var(--text-3)' }}>
                      <span>{chartSeries[0]?.day?.slice(5)}</span>
                      <span>{chartSeries[chartSeries.length - 1]?.day?.slice(5)}</span>
                    </div>
                  </div>
                </div>
              )}

              {chartSeries.length > 0 && chartSeries.some((d: any) => d.purchases > 0 || d.late_purchases > 0) && (
                <div className="cp-detail-section" style={{ overflow: 'hidden' }}>
                  <div className="cp-detail-section-hdr" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span>Purchases Trend</span>
                    <div style={{ display: 'flex', gap: 10, fontSize: '.68rem', color: 'var(--text-3)' }}>
                      <span style={{ color: 'var(--c-emerald)' }}>■ Valid</span>
                      <span style={{ color: 'var(--c-rose)' }}>■ Late</span>
                    </div>
                  </div>
                  <div style={{ padding: '10px 14px 6px' }}>
                    <MiniDualBarChart
                      series={chartSeries}
                      fieldA="purchases" fieldB="late_purchases"
                      colorA="var(--c-emerald)" colorB="var(--c-rose)"
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3, fontSize: '.65rem', color: 'var(--text-3)' }}>
                      <span>{chartSeries[0]?.day?.slice(5)}</span>
                      <span>{chartSeries[chartSeries.length - 1]?.day?.slice(5)}</span>
                    </div>
                  </div>
                </div>
              )}

              {chartSeries.length > 0 && chartSeries.some((d: any) => d.opens > 0) && (
                <div className="cp-detail-section" style={{ overflow: 'hidden' }}>
                  <div className="cp-detail-section-hdr" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span>Opens Trend</span>
                    <span style={{ fontSize: '.7rem', color: 'var(--text-3)', fontWeight: 400 }}>
                      {chartSeries.filter((d: any) => d.opens > 0).length} active days
                    </span>
                  </div>
                  <div style={{ padding: '10px 14px 6px' }}>
                    <MiniBarChart series={chartSeries} field="opens" />
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3, fontSize: '.65rem', color: 'var(--text-3)' }}>
                      <span>{chartSeries[0]?.day?.slice(5)}</span>
                      <span>{chartSeries[chartSeries.length - 1]?.day?.slice(5)}</span>
                    </div>
                  </div>
                </div>
              )}

              {perCampSummary.length > 0 && (
                <div className="cp-table-section">
                  <div className="cp-table-section-hdr">
                    <span className="cp-ana-section-title">Campaign Breakdown</span>
                  </div>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr>
                          <th>Campaign</th><th>Runs</th><th>Active</th><th>Valid Rev</th><th>Late Rev</th>
                          <th>Purchases</th><th>AOV</th><th>Opens</th><th>Unique</th><th>Conv</th><th>Latest Run</th><th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {perCampSummary.map((c: any) => {
                          const cPurchases = Number(c.purchases) || 0;
                          const cRevenue   = Number(c.revenue) || 0;
                          const cAov       = cPurchases > 0 ? (cRevenue / cPurchases).toFixed(2) : '—';
                          return (
                            <tr key={c.id} style={{ cursor: 'pointer' }} onClick={() => setNav({ screen: 'analytics', campaignId: c.id, campaignName: c.name })}>
                              <td style={{ maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</td>
                              <td style={{ fontSize: '.72rem' }}>{c.total_runs || 0}</td>
                              <td style={{ fontSize: '.72rem' }}>{c.active_run_count || 0}</td>
                              <td className="accent">{fmt(cRevenue)}</td>
                              <td style={{ color: Number(c.late_revenue) > 0 ? 'var(--c-rose)' : undefined }}>{fmt(c.late_revenue || 0)}</td>
                              <td>{cPurchases}</td>
                              <td style={{ fontSize: '.72rem' }}>{cAov !== '—' ? fmt(Number(cAov)) : '—'}</td>
                              <td>{c.opens || 0}</td>
                              <td>{c.unique_users || 0}</td>
                              <td>{Number(c.opens) > 0 ? ((cPurchases / Number(c.opens)) * 100).toFixed(1) + '%' : '—'}</td>
                              <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{c.latest_run_at ? fmtDate(c.latest_run_at) : '—'}</td>
                              <td><StatusBadge status={c.status || 'draft'} /></td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {perCampSummary.map((c: any) => {
                      const cPurchases = Number(c.purchases) || 0;
                      const cRevenue   = Number(c.revenue) || 0;
                      const cAov       = cPurchases > 0 ? (cRevenue / cPurchases).toFixed(2) : '—';
                      return (
                        <div key={c.id} className="cp-log-card-item" style={{ cursor: 'pointer' }} onClick={() => setNav({ screen: 'analytics', campaignId: c.id, campaignName: c.name })}>
                          <div className="cp-log-card-top">
                            <span className="cp-log-card-title">{c.name}</span>
                            <span className="cp-log-card-badge"><StatusBadge status={c.status || 'draft'} /></span>
                          </div>
                          <div className="cp-log-card-grid">
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Revenue</div><div className="cp-log-card-fv accent">{fmt(cRevenue)}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Purchases</div><div className="cp-log-card-fv">{cPurchases}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Opens</div><div className="cp-log-card-fv">{c.opens || 0}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Conv</div><div className="cp-log-card-fv">{Number(c.opens) > 0 ? ((cPurchases / Number(c.opens)) * 100).toFixed(1) + '%' : '—'}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Runs</div><div className="cp-log-card-fv">{c.total_runs || 0}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Latest</div><div className="cp-log-card-fv">{c.latest_run_at ? fmtDate(c.latest_run_at).slice(0,10) : '—'}</div></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {deliveries.length > 0 && (
                <div className="cp-table-section">
                  <div className="cp-table-section-hdr">
                    <span className="cp-ana-section-title">Recent Deliveries</span>
                    <div style={{ display: 'flex', gap: 4 }}>
                      {(['all', 'sent', 'failed'] as const).map(f => (
                        <button key={f} className={`cp-filter-chip${dlFilter === f ? ' active' : ''}`} onClick={() => setDlFilter(f)} style={{ padding: '3px 9px', fontSize: '.7rem' }}>{f}</button>
                      ))}
                    </div>
                  </div>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr><th>User</th><th>Campaign</th><th>Kind</th><th>Status</th><th>Method</th><th>Time</th></tr>
                      </thead>
                      <tbody>
                        {filteredDl.slice(0, 80).map((l: any) => (
                          <tr key={l.id}>
                            <td><UserIdentity firstName={l.first_name} lastName={l.last_name} username={l.tg_username} telegramId={l.telegram_id} photoUrl={l.profile_photo_url} /></td>
                            <td style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '.72rem' }}>{l.campaign_name}</td>
                            <td className="mono" style={{ fontSize: '.7rem' }}>{l.message_kind}</td>
                            <td><span className={`cp-delivery-badge ${l.delivery_status === 'sent' ? 'cp-del-ok' : 'cp-del-fail'}`}>{l.delivery_status}</span></td>
                            <td><span className={`cp-delivery-badge ${(l.delivery_method === 'forward_message' || l.delivery_method === 'copy_message') ? 'cp-del-copy' : 'cp-del-ok'}`}>{l.delivery_method === 'forward_message' ? 'fwd' : l.delivery_method === 'copy_message' ? 'copy' : 'direct'}</span></td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.72rem' }}>{fmtDate(l.created_at)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {filteredDl.slice(0, 80).map((l: any) => (
                      <div key={l.id} className="cp-log-card-item">
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title"><UserIdentity firstName={l.first_name} lastName={l.last_name} username={l.tg_username} telegramId={l.telegram_id} photoUrl={l.profile_photo_url} /></span>
                          <span className="cp-log-card-badge">
                            <span className={`cp-delivery-badge ${l.delivery_status === 'sent' ? 'cp-del-ok' : 'cp-del-fail'}`}>{l.delivery_status}</span>
                            {(l.delivery_method === 'forward_message' || l.delivery_method === 'copy_message') && <span className="cp-delivery-badge cp-del-copy" style={{ marginLeft: 4, fontSize: '.58rem' }}>{l.delivery_method === 'forward_message' ? 'fwd' : 'copy'}</span>}
                          </span>
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Campaign</div><div className="cp-log-card-fv">{l.campaign_name}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Kind</div><div className="cp-log-card-fv mono">{l.message_kind}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Method</div><div className="cp-log-card-fv mono">{l.delivery_method === 'forward_message' ? 'forwardMessage' : l.delivery_method === 'copy_message' ? 'copyMessage' : 'direct'}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Time</div><div className="cp-log-card-fv">{fmtDate(l.created_at)}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {!summary && <EmptyState icon="chart" title="No analytics data yet" sub="Analytics populate as campaigns run and users interact" />}
            </>
          )}

          {/* ── RUNS ── */}
          {tab === 'runs' && (
            selectedRunId && selectedRunData ? (
              <div>
                <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 8, borderBottom: '1px solid var(--border)' }}>
                  <button className="btn-ghost-sm" style={{ fontSize: '.7rem' }} onClick={() => setSelectedRunId(null)}>← Back to Runs</button>
                  <span style={{ fontWeight: 700, fontSize: '.85rem' }}>Run #{selectedRunData.run_id}</span>
                  <span className="mono" style={{ fontSize: '.7rem', color: 'var(--text-3)' }}>{selectedRunData.run_type}</span>
                  <StatusBadge status={selectedRunData.run_status || 'unknown'} />
                </div>
                <div className="cp-stat-grid" style={{ padding: '12px 16px' }}>
                  <div className="cp-stat-card"><span className="cp-stat-card-v">{selectedRunData.campaign_name}</span><span className="cp-stat-card-l">Campaign</span></div>
                  <div className="cp-stat-card"><span className="cp-stat-card-v">{fmtDate(selectedRunData.executed_at)}</span><span className="cp-stat-card-l">Executed</span></div>
                  <div className="cp-stat-card"><span className="cp-stat-card-v">{selectedRunData.total_sent || 0}</span><span className="cp-stat-card-l">Messages Sent</span></div>
                  <div className="cp-stat-card"><span className="cp-stat-card-v">{selectedRunData.total_failed || 0}</span><span className="cp-stat-card-l">Failed</span></div>
                  {selectedRunData.channels_targeted > 0 && (
                    <div className="cp-stat-card"><span className="cp-stat-card-v">{selectedRunData.channels_copied || 0}/{selectedRunData.channels_targeted}</span><span className="cp-stat-card-l">Channels Sent</span></div>
                  )}
                  <div className="cp-stat-card"><span className="cp-stat-card-v accent">{fmt(selectedRunData.valid_revenue || 0)}</span><span className="cp-stat-card-l">Valid Revenue</span></div>
                  <div className="cp-stat-card"><span className="cp-stat-card-v" style={{ color: 'var(--c-rose)' }}>{fmt(selectedRunData.late_revenue || 0)}</span><span className="cp-stat-card-l">Late Revenue</span></div>
                </div>
                {selectedRunData.attribution_start_at && (
                  <div style={{ padding: '0 16px 12px', fontSize: '.72rem', color: 'var(--text-3)' }}>
                    Attribution window: {fmtDate(selectedRunData.attribution_start_at)} → {selectedRunData.attribution_end_at ? fmtDate(selectedRunData.attribution_end_at) : 'Open'}
                  </div>
                )}
                <div className="cp-table-section">
                  <div className="cp-table-section-hdr"><span className="cp-ana-section-title">Deep Links for Run #{selectedRunData.run_id}</span></div>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr><th>Code</th><th>Status</th><th>Opens</th><th>Purchases</th><th>Valid Rev</th><th>Late Rev</th><th>Conv</th><th>Created</th><th></th></tr>
                      </thead>
                      <tbody>
                        {runDeepLinks.length === 0 ? (
                          <tr><td colSpan={9} style={{ textAlign: 'center', color: 'var(--text-3)', padding: 20 }}>No deep links for this run</td></tr>
                        ) : runDeepLinks.map((dl: any) => (
                          <tr key={dl.id}>
                            <td><code style={{ fontSize: '.7rem', color: 'var(--c-accent-bright)' }}>{dl.code}</code></td>
                            <td><span className={`cp-dl-badge cp-dl-badge--${dl.status}`}>{dl.status}</span></td>
                            <td>{dl.opens_count || 0}</td>
                            <td>{dl.valid_purchases || 0}</td>
                            <td className="accent">{fmt(dl.valid_revenue || 0)}</td>
                            <td style={{ color: Number(dl.late_revenue) > 0 ? 'var(--c-rose)' : undefined }}>{fmt(dl.late_revenue || 0)}</td>
                            <td>{dl.conversion_rate || 0}%</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{fmtDate(dl.created_at)}</td>
                            <td>
                              <button className="btn-ghost-sm" style={{ fontSize: '.65rem', padding: '2px 7px' }}
                                onClick={() => setNav({ screen: 'deep-link-detail', linkId: dl.id, campaignName: dl.campaign_name, fromCampaignId: dl.campaign_id })}>
                                View
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {runDeepLinks.length === 0
                      ? <div style={{ textAlign: 'center', color: 'var(--text-3)', padding: 20, fontSize: '.8rem' }}>No deep links for this run</div>
                      : runDeepLinks.map((dl: any) => (
                        <div key={dl.id} className="cp-log-card-item" onClick={() => setNav({ screen: 'deep-link-detail', linkId: dl.id, campaignName: dl.campaign_name, fromCampaignId: dl.campaign_id })} style={{ cursor: 'pointer' }}>
                          <div className="cp-log-card-top">
                            <span className="cp-log-card-title" style={{ color: 'var(--c-accent-bright)', fontFamily: 'var(--font-mono)', fontSize: '.78rem' }}>{dl.code}</span>
                            <span className="cp-log-card-badge"><span className={`cp-dl-badge cp-dl-badge--${dl.status}`}>{dl.status}</span></span>
                          </div>
                          <div className="cp-log-card-grid">
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Revenue</div><div className="cp-log-card-fv accent">{fmt(dl.valid_revenue || 0)}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Purchases</div><div className="cp-log-card-fv">{dl.valid_purchases || 0}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Opens</div><div className="cp-log-card-fv">{dl.opens_count || 0}</div></div>
                            <div className="cp-log-card-field"><div className="cp-log-card-fl">Conv</div><div className="cp-log-card-fv">{dl.conversion_rate || 0}%</div></div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            ) : runs.length === 0
              ? <EmptyState icon="list" title="No runs yet" sub="Campaign runs appear here after the scheduler fires" />
              : (
                <div className="cp-table-section">
                  <div className="cp-table-section-hdr"><span className="cp-ana-section-title">Campaign Runs</span></div>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr>
                          <th>#</th><th>Campaign</th><th>Type</th><th>Deep Link</th><th>DL Status</th>
                          <th>Opens</th><th>Unique</th><th>Purchases</th><th>Late Pch</th><th>Valid Rev</th><th>Late Rev</th><th>Conv</th><th>Executed</th><th>Activated</th><th>Expired</th><th>Window</th><th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {runs.map((r: any) => (
                          <tr key={r.run_id} style={{ cursor: 'pointer' }} onClick={() => setSelectedRunId(r.run_id)}>
                            <td className="mono" style={{ fontSize: '.7rem' }}>{r.run_id}</td>
                            <td style={{ maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '.72rem' }}>{r.campaign_name}</td>
                            <td className="mono" style={{ fontSize: '.7rem' }}>{r.run_type}</td>
                            <td>
                              {r.deep_link_code
                                ? <code style={{ fontSize: '.7rem', color: 'var(--c-accent-bright)' }}>{r.deep_link_code}</code>
                                : <span style={{ color: 'var(--text-3)', fontSize: '.7rem' }}>—</span>}
                            </td>
                            <td>
                              {r.deep_link_status
                                ? <span className={`cp-dl-badge cp-dl-badge--${r.deep_link_status}`}>{r.deep_link_status}</span>
                                : '—'}
                            </td>
                            <td>{r.opens_count || 0}</td>
                            <td>{r.unique_opens_count || 0}</td>
                            <td>{r.valid_purchases || 0}</td>
                            <td style={{ color: Number(r.late_purchases) > 0 ? 'var(--c-rose)' : undefined }}>{r.late_purchases || 0}</td>
                            <td className="accent">{fmt(r.valid_revenue || 0)}</td>
                            <td style={{ color: Number(r.late_revenue) > 0 ? 'var(--c-rose)' : undefined }}>{fmt(r.late_revenue || 0)}</td>
                            <td>{Number(r.opens_count) > 0 ? ((Number(r.valid_purchases) / Number(r.opens_count)) * 100).toFixed(1) + '%' : '—'}</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{fmtDate(r.executed_at)}</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{r.activated_at ? fmtDate(r.activated_at) : '—'}</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{r.expired_at ? fmtDate(r.expired_at) : '—'}</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.65rem', color: 'var(--text-3)' }}>
                              {r.attribution_start_at ? fmtDate(r.attribution_start_at).slice(0,10) : '—'}
                              {r.attribution_end_at ? ` → ${fmtDate(r.attribution_end_at).slice(0,10)}` : ''}
                            </td>
                            <td>
                              <button
                                className="btn-ghost-sm"
                                style={{ fontSize: '.65rem', padding: '2px 7px' }}
                                onClick={(e) => { e.stopPropagation(); setSelectedRunId(r.run_id); }}
                              >
                                Detail
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {runs.map((r: any) => (
                      <div key={r.run_id} className="cp-log-card-item" style={{ cursor: 'pointer' }} onClick={() => setSelectedRunId(r.run_id)}>
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title">#{r.run_id} {r.campaign_name}</span>
                          <span className="cp-log-card-badge">
                            {r.deep_link_status ? <span className={`cp-dl-badge cp-dl-badge--${r.deep_link_status}`}>{r.deep_link_status}</span> : null}
                          </span>
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Revenue</div><div className="cp-log-card-fv accent">{fmt(r.valid_revenue || 0)}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Purchases</div><div className="cp-log-card-fv">{r.valid_purchases || 0}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Opens</div><div className="cp-log-card-fv">{r.opens_count || 0}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Type</div><div className="cp-log-card-fv mono">{r.run_type}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Executed</div><div className="cp-log-card-fv">{fmtDate(r.executed_at)}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Deep Link</div><div className="cp-log-card-fv accent">{r.deep_link_code || '—'}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
          )}

          {/* ── DEEP LINKS ── */}
          {tab === 'deep-links' && (
            deepLinks.length === 0
              ? <EmptyState icon="flag" title="No deep links found" sub="Deep links are generated when campaign runs fire" />
              : (
                <div className="cp-table-section">
                  <div className="cp-table-section-hdr"><span className="cp-ana-section-title">Deep Link Analytics</span></div>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr>
                          <th>Code</th><th>Campaign</th><th>Run</th><th>Status</th><th>Opens</th><th>Starts</th>
                          <th>Purchases</th><th>Valid Rev</th><th>Late Rev</th><th>Conv</th><th>Created</th><th>Expires</th><th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {deepLinks.map((dl: any) => (
                          <tr key={dl.id}>
                            <td><code style={{ fontSize: '.7rem', color: 'var(--c-accent-bright)' }}>{dl.code}</code></td>
                            <td style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '.72rem' }}>{dl.campaign_name}</td>
                            <td style={{ fontSize: '.7rem', whiteSpace: 'nowrap' }}>
                              {dl.campaign_run_id ? <span className="mono">#{dl.campaign_run_id} <span style={{ color: 'var(--text-3)' }}>{dl.run_type || ''}</span></span> : '—'}
                            </td>
                            <td><span className={`cp-dl-badge cp-dl-badge--${dl.status}`}>{dl.status}</span></td>
                            <td>{dl.opens_count || 0}</td>
                            <td>{dl.starts_count || 0}</td>
                            <td>{dl.valid_purchases || 0}</td>
                            <td className="accent">{fmt(dl.valid_revenue || 0)}</td>
                            <td style={{ color: Number(dl.late_revenue) > 0 ? 'var(--c-rose)' : undefined }}>{fmt(dl.late_revenue || 0)}</td>
                            <td>{dl.conversion_rate || 0}%</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{fmtDate(dl.created_at)}</td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{dl.expired_at ? fmtDate(dl.expired_at) : '—'}</td>
                            <td>
                              <div style={{ display: 'flex', gap: 4 }}>
                                <button
                                  className="cp-icon-btn"
                                  title="Copy link"
                                  onClick={() => navigator.clipboard?.writeText(dl.full_url || '').catch(() => {})}
                                >⧉</button>
                                <button
                                  className="btn-ghost-sm"
                                  style={{ fontSize: '.65rem', padding: '2px 7px' }}
                                  onClick={() => setNav({ screen: 'deep-link-detail', linkId: dl.id, campaignName: dl.campaign_name, fromCampaignId: dl.campaign_id })}
                                >
                                  View
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {deepLinks.map((dl: any) => (
                      <div key={dl.id} className="cp-log-card-item" onClick={() => setNav({ screen: 'deep-link-detail', linkId: dl.id, campaignName: dl.campaign_name, fromCampaignId: dl.campaign_id })} style={{ cursor: 'pointer' }}>
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title" style={{ color: 'var(--c-accent-bright)', fontFamily: 'var(--font-mono)', fontSize: '.78rem' }}>{dl.code}</span>
                          <span className="cp-log-card-badge"><span className={`cp-dl-badge cp-dl-badge--${dl.status}`}>{dl.status}</span></span>
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Campaign</div><div className="cp-log-card-fv">{dl.campaign_name}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Revenue</div><div className="cp-log-card-fv accent">{fmt(dl.valid_revenue || 0)}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Purchases</div><div className="cp-log-card-fv">{dl.valid_purchases || 0}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Opens</div><div className="cp-log-card-fv">{dl.opens_count || 0}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Conv</div><div className="cp-log-card-fv">{dl.conversion_rate || 0}%</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Created</div><div className="cp-log-card-fv">{fmtDate(dl.created_at)}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
          )}

          {/* ── ORDERS ── */}
          {tab === 'orders' && (
            orders.length === 0
              ? <EmptyState icon="flag" title="No attributed orders" sub="Orders attributed to campaign deep links will appear here" />
              : (
                <div className="cp-table-section">
                  <div className="cp-table-section-hdr"><span className="cp-ana-section-title">Order Attribution</span></div>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr>
                          <th>Order</th><th>User</th><th>Campaign</th><th>Run</th><th>Deep Link</th>
                          <th>Product</th><th>Amount</th><th>Status</th><th>Attribution</th><th>Reason</th><th>Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.map((o: any) => (
                          <tr key={o.order_id}>
                            <td className="mono">#{o.order_id}</td>
                            <td>
                              <UserIdentity
                                firstName={o.first_name}
                                lastName={o.last_name}
                                username={o.tg_username}
                                telegramId={String(o.telegram_id)}
                                photoUrl={o.profile_photo_url}
                              />
                            </td>
                            <td style={{ maxWidth: 110, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '.72rem' }}>{o.campaign_name || '—'}</td>
                            <td style={{ fontSize: '.7rem', whiteSpace: 'nowrap' }}>
                              {o.campaign_run_id ? <span className="mono">#{o.campaign_run_id} <span style={{ color: 'var(--text-3)' }}>{o.run_type || ''}</span></span> : '—'}
                            </td>
                            <td><code style={{ fontSize: '.7rem', color: 'var(--c-accent-bright)' }}>{o.deep_link_code || '—'}</code></td>
                            <td style={{ fontSize: '.72rem', whiteSpace: 'nowrap' }}>{o.category} · {o.duration}</td>
                            <td className="accent">{fmt(o.amount)}</td>
                            <td><StatusBadge status={o.payment_status} /></td>
                            <td><AtrBadge isLate={o.attribution_status === 'late'} status={o.attribution_status === 'unpaid' ? 'unpaid' : o.payment_status} /></td>
                            <td style={{ fontSize: '.68rem', color: 'var(--text-3)', maxWidth: 140, whiteSpace: 'normal' }}>
                              {o.exclusion_reason || <span style={{ color: 'var(--c-accent-bright)' }}>—</span>}
                            </td>
                            <td style={{ whiteSpace: 'nowrap', fontSize: '.7rem' }}>{fmtDate(o.purchase_time)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {orders.map((o: any) => (
                      <div key={o.order_id} className="cp-log-card-item">
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title">#{o.order_id} — {o.category} · {o.duration}</span>
                          <span className="cp-log-card-badge"><StatusBadge status={o.payment_status} /></span>
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Amount</div><div className="cp-log-card-fv accent">{fmt(o.amount)}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Attribution</div><div className="cp-log-card-fv"><AtrBadge isLate={o.attribution_status === 'late'} status={o.attribution_status === 'unpaid' ? 'unpaid' : o.payment_status} /></div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Campaign</div><div className="cp-log-card-fv">{o.campaign_name || '—'}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Deep Link</div><div className="cp-log-card-fv accent">{o.deep_link_code || '—'}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">User</div><div className="cp-log-card-fv"><UserIdentity firstName={o.first_name} lastName={o.last_name} username={o.tg_username} telegramId={String(o.telegram_id)} photoUrl={o.profile_photo_url} /></div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Time</div><div className="cp-log-card-fv">{fmtDate(o.purchase_time)}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
          )}

          {/* ── FUNNEL ── */}
          {tab === 'funnel' && (
            !funnel
              ? <EmptyState icon="chart" title="No funnel data" sub="Funnel builds as campaigns run" />
              : (
                <div style={{ padding: '16px' }}>
                  <div className="cp-table-section-hdr" style={{ marginBottom: 16 }}>
                    <span className="cp-ana-section-title">Conversion Funnel</span>
                  </div>
                  {([
                    { label: 'Messages Delivered', count: funnel.delivered,  color: 'var(--c-accent-bright)' },
                    { label: 'Link Opened',         count: funnel.opened,    color: 'var(--c-emerald)' },
                    { label: 'Bot Started',          count: funnel.started,   color: '#f59e0b' },
                    { label: 'Purchase Completed',   count: funnel.purchased, color: 'var(--c-rose)' },
                  ] as any[]).map((step: any, i: number, arr: any[]) => {
                    const pct   = arr[0].count > 0 ? Math.round((step.count / arr[0].count) * 100) : (i === 0 ? 100 : 0);
                    const sPct  = i > 0 && arr[i-1].count > 0 ? ((step.count / arr[i-1].count) * 100).toFixed(1) : null;
                    return (
                      <div key={step.label} className="cp-funnel-step">
                        <div className="cp-funnel-step-label">
                          <span className="cp-funnel-num">{i + 1}</span>
                          <span className="cp-funnel-lbl">{step.label}</span>
                          {sPct && <span className="cp-funnel-drop">↓ {sPct}% from prev</span>}
                        </div>
                        <div className="cp-funnel-bar-row">
                          <div className="cp-funnel-bar-track">
                            <div className="cp-funnel-bar-fill" style={{ width: `${Math.max(pct, 2)}%`, background: step.color }} />
                          </div>
                          <div className="cp-funnel-bar-vals">
                            <span className="cp-funnel-count">{Number(step.count).toLocaleString()}</span>
                            <span className="cp-funnel-pct">{pct}%</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <div style={{ marginTop: 20, padding: '14px 16px', background: 'var(--c-surface-2)', borderRadius: 10, border: '1px solid var(--c-border)', display: 'flex', gap: 24, flexWrap: 'wrap' }}>
                    <div>
                      <div style={{ fontSize: '.65rem', color: 'var(--text-3)', marginBottom: 2 }}>Delivered → Opened</div>
                      <div style={{ fontSize: '.95rem', fontWeight: 700, color: 'var(--c-accent-bright)' }}>
                        {funnel.delivered > 0 ? ((funnel.opened / funnel.delivered) * 100).toFixed(1) : 0}%
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: '.65rem', color: 'var(--text-3)', marginBottom: 2 }}>Opened → Purchased</div>
                      <div style={{ fontSize: '.95rem', fontWeight: 700, color: 'var(--c-emerald)' }}>
                        {funnel.opened > 0 ? ((funnel.purchased / funnel.opened) * 100).toFixed(1) : 0}%
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: '.65rem', color: 'var(--text-3)', marginBottom: 2 }}>Unique Openers</div>
                      <div style={{ fontSize: '.95rem', fontWeight: 700 }}>{Number(funnel.unique_openers || 0).toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              )
          )}

        </div>
      )}
    </div>
  );
}

// ── LOGS SCREEN ────────────────────────────────────────────────────────────

function LogsScreen({ campaignId, campaignName, campaigns, setNav }: any) {
  const [logsTab, setLogsTab] = useState<LogsTab>('runs');
  const [runLogs, setRunLogs] = useState<any[]>([]);
  const [deliveries, setDeliveries] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [filterCampId, setFilterCampId] = useState<number | ''>(campaignId || '');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      if (filterCampId) {
        const d = await apiGet(`/campaigns/${filterCampId}/logs`);
        setRunLogs(d.run_logs || []);
        setDeliveries(d.delivery_logs || []);
      } else {
        const d = await apiGet('/campaigns/analytics/dispatch-logs?limit=200');
        setDeliveries(d.delivery_logs || []);
        setRunLogs([]);
      }
    } catch {}
    setLoading(false);
  }, [filterCampId]);

  useEffect(() => { load(); }, [load]);

  const failures = deliveries.filter((l: any) => l.delivery_status === 'failed');
  const sent = deliveries.filter((l: any) => l.delivery_status === 'sent');

  return (
    <div className="cp-screen">
      <div className="cp-screen-hdr">
        <BackButton onBack={() => setNav({ screen: 'home' })} />
        <div>
          <h3 className="cp-screen-title">Campaign Logs</h3>
          {campaignName && <div className="cp-screen-sub">{campaignName}</div>}
        </div>
        <button className="btn-ghost-sm" onClick={load} disabled={loading}><Icon name="refresh" /></button>
      </div>

      {/* Filter bar */}
      <div className="cp-filter-bar">
        <select className="cp-filter-select" value={filterCampId} onChange={e => setFilterCampId(e.target.value ? Number(e.target.value) : '')}>
          <option value="">All Campaigns</option>
          {campaigns.map((c: Campaign) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {/* Sub-tabs */}
      <div className="cp-sub-tabs">
        <button className={`cp-sub-tab${logsTab === 'runs' ? ' active' : ''}`} onClick={() => setLogsTab('runs')}>Runs {runLogs.length > 0 && `(${runLogs.length})`}</button>
        <button className={`cp-sub-tab${logsTab === 'deliveries' ? ' active' : ''}`} onClick={() => setLogsTab('deliveries')}>Deliveries {sent.length > 0 && `(${sent.length})`}</button>
        <button className={`cp-sub-tab${logsTab === 'failures' ? ' active' : ''}`} onClick={() => setLogsTab('failures')}>Failures {failures.length > 0 && `(${failures.length})`}</button>
      </div>

      {loading && <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-3)' }}>Loading logs…</div>}

      {!loading && (
        <div style={{ padding: '12px 0 60px' }}>
          {logsTab === 'runs' && (
            runLogs.length === 0
              ? <EmptyState icon="list" title="No run logs" sub="Run logs appear when campaigns execute" />
              : <>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr><th>#</th><th>Campaign</th><th>Type</th><th>Executed</th><th>Status</th><th>Sent</th><th>Failed</th></tr>
                      </thead>
                      <tbody>
                        {runLogs.map((r: any) => (
                          <tr key={r.id}>
                            <td className="mono">{r.id}</td>
                            <td style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.campaign_name || `#${r.campaign_id}`}</td>
                            <td className="mono">{r.run_type}</td>
                            <td style={{ whiteSpace: 'nowrap' }}>{fmtDate(r.executed_at)}</td>
                            <td><StatusBadge status={r.status} /></td>
                            <td>{r.total_sent || 0}</td>
                            <td className={r.total_failed > 0 ? 'danger' : ''}>{r.total_failed || 0}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {runLogs.map((r: any) => (
                      <div key={r.id} className="cp-log-card-item">
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title">{r.campaign_name || `#${r.campaign_id}`}</span>
                          <span className="cp-log-card-badge"><StatusBadge status={r.status} /></span>
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Run #</div><div className="cp-log-card-fv mono">{r.id}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Type</div><div className="cp-log-card-fv mono">{r.run_type}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Sent</div><div className="cp-log-card-fv">{r.total_sent || 0}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Failed</div><div className={`cp-log-card-fv${r.total_failed > 0 ? ' danger' : ''}`}>{r.total_failed || 0}</div></div>
                          {(r.channels_targeted > 0 || r.source_message_id) && (
                            <>
                              <div className="cp-log-card-field"><div className="cp-log-card-fl">Ch. Sent</div><div className="cp-log-card-fv">{r.channels_copied || 0}/{r.channels_targeted || 0}</div></div>
                              <div className="cp-log-card-field"><div className="cp-log-card-fl">Source Msg</div><div className="cp-log-card-fv mono">{r.source_message_id || '—'}</div></div>
                            </>
                          )}
                          <div className="cp-log-card-field" style={{ gridColumn: '1 / -1' }}><div className="cp-log-card-fl">Executed</div><div className="cp-log-card-fv">{fmtDate(r.executed_at)}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
          )}

          {logsTab === 'deliveries' && (
            sent.length === 0
              ? <EmptyState icon="send" title="No delivery logs" sub="Delivery logs appear after campaigns send messages" />
              : <>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr><th>User</th><th>Campaign</th><th>Kind</th><th>Target</th><th>Method</th><th>Time</th></tr>
                      </thead>
                      <tbody>
                        {sent.slice(0, 200).map((l: any) => (
                          <tr key={l.id}>
                            <td><UserIdentity firstName={l.first_name} lastName={l.last_name} username={l.tg_username} telegramId={l.telegram_id} photoUrl={l.profile_photo_url} /></td>
                            <td style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.campaign_name}</td>
                            <td className="mono">{l.message_kind}</td>
                            <td className="mono">{l.target_type}</td>
                            <td><span className={`cp-delivery-badge ${(l.delivery_method === 'forward_message' || l.delivery_method === 'copy_message') ? 'cp-del-copy' : 'cp-del-ok'}`}>{l.delivery_method === 'forward_message' ? 'fwd' : l.delivery_method === 'copy_message' ? 'copy' : 'direct'}</span></td>
                            <td style={{ whiteSpace: 'nowrap' }}>{fmtDate(l.created_at)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {sent.slice(0, 200).map((l: any) => (
                      <div key={l.id} className="cp-log-card-item">
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title">
                            <UserIdentity firstName={l.first_name} lastName={l.last_name} username={l.tg_username} telegramId={l.telegram_id} photoUrl={l.profile_photo_url} />
                          </span>
                          {(l.delivery_method === 'forward_message' || l.delivery_method === 'copy_message') && <span className="cp-delivery-badge cp-del-copy" style={{ fontSize: '.6rem' }}>{l.delivery_method === 'forward_message' ? 'fwd' : 'copy'}</span>}
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Campaign</div><div className="cp-log-card-fv">{l.campaign_name}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Kind</div><div className="cp-log-card-fv mono">{l.message_kind}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Target</div><div className="cp-log-card-fv mono">{l.target_type}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Method</div><div className="cp-log-card-fv mono">{l.delivery_method === 'forward_message' ? 'forwardMessage' : l.delivery_method === 'copy_message' ? 'copyMessage' : 'direct'}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Time</div><div className="cp-log-card-fv">{fmtDate(l.created_at)}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
          )}

          {logsTab === 'failures' && (
            failures.length === 0
              ? <EmptyState icon="check" title="No failures" sub="All recent deliveries were successful" />
              : <>
                  <div className="cp-tbl-wrap has-cards">
                    <table className="cp-tbl">
                      <thead>
                        <tr><th>User</th><th>Campaign</th><th>Kind</th><th>Error</th><th>Time</th></tr>
                      </thead>
                      <tbody>
                        {failures.slice(0, 200).map((l: any) => (
                          <tr key={l.id}>
                            <td><UserIdentity firstName={l.first_name} lastName={l.last_name} username={l.tg_username} telegramId={l.telegram_id} photoUrl={l.profile_photo_url} /></td>
                            <td style={{ maxWidth: 100, overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.campaign_name}</td>
                            <td className="mono">{l.message_kind}</td>
                            <td className="err-cell" style={{ maxWidth: 180 }}>{l.error_text || '—'}</td>
                            <td style={{ whiteSpace: 'nowrap' }}>{fmtDate(l.created_at)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="cp-log-cards">
                    {failures.slice(0, 200).map((l: any) => (
                      <div key={l.id} className="cp-log-card-item">
                        <div className="cp-log-card-top">
                          <span className="cp-log-card-title">
                            <UserIdentity firstName={l.first_name} lastName={l.last_name} username={l.tg_username} telegramId={l.telegram_id} photoUrl={l.profile_photo_url} />
                          </span>
                        </div>
                        <div className="cp-log-card-grid">
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Campaign</div><div className="cp-log-card-fv">{l.campaign_name}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Kind</div><div className="cp-log-card-fv mono">{l.message_kind}</div></div>
                          <div className="cp-log-card-field" style={{ gridColumn: '1 / -1' }}><div className="cp-log-card-fl">Error</div><div className="cp-log-card-fv danger">{l.error_text || '—'}</div></div>
                          <div className="cp-log-card-field"><div className="cp-log-card-fl">Time</div><div className="cp-log-card-fv">{fmtDate(l.created_at)}</div></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
          )}
        </div>
      )}
    </div>
  );
}

// ── DEEP LINK DETAIL SCREEN ───────────────────────────────────────────────

type DLTab = 'overview' | 'events' | 'orders';

function DeepLinkDetailScreen({ linkId, campaignName, fromCampaignId, setNav }: any) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [dlTab, setDlTab] = useState<DLTab>('overview');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setLoading(true);
    apiGet(`/campaigns/deep-links/${linkId}`)
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [linkId]);

  const link     = data?.link     || {};
  const events   = data?.events   || [];
  const orders   = data?.orders   || [];
  const daily    = data?.daily_series || [];

  const convRate = Number(link.opens_count) > 0
    ? ((Number(link.purchases_count) / Number(link.opens_count)) * 100).toFixed(1)
    : '0.0';

  const copyLink = () => {
    const url = link.full_url || link.deep_link_url || '';
    navigator.clipboard?.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };

  const backTo = fromCampaignId
    ? () => setNav({ screen: 'detail', campaignId: fromCampaignId })
    : () => setNav({ screen: 'home' });

  if (loading) return <div className="cp-screen"><div className="page-loader"><div className="loader-spinner" /></div></div>;
  if (!data?.link) return (
    <div className="cp-screen">
      <div className="cp-screen-hdr"><BackButton onBack={backTo} /></div>
      <EmptyState icon="flag" title="Deep link not found" />
    </div>
  );

  return (
    <div className="cp-screen">
      <div className="cp-screen-hdr">
        <BackButton onBack={backTo} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <h3 className="cp-screen-title" style={{ margin: 0 }}>Deep Link</h3>
          {(campaignName || link.campaign_name) && (
            <div className="cp-screen-sub">{campaignName || link.campaign_name}</div>
          )}
        </div>
        <button className="btn-ghost-sm" onClick={copyLink} title="Copy link">
          {copied ? '✓ Copied' : <><Icon name="copy" /> Copy</>}
        </button>
      </div>

      {/* Link identity strip */}
      <div style={{ padding: '10px 16px', background: 'var(--c-surface-2)', borderBottom: '1px solid var(--c-border)', display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span className={`cp-dl-badge cp-dl-badge--${link.status}`}>{link.status}</span>
          <code style={{ fontSize: '.75rem', color: 'var(--c-accent-bright)', wordBreak: 'break-all' }}>{link.code}</code>
        </div>
        <div style={{ fontSize: '.7rem', color: 'var(--text-3)', wordBreak: 'break-all' }}>{link.full_url || link.deep_link_url}</div>
      </div>

      {/* Sub-tabs */}
      <div className="cp-sub-tabs">
        <button className={`cp-sub-tab${dlTab === 'overview' ? ' active' : ''}`} onClick={() => setDlTab('overview')}>Overview</button>
        <button className={`cp-sub-tab${dlTab === 'events' ? ' active' : ''}`} onClick={() => setDlTab('events')}>Events {events.length > 0 && `(${events.length})`}</button>
        <button className={`cp-sub-tab${dlTab === 'orders' ? ' active' : ''}`} onClick={() => setDlTab('orders')}>Orders {orders.length > 0 && `(${orders.length})`}</button>
      </div>

      <div style={{ padding: '12px 0 80px' }}>
        {/* ── OVERVIEW TAB ── */}
        {dlTab === 'overview' && (
          <>
            {/* KPI grid */}
            <div className="cp-stat-grid" style={{ margin: '0 0 12px' }}>
              {[
                { l: 'Opens',    v: link.opens_count    || 0 },
                { l: 'Unique',   v: link.unique_opens_count || 0 },
                { l: 'Starts',   v: link.starts_count   || 0 },
                { l: 'Purchases',v: link.purchases_count || 0 },
                { l: 'Revenue',  v: fmt(link.revenue_total || 0), accent: true },
                { l: 'Conv. Rate', v: `${convRate}%`,   accent: true },
                { l: 'Late Buys',v: link.late_purchases_count || 0 },
                { l: 'Late Rev', v: fmt(link.late_revenue_total || 0) },
              ].map((k, i) => (
                <div key={i} className="cp-stat-card">
                  <span className="cp-stat-card-v" style={(k as any).accent ? { color: 'var(--c-accent-bright)' } : undefined}>{k.v}</span>
                  <span className="cp-stat-card-l">{k.l}</span>
                </div>
              ))}
            </div>

            {/* Link info */}
            <div className="cp-detail-section">
              <div className="cp-detail-section-hdr">Link Info</div>
              <div className="cp-detail-section-body">
                <div className="cp-detail-kv-grid">
                  <div className="cp-detail-kv"><div className="cp-detail-kv-l">Status</div>
                    <div className="cp-detail-kv-v"><span className={`cp-dl-badge cp-dl-badge--${link.status}`}>{link.status}</span></div>
                  </div>
                  <div className="cp-detail-kv"><div className="cp-detail-kv-l">Run type</div><div className="cp-detail-kv-v">{link.run_type || '—'}</div></div>
                  <div className="cp-detail-kv"><div className="cp-detail-kv-l">Activated</div><div className="cp-detail-kv-v">{fmtDate(link.activated_at || link.created_at)}</div></div>
                  <div className="cp-detail-kv"><div className="cp-detail-kv-l">Expired at</div><div className="cp-detail-kv-v">{link.expired_at ? fmtDate(link.expired_at) : '—'}</div></div>
                  <div className="cp-detail-kv"><div className="cp-detail-kv-l">Attribution end</div><div className="cp-detail-kv-v">{link.attribution_end_at ? fmtDate(link.attribution_end_at) : '—'}</div></div>
                  <div className="cp-detail-kv"><div className="cp-detail-kv-l">Campaign run #</div><div className="cp-detail-kv-v mono">{link.campaign_run_id || '—'}</div></div>
                </div>
              </div>
            </div>

            {/* Daily series mini chart */}
            {daily.length > 0 && (
              <div className="cp-detail-section" style={{ overflow: 'hidden' }}>
                <div className="cp-detail-section-hdr" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>Revenue Timeline</span>
                  <span style={{ fontSize: '.7rem', color: 'var(--text-3)', fontWeight: 400 }}>
                    {daily.filter((d: any) => Number(d.revenue) > 0).length} active days
                  </span>
                </div>
                <div style={{ padding: '12px 14px' }}>
                  <MiniBarChart series={daily} field="revenue" />
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, fontSize: '.65rem', color: 'var(--text-3)' }}>
                    <span>{daily[0]?.day?.slice(5) || ''}</span>
                    <span>{daily[daily.length - 1]?.day?.slice(5) || ''}</span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* ── EVENTS TAB ── */}
        {dlTab === 'events' && (
          events.length === 0
            ? <EmptyState icon="list" title="No events" sub="Opens and starts will appear here" />
            : <>
                <div className="cp-tbl-wrap has-cards">
                  <table className="cp-tbl">
                    <thead>
                      <tr><th>User</th><th>Event</th><th>Order</th><th>Revenue</th><th>Late</th><th>Time</th></tr>
                    </thead>
                    <tbody>
                      {events.map((e: any) => (
                        <tr key={e.id}>
                          <td>
                            <span style={{ fontSize: '.75rem', color: 'var(--text-2)' }}>
                              {e.tg_username ? `@${e.tg_username}` : `ID ${e.telegram_user_id}`}
                            </span>
                          </td>
                          <td><span className="cp-tag">{e.event_type}</span></td>
                          <td className="mono">{e.order_id || '—'}</td>
                          <td className={e.revenue_amount > 0 ? 'accent' : ''}>{e.revenue_amount > 0 ? fmt(e.revenue_amount) : '—'}</td>
                          <td>{e.is_late_conversion ? <span style={{ color: 'var(--c-rose)', fontSize: '.7rem' }}>late</span> : '—'}</td>
                          <td style={{ whiteSpace: 'nowrap', fontSize: '.72rem' }}>{fmtDate(e.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="cp-log-cards">
                  {events.map((e: any) => (
                    <div key={e.id} className="cp-log-card-item">
                      <div className="cp-log-card-top">
                        <span className="cp-log-card-title">{e.tg_username ? `@${e.tg_username}` : `ID ${e.telegram_user_id}`}</span>
                        <span className="cp-tag">{e.event_type}</span>
                      </div>
                      <div className="cp-log-card-grid">
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Order</div><div className="cp-log-card-fv mono">{e.order_id || '—'}</div></div>
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Revenue</div><div className={`cp-log-card-fv${e.revenue_amount > 0 ? ' accent' : ''}`}>{e.revenue_amount > 0 ? fmt(e.revenue_amount) : '—'}</div></div>
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Late</div><div className={`cp-log-card-fv${e.is_late_conversion ? ' danger' : ''}`}>{e.is_late_conversion ? 'late' : '—'}</div></div>
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Time</div><div className="cp-log-card-fv">{fmtDate(e.created_at)}</div></div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
        )}

        {/* ── ORDERS TAB ── */}
        {dlTab === 'orders' && (
          orders.length === 0
            ? <EmptyState icon="flag" title="No attributed orders" sub="Purchases attributed to this deep link will appear here" />
            : <>
                <div className="cp-tbl-wrap has-cards">
                  <table className="cp-tbl">
                    <thead>
                      <tr><th>Order</th><th>User</th><th>Product</th><th>Amount</th><th>Status</th><th>Attribution</th><th>Time</th></tr>
                    </thead>
                    <tbody>
                      {orders.map((o: any) => (
                        <tr key={o.order_id}>
                          <td className="mono">#{o.order_id}</td>
                          <td style={{ fontSize: '.75rem' }}>
                            {o.tg_username ? `@${o.tg_username}` : (o.first_name || `ID ${o.telegram_id}`)}
                          </td>
                          <td style={{ fontSize: '.72rem' }}>{o.category} · {o.duration}</td>
                          <td className="accent">{fmt(o.amount)}</td>
                          <td><StatusBadge status={o.payment_status} /></td>
                          <td>
                            {o.is_campaign_late_conversion || o.event_is_late
                              ? <span style={{ color: 'var(--c-rose)', fontSize: '.7rem', fontWeight: 600 }}>late</span>
                              : <span style={{ color: 'var(--c-emerald)', fontSize: '.7rem', fontWeight: 600 }}>counted</span>
                            }
                          </td>
                          <td style={{ whiteSpace: 'nowrap', fontSize: '.72rem' }}>{fmtDate(o.purchase_time)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="cp-log-cards">
                  {orders.map((o: any) => (
                    <div key={o.order_id} className="cp-log-card-item">
                      <div className="cp-log-card-top">
                        <span className="cp-log-card-title">#{o.order_id} · {o.tg_username ? `@${o.tg_username}` : (o.first_name || `ID ${o.telegram_id}`)}</span>
                        <span className="cp-log-card-badge"><StatusBadge status={o.payment_status} /></span>
                      </div>
                      <div className="cp-log-card-grid">
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Product</div><div className="cp-log-card-fv">{o.category} · {o.duration}</div></div>
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Amount</div><div className="cp-log-card-fv accent">{fmt(o.amount)}</div></div>
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Attribution</div><div className={`cp-log-card-fv${o.is_campaign_late_conversion || o.event_is_late ? ' danger' : ''}`}>{o.is_campaign_late_conversion || o.event_is_late ? 'late' : 'counted'}</div></div>
                        <div className="cp-log-card-field"><div className="cp-log-card-fl">Time</div><div className="cp-log-card-fv">{fmtDate(o.purchase_time)}</div></div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
        )}
      </div>
    </div>
  );
}

// ── CAMPAIGN FORM SCREEN ───────────────────────────────────────────────────

function deriveScopeType(campaign: any): ScopeType {
  const rules: any[] = campaign.discount_rules || [];
  const catScope: number[] = (() => { try { return JSON.parse(campaign.category_scope_json || '[]'); } catch { return []; } })();
  const hasPairs = rules.some(r => r.applies_to_category_id && r.applies_to_duration_id);
  if (hasPairs) return 'selected_pairs';
  if (catScope.length > 0) return 'selected_categories';
  return 'all_products';
}

function derivePairs(campaign: any) {
  const rules: any[] = campaign.discount_rules || [];
  const pairs = rules.filter(r => r.applies_to_category_id && r.applies_to_duration_id)
    .map(r => ({ category_id: Number(r.applies_to_category_id), duration_id: Number(r.applies_to_duration_id) }));
  return pairs.length > 0 ? pairs : [{ category_id: 0, duration_id: 0 }];
}

function deriveDiscountRule(campaign: any) {
  const rules: any[] = campaign.discount_rules || [];
  const r = rules[0] || {};
  return {
    discount_mode: r.discount_mode || 'random_percent',
    min_value: r.min_value != null ? Number(r.min_value) : 5,
    max_value: r.max_value != null ? Number(r.max_value) : 30,
    fixed_value: r.fixed_value != null ? Number(r.fixed_value) : null,
  };
}

function CampaignFormScreen({ campaign, templates, categories, durations, discountPlans, onSave, onCancel }: any) {
  const [form, setForm] = useState(() => ({
    id: campaign.id || 0,
    name: campaign.name || '',
    description: campaign.description || '',
    campaign_mode: campaign.campaign_mode || 'random_discount',
    linked_discount_plan_id: campaign.linked_discount_plan_id,
    repeat_mode: campaign.repeat_mode || 'once',
    timezone: campaign.timezone || 'Asia/Kolkata',
    start_at: campaign.start_at ? toLocalInput(campaign.start_at, campaign.timezone || 'Asia/Kolkata') : '',
    expire_at: campaign.expire_at ? toLocalInput(campaign.expire_at, campaign.timezone || 'Asia/Kolkata') : '',
    promo_template_id: campaign.promo_template_id,
    expiry_template_id: campaign.expiry_template_id,
    send_to_users: campaign.send_to_users !== false,
    send_to_channels: campaign.send_to_channels === true,
    channel_targets: (() => { try { return Array.isArray(campaign.channel_targets) ? campaign.channel_targets : JSON.parse(campaign.channel_targets_json || '[]'); } catch { return []; } })(),
    targets: campaign.targets || [{ target_type: 'all_users', target_value: '', message_kind: 'promo_start' }],
  }));

  const [activeChannels, setActiveChannels] = useState<any[]>([]);
  useEffect(() => {
    apiGet('/channels/active').then(r => setActiveChannels(r.channels || [])).catch(() => {});
  }, []);

  const [scopeType, setScopeType] = useState<ScopeType>(() => deriveScopeType(campaign));
  const [selectedCatIds, setSelectedCatIds] = useState<number[]>(() => {
    try { return JSON.parse(campaign.category_scope_json || '[]'); } catch { return []; }
  });
  const [scopePairs, setScopePairs] = useState(() => derivePairs(campaign));
  const [discountRule, setDiscountRule] = useState(() => deriveDiscountRule(campaign));

  const upd = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));
  const updTarget = (i: number, k: string, v: any) => {
    const t = [...form.targets]; t[i] = { ...t[i], [k]: v }; upd('targets', t);
  };
  const updDR = (k: string, v: any) => setDiscountRule(r => ({ ...r, [k]: v }));

  const changeScopeType = (newType: ScopeType) => {
    if (newType === scopeType) return;
    if ((scopeType === 'selected_categories' && selectedCatIds.length > 0) ||
        (scopeType === 'selected_pairs' && scopePairs.some((p: any) => p.category_id))) {
      if (!confirm('Changing scope type will clear your selections. Continue?')) return;
    }
    setScopeType(newType);
    setSelectedCatIds([]);
    setScopePairs([{ category_id: 0, duration_id: 0 }]);
  };

  const toggleCat = (id: number) =>
    setSelectedCatIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const addPair = () => setScopePairs((p: any) => [...p, { category_id: 0, duration_id: 0 }]);
  const removePair = (i: number) => setScopePairs((p: any) => { const a = [...p]; a.splice(i, 1); return a; });
  const updPair = (i: number, k: 'category_id' | 'duration_id', v: number) =>
    setScopePairs((p: any) => { const a = [...p]; a[i] = { ...a[i], [k]: v }; return a; });

  const durationsForCategory = (catId: number) => durations.filter((d: any) => d.category_id === catId);

  const getAffectedProducts = () => {
    if (scopeType === 'all_products') return durations.map((d: any) => ({ category_name: d.category_name || 'Cat', duration_name: d.name, original_price: Number(d.price || 0) }));
    if (scopeType === 'selected_categories') return durations.filter((d: any) => selectedCatIds.includes(d.category_id)).map((d: any) => ({ category_name: d.category_name || 'Cat', duration_name: d.name, original_price: Number(d.price || 0) }));
    return scopePairs.filter((p: any) => p.category_id && p.duration_id).map((p: any) => {
      const dur = durations.find((d: any) => d.id === p.duration_id);
      const cat = categories.find((c: any) => c.id === p.category_id);
      return { category_name: cat?.name || `Cat #${p.category_id}`, duration_name: dur?.name || `Dur #${p.duration_id}`, original_price: Number(dur?.price || 0) };
    });
  };

  const calcDiscounted = (original: number): number => {
    if (discountRule.discount_mode === 'fixed_price_override') return Number(discountRule.fixed_value || 0);
    const pct = discountRule.discount_mode === 'fixed_percent'
      ? Number(discountRule.fixed_value || 0)
      : (Number(discountRule.min_value || 0) + Number(discountRule.max_value || 0)) / 2;
    return Math.max(0, original * (1 - pct / 100));
  };

  const affectedProducts = getAffectedProducts();

  const discountSummary = () => {
    const mode = discountRule.discount_mode;
    const scope = scopeType === 'all_products' ? 'all categories and all durations'
      : scopeType === 'selected_categories' ? (selectedCatIds.length > 0 ? `${selectedCatIds.length} selected categor${selectedCatIds.length === 1 ? 'y' : 'ies'}` : 'no categories selected')
      : `${scopePairs.filter((p: any) => p.category_id && p.duration_id).length} specific pair${scopePairs.filter((p: any) => p.category_id && p.duration_id).length !== 1 ? 's' : ''}`;
    if (mode === 'random_percent') return `Random ${discountRule.min_value}%–${discountRule.max_value}% discount on ${scope}`;
    if (mode === 'fixed_percent') return `Fixed ${discountRule.fixed_value || 0}% discount on ${scope}`;
    return `Price override: ${fmt(discountRule.fixed_value)} on ${scope}`;
  };

  const buildSaveData = () => {
    let category_scope_json: number[] = [];
    let duration_scope_json: number[] = [];
    let discount_rules: any[] = [];

    if (form.campaign_mode !== 'message_only') {
      if (scopeType === 'all_products') {
        discount_rules = [{ ...discountRule }];
      } else if (scopeType === 'selected_categories') {
        category_scope_json = selectedCatIds;
        discount_rules = [{ ...discountRule }];
      } else {
        const validPairs = scopePairs.filter((p: any) => p.category_id && p.duration_id);
        category_scope_json = Array.from(new Set<number>(validPairs.map((p: any) => Number(p.category_id))));
        duration_scope_json = Array.from(new Set<number>(validPairs.map((p: any) => Number(p.duration_id))));
        discount_rules = validPairs.map((p: any) => ({ ...discountRule, applies_to_category_id: p.category_id, applies_to_duration_id: p.duration_id }));
        if (discount_rules.length === 0) discount_rules = [{ ...discountRule }];
      }
    }

    const hasChannelTarget = form.targets.some((t: any) => t.target_type === 'channels');
    return { ...form, category_scope_json, duration_scope_json, discount_rules,
      send_to_channels: hasChannelTarget && form.channel_targets.length > 0,
      channel_targets: hasChannelTarget ? form.channel_targets : [],
      start_at: fromLocalInput(form.start_at, form.timezone),
      expire_at: fromLocalInput(form.expire_at, form.timezone) };
  };

  const handleSave = () => {
    if (!form.name.trim()) { alert('Campaign name is required'); return; }
    if (scopeType === 'selected_categories' && selectedCatIds.length === 0 && form.campaign_mode !== 'message_only') {
      alert('Please select at least one category, or change Scope Type to "All Products".');
      return;
    }
    if (scopeType === 'selected_pairs' && !scopePairs.some((p: any) => p.category_id && p.duration_id) && form.campaign_mode !== 'message_only') {
      alert('Please add at least one valid category + duration pair.');
      return;
    }
    onSave(buildSaveData());
  };

  const isEdit = !!form.id;

  return (
    <div className="cp-screen">
      <div className="cp-screen-hdr">
        <BackButton onBack={onCancel} label="Cancel" />
        <h3 className="cp-screen-title">{isEdit ? 'Edit Campaign' : 'New Campaign'}</h3>
        <button className="btn-primary-sm" onClick={handleSave}><Icon name="send" /> Save</button>
      </div>

      <div className="cp-editor-body">

        {/* 1. BASIC INFO */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="flag" /> Basic Info</h4>
          <div className="cp-field"><label>Campaign Name</label><input value={form.name} onChange={e => upd('name', e.target.value)} placeholder="e.g. Night Flash Sale" /></div>
          <div className="cp-field"><label>Description</label><textarea value={form.description} onChange={e => upd('description', e.target.value)} rows={2} placeholder="Brief campaign description..." /></div>
          <div className="cp-field">
            <label>Campaign Mode</label>
            <select value={form.campaign_mode} onChange={e => upd('campaign_mode', e.target.value)}>
              <option value="random_discount">Random Discount — random % off between min and max</option>
              <option value="fixed_plan">Fixed Discount Plan — link a saved discount plan</option>
              <option value="message_only">Message Only — no discount, just a broadcast</option>
            </select>
          </div>
          {form.campaign_mode === 'fixed_plan' && (
            <div className="cp-field">
              <label>Linked Discount Plan</label>
              <select value={form.linked_discount_plan_id || ''} onChange={e => upd('linked_discount_plan_id', e.target.value ? Number(e.target.value) : null)}>
                <option value="">— Select Plan —</option>
                {discountPlans.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          )}
        </div>

        {/* 2. DISCOUNT + SCOPE */}
        {form.campaign_mode !== 'message_only' && (
          <div className="cp-section">
            <h4 className="cp-section-title"><Icon name="zap" /> Discount &amp; Scope</h4>

            <div className="cp-scope-info-box" style={{ marginBottom: 14, background: 'var(--c-accent-surface)', borderColor: 'var(--c-accent)' }}>
              <span className="cp-scope-info-icon"><Icon name="info" /></span>
              <div>
                <div className="cp-scope-info-title" style={{ color: 'var(--c-accent-bright)' }}>Live Summary</div>
                <div className="cp-scope-info-text">{discountSummary()}</div>
              </div>
            </div>

            <div className="cp-field">
              <label>Discount Type</label>
              <select value={discountRule.discount_mode} onChange={e => updDR('discount_mode', e.target.value)}>
                <option value="random_percent">Random % — random discount between min and max</option>
                <option value="fixed_percent">Fixed % — exact percentage discount</option>
                <option value="fixed_price_override">Price Override — set a fixed price</option>
              </select>
            </div>

            {discountRule.discount_mode === 'random_percent' && (
              <div className="cp-row-2">
                <div className="cp-field"><label>Min %</label><input type="number" min="0" max="100" value={discountRule.min_value ?? ''} onChange={e => updDR('min_value', e.target.value ? Number(e.target.value) : null)} placeholder="5" /></div>
                <div className="cp-field"><label>Max %</label><input type="number" min="0" max="100" value={discountRule.max_value ?? ''} onChange={e => updDR('max_value', e.target.value ? Number(e.target.value) : null)} placeholder="30" /></div>
              </div>
            )}
            {discountRule.discount_mode === 'fixed_percent' && (
              <div className="cp-field"><label>Discount %</label><input type="number" min="0" max="100" value={discountRule.fixed_value ?? ''} onChange={e => updDR('fixed_value', e.target.value ? Number(e.target.value) : null)} placeholder="e.g. 20" /></div>
            )}
            {discountRule.discount_mode === 'fixed_price_override' && (
              <div className="cp-field"><label>Override Price ({cfg.currency})</label><input type="number" min="0" value={discountRule.fixed_value ?? ''} onChange={e => updDR('fixed_value', e.target.value ? Number(e.target.value) : null)} placeholder="e.g. 99" /></div>
            )}

            <div style={{ height: 1, background: 'var(--border)', margin: '14px 0' }} />

            <div className="cp-field">
              <label>Applies To</label>
              <select value={scopeType} onChange={e => changeScopeType(e.target.value as ScopeType)}>
                <option value="all_products">All Products — store-wide discount</option>
                <option value="selected_categories">Selected Categories — all durations in chosen categories</option>
                <option value="selected_pairs">Exact Pairs — specific category + duration combinations</option>
              </select>
            </div>

            {scopeType === 'all_products' && (
              <div className="cp-scope-info-box">
                <span className="cp-scope-info-icon"><Icon name="info" /></span>
                <div>
                  <div className="cp-scope-info-title">Store-wide</div>
                  <div className="cp-scope-info-text">Discount applies to every visible product in your store.</div>
                </div>
              </div>
            )}

            {scopeType === 'selected_categories' && (
              <div>
                <div className="cp-chip-grid">
                  {categories.map((c: any) => (
                    <button key={c.id} type="button"
                      className={`cp-scope-chip${selectedCatIds.includes(c.id) ? ' active' : ''}`}
                      onClick={() => toggleCat(c.id)}>
                      {c.name}
                    </button>
                  ))}
                  {categories.length === 0 && <span className="cp-hint">No categories available</span>}
                </div>
                {selectedCatIds.length === 0 && <p className="cp-hint" style={{ marginTop: 6, color: 'var(--c-amber)' }}>Select at least one category</p>}
                {selectedCatIds.length > 0 && <p className="cp-hint" style={{ marginTop: 6, color: 'var(--c-emerald)' }}>{selectedCatIds.length} category selected · {durations.filter((d: any) => selectedCatIds.includes(d.category_id)).length} durations affected</p>}
              </div>
            )}

            {scopeType === 'selected_pairs' && (
              <div>
                {scopePairs.map((pair: any, i: number) => {
                  const isDup = scopePairs.some((p: any, j: number) => j !== i && p.category_id === pair.category_id && p.duration_id === pair.duration_id && p.category_id !== 0);
                  return (
                    <div key={i} className="cp-pair-row" style={isDup ? { borderColor: 'var(--c-rose)' } : undefined}>
                      <div className="cp-field" style={{ flex: 1, minWidth: 0 }}>
                        <label style={{ fontSize: '.7rem' }}>Category</label>
                        <select value={pair.category_id || ''} onChange={e => updPair(i, 'category_id', Number(e.target.value))}>
                          <option value="">— Category —</option>
                          {categories.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                      </div>
                      <div className="cp-field" style={{ flex: 1, minWidth: 0 }}>
                        <label style={{ fontSize: '.7rem' }}>Duration</label>
                        <select value={pair.duration_id || ''} onChange={e => updPair(i, 'duration_id', Number(e.target.value))} disabled={!pair.category_id}>
                          <option value="">— Duration —</option>
                          {durationsForCategory(pair.category_id).map((d: any) => <option key={d.id} value={d.id}>{d.name} — {fmt(d.price)}</option>)}
                        </select>
                      </div>
                      {scopePairs.length > 1 && <button type="button" className="btn-danger-sm" style={{ alignSelf: 'flex-end', marginBottom: '5px' }} onClick={() => removePair(i)}>×</button>}
                    </div>
                  );
                })}
                <button type="button" className="btn-outline-sm" style={{ marginTop: 6 }} onClick={addPair}><Icon name="plus" /> Add Pair</button>
              </div>
            )}

            {/* Discount preview table */}
            {affectedProducts.length > 0 && form.campaign_mode !== 'message_only' && (
              <div style={{ marginTop: 14 }}>
                <p className="cp-section-sub" style={{ marginBottom: 8 }}>Price preview ({affectedProducts.length} product{affectedProducts.length !== 1 ? 's' : ''} affected):</p>
                <div className="cp-tbl-wrap" style={{ borderRadius: 8, border: '1px solid var(--border)' }}>
                  <table className="cp-tbl">
                    <thead><tr><th>Category</th><th>Duration</th><th>Original</th><th>After Discount</th></tr></thead>
                    <tbody>
                      {affectedProducts.slice(0, 12).map((p: any, i: number) => (
                        <tr key={i}>
                          <td>{p.category_name}</td>
                          <td>{p.duration_name}</td>
                          <td>{fmt(p.original_price)}</td>
                          <td className="accent">{fmt(calcDiscounted(p.original_price))}</td>
                        </tr>
                      ))}
                      {affectedProducts.length > 12 && <tr><td colSpan={4} className="muted" style={{ textAlign: 'center', fontSize: '.72rem' }}>+{affectedProducts.length - 12} more products</td></tr>}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 3. SCHEDULE */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="calendar" /> Schedule</h4>
          <div className="cp-field">
            <label>Timezone</label>
            <select value={form.timezone} onChange={e => upd('timezone', e.target.value)}>
              {COMMON_TIMEZONES.map(tz => <option key={tz} value={tz}>{tz}</option>)}
            </select>
          </div>
          <div className="cp-row-2">
            <div className="cp-field"><label>Start Time</label><input type="datetime-local" value={form.start_at} onChange={e => upd('start_at', e.target.value)} /></div>
            <div className="cp-field"><label>Expire Time</label><input type="datetime-local" value={form.expire_at} onChange={e => upd('expire_at', e.target.value)} /></div>
          </div>
          <div className="cp-field">
            <label>Repeat</label>
            <select value={form.repeat_mode} onChange={e => upd('repeat_mode', e.target.value)}>
              <option value="once">Once — run once then stop</option>
              <option value="daily">Daily — repeat every day</option>
              <option value="weekly">Weekly — repeat every week</option>
              <option value="monthly">Monthly — repeat every month</option>
            </select>
          </div>
        </div>

        {/* 4. MESSAGE TEMPLATES */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="file" /> Message Templates</h4>
          <div className="cp-field">
            <label>Promo Start Template <span className="cp-hint" style={{ fontStyle: 'normal' }}>— sent when campaign begins</span></label>
            <select value={form.promo_template_id || ''} onChange={e => upd('promo_template_id', e.target.value ? Number(e.target.value) : null)}>
              <option value="">— None —</option>
              {templates.filter((t: Template) => t.template_type === 'promo_start').map((t: Template) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div className="cp-field">
            <label>Promo Expiry Template <span className="cp-hint" style={{ fontStyle: 'normal' }}>— sent when campaign ends</span></label>
            <select value={form.expiry_template_id || ''} onChange={e => upd('expiry_template_id', e.target.value ? Number(e.target.value) : null)}>
              <option value="">— None —</option>
              {templates.filter((t: Template) => t.template_type === 'promo_expiry').map((t: Template) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
        </div>

        {/* 5. AUDIENCE TARGETS */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="target" /> Audience Targets</h4>
          {form.targets.map((t: any, i: number) => (
            <div key={i} className="cp-pair-row" style={{ alignItems: 'flex-end', marginBottom: 8 }}>
              <div className="cp-field" style={{ flex: 1, minWidth: 0 }}>
                <label style={{ fontSize: '.7rem' }}>Target Type</label>
                <select value={t.target_type} onChange={e => updTarget(i, 'target_type', e.target.value)}>
                  {Object.entries(TARGET_MAP).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div className="cp-field" style={{ flex: 1, minWidth: 0 }}>
                <label style={{ fontSize: '.7rem' }}>Message Kind</label>
                <select value={t.message_kind} onChange={e => updTarget(i, 'message_kind', e.target.value)}>
                  <option value="promo_start">Promo Start</option>
                  <option value="promo_expiry">Promo Expiry</option>
                </select>
              </div>
              {form.targets.length > 1 && <button type="button" className="btn-danger-sm" onClick={() => upd('targets', form.targets.filter((_: any, j: number) => j !== i))}>×</button>}
            </div>
          ))}
          <button type="button" className="btn-outline-sm" style={{ marginTop: 4 }} onClick={() => upd('targets', [...form.targets, { target_type: 'all_users', target_value: '', message_kind: 'promo_start' }])}>
            <Icon name="plus" /> Add Target
          </button>

          {form.targets.some((t: any) => t.target_type === 'channels') && (
            <div className="cp-channel-selector" style={{ marginTop: 12, padding: '12px 14px', background: 'var(--bg-1)', border: '1px solid var(--border)', borderRadius: 'var(--r-md)' }}>
              <label style={{ fontSize: '.72rem', fontWeight: 600, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '.04em', display: 'block', marginBottom: 6 }}>
                <Icon name="send" /> Select Channels
              </label>
              {activeChannels.length === 0 ? (
                <div style={{ fontSize: '.78rem', color: 'var(--c-rose)', padding: '8px 0' }}>
                  No validated channels available. Configure channels in the Channels page first.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {activeChannels.map((ch: any) => {
                    const selected = form.channel_targets.includes(ch.id);
                    return (
                      <label key={ch.id} style={{
                        display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px',
                        background: selected ? 'var(--c-accent-surface)' : 'var(--bg-2)',
                        border: `1px solid ${selected ? 'var(--c-accent)' : 'var(--border)'}`,
                        borderRadius: 'var(--r-sm)', cursor: 'pointer', transition: 'all .15s',
                        fontSize: '.8rem', color: 'var(--text-1)',
                      }}>
                        <input type="checkbox" checked={selected}
                          onChange={() => upd('channel_targets', selected
                            ? form.channel_targets.filter((id: number) => id !== ch.id)
                            : [...form.channel_targets, ch.id]
                          )}
                          style={{ accentColor: 'var(--c-accent)' }}
                        />
                        <span style={{ fontWeight: 600 }}>{ch.resolved_title || ch.label}</span>
                        {ch.resolved_username && <span style={{ color: 'var(--text-3)', fontSize: '.72rem' }}>@{ch.resolved_username}</span>}
                      </label>
                    );
                  })}
                  {form.channel_targets.length === 0 && (
                    <div style={{ fontSize: '.72rem', color: 'var(--c-amber)', padding: '4px 0' }}>
                      Select at least one channel for channel delivery
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

      </div>

      <div className="cp-editor-footer">
        <button className="btn-ghost-sm" onClick={onCancel}>Cancel</button>
        <button className="btn-primary-sm" onClick={handleSave}><Icon name="send" /> {isEdit ? 'Save Changes' : 'Create Campaign'}</button>
      </div>
    </div>
  );
}

// ── TEMPLATE FORM SCREEN ──────────────────────────────────────────────────

function TemplateFormScreen({ template, onSave, onCancel }: { template: Template | null; onSave: (d: any) => void; onCancel: () => void }) {
  const isNew = !template?.id;
  const [form, setForm] = useState(() => ({
    id: template?.id || 0,
    name: template?.name || '',
    template_type: template?.template_type || 'promo_start',
    body_text: template?.body_text || '',
    parse_mode: template?.parse_mode || 'HTML',
    inline_buttons_json: template?.inline_buttons_json || '',
    custom_emoji_json: template?.custom_emoji_json || '',
    is_active: template?.is_active !== false,
  }));
  const [btnMode, setBtnMode] = useState<'visual' | 'json'>('visual');
  const [buttons, setButtons] = useState<any[]>(() => {
    try {
      const p = JSON.parse(template?.inline_buttons_json || '[]');
      return Array.isArray(p) ? p.map(normalizeBtn) : [];
    } catch { return []; }
  });
  const [btnAdvOpen, setBtnAdvOpen] = useState<Record<string, boolean>>({});
  const [showVarHelp, setShowVarHelp] = useState(false);
  const [previewMode, setPreviewMode] = useState<'user' | 'channel'>('user');
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const upd = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const insertVar = (v: string) => {
    const el = bodyRef.current;
    if (!el) { upd('body_text', form.body_text + v); return; }
    const s = el.selectionStart; const e = el.selectionEnd;
    const newText = form.body_text.substring(0, s) + v + form.body_text.substring(e);
    upd('body_text', newText);
    setTimeout(() => { el.focus(); el.setSelectionRange(s + v.length, s + v.length); }, 10);
  };

  const addBtn = () => setButtons(b => [...b, normalizeBtn({ text: '', url: '{deep_link}', style: 'primary', icon_custom_emoji_id: '', row: 1, enabled: true })]);
  const updBtn = (i: number, k: string, v: any) => setButtons(b => { const nb = [...b]; nb[i] = { ...nb[i], [k]: v }; return nb; });
  const rmBtn  = (i: number) => setButtons(b => b.filter((_, j) => j !== i));
  const moveBtn = (i: number, dir: -1 | 1) => setButtons(b => {
    const nb = [...b]; const j = i + dir;
    if (j < 0 || j >= nb.length) return nb;
    [nb[i], nb[j]] = [nb[j], nb[i]]; return nb;
  });

  const getSample = (key: string) => (SAMPLE_DATA[form.template_type] ?? SAMPLE_DATA.general)[key] ?? key;
  const renderPreview = () => {
    let text = form.body_text;
    VARS.forEach(({ key }) => { text = text.replaceAll(key, getSample(key)); });
    return text;
  };

  const useRecommended = () => {
    const rec = RECOMMENDED_BODIES[form.template_type];
    if (!rec) return;
    if (form.body_text && !window.confirm('Replace current message body with the recommended template?')) return;
    upd('body_text', rec.body);
    if (rec.buttons && buttons.length === 0) setButtons(rec.buttons.map(normalizeBtn));
  };

  const handleSave = () => {
    if (!form.name.trim()) { alert('Template name is required'); return; }
    onSave({ ...form, inline_buttons_json: buttons.length ? JSON.stringify(buttons) : null });
  };

  const isStart  = form.template_type === 'promo_start';
  const isExpiry = form.template_type === 'promo_expiry';

  const activeButtons = buttons.filter(b => b.enabled !== false);
  const buttonRowMap: Record<number, any[]> = {};
  activeButtons.forEach(b => { const r = b.row || 1; (buttonRowMap[r] = buttonRowMap[r] || []).push(b); });

  return (
    <div className="cp-screen">
      <div className="cp-screen-hdr">
        <BackButton onBack={onCancel} label="Cancel" />
        <h3 className="cp-screen-title">{isNew ? 'New Template' : 'Edit Template'}</h3>
        <button className="btn-primary-sm" onClick={handleSave}><Icon name="send" /> Save</button>
      </div>

      <div className="cp-editor-body">

        {/* 1. BASIC INFO */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="file" /> Basic Info</h4>
          <div className="cp-field">
            <label>Template Name</label>
            <input value={form.name} onChange={e => upd('name', e.target.value)} placeholder="e.g. Night Offer Start" />
          </div>
          <div className="cp-field">
            <label>Type</label>
            <div className="cp-tpl-type-cards">
              {([
                { value: 'promo_start', label: '📢 Promo Start', sub: 'Sent when campaign begins' },
                { value: 'promo_expiry', label: '⏰ Promo Expiry', sub: 'Sent when campaign ends' },
              ] as const).map(opt => (
                <button key={opt.value} type="button"
                  className={`cp-tpl-type-card${form.template_type === opt.value ? ' active' : ''}`}
                  onClick={() => upd('template_type', opt.value)}>
                  <div className="cp-tpl-type-card-label">{opt.label}</div>
                  <div className="cp-tpl-type-card-sub">{opt.sub}</div>
                </button>
              ))}
            </div>
            <span className="cp-hint">
              {isStart  && 'Sent to users when the discount campaign kicks off and prices drop.'}
              {isExpiry && 'Sent to users when the campaign ends and prices return to normal.'}
              {!isStart && !isExpiry && 'Used for manual broadcast messages not tied to a campaign schedule.'}
            </span>
          </div>
        </div>

        {/* 2. RECOMMENDED TEMPLATE (context-aware) */}
        {(isStart || isExpiry) && (
          <div className="cp-section cp-tpl-rec-section">
            <div className="cp-tpl-rec-header">
              <div>
                <h4 className="cp-section-title" style={{ marginBottom: 3 }}>
                  {isStart ? '📋 Promo Start Template' : '📋 Promo Expiry Template'}
                </h4>
                <p className="cp-section-sub">Ready-to-use message structure — click Load to apply.</p>
              </div>
              <button className="btn-ghost-sm cp-tpl-rec-load-btn" onClick={useRecommended}>
                <Icon name="copy" /> Load Template
              </button>
            </div>
            <pre className="cp-tpl-rec-pre">{RECOMMENDED_BODIES[form.template_type]?.body ?? ''}</pre>
          </div>
        )}

        {/* 3. MESSAGE BODY + VARIABLES */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="edit" /> Message Body</h4>
          <div className="cp-field">
            <label>Body (HTML supported: b, i, u, s, code, pre)</label>
            <textarea ref={bodyRef} value={form.body_text} onChange={e => upd('body_text', e.target.value)}
              rows={10} placeholder="Write your promo message here..." className="cp-textarea-lg" />
          </div>

          <div className="cp-var-picker">
            <div className="cp-var-picker-head"><span className="cp-var-label">Tap a variable to insert at cursor:</span></div>
            <div className="cp-var-group">
              <div className="cp-var-group-label">Pricing</div>
              <div className="cp-var-chips">
                {['{original_price}','{discounted_price}','{current_price}','{discount_percent}'].map(k =>
                  <button key={k} className="cp-var-chip" onClick={() => insertVar(k)}>{k}</button>)}
              </div>
            </div>
            <div className="cp-var-group">
              <div className="cp-var-group-label">Campaign</div>
              <div className="cp-var-chips">
                {['{campaign_name}','{starts_at}','{expires_at}'].map(k =>
                  <button key={k} className="cp-var-chip" onClick={() => insertVar(k)}>{k}</button>)}
              </div>
            </div>
            <div className="cp-var-group">
              <div className="cp-var-group-label">Product</div>
              <div className="cp-var-chips">
                {['{category_name}','{duration_name}'].map(k =>
                  <button key={k} className="cp-var-chip" onClick={() => insertVar(k)}>{k}</button>)}
              </div>
            </div>
            <div className="cp-var-group">
              <div className="cp-var-group-label">User &amp; Link</div>
              <div className="cp-var-chips">
                {['{user_name}','{deep_link}'].map(k =>
                  <button key={k} className="cp-var-chip" onClick={() => insertVar(k)}>{k}</button>)}
              </div>
            </div>
            <div className="cp-var-group">
              <div className="cp-var-group-label">Auto Blocks</div>
              <div className="cp-var-chips">
                <button className={`cp-var-chip cp-var-chip-block${isExpiry ? ' cp-var-chip-muted' : ''}`} onClick={() => insertVar('{product_discount_lines}')}>{'{product_discount_lines}'}</button>
                <button className={`cp-var-chip cp-var-chip-block${isStart ? ' cp-var-chip-muted' : ''}`} onClick={() => insertVar('{product_expiry_lines}')}>{'{product_expiry_lines}'}</button>
              </div>
              <p className="cp-hint" style={{ marginTop: 5 }}>
                {isStart  && 'Use {product_discount_lines} — auto-generates the full discounted product list.'}
                {isExpiry && 'Use {product_expiry_lines} — auto-generates the restored price list.'}
                {!isStart && !isExpiry && 'Auto-generate full product price lists at send time.'}
              </p>
            </div>
          </div>

          {/* Variable guide collapsible */}
          <div className="cp-var-help-wrap">
            <button className="cp-var-help-toggle" onClick={() => setShowVarHelp(v => !v)}>
              {showVarHelp ? 'Hide variable guide ▲' : 'How do variables work? ▼'}
            </button>
            {showVarHelp && (
              <div className="cp-var-help-panel">
                <div className="cp-var-help-title">Variable Reference</div>
                <div className="cp-var-help-grid">
                  {[
                    ['{original_price}',   'Normal store price before discount. Stays constant.'],
                    ['{discounted_price}',  'The campaign price during the sale.'],
                    ['{current_price}',     'Active price when message is sent. Same as discounted_price during promo, restored after.'],
                    ['{discount_percent}',  'The percentage off. e.g. 20 = 20% off.'],
                    ['{product_discount_lines}', 'Auto block: all products with discounted prices. Use in Promo Start.'],
                    ['{product_expiry_lines}',   'Auto block: all products with restored prices. Use in Promo Expiry.'],
                    ['{campaign_name}',    'Campaign title.'],
                    ['{user_name}',        'Recipient user name.'],
                    ['{deep_link}',        'Tracking link that opens the bot with campaign attribution.'],
                  ].map(([k, desc]) => (
                    <div key={k as string} className="cp-var-help-row">
                      <code className="cp-var-help-key">{k}</code>
                      <div className="cp-var-help-desc">{desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 4. LIVE PREVIEW (phone style) */}
        <div className="cp-section">
          <h4 className="cp-section-title">
            <Icon name="eye" /> Live Preview
            <span className="cp-section-badge" style={{ marginLeft: 8 }}>
              {isStart ? 'Promo Start' : isExpiry ? 'Promo Expiry' : 'General'}
            </span>
          </h4>
          {(isStart || isExpiry) && (
            <div className="cp-toggle-row" style={{ marginBottom: 10 }}>
              <button className={`cp-toggle-btn ${previewMode === 'user' ? 'active' : ''}`} onClick={() => setPreviewMode('user')}>User Preview</button>
              <button className={`cp-toggle-btn ${previewMode === 'channel' ? 'active' : ''}`} onClick={() => setPreviewMode('channel')}>Channel Preview</button>
            </div>
          )}
          <div className="cp-phone-preview">
            <div className="cp-phone-bubble">
              <div className="cp-phone-bubble-text" dangerouslySetInnerHTML={{
                __html: sanitizeHtml(
                  previewMode === 'channel' && (isStart || isExpiry)
                    ? stripEmojisForChannel(renderPreview())
                    : renderPreview()
                ).replace(/\n/g, '<br/>')
              }} />
            </div>
            {Object.keys(buttonRowMap).length > 0 && (
              <div className="cp-phone-buttons">
                {Object.entries(buttonRowMap).sort(([a],[z]) => +a - +z).map(([rn, row]) => (
                  <div key={rn} className="cp-phone-btn-row">
                    {row.map((b, i) => (
                      <div key={i} className={`cp-phone-btn${phoneBtnClass(b.style)}`}>
                        {getButtonPreviewText(b)}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="cp-tg-preview-meta">
            {previewMode === 'channel' && (isStart || isExpiry)
              ? 'Channel Preview · No emojis · Direct send · Formatting preserved'
              : `Sample · campaign=Sunday Discount · discount=20% · ${isStart ? `price=${cfg.currency}8.00` : `price=${cfg.currency}10.00`}`}
          </div>
        </div>

        {/* 5. INLINE BUTTONS */}
        <div className="cp-section">
          <h4 className="cp-section-title"><Icon name="link" /> Inline Buttons</h4>

          <div className="cp-toggle-row">
            <button className={`cp-toggle-btn ${btnMode === 'visual' ? 'active' : ''}`} onClick={() => setBtnMode('visual')}>Visual</button>
            <button className={`cp-toggle-btn ${btnMode === 'json' ? 'active' : ''}`} onClick={() => {
              setBtnMode('json');
              upd('inline_buttons_json', buttons.length ? JSON.stringify(buttons, null, 2) : '[]');
            }}>JSON</button>
          </div>

          {btnMode === 'visual' ? (
            <div className="ibe-wrap">
              {buttons.length === 0 && (
                <div className="ibe-empty">
                  <span>No buttons configured</span>
                  <span className="ibe-empty-hint">Add link buttons that appear below the message</span>
                </div>
              )}
              {buttons.map((b, i) => {
                const isAdvOpen = !!btnAdvOpen[b.id];
                const urlInvalid = b.url && b.url !== '{deep_link}' && !b.url.startsWith('http') && !b.url.startsWith('tg://');
                return (
                  <div key={b.id || i} className={`ibe-row${b.enabled === false ? ' cp-btn-off' : ''}`}>
                    <div className="ibe-row-head">
                      <span className="ibe-row-num">Button {i + 1}</span>
                      <div className="ibe-row-actions">
                        {buttons.length > 1 && (<>
                          <button type="button" className="ibe-move" disabled={i === 0} onClick={() => moveBtn(i, -1)}>↑</button>
                          <button type="button" className="ibe-move" disabled={i === buttons.length - 1} onClick={() => moveBtn(i, 1)}>↓</button>
                        </>)}
                        <label className="cp-btn-on-lbl" title="Enable/disable this button">
                          <input type="checkbox" checked={b.enabled !== false} onChange={e => updBtn(i, 'enabled', e.target.checked)} />
                          <span>On</span>
                        </label>
                        <button type="button" className="ibe-remove" onClick={() => rmBtn(i)}>×</button>
                      </div>
                    </div>
                    <div className="ibe-fields">
                      <div className="ibe-field">
                        <label className="ibe-label">Name</label>
                        <input className="bm-inp" value={b.text} onChange={e => updBtn(i, 'text', e.target.value)} placeholder="Buy Now" />
                      </div>
                      <div className="ibe-field">
                        <label className="ibe-label">URL</label>
                        <div className="cp-url-grp">
                          <input className={`bm-inp${urlInvalid ? ' err' : ''}`} value={b.url || ''} onChange={e => updBtn(i, 'url', e.target.value)} placeholder="https://... or {deep_link}" />
                          {b.url !== '{deep_link}' && (
                            <button type="button" className="cp-dl-pill" onClick={() => updBtn(i, 'url', '{deep_link}')}>Deep Link</button>
                          )}
                        </div>
                        {urlInvalid && <span className="bm-err">Must start with https:// or tg://</span>}
                      </div>
                    </div>
                    <div className="ibe-extras">
                      <div className="ibe-field ibe-field-style">
                        <label className="ibe-label">Color
                          <span className="cp-lbl-hint"> · Bot API 9.4 — sent to Telegram</span>
                        </label>
                        <div className="ibe-style-row">
                          {CB_STYLE_OPTIONS.map(o => (
                            <button key={o.value} type="button"
                              className={`ibe-style-opt${b.style === o.value ? ' active' : ''}`}
                              style={b.style === o.value ? { borderColor: o.color, color: o.color } : {}}
                              onClick={() => updBtn(i, 'style', o.value)}>
                              {o.label}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="ibe-field ibe-field-emoji">
                        <label className="ibe-label">Button Icon
                          <span className="cp-lbl-hint"> · Custom emoji ID sent as button icon</span>
                        </label>
                        <input className="bm-inp mono" inputMode="numeric"
                          value={b.icon_custom_emoji_id || ''}
                          onChange={e => updBtn(i, 'icon_custom_emoji_id', e.target.value.replace(/\D/g, ''))}
                          placeholder="Custom Emoji ID (empty = no icon)" />
                        {b.icon_custom_emoji_id && (
                          <span className="cp-lbl-hint" style={{ marginTop: 4 }}>
                            icon_custom_emoji_id: {b.icon_custom_emoji_id}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="ibe-preview-row">
                      <span className="ibe-preview-label">Delivery:</span>
                      <span className={`ibe-preview-chip${btnStyleClass(b.style)}`}>
                        {getButtonPreviewText(b)} ↗
                      </span>
                      {b.icon_custom_emoji_id && (
                        <span className="cp-emoji-id-badge" title={`icon_custom_emoji_id: ${b.icon_custom_emoji_id}`}>
                          icon·{b.icon_custom_emoji_id.slice(0, 8)}
                        </span>
                      )}
                      {b.style && <span className="cp-style-badge" style={{ color: CB_STYLE_OPTIONS.find(o => o.value === b.style)?.color }}>{b.style}</span>}
                      <button type="button" className="cp-adv-toggle"
                        onClick={() => setBtnAdvOpen(o => ({ ...o, [b.id]: !o[b.id] }))}>
                        Advanced {isAdvOpen ? '▲' : '▼'}
                      </button>
                    </div>
                    {isAdvOpen && (
                      <div className="cp-btn-adv">
                        <div className="cp-adv-grid">
                          <div className="ibe-field">
                            <label className="ibe-label">Row <span className="cp-lbl-hint">same row = side-by-side in Telegram</span></label>
                            <input type="number" className="bm-inp" min={1} max={10} value={b.row || 1}
                              onChange={e => updBtn(i, 'row', Math.max(1, parseInt(e.target.value) || 1))}
                              style={{ width: 64 }} />
                          </div>
                        </div>
                        <div className="cp-payload-preview">
                          <span className="cp-payload-label">Bot API payload sent to Telegram:</span>
                          <code className="cp-payload-code">
                            {[
                              `text="${getButtonTelegramText(b)}"`,
                              `url="${(b.url || '').slice(0, 45)}${(b.url || '').length > 45 ? '…' : ''}"`,
                              b.style ? `style="${b.style}"` : null,
                              b.icon_custom_emoji_id ? `icon_custom_emoji_id="${b.icon_custom_emoji_id}"` : null,
                            ].filter(Boolean).join('  ')}
                          </code>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              <div className="ibe-bottom">
                <button type="button" className="ibe-add" onClick={addBtn}>+ Add Button</button>
              </div>
            </div>
          ) : (
            <div className="cp-field">
              <label>Buttons JSON</label>
              <textarea className="mono" value={form.inline_buttons_json} onChange={e => {
                upd('inline_buttons_json', e.target.value);
                try {
                  const p = JSON.parse(e.target.value);
                  if (Array.isArray(p)) setButtons(p.map(normalizeBtn));
                } catch {}
              }} rows={8} placeholder='[{"text":"Buy Now","url":"{deep_link}","style":"primary","icon_custom_emoji_id":"","row":1,"enabled":true}]' />
              <span className="bm-hint">Switch back to Visual to use the builder. JSON syncs both ways.</span>
            </div>
          )}
        </div>

      </div>

      <div className="cp-editor-footer">
        <button className="btn-ghost-sm" onClick={onCancel}>Cancel</button>
        <button className="btn-primary-sm" onClick={handleSave}><Icon name="send" /> {isNew ? 'Create Template' : 'Save Changes'}</button>
      </div>
    </div>
  );
}

// ── MAIN CAMPAIGNS COMPONENT ──────────────────────────────────────────────

export default function Campaigns() {
  const [nav, setNav] = useState<Nav>({ screen: 'home' });
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  const [categories, setCategories] = useState<any[]>([]);
  const [durations, setDurations] = useState<any[]>([]);
  const [discountPlans, setDiscountPlans] = useState<any[]>([]);
  const [seeded, setSeeded] = useState(false);
  const [tplSeeded, setTplSeeded] = useState(false);

  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(''), 3500); };

  const load = useCallback(async () => {
    try {
      const [c, t, s, cats, durs, plans] = await Promise.all([
        apiGet('/campaigns'), apiGet('/campaigns/templates?type=promo'), apiGet('/campaigns/stats'),
        apiGet('/categories'), apiGet('/durations'), apiGet('/discount-plans'),
      ]);
      setCampaigns(c); setTemplates(t); setStats(s);
      setCategories(cats); setDurations(durs); setDiscountPlans(plans);
      if (!seeded && c.length === 0 && t.length === 0) {
        setSeeded(true);
        try { await apiPost('/campaigns/seed-demo'); await load(); return; } catch {}
      }
      if (!tplSeeded) {
        setTplSeeded(true);
        const hasDefaults = (t as Template[]).some(tp => tp.name === 'Default Promo Start' || tp.name === 'Default Promo Expiry');
        if (!hasDefaults) {
          try { await apiPost('/campaigns/seed-default-templates'); const fresh = await apiGet('/campaigns/templates?type=promo'); setTemplates(fresh); } catch {}
        }
      }
    } catch { flash('Failed to load campaign data'); }
    setLoading(false);
  }, [seeded, tplSeeded]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="page-loader"><div className="loader-spinner" /><span className="loader-text">Loading campaigns…</span></div>;

  return (
    <div className="cp-page">
      {msg && <div className="toast-msg">{msg}</div>}

      {nav.screen === 'home' && (
        <HomeScreen
          nav={nav} setNav={setNav}
          campaigns={campaigns} templates={templates} stats={stats}
          categories={categories} durations={durations} discountPlans={discountPlans}
          onFlash={flash} load={load}
        />
      )}

      {nav.screen === 'detail' && (
        <CampaignDetailScreen
          campaignId={nav.campaignId}
          setNav={setNav}
          categories={categories}
          templates={templates}
          onFlash={flash}
          load={load}
        />
      )}

      {nav.screen === 'deep-link-detail' && (
        <DeepLinkDetailScreen
          linkId={nav.linkId}
          campaignName={nav.campaignName}
          fromCampaignId={nav.fromCampaignId}
          setNav={setNav}
        />
      )}

      {nav.screen === 'analytics' && (
        <AnalyticsScreen
          campaignId={nav.campaignId}
          campaignName={nav.campaignName}
          campaigns={campaigns}
          setNav={setNav}
        />
      )}

      {nav.screen === 'logs' && (
        <LogsScreen
          campaignId={nav.campaignId}
          campaignName={nav.campaignName}
          campaigns={campaigns}
          setNav={setNav}
        />
      )}

      {nav.screen === 'campaign-form' && (
        <CampaignFormScreen
          campaign={nav.campaign || {
            id: 0, name: '', description: '', status: 'draft', campaign_mode: 'random_discount',
            linked_discount_plan_id: null, category_scope_json: '[]', duration_scope_json: '[]',
            repeat_mode: 'once', timezone: 'Asia/Kolkata', start_at: '', expire_at: '',
            next_run_at: null, next_expire_at: null, is_enabled: false,
            promo_template_id: null, expiry_template_id: null, send_to_users: true, send_to_channels: false,
            created_at: '', discount_rules: [{ discount_mode: 'random_percent', min_value: 5, max_value: 30 }],
            targets: [{ target_type: 'all_users', target_value: '', message_kind: 'promo_start' }],
          }}
          templates={templates}
          categories={categories}
          durations={durations}
          discountPlans={discountPlans}
          onSave={async (d: any) => {
            try {
              if (d.id) await apiPut(`/campaigns/${d.id}`, d);
              else await apiPost('/campaigns', d);
              flash(d.id ? 'Campaign updated' : 'Campaign created');
              setNav({ screen: 'home' });
              load();
            } catch (e: any) { flash(e?.message || 'Save failed'); }
          }}
          onCancel={() => setNav({ screen: 'home' })}
        />
      )}

      {nav.screen === 'template-form' && (
        <TemplateFormScreen
          template={nav.template}
          onSave={async (d: any) => {
            try {
              if (d.id) await apiPut(`/campaigns/templates/${d.id}`, d);
              else await apiPost('/campaigns/templates', d);
              flash(d.id ? 'Template updated' : 'Template created');
              setNav({ screen: 'home' });
              load();
            } catch { flash('Save failed'); }
          }}
          onCancel={() => setNav({ screen: 'home' })}
        />
      )}
    </div>
  );
}
