#!/usr/bin/env bash

echo "--- Starting Telegram bot (background) ---"
BOT_WEBHOOK_MODE=webhook python -m bot.main &
BOT_PID=$!

echo "--- Starting admin server ---"
NODE_ENV=production ./node_modules/.bin/tsx server/index.ts
STATUS=$?

# Server exited — clean up bot
echo "--- Server exited ($STATUS), stopping bot ---"
kill $BOT_PID 2>/dev/null
exit $STATUS
