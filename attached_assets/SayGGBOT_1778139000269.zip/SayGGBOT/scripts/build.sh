#!/usr/bin/env bash
set -e

echo "--- [1/3] Installing Node.js dependencies ---"
npm install

echo "--- [2/3] Installing Python dependencies ---"
pip install -r requirements.txt

echo "--- [3/3] Building frontend ---"
npm run build:client

echo "--- Build complete ---"
